//! The compiled contract's ABI and the campaign's named actors. Together
//! they turn the model's string-typed calls into exact calldata.

use std::collections::{BTreeMap, BTreeSet};
use std::str::FromStr;

use alloy_dyn_abi::{DynSolType, DynSolValue, JsonAbiExt, Specifier};
use alloy_json_abi::{Function, JsonAbi, StateMutability};
use alloy_primitives::{Address, B256, Bytes, FixedBytes, I256, U256, keccak256};
use serde_json::Value;

use crate::plan::{FuzzActor, ProtocolContract};

pub(crate) struct ContractAbi(JsonAbi);

impl ContractAbi {
    pub fn parse(json: &str) -> Result<Self, String> {
        let abi: JsonAbi = serde_json::from_str(json)
            .map_err(|e| format!("abi must be a JSON array string: {e}"))?;
        if abi.functions().next().is_none() {
            return Err("ABI contains no callable functions".into());
        }
        Ok(Self(abi))
    }

    pub fn functions(&self) -> impl Iterator<Item = &Function> {
        self.0.functions()
    }

    pub fn inner(&self) -> &JsonAbi {
        &self.0
    }

    pub fn function(&self, signature: &str) -> Result<&Function, String> {
        self.0
            .functions()
            .find(|function| function.signature() == signature)
            .ok_or_else(|| format!("function `{signature}` is not in the ABI"))
    }

    pub fn read_only(function: &Function) -> bool {
        matches!(
            function.state_mutability,
            StateMutability::View | StateMutability::Pure
        )
    }

    /// Canonical signatures of every state-changing function.
    pub fn writable(&self) -> BTreeSet<String> {
        self.0
            .functions()
            .filter(|function| !Self::read_only(function))
            .map(Function::signature)
            .collect()
    }

    /// ABI-encode `signature(arguments)`. Each argument is a string; arrays
    /// and tuples are JSON text; `$name` resolves to that actor's address.
    pub fn encode(
        &self,
        actors: &Actors,
        signature: &str,
        arguments: &[String],
    ) -> Result<Bytes, String> {
        let function = self.function(signature)?;
        if function.inputs.len() != arguments.len() {
            return Err(format!(
                "`{signature}` takes {} arguments, got {}",
                function.inputs.len(),
                arguments.len()
            ));
        }
        let values = function
            .inputs
            .iter()
            .zip(arguments)
            .map(|(parameter, text)| {
                let ty = parameter.resolve().map_err(|e| e.to_string())?;
                let value = match ty {
                    DynSolType::Array(_) | DynSolType::FixedArray(..) | DynSolType::Tuple(_) => {
                        serde_json::from_str(text)
                            .map_err(|e| format!("array/tuple argument must be JSON text: {e}"))?
                    }
                    _ => Value::String(text.clone()),
                };
                actors.to_sol(&ty, &value)
            })
            .collect::<Result<Vec<_>, _>>()?;
        function
            .abi_encode_input(&values)
            .map(Bytes::from)
            .map_err(|e| e.to_string())
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct Actor {
    pub address: Address,
    pub balance: U256,
}

/// Named actors with addresses derived from the artifact, so the same plan
/// against the same contract always uses the same addresses.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct Actors(BTreeMap<String, Actor>, BTreeMap<String, Address>);

impl Actors {
    pub fn derive(artifact: B256, inputs: &[FuzzActor]) -> Result<Self, String> {
        let mut actors = BTreeMap::new();
        for input in inputs {
            input.validate()?;
            if actors.contains_key(&input.name) {
                return Err(format!("actor `{}` is declared twice", input.name));
            }
            let address = match &input.address {
                Some(fixed) => Address::from_str(fixed.trim()).map_err(|_| {
                    format!("actor `{}` has an invalid address `{fixed}`", input.name)
                })?,
                None => {
                    let hash = keccak256([artifact.as_slice(), input.name.as_bytes()].concat());
                    Address::from_slice(&hash[12..])
                }
            };
            if actors
                .values()
                .any(|actor: &Actor| actor.address == address)
            {
                return Err(format!(
                    "actor `{}` reuses another actor's address {address:#x}",
                    input.name
                ));
            }
            actors.insert(
                input.name.clone(),
                Actor {
                    address,
                    balance: U256::from_str(&input.balance)
                        .map_err(|_| format!("actor `{}` has an invalid balance", input.name))?,
                },
            );
        }
        Ok(Self(actors, BTreeMap::new()))
    }

    /// Lets `@name` arguments resolve to the protocol's contract addresses.
    pub fn with_contracts(mut self, targets: &Targets) -> Self {
        self.1 = targets
            .0
            .iter()
            .map(|(name, (address, _))| (name.clone(), *address))
            .collect();
        self
    }

    pub fn get(&self, name: &str) -> Result<&Actor, String> {
        self.0
            .get(name)
            .ok_or_else(|| format!("unknown actor `{name}`"))
    }

    pub fn iter(&self) -> impl Iterator<Item = (&String, &Actor)> {
        self.0.iter()
    }

    pub fn len(&self) -> usize {
        self.0.len()
    }

    fn to_sol(&self, ty: &DynSolType, value: &Value) -> Result<DynSolValue, String> {
        let resolved = match value.as_str() {
            Some(text) if text.starts_with('$') => {
                Value::String(format!("{:#x}", self.get(&text[1..])?.address))
            }
            Some(text) if text.starts_with('@') => {
                let address = self
                    .1
                    .get(&text[1..])
                    .ok_or_else(|| format!("unknown contract `{text}`"))?;
                Value::String(format!("{address:#x}"))
            }
            _ => value.clone(),
        };
        let text = || {
            resolved
                .as_str()
                .ok_or_else(|| format!("expected a string for {ty}"))
        };
        let list = |expected: Option<usize>| -> Result<Vec<&Value>, String> {
            let items = resolved
                .as_array()
                .ok_or_else(|| format!("expected a JSON array for {ty}"))?;
            match expected {
                Some(len) if items.len() != len => {
                    Err(format!("{ty} needs {len} items, got {}", items.len()))
                }
                _ => Ok(items.iter().collect()),
            }
        };
        match ty {
            DynSolType::Bool => resolved
                .as_bool()
                .or_else(|| text().ok()?.parse().ok())
                .map(DynSolValue::Bool)
                .ok_or_else(|| "expected a boolean".into()),
            DynSolType::Int(bits) => Ok(DynSolValue::Int(
                text()?.parse::<I256>().map_err(|e| e.to_string())?,
                *bits,
            )),
            DynSolType::Uint(bits) => Ok(DynSolValue::Uint(
                U256::from_str(text()?).map_err(|e| e.to_string())?,
                *bits,
            )),
            DynSolType::Address => Ok(DynSolValue::Address(
                text()?.parse().map_err(|e| format!("{e}"))?,
            )),
            DynSolType::FixedBytes(len) => {
                let bytes = Bytes::from_str(text()?).map_err(|e| e.to_string())?;
                if bytes.len() != *len {
                    return Err(format!("bytes{len} needs {len} bytes, got {}", bytes.len()));
                }
                let mut word = [0u8; 32];
                word[..*len].copy_from_slice(&bytes);
                Ok(DynSolValue::FixedBytes(FixedBytes::from(word), *len))
            }
            DynSolType::Bytes => Ok(DynSolValue::Bytes(
                Bytes::from_str(text()?)
                    .map_err(|e| e.to_string())?
                    .to_vec(),
            )),
            DynSolType::String => Ok(DynSolValue::String(text()?.to_owned())),
            DynSolType::Array(inner) => Ok(DynSolValue::Array(
                list(None)?
                    .into_iter()
                    .map(|item| self.to_sol(inner, item))
                    .collect::<Result<_, _>>()?,
            )),
            DynSolType::FixedArray(inner, len) => Ok(DynSolValue::FixedArray(
                list(Some(*len))?
                    .into_iter()
                    .map(|item| self.to_sol(inner, item))
                    .collect::<Result<_, _>>()?,
            )),
            DynSolType::Tuple(types) => Ok(DynSolValue::Tuple(
                types
                    .iter()
                    .zip(list(Some(types.len()))?)
                    .map(|(ty, item)| self.to_sol(ty, item))
                    .collect::<Result<_, _>>()?,
            )),
            other => Err(format!("unsupported ABI type {other}")),
        }
    }
}

/// Every contract a plan may call, by name: the contract under test plus
/// the rest of its protocol, each already sitting in the world.
pub(crate) struct Targets(BTreeMap<String, (Address, ContractAbi)>, String);

impl Targets {
    pub fn new(
        name: &str,
        address: Address,
        abi: ContractAbi,
        protocol: &[ProtocolContract],
    ) -> Result<Self, String> {
        let mut targets = BTreeMap::from([(name.to_string(), (address, abi))]);
        for contract in protocol {
            let address = Address::from_str(contract.address.trim()).map_err(|_| {
                format!(
                    "protocol contract `{}` has an invalid address",
                    contract.name
                )
            })?;
            let abi = ContractAbi::parse(&contract.abi)
                .map_err(|e| format!("protocol contract `{}`: {e}", contract.name))?;
            if targets
                .insert(contract.name.clone(), (address, abi))
                .is_some()
            {
                return Err(format!(
                    "protocol contract `{}` is named twice",
                    contract.name
                ));
            }
        }
        Ok(Self(targets, name.to_string()))
    }

    /// The contract under test.
    pub fn primary(&self) -> &ContractAbi {
        &self.0[&self.1].1
    }

    /// Whether a call naming `contract` targets the contract under test.
    pub fn is_primary(&self, contract: Option<&str>) -> bool {
        contract.is_none_or(|name| name == self.1)
    }

    /// `contract` as the campaign stores it: `None` for the contract under
    /// test, whether the plan left it null or named it, so actions,
    /// properties, and findings compare equal either way.
    pub fn canonical(&self, contract: Option<&str>) -> Option<String> {
        contract
            .filter(|name| !self.is_primary(Some(name)))
            .map(str::to_owned)
    }

    /// Address and ABI of `contract`, or of the contract under test.
    pub fn get(&self, contract: Option<&str>) -> Result<(Address, &ContractAbi), String> {
        let name = contract.unwrap_or(&self.1);
        self.0
            .get(name)
            .map(|(address, abi)| (*address, abi))
            .ok_or_else(|| format!("unknown contract `{name}`"))
    }
}

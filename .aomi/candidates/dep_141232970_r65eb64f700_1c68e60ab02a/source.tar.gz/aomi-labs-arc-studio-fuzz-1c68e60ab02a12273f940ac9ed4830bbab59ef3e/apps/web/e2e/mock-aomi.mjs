// Deterministic browser fixture, not an EVM or model. Uses the real SDK's HTTP
// and SSE protocol so E2E covers workspace launch, event folding and recovery.
import http from "node:http";

const sessions = new Map();
let latest;
const owner = "0x0000000000000000000000000000000000000001";
const attacker = "0x0000000000000000000000000000000000000002";
const target = "0x00000000000000000000000000000000fa22c0de";
const actions = [
  {
    label: "Fund vault",
    actor: "alice",
    contract: null,
    function: "deposit()",
    arguments: [],
    value: "1000",
  },
  {
    label: "Withdraw without a deposit",
    actor: "attacker",
    contract: null,
    function: "withdraw(uint256)",
    arguments: ["10"],
    value: "0",
  },
];
const deposit = {
  label: "a0",
  from: owner,
  to: target,
  data: "0xd0e30db0",
  value: "1000",
};
const withdraw = {
  label: "a1",
  from: attacker,
  to: target,
  data: `0x2e1a7d4d${"0".repeat(63)}a`,
  value: "0",
};
const batch = {
  snapshot: "arc-fuzz-baseline",
  chain_id: 5042002,
  watch: [owner, attacker],
  traces: [
    { id: "1-1", calls: [deposit], probes: [] },
    { id: "1-2", calls: [deposit, withdraw], probes: [] },
    { id: "1-3", calls: [withdraw], probes: [] },
  ],
};
const next = {
  ...batch,
  traces: [{ id: "2-4", calls: [deposit, withdraw, withdraw], probes: [] }],
};
const progress = (status = "exploring", overrides = {}) => ({
  campaign_id: "fixture-campaign",
  status,
  hypothesis: "An attacker may withdraw another actor’s deposit",
  round: 1,
  executions: 3,
  max_executions: 32,
  frontier_size: 8,
  corpus_size: 2,
  inconclusive_traces: 1,
  uncovered_writes: [],
  covered_writes: ["deposit()", "withdraw(uint256)"],
  behavior_coverage: [],
  findings: [],
  unconfirmed: [],
  limitations: [],
  ...overrides,
});
function event(session, value) {
  const sequence = session.events.length + 1;
  session.events.push({
    event_id: `${session.id}-${sequence}`,
    sequence,
    turn_id: session.turn,
    occurred_at: Date.now(),
    ...value,
  });
}
function tool(session, id, name, args, result) {
  if (args !== undefined)
    event(session, {
      type: "message",
      sender: "agent",
      content: "",
      tool_name: name,
      tool_call_id: id,
      tool_arguments: args,
    });
  if (result !== undefined)
    event(session, {
      type: "tool_complete",
      id,
      call_id: id,
      tool_name: name,
      result,
    });
}
function page(session, cursor = 0) {
  return {
    session_id: session.id,
    cursor: String(session.events.length),
    events: session.events.filter((event) => event.sequence > Number(cursor)),
    has_more: false,
  };
}
function publish(session) {
  for (const response of session.streams) response.write(`event: page\ndata: ${JSON.stringify(page(session))}\n\n`);
}
function advance(session, phase) {
  if (phase === "wide") {
    const revised = Array.from({ length: 30 }, (_, index) => ({ ...actions[1], arguments: [String(index + 1)] }));
    tool(
      session,
      "wide",
      "arc_fuzz_round",
      { plan: { actions: revised }, replay: [] },
      {
        revision: "applied",
        progress: progress(),
        next_batch: {
          ...batch,
          traces: revised.map((action, index) => ({
            id: `wide-${index}`,
            calls: [
              { ...withdraw, label: `a${index}`, data: `0x2e1a7d4d${(index + 1).toString(16).padStart(64, "0")}` },
            ],
            probes: [],
          })),
        },
      },
    );
  } else if (phase === "exploring") {
    tool(
      session,
      "start",
      "arc_fuzz_start",
      {
        actions,
        hypothesis: "An attacker may withdraw another actor’s deposit",
      },
      { next_batch: batch, progress: progress("exploring", { executions: 0 }) },
    );
    tool(session, "replay", "sim_replay_traces", batch);
  } else if (phase === "executed") {
    tool(session, "replay", "sim_replay_traces", undefined, {
      traces: [
        { id: "1-1", statuses: ["succeeded"], balances: [], probes: [] },
        {
          id: "1-2",
          statuses: ["succeeded", "reverted"],
          balances: [{ address: owner, before: "2000", after: "1000" }],
          probes: [{ label: "p0", status: "succeeded", return_data: "0x03e8" }],
        },
        { id: "1-3", statuses: ["engine_error"], balances: [], probes: [] },
      ],
    });
    tool(session, "round", "arc_fuzz_round", { replay: [] }, { next_batch: next, progress: progress() });
  } else if (phase === "confirming") {
    tool(
      session,
      "confirm",
      "arc_fuzz_round",
      { replay: [] },
      {
        progress: progress("confirming"),
        next_batch: {
          ...batch,
          traces: [
            { id: "3-5", calls: [withdraw], probes: [] },
            { id: "3-6", calls: [withdraw], probes: [] },
          ],
        },
      },
    );
  } else if (phase === "complete") {
    tool(
      session,
      "report",
      "arc_fuzz_report",
      {},
      progress("complete", {
        frontier_size: 0,
        executions: 6,
        findings: [
          {
            property: "Unauthorized withdrawal must fail",
            minimized_trace: [actions[1]],
            steps: [
              {
                label: "Withdraw without a deposit",
                actor: "attacker",
                function: "withdraw(uint256)",
                status: "succeeded",
              },
            ],
            balances: [{ address: attacker, before: "100", after: "110" }],
            probes: [],
            reproductions: 2,
          },
        ],
      }),
    );
    event(session, {
      type: "message",
      sender: "agent",
      content: "Fixture campaign finished with a twice-reproduced violation.",
    });
    event(session, { type: "turn_state_changed", state: "complete" });
  } else if (phase === "budget") {
    tool(
      session,
      "budget",
      "arc_fuzz_round",
      { replay: [] },
      {
        next_batch: null,
        progress: progress("budget_exhausted", { max_executions: 3 }),
      },
    );
    event(session, { type: "turn_state_changed", state: "complete" });
  }
  publish(session);
}
http
  .createServer(async (request, response) => {
    const url = new URL(request.url, "http://localhost:4128");
    response.setHeader("access-control-allow-origin", "http://localhost:3118");
    response.setHeader("access-control-allow-headers", "*");
    response.setHeader("access-control-allow-methods", "GET, POST, OPTIONS");
    const json = (value, status = 200) => {
      response.writeHead(status, { "content-type": "application/json" });
      response.end(JSON.stringify(value));
    };
    if (request.method === "OPTIONS") {
      response.writeHead(204);
      return response.end();
    }
    if (url.pathname === "/health") return json({ ok: true });
    if (url.pathname === "/api/thread/models") return json(["Claude Opus 5.5"]);
    if (url.pathname === "/api/thread/model") return json({ success: true, rig: "opus" });
    if (url.pathname === "/api/thread/apps")
      return json([
        {
          name: "arc-studio-fuzzer",
          description: "Fuzzer",
          applicationId: 2937813,
        },
      ]);
    if (url.pathname === "/api/auth/widget/guest") return json({ access_token: "fixture-guest" });
    if (url.pathname === "/v1/agent/sessions")
      return json({
        sessions: [...sessions.values()].map((session) => ({
          id: session.id,
          title: "Fixture campaign",
          updatedAt: Date.now(),
          archived: false,
        })),
        nextCursor: null,
      });
    if (url.pathname.startsWith("/v1/agent/sessions/"))
      return json({
        id: url.pathname.split("/").at(-1),
        title: "Fixture campaign",
        updatedAt: Date.now(),
        archived: false,
      });
    let body = "";
    if (request.method === "POST") for await (const chunk of request) body += chunk;
    const input = body ? JSON.parse(body) : {};
    if (url.pathname === "/__test/advance") {
      const session = sessions.get(input.sessionId ?? latest);
      if (!session) return json({ error: "no session" }, 404);
      advance(session, input.phase);
      return json({ ok: true });
    }
    if (url.pathname === "/v1/agent/chat" && request.method === "POST") {
      let session = sessions.get(input.sessionId);
      if (!session) {
        session = {
          id: input.sessionId,
          turn: "fixture-turn",
          events: [],
          streams: new Set(),
        };
        sessions.set(session.id, session);
      }
      latest = session.id;
      event(session, {
        type: "message",
        sender: "user",
        content: input.message,
      });
      event(session, { type: "turn_state_changed", state: "processing" });
      return json(page(session, input.cursor));
    }
    const match = /^\/v1\/agent\/chat\/([^/]+)(\/stream|\/interrupt)?$/.exec(url.pathname);
    if (match) {
      const session = sessions.get(match[1]);
      if (!session) return json({ error: "not found" }, 404);
      if (match[2] === "/interrupt") {
        event(session, { type: "turn_state_changed", state: "interrupted" });
        publish(session);
        return json(page(session, input.cursor));
      }
      if (match[2] === "/stream") {
        response.writeHead(200, {
          "content-type": "text/event-stream",
          "cache-control": "no-cache",
          connection: "keep-alive",
        });
        response.write(`event: page\ndata: ${JSON.stringify(page(session, url.searchParams.get("cursor")))}\n\n`);
        session.streams.add(response);
        request.on("close", () => session.streams.delete(response));
        return;
      }
      return json(page(session, url.searchParams.get("cursor")));
    }
    json({ error: `Unhandled fixture request: ${request.method} ${url.pathname}` }, 404);
  })
  .listen(4128, () => console.log("Fixture Aomi on :4128"));

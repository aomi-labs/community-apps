import { test, expect, type Page, type APIRequestContext } from "@playwright/test";
import { readFile } from "node:fs/promises";

const app = "00000000-0000-4000-8000-00000000a11c";
async function launch(page: Page) {
  await page.goto("/");
  await page.getByLabel("Arc Studio token").fill("origin_pat_mock_local_dev");
  await page.getByRole("button", { name: "Connect", exact: true }).click();
  await expect(page.getByText("Pick an Arc Studio app to fuzz")).toBeVisible();
  await page.goto(`/apps/${app}`);
  await page.getByRole("button", { name: /UnsafeVault.*built/ }).click();
  await page.getByTestId("run-aomi-fuzz").click();
  await expect(page.getByRole("region", { name: "Campaign progress" })).toContainText("Planning");
}
async function advance(request: APIRequestContext, phase: string) {
  const response = await request.post("http://localhost:4128/__test/advance", {
    data: { phase },
  });
  expect(response.ok()).toBeTruthy();
}

test("live paths, selection, evidence, confirmation, and restored history", async ({ page, request }, testInfo) => {
  const errors: string[] = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await launch(page);
  await expect(page.getByRole("tab", { name: "Fuzz tree" })).toHaveAttribute("aria-selected", "true");
  await advance(request, "exploring");
  const progress = page.getByRole("region", { name: "Campaign progress" });
  await expect(progress).toContainText("Executing batch");
  const paths = page.getByLabel("Observed execution paths");
  await expect(paths).toContainText("deposit()");
  await advance(request, "executed");
  await expect(progress).toContainText("3 / 32");
  await expect(paths).toContainText("Reverted");
  await expect(paths).toContainText("Simulation error");
  await paths.getByRole("button", { name: /withdraw\(uint256\).*Reverted/ }).click();
  await expect(page.getByRole("button", { name: "Follow latest", exact: true })).toHaveAttribute(
    "aria-pressed",
    "false",
  );
  const inspector = page.getByLabel("Selected path", { exact: true });
  await expect(inspector).toContainText("Selected path · 2 calls");
  await inspector.getByText("Watched balance changes (1)").click();
  await expect(inspector).toContainText("2000");
  await inspector.getByText("Probe results (1)").click();
  await expect(inspector).toContainText("0x03e8");
  await advance(request, "confirming");
  await expect(progress).toContainText("Confirming violation");
  await expect(inspector).toContainText("Selected path · 2 calls");
  await page.getByRole("button", { name: "Expand activity", exact: true }).click();
  await inspector.evaluate((element) => {
    element.scrollTop = 0;
  });
  await page.screenshot({
    path: testInfo.outputPath("running-tree.png"),
    fullPage: true,
  });
  await page.getByRole("button", { name: "Follow latest", exact: true }).click();
  await expect(inspector).toContainText("Selected path · 1 call");
  await expect(inspector.getByRole("combobox", { name: "Replay history" }).locator("option")).toHaveCount(3);
  await advance(request, "complete");
  await expect(progress).toContainText("Finished");
  await expect(paths).toContainText("Confirmed finding");
  await expect(inspector).toContainText("Unauthorized withdrawal must fail");
  await page.getByRole("tab", { name: /Tools/ }).click();
  await expect(page.getByTestId("agent-trace")).toContainText("sim_replay_traces");
  await page.getByRole("tab", { name: /All events/ }).click();
  await expect(page.getByTestId("ledger")).toContainText("tool_complete");
  const downloading = page.waitForEvent("download");
  await page.getByRole("button", { name: "Export evidence", exact: true }).click();
  const download = await downloading;
  const exported = JSON.parse(await readFile((await download.path())!, "utf8"));
  expect(exported.report.status).toBe("complete");
  expect(exported.events.length).toBeGreaterThan(10);
  await page.reload();
  await page.getByRole("button", { name: /UnsafeVault.*Finding reproduced/ }).click();
  await expect(page.getByLabel("Observed execution paths")).toContainText("Confirmed finding");
  await expect(page.getByRole("region", { name: "Campaign progress" })).toContainText("Finished");
  expect(errors).toEqual([]);
});

test("budget exhaustion stays incomplete and stop never looks like execution", async ({ page, request }) => {
  await launch(page);
  await advance(request, "exploring");
  await advance(request, "executed");
  await advance(request, "budget");
  await expect(page.getByRole("region", { name: "Campaign progress" })).toContainText("Budget exhausted");
  await expect(page.getByRole("region", { name: "Campaign progress" })).toContainText("incomplete campaign");
  await expect(page.getByText("Campaign complete", { exact: true })).toHaveCount(0);
  await page.getByRole("button", { name: "Continue campaign", exact: true }).click();
  await page.getByRole("button", { name: "Stop execution", exact: true }).click();
  await expect(page.getByRole("region", { name: "Campaign progress" })).toContainText("Stopped");
  await expect(page.getByLabel("Observed execution paths")).not.toContainText("Executing");
});

test("crowded branches stay usable in a narrow panel and quiet runs show elapsed time", async ({
  page,
  request,
}, testInfo) => {
  await page.setViewportSize({ width: 1140, height: 1000 });
  await page.clock.install();
  await launch(page);
  await advance(request, "exploring");
  await advance(request, "executed");
  await advance(request, "wide");
  const paths = page.getByLabel("Observed execution paths");
  await expect(paths.getByRole("button", { name: /Show more branches/ })).toBeVisible();
  const before = await page.getByRole("region", { name: "Campaign activity", exact: true }).boundingBox();
  await page.getByRole("button", { name: "Expand activity", exact: true }).click();
  const after = await page.getByRole("region", { name: "Campaign activity", exact: true }).boundingBox();
  expect(after!.height).toBeGreaterThan(before!.height);
  await paths.getByRole("button", { name: /Show more branches/ }).click();
  // The 24 hidden siblings are revealed; a followed branch may add nested
  // withdraw nodes depending on how the mock's pages arrived.
  await expect
    .poll(() => paths.getByRole("button", { name: /withdraw\(uint256\)/ }).count())
    .toBeGreaterThanOrEqual(24);
  // Which withdraw branch sits first depends on how the mock's pages arrived;
  // any of them exposes its ordered call with its argument once selected.
  await paths
    .getByRole("button", { name: /withdraw\(uint256\)/ })
    .first()
    .click();
  await expect(page.getByLabel("Selected path", { exact: true })).toContainText(/Arguments: \d+/);
  await page.clock.runFor(31_000);
  await expect(page.getByRole("region", { name: "Campaign progress" })).toContainText("No new events for 31s");
  await page.screenshot({ path: testInfo.outputPath("narrow-tree.png"), fullPage: true });
  await page.getByRole("button", { name: "Restore activity size", exact: true }).click();
  await expect(page.getByRole("button", { name: "Expand activity", exact: true })).toBeVisible();
});

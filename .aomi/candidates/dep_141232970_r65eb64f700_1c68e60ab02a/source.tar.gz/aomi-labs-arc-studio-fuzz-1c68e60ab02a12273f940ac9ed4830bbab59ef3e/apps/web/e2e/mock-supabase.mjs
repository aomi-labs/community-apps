#!/usr/bin/env node
// In-memory stand-in for the dedicated snapshot Supabase project, covering the
// PostgREST and Storage calls apps/web/src/server/snapshot-store.ts makes:
// arc_workspaces upserts, arc_snapshots inserts and lookups, private object
// uploads/reads, and signed links. Development fixture only.
import { createServer } from "node:http";

const port = Number(process.env.PORT ?? 4138);
const BUCKET = "arc-snapshots";
const rows = { arc_snapshots: [], arc_workspaces: [] };
const objects = new Map();
let nextId = 0;
const uuid = () => `00000000-0000-4000-8000-${String(++nextId).padStart(12, "0")}`;

const read = (request) =>
  new Promise((resolve) => {
    const chunks = [];
    request.on("data", (chunk) => chunks.push(chunk));
    request.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
  });
const json = (response, status, body) => {
  response.writeHead(status, { "content-type": "application/json" });
  response.end(JSON.stringify(body));
};
/** PostgREST `column=eq.value` filters, `order`, `limit`, `select`. */
function query(table, params) {
  let out = rows[table];
  for (const [name, value] of params) {
    if (value.startsWith("eq.")) out = out.filter((row) => String(row[name]) === value.slice(3));
  }
  const order = params.get("order");
  if (order) {
    const [column, direction] = order.split(".");
    out = [...out].sort((a, b) => (a[column] < b[column] ? -1 : 1) * (direction === "desc" ? -1 : 1));
  }
  const limit = params.get("limit");
  if (limit) out = out.slice(0, Number(limit));
  const select = params.get("select");
  return select && select !== "*" ? out.map((row) => Object.fromEntries(select.split(",").map((c) => [c, row[c]]))) : out;
}

createServer(async (request, response) => {
  const url = new URL(request.url, `http://127.0.0.1:${port}`);
  if (!request.headers.apikey) return json(response, 401, { message: "No API key found in request" });
  const rest = /^\/rest\/v1\/(arc_snapshots|arc_workspaces)$/.exec(url.pathname);
  if (rest) {
    const table = rest[1];
    if (request.method === "GET") return json(response, 200, query(table, url.searchParams));
    if (request.method === "POST") {
      const body = JSON.parse(await read(request));
      const prefer = request.headers.prefer ?? "";
      const conflict = (url.searchParams.get("on_conflict") ?? "").split(",").filter(Boolean);
      const existing = rows[table].find((row) => conflict.every((c) => row[c] === body[c]));
      if (existing && /ignore-duplicates/.test(prefer)) return json(response, 201, []);
      const row = existing && /merge-duplicates/.test(prefer)
        ? Object.assign(existing, body)
        : { id: uuid(), captured_at: new Date().toISOString(), ...body };
      if (!existing) rows[table].push(row);
      return json(response, 201, /return=representation/.test(prefer) ? [row] : []);
    }
  }
  const upload = new RegExp(`^/storage/v1/object/${BUCKET}/(.+)$`).exec(url.pathname);
  if (upload && request.method === "POST") {
    const path = upload[1];
    if (objects.has(path)) return json(response, 400, { error: "Duplicate", message: "The resource already exists" });
    objects.set(path, await read(request));
    return json(response, 200, { Key: `${BUCKET}/${path}` });
  }
  const download = new RegExp(`^/storage/v1/object/(?:authenticated|sign)/${BUCKET}/(.+)$`).exec(url.pathname);
  if (download && request.method === "GET") {
    const body = objects.get(download[1]);
    if (body === undefined) return json(response, 404, { error: "not_found" });
    response.writeHead(200, { "content-type": "application/json" });
    return response.end(body);
  }
  const sign = new RegExp(`^/storage/v1/object/sign/${BUCKET}/(.+)$`).exec(url.pathname);
  if (sign && request.method === "POST") {
    if (!objects.has(sign[1])) return json(response, 404, { error: "not_found" });
    return json(response, 200, { signedURL: `/object/sign/${BUCKET}/${sign[1]}?token=fixture` });
  }
  if (url.pathname === "/health") return json(response, 200, { ok: true });
  json(response, 404, { message: `Unhandled fixture request: ${request.method} ${url.pathname}` });
}).listen(port, "127.0.0.1", () => console.log(`mock supabase on http://127.0.0.1:${port}`));

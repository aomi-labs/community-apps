import { defineConfig } from "@playwright/test";

export default defineConfig({
  testDir: "./e2e",
  workers: 1,
  timeout: 60_000,
  use: {
    baseURL: "http://localhost:3118",
    viewport: { width: 1440, height: 1000 },
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
    launchOptions: {
      executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH,
    },
  },
  webServer: [
    { command: "PORT=4118 node ../../scripts/mock-arc-studio.mjs", port: 4118 },
    { command: "node e2e/mock-aomi.mjs", port: 4128 },
    { command: "PORT=4138 node e2e/mock-supabase.mjs", port: 4138 },
    {
      command: "pnpm build && PORT=3118 node .output/server/index.mjs",
      port: 3118,
      timeout: 120_000,
      env: {
        SESSION_SECRET: "local-e2e-session-secret-never-for-production",
        ARC_STUDIO_API_URL: "http://localhost:4118",
        NEXT_PUBLIC_AOMI_BACKEND_URL: "http://localhost:4128",
        NEXT_PUBLIC_AOMI_MODEL: "Claude Opus 5.5",
        SUPABASE_SNAPSHOT_URL: "http://127.0.0.1:4138",
        SUPABASE_SNAPSHOT_SERVICE_ROLE_KEY: "sb_secret_local_e2e_fixture",
      },
    },
  ],
});

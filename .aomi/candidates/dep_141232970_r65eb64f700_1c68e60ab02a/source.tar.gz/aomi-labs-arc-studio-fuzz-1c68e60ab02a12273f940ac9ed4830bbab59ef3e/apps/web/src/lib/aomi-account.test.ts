import { expect, test, vi } from "vitest";
const signIn = vi.hoisted(() => vi.fn(async () => "test-guest"));
vi.mock("@aomi-labs/client", () => ({ createGuestSessionProvider: () => Object.assign(signIn, { clear: vi.fn() }) }));

test("campaigns share a guest and reload restores it without creating another identity", async () => {
  const values = new Map<string, string>();
  vi.stubGlobal("sessionStorage", { getItem: (key: string) => values.get(key), setItem: (key: string, value: string) => values.set(key, value), removeItem: (key: string) => values.delete(key) });
  const { guestSession } = await import("./aomi-account");
  const a = guestSession("https://staging.test");
  expect(guestSession("https://staging.test")).toBe(a);
  expect(await Promise.all([a(), a()])).toEqual(["test-guest", "test-guest"]);
  expect(signIn).toHaveBeenCalledTimes(1);
  vi.resetModules();
  const reloaded = await import("./aomi-account");
  expect(await reloaded.guestSession("https://staging.test")()).toBe("test-guest");
  expect(signIn).toHaveBeenCalledTimes(1);
  await reloaded.guestSession("https://another.test")();
  expect(signIn).toHaveBeenCalledTimes(2);
  vi.unstubAllGlobals();
});

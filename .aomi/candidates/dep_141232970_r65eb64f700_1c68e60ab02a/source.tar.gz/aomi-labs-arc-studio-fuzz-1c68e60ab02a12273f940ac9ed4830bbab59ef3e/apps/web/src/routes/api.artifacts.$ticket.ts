import { createFileRoute } from "@tanstack/react-router";
import { INSTALL_ADDRESS } from "@aomi-labs/arc-studio-fuzz-core";

import { StudioSession, artifactDigest } from "@/server/studio-session";

/**
 * Serves one contract's compiled artifact to the Aomi arc-studio-fuzzer app.
 * The ticket is a sealed, 30-minute capability for exactly this artifact.
 *
 * For a live deployment the artifact also lists the rest of the protocol: the
 * app's other contracts deployed on the same chain, with their ABIs. The
 * fuzzer forks that chain, so they are already in the world at those addresses.
 */
export const Route = createFileRoute("/api/artifacts/$ticket")({
  server: {
    handlers: {
      GET: async ({ request, params }) => {
        const { ticket } = params;
        const redeemed = StudioSession.fromArtifactTicket(ticket);
        if (!redeemed) return new Response("Artifact link is invalid or expired.", { status: 403 });
        try {
          const app = await redeemed.session.app(redeemed.appId);
          const target = await StudioSession.timed(`artifact ${redeemed.contract}`, () =>
            app.target(redeemed.sourcePath, redeemed.contract),
          );
          const protocol = target.deployment ? await app.protocol(target.name, target.deployment.chainId) : [];
          const digest = artifactDigest([target.source, target.abi, target.deployedBytecode, target.chainId, target.deployment ?? null, protocol]);
          if (redeemed.digest !== digest) return new Response("The compiled target changed. Prepare a new campaign before running.", { status: 409 });
          return Response.json(
            {
              name: target.name,
              source_code: target.source,
              abi: JSON.stringify(target.abi),
              deployed_bytecode: target.deployedBytecode,
              chain_id: target.chainId,
              ...(target.deployment
                ? { deployment: { address: target.deployment.address, chain_id: target.deployment.chainId } }
                : redeemed.installed && {
                    // The harness installed the runtime here before the turn.
                    deployment: { address: INSTALL_ADDRESS, chain_id: target.chainId, installed: true },
                  }),
              ...(protocol.length > 0 && { protocol }),
            },
            { headers: { "cache-control": "private, no-store" } },
          );
        } catch (error) {
          return new Response(error instanceof Error ? error.message : String(error), { status: 422 });
        }
      },
    },
  },
});

import "@tanstack/react-start/server-only";

import type { TargetData } from "@/app/actions";
import { StudioSession } from "@/server/studio-session";
import { launchSnapshot, savedSnapshot, saveSnapshot } from "@/server/snapshot-store";

export interface TargetSelection {
  appId: string;
  sourcePath: string;
  contract: string;
  snapshotId?: string;
  refresh?: boolean;
}

export async function prepareTarget(current: StudioSession, selection: TargetSelection): Promise<TargetData> {
  const { appId, sourcePath, contract, snapshotId, refresh } = selection;
  // A launch always uses the exact object that was previewed. Neither branch
  // below touches Arc Studio unless preparation was explicitly requested.
  if (snapshotId) return launchSnapshot(current.token, appId, sourcePath, contract, snapshotId);
  if (!refresh) {
    const saved = await savedSnapshot(current.token, appId, sourcePath, contract);
    if (saved) return saved;
  }
  const target = await StudioSession.timed(`target ${contract}`, async () =>
    (await current.app(appId, { fresh: true })).target(sourcePath, contract),
  );
  const protocol = target.deployment ? await (await current.app(appId)).protocol(target.name, target.chainId) : [];
  const prepared: TargetData = {
    name: target.name, sourcePath: target.sourcePath, source: target.source,
    abi: target.abi, deployedBytecode: target.deployedBytecode, chainId: target.chainId,
    immutableReferences: target.immutableReferences, deployment: target.deployment,
    protocol: protocol.map(({ name, address }) => ({ name, address })),
  };
  return saveSnapshot(current.token, appId, prepared, protocol);
}

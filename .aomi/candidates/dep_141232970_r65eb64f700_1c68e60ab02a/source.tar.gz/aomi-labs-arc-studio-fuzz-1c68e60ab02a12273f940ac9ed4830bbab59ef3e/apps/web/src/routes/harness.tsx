import { createFileRoute, notFound } from "@tanstack/react-router";

import { HarnessWorkspace } from "@/components/harness-workspace";
import { harness } from "@/server/loaders";

/**
 * Fuzz a whole protocol seeded by `scripts/seed-protocol.mjs` on a self-hosted
 * Aomi stack. Exists only in development with HARNESS_SEED_DIR set; see
 * apps/web/.env.example.
 */
export const Route = createFileRoute("/harness")({
  loader: async () => {
    const { protocol } = await harness();
    if (!protocol) throw notFound();
    return protocol;
  },
  component: Harness,
});

function Harness() {
  return <HarnessWorkspace protocol={Route.useLoaderData()} />;
}

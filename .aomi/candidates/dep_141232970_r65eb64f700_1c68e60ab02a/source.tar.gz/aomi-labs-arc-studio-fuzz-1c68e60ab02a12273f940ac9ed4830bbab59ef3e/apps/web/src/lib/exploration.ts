import type { FuzzCall, FuzzCampaignReport, TraceRow } from "@aomi-labs/arc-studio-fuzz-core";

type ObjectValue = Record<string, unknown>;
export function object(value: unknown): ObjectValue {
  if (typeof value === "string") {
    try {
      return object(JSON.parse(value));
    } catch {
      return {};
    }
  }
  return value && typeof value === "object" && !Array.isArray(value) ? (value as ObjectValue) : {};
}
function list(value: unknown): ObjectValue[] {
  return Array.isArray(value) ? value.map(object) : [];
}

export interface ObservedCall {
  label: string;
  from: string;
  to: string;
  data: string;
  value: string;
  action?: FuzzCall;
}
export interface ObservedReplay {
  id: string;
  calls: ObservedCall[];
  state: "Queued" | "Executing" | "Executed" | "Replay failed" | "Awaiting result";
  statuses: string[];
  balances: ObjectValue[];
  probes: ObjectValue[];
}
export interface PathNode {
  id: string;
  call: ObservedCall;
  children: PathNode[];
  /** Replays that end at this node; shared prefixes are not extra executions. */
  replays: ObservedReplay[];
  path: ObservedCall[];
  confirmed: string[];
}
function callKey(call: ObservedCall): string {
  return JSON.stringify([call.from.toLowerCase(), call.to.toLowerCase(), call.data.toLowerCase(), call.value]);
}
function sameAction(a: FuzzCall | undefined, b: FuzzCall, targetName?: string): boolean {
  const contract = (name?: string | null) => (!name || name === targetName ? null : name);
  return Boolean(
    a &&
    a.actor === b.actor &&
    a.function === b.function &&
    contract(a.contract) === contract(b.contract) &&
    (a.value ?? "0") === (b.value ?? "0") &&
    JSON.stringify(a.arguments ?? []) === JSON.stringify(b.arguments ?? []),
  );
}

/** A presentation-only projection. Never generates work or infers pruning/violations. */
export function exploration(rows: readonly TraceRow[], report: FuzzCampaignReport | null, targetName?: string) {
  const replays = new Map<string, ObservedReplay>();
  let actions: FuzzCall[] = [];
  const schedule = (batch: ObjectValue) => {
    for (const trace of list(batch.traces)) {
      if (typeof trace.id !== "string" || replays.has(trace.id)) continue;
      const calls = list(trace.calls).map((call): ObservedCall => {
        const label = String(call.label ?? "call");
        const index = /^a(\d+)$/.exec(label)?.[1];
        return {
          label,
          from: String(call.from ?? ""),
          to: String(call.to ?? ""),
          data: String(call.data ?? ""),
          value: String(call.value ?? "0"),
          action: index === undefined ? undefined : actions[Number(index)],
        };
      });
      if (calls.length)
        replays.set(trace.id, {
          id: trace.id,
          calls,
          state: "Queued",
          statuses: [],
          balances: [],
          probes: [],
        });
    }
  };
  const results = (value: unknown) => {
    for (const output of list(value)) {
      const replay = replays.get(String(output.id));
      if (!replay || !Array.isArray(output.statuses)) continue;
      replay.state = "Executed";
      replay.statuses = output.statuses.map(String);
      replay.balances = list(output.balances);
      replay.probes = list(output.probes);
    }
  };
  for (const row of rows) {
    const args = object(row.arguments);
    const result = object(row.result);
    if (row.name === "arc_fuzz_start" && row.state === "complete") {
      actions = list(args.actions) as unknown as FuzzCall[];
    }
    if (row.name === "arc_fuzz_round") {
      results(args.replay);
      if (result.revision === "applied") actions = list(object(args.plan).actions) as unknown as FuzzCall[];
    }
    if (row.name.startsWith("arc_fuzz_") && row.state === "complete") schedule(object(result.next_batch));
    if (row.name !== "sim_replay_traces") continue;
    schedule(args);
    for (const trace of list(args.traces)) {
      const replay = replays.get(String(trace.id));
      if (replay && replay.state !== "Executed")
        replay.state =
          row.state === "calling" ? "Executing" : row.state === "failed" ? "Replay failed" : "Awaiting result";
    }
    results(result.traces);
  }
  const roots: PathNode[] = [];
  const nodes = new Map<string, PathNode>();
  for (const replay of replays.values()) {
    let siblings = roots;
    const path: ObservedCall[] = [];
    for (const call of replay.calls) {
      path.push(call);
      const id = JSON.stringify(path.map(callKey));
      let node = nodes.get(id);
      if (!node) {
        node = {
          id,
          call,
          path: [...path],
          children: [],
          replays: [],
          confirmed: [],
        };
        nodes.set(id, node);
        siblings.push(node);
      }
      if (path.length === replay.calls.length) node.replays.push(replay);
      siblings = node.children;
    }
  }
  for (const node of nodes.values()) {
    node.confirmed = (report?.findings ?? [])
      .filter(
        (finding) =>
          finding.minimized_trace.length === node.path.length &&
          finding.minimized_trace.every((call, index) => sameAction(node.path[index]?.action, call, targetName)),
      )
      .map((finding) => finding.property);
  }
  return { roots, nodes, replays: [...replays.values()] };
}

export function nodeState(node: PathNode, busy: boolean): string {
  if (node.confirmed.length) return "Confirmed finding";
  const latest = node.replays.at(-1);
  if (!latest) return "Shared prefix";
  if (latest.state === "Executing") return busy ? "Executing" : "Awaiting result";
  if (latest.state !== "Executed") return latest.state;
  if (latest.statuses.includes("engine_error")) return "Simulation error";
  if (latest.statuses.length !== latest.calls.length) return "Incomplete result";
  if (latest.statuses.includes("reverted")) return "Reverted";
  if (latest.statuses.some((status) => status !== "succeeded")) return "Call failed";
  return "Executed";
}

export function campaignPhase(
  report: FuzzCampaignReport | null,
  rows: readonly TraceRow[],
  busy: boolean,
  preparing: boolean,
): string {
  if (preparing) return "Preparing fork";
  const active = rows.findLast((row) => row.state === "calling");
  if (busy && active?.name === "sim_replay_traces") return "Executing batch";
  if (report?.status === "complete") return "Finished";
  if (report?.status === "budget_exhausted") return "Budget exhausted";
  if (report?.status === "confirming") return "Confirming violation";
  if (!busy) return "Paused · campaign incomplete";
  if (active && ["sim_open", "sim_set_code", "sim_set_balance", "sim_snapshot"].includes(active.name))
    return "Preparing fork";
  if (active?.name === "arc_map_attack_surface" || !report) return "Planning";
  return "Exploring";
}

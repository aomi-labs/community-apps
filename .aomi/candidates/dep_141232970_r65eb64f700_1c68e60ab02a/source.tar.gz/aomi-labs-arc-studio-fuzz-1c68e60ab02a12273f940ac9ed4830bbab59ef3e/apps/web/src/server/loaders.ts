import { createServerFn } from "@tanstack/react-start";
import { getRequestHeader, setResponseHeader } from "@tanstack/react-start/server";
import { redirect } from "@tanstack/react-router";
import { z } from "zod";
import { LocalHarness } from "./local-harness";
import { StudioSession } from "./studio-session";
import { studioErrorMessage } from "./studio-error";

export const home = createServerFn().handler(async () => {
  setResponseHeader("cache-control", "private, no-store");
  const session = await StudioSession.current();
  const apps = await session
    ?.client()
    .listApps()
    .then((list) => list.sort((a, b) => b.timestamp.localeCompare(a.timestamp)))
    .catch(() => null);
  return { apps: apps ?? null, expired: Boolean(session), authorizeUrl: `${StudioSession.apiUrl}/cli-auth` };
});

export const workspace = createServerFn()
  .validator(z.object({ appId: z.string().uuid() }))
  .handler(async ({ data: { appId } }) => {
    setResponseHeader("cache-control", "private, no-store");
    const session = await StudioSession.current();
    if (!session) throw redirect({ to: "/" });
    try {
      const { loadWorkspace } = await import("./prepare-workspace");
      const saved = await loadWorkspace(session, appId);
      return {
        appId,
        appName: saved.appName,
        studioUrl: saved.studioUrl,
        contracts: saved.contracts,
        files: saved.files,
        error: null,
      };
    } catch (error) {
      return {
        appId,
        appName: "Unavailable app",
        studioUrl: session.client().webUrl(appId),
        contracts: [],
        files: [],
        error: studioErrorMessage(error),
      };
    }
  });

/** The harness-seeded protocol for /harness, or null when the harness is off. */
export const harness = createServerFn().handler(async () => {
  setResponseHeader("cache-control", "private, no-store");
  const local = LocalHarness.current();
  if (!local) return { protocol: null };
  // The fuzzer app on the stack downloads the artifact from this web app, so
  // the link must name an origin the backend can reach.
  const host = getRequestHeader("x-forwarded-host") ?? getRequestHeader("host") ?? "127.0.0.1:3108";
  const origin = (process.env.HARNESS_PUBLIC_ORIGIN ?? `http://${host}`).replace(/\/+$/, "");
  return { protocol: await local.protocol(origin) };
});

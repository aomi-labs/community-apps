import { createFileRoute } from "@tanstack/react-router";

import { LocalHarness } from "@/server/local-harness";

/**
 * Serves the seeded protocol's artifact to the arc-studio-fuzzer app running
 * on the self-hosted stack (built with ARC_FUZZ_ARTIFACT_ORIGIN set to this web
 * app's origin). Development only, like the /harness page.
 */
export const Route = createFileRoute("/api/harness/artifact")({
  server: {
    handlers: {
      GET: async () => {
        const local = LocalHarness.current();
        if (!local) return new Response("Not found", { status: 404 });
        try {
          return new Response(await local.artifact(), {
            headers: { "content-type": "application/json", "cache-control": "no-store" },
          });
        } catch (error) {
          return new Response(error instanceof Error ? error.message : String(error), { status: 422 });
        }
      },
    },
  },
});

import { createFileRoute } from "@tanstack/react-router";
import { StudioSession } from "@/server/studio-session";

/** Upper bound per request; Arc Studio's batch read is chunked at 50 anyway. */
const MAX_PATHS = 80;

/** Several workspace files in one round trip, used to warm the viewer after the page opens. */
export const Route = createFileRoute("/api/apps/$appId/files")({
  server: {
    handlers: {
      POST: async ({ request, params }) => {
        const { appId } = params;
        const session = await StudioSession.current();
        if (!session) return Response.json({ error: "Not connected to Arc Studio." }, { status: 401 });
        const body = (await request.json().catch(() => null)) as { paths?: unknown } | null;
        const paths = Array.isArray(body?.paths) ? body.paths.filter((p): p is string => typeof p === "string") : [];
        try {
          const files = await StudioSession.timed(`prefetch ${Math.min(paths.length, MAX_PATHS)} files`, async () =>
            (await session.app(appId)).readFiles(paths.slice(0, MAX_PATHS)),
          );
          return Response.json(Object.fromEntries(files), { headers: { "cache-control": "private, no-store" } });
        } catch (error) {
          return Response.json({ error: error instanceof Error ? error.message : String(error) }, { status: 422 });
        }
      },
    },
  },
});

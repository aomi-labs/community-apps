import { createHash } from "node:crypto";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import type { TargetData } from "@/app/actions";
import { launchSnapshot, savedSnapshot, savedWorkspace, saveSnapshot, saveWorkspace } from "./snapshot-store";

const project = "https://snapshots.example.test";
const appId = "11111111-1111-4111-8111-111111111111";
const sourcePath = "contracts/Vault.sol";
const target: TargetData = {
  name: "Vault",
  sourcePath,
  source: "contract Vault {}",
  abi: [{ type: "function", name: "deposit", stateMutability: "payable" }],
  deployedBytecode: "0x6000",
  chainId: 5042002,
};

type Row = {
  id: string;
  owner_hash: string;
  app_id: string;
  source_path: string;
  contract_name: string;
  digest: string;
  storage_path: string;
  installed_path: string | null;
  captured_at: string;
};

let objects: Map<string, string>;
let rows: Row[];
let workspaceRows: Array<Record<string, unknown>>;
let requests: string[];
let requestHeaders: Array<Record<string, string>>;

beforeEach(() => {
  process.env.SUPABASE_SNAPSHOT_URL = project;
  process.env.SUPABASE_SNAPSHOT_SERVICE_ROLE_KEY = "test-service-key";
  process.env.SESSION_SECRET = "a test-only session secret longer than 32 characters";
  objects = new Map();
  rows = [];
  workspaceRows = [];
  requests = [];
  requestHeaders = [];
  vi.stubGlobal("fetch", vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = new URL(String(input));
    requests.push(`${init?.method ?? "GET"} ${url.pathname}`);
    requestHeaders.push(init?.headers as Record<string, string>);
    const response = (body: unknown, status = 200) => Response.json(body, { status });
    const object = url.pathname.match(/^\/storage\/v1\/object\/(?:authenticated\/)?arc-snapshots\/(.+)$/);
    if (object) {
      const path = object[1] as string;
      if (init?.method === "POST") {
        if (objects.has(path)) return response({ message: "Asset Already Exists" }, 400);
        objects.set(path, String(init.body));
        return response({ Key: path });
      }
      const body = objects.get(path);
      return body ? new Response(body) : response({ message: "missing" }, 404);
    }
    const signed = url.pathname.match(/^\/storage\/v1\/object\/sign\/arc-snapshots\/(.+)$/);
    if (signed) return response({ signedURL: `/object/sign/arc-snapshots/${signed[1]}?token=test` });
    if (url.pathname === "/rest/v1/arc_workspaces" && init?.method === "POST") {
      const body = JSON.parse(String(init.body)) as Record<string, unknown>;
      workspaceRows = workspaceRows.filter((row) => row.owner_hash !== body.owner_hash || row.app_id !== body.app_id);
      workspaceRows.push(body);
      return new Response(null, { status: 204 });
    }
    if (url.pathname === "/rest/v1/arc_workspaces") {
      return response(workspaceRows.filter((row) =>
        row.owner_hash === url.searchParams.get("owner_hash")?.slice(3) &&
        row.app_id === url.searchParams.get("app_id")?.slice(3)));
    }
    if (url.pathname === "/rest/v1/arc_snapshots" && init?.method === "POST") {
      const body = JSON.parse(String(init.body)) as Omit<Row, "id" | "captured_at">;
      const existing = rows.find((row) => row.owner_hash === body.owner_hash && row.app_id === body.app_id && row.source_path === body.source_path && row.contract_name === body.contract_name && row.digest === body.digest);
      if (existing) return response([]);
      const row = { ...body, id: "22222222-2222-4222-8222-222222222222", captured_at: "2026-10-20T12:00:00Z" };
      rows.push(row);
      return response([row]);
    }
    if (url.pathname === "/rest/v1/arc_snapshots") {
      const filtered = rows.filter((row) => ["owner_hash", "app_id", "source_path", "contract_name", "id", "digest"].every((field) => {
        const filter = url.searchParams.get(field);
        return !filter || row[field as keyof Row] === filter.slice(3);
      }));
      return response(filtered);
    }
    return response({ message: "unexpected test request" }, 500);
  }));
});

afterEach(() => {
  vi.unstubAllGlobals();
  delete process.env.SUPABASE_SNAPSHOT_URL;
  delete process.env.SUPABASE_SNAPSHOT_SERVICE_ROLE_KEY;
  delete process.env.SESSION_SECRET;
});

describe("dedicated Arc snapshot store", () => {
  it("uses new secret keys only in the apikey header and legacy keys as bearer tokens", async () => {
    await savedWorkspace("builder-a", appId);
    expect(requestHeaders[0]).toMatchObject({ apikey: "test-service-key", authorization: "Bearer test-service-key" });
    process.env.SUPABASE_SNAPSHOT_SERVICE_ROLE_KEY = "sb_secret_test";
    await savedWorkspace("builder-a", appId);
    expect(requestHeaders[1]).toMatchObject({ apikey: "sb_secret_test" });
    expect(requestHeaders[1]).not.toHaveProperty("authorization");
  });
  it("returns a saved workspace without asking Arc Studio and isolates its owner", async () => {
    await saveWorkspace("builder-a", appId, {
      appName: "Lending protocol", studioUrl: "https://studio.arc.io/apps/example",
      contracts: [{ path: sourcePath, source: target.source, contracts: [target.name], built: true }],
      files: [sourcePath],
    });
    expect((await savedWorkspace("builder-a", appId))?.contracts[0]?.contracts).toEqual(["Vault"]);
    expect(await savedWorkspace("builder-b", appId)).toBeNull();
  });
  it("reuses an immutable build and signs only its selected object", async () => {
    const prepared = await saveSnapshot("builder-a", appId, target, []);
    expect(prepared.snapshotHash).toMatch(/^[0-9a-f]{64}$/);
    expect(prepared.capturedAt).toBe("2026-10-20T12:00:00Z");
    expect(objects.size).toBe(2); // plain and installed-runtime variants
    const reused = await saveSnapshot("builder-a", appId, target, []);
    expect(reused.snapshotId).toBe(prepared.snapshotId);
    expect(rows).toHaveLength(1);
    expect((await savedSnapshot("builder-a", appId, sourcePath, target.name))?.snapshotHash).toBe(prepared.snapshotHash);
    const launch = await launchSnapshot("builder-a", appId, sourcePath, target.name, prepared.snapshotId as string);
    expect(launch.snapshotHash).toBe(prepared.snapshotHash);
    expect(launch.installedArtifactUrl).toContain("/storage/v1/object/sign/arc-snapshots/");
    expect(requests.filter((request) => request.includes("/object/sign/"))).toHaveLength(2);
    await launchSnapshot("builder-a", appId, sourcePath, target.name, prepared.snapshotId as string);
    expect(requests.filter((request) => request.includes("/object/sign/"))).toHaveLength(4);
  });

  it("isolates builders and rejects a changed stored artifact", async () => {
    const prepared = await saveSnapshot("builder-a", appId, target, []);
    expect(await savedSnapshot("builder-b", appId, sourcePath, target.name)).toBeNull();
    await expect(launchSnapshot("builder-b", appId, sourcePath, target.name, prepared.snapshotId as string)).rejects.toThrow("unavailable");
    objects.set(rows[0]!.storage_path, "{}\n");
    await expect(savedSnapshot("builder-a", appId, sourcePath, target.name)).rejects.toThrow("hash check");
  });

  it("fails clearly when an artifact is missing and never launches another build", async () => {
    const prepared = await saveSnapshot("builder-a", appId, target, []);
    objects.delete(rows[0]!.storage_path);
    await expect(launchSnapshot("builder-a", appId, sourcePath, target.name, prepared.snapshotId as string))
      .rejects.toThrow("HTTP 404");
    expect(requests.filter((request) => request.includes("/object/sign/"))).toHaveLength(0);
  });

  it("rejects an oversized compiler artifact before upload", async () => {
    await expect(saveSnapshot("builder-a", appId, { ...target, source: "x".repeat(4 * 1024 * 1024) }, []))
      .rejects.toThrow("4 MB snapshot limit");
    expect(objects.size).toBe(0);
  });
});


it("reprepares legacy name-only deployment snapshots and refuses to launch them", async () => {
  const deployed = { ...target, deployment: { address: "0x00000000000000000000000000000000000000de", chainId: target.chainId } };
  const prepared = await saveSnapshot("builder-a", appId, deployed, []);
  expect((await savedSnapshot("builder-a", appId, sourcePath, target.name))?.deployment).toEqual(deployed.deployment);
  const row = rows[0]!;
  const legacy = JSON.parse(objects.get(row.storage_path)!);
  delete legacy.deployment_source_path;
  const body = JSON.stringify(legacy);
  row.digest = createHash("sha256").update(body).digest("hex");
  objects.set(row.storage_path, body);
  expect(await savedSnapshot("builder-a", appId, sourcePath, target.name)).toBeNull();
  await expect(launchSnapshot("builder-a", appId, sourcePath, target.name, prepared.snapshotId!))
    .rejects.toThrow(/Refresh the build/);
  expect(requests.filter((request) => request.includes("/object/sign/"))).toHaveLength(0);
});

"use client";

import { ArcStudioApp } from "@aomi-labs/arc-studio-fuzz-core";
import { ChevronRight, File, FileCode2, Folder, FolderOpen, Lock } from "lucide-react";
import { useMemo, useState } from "react";

interface Node {
  name: string;
  /** Raw sandbox path for files; folder key for folders. */
  path: string;
  children?: Node[];
}

/** Folders that are dependencies or build output: listed, but closed until asked for. */
export const COLLAPSED = new Set([".agents", ".git", "lib", "node_modules", "out", "cache", "broadcast", "dist"]);

export function FileTree({
  files,
  openPath,
  onOpen,
  onPrefetch,
}: {
  files: string[];
  openPath?: string;
  onOpen: (path: string) => void;
  /** Called on hover so the file is usually loaded before the click lands. */
  onPrefetch?: (path: string) => void;
}) {
  const root = useMemo(() => {
    const top: Node = { name: "", path: "", children: [] };
    for (const raw of files) {
      const parts = ArcStudioApp.workspacePath(raw).split("/");
      let node = top;
      parts.forEach((part, index) => {
        const leaf = index === parts.length - 1;
        const key = leaf ? raw : parts.slice(0, index + 1).join("/");
        let child = node.children?.find((c) => c.name === part && Boolean(c.children) === !leaf);
        if (!child) {
          child = { name: part, path: key, ...(leaf ? {} : { children: [] }) };
          node.children?.push(child);
        }
        node = child;
      });
    }
    const sort = (node: Node) => {
      node.children?.sort((a, b) =>
        Boolean(a.children) === Boolean(b.children) ? a.name.localeCompare(b.name) : a.children ? -1 : 1,
      );
      node.children?.forEach(sort);
    };
    sort(top);
    return top;
  }, [files]);

  const [open, setOpen] = useState<Record<string, boolean>>({});
  const isOpen = (node: Node) => open[node.path] ?? !COLLAPSED.has(node.name);

  const render = (node: Node, depth: number): React.ReactNode =>
    node.children ? (
      <li key={node.path}>
        <button
          onClick={() => setOpen((state) => ({ ...state, [node.path]: !isOpen(node) }))}
          className="flex w-full items-center gap-1.5 rounded-sm px-2 py-1 text-left text-ink-muted hover:bg-hover"
          style={{ paddingLeft: 8 + depth * 14 }}
        >
          <ChevronRight className={`size-3.5 shrink-0 transition ${isOpen(node) ? "rotate-90" : ""}`} />
          {isOpen(node) ? (
            <FolderOpen className="size-4 shrink-0 text-accent" />
          ) : (
            <Folder className="size-4 shrink-0 text-ink-muted" />
          )}
          <span className="truncate">{node.name}</span>
        </button>
        {isOpen(node) && <ul>{node.children.map((child) => render(child, depth + 1))}</ul>}
      </li>
    ) : (
      <li key={node.path}>
        {ArcStudioApp.isSensitive(node.path) ? (
          <div
            className="flex items-center gap-1.5 px-2 py-1 text-ink-muted/60"
            style={{ paddingLeft: 30 + depth * 14 }}
            title="May hold secrets; not shown"
          >
            <Lock className="size-3.5 shrink-0" />
            <span className="truncate">{node.name}</span>
          </div>
        ) : (
          <button
            onClick={() => onOpen(node.path)}
            onMouseEnter={() => onPrefetch?.(node.path)}
            title={ArcStudioApp.workspacePath(node.path)}
            className={`flex w-full items-center gap-1.5 rounded-sm px-2 py-1 text-left ${
              openPath === node.path ? "bg-accent-subtle text-ink" : "text-ink hover:bg-hover"
            }`}
            style={{ paddingLeft: 30 + depth * 14 }}
          >
            {node.name.endsWith(".sol") ? (
              <FileCode2 className="size-3.5 shrink-0 text-accent" />
            ) : (
              <File className="size-3.5 shrink-0 text-ink-muted" />
            )}
            <span className="truncate">{node.name}</span>
          </button>
        )}
      </li>
    );

  return <ul className="pb-4 text-[13px]">{root.children?.map((child) => render(child, 0))}</ul>;
}

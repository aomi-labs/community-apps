/** Keep upstream gateway pages out of the contract preview. */
export function studioErrorMessage(error: unknown): string {
  const message = error instanceof Error ? error.message : String(error);
  const gateway = message.match(/^(?:GET|POST) \/api\/\S+ failed: (\d{3})\b/);
  if (gateway && /<!doctype html|<html[\s>]/i.test(message)) {
    return `Arc Studio is temporarily unavailable (HTTP ${gateway[1]}). Try again shortly.`;
  }
  return message;
}

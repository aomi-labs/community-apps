import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, expect, it } from "vitest";
import type { Event } from "@aomi-labs/client";
import { CampaignTrace } from "@aomi-labs/arc-studio-fuzz-core";
import { CampaignProgress } from "./campaign-explorer";

afterEach(cleanup);

const failed = {
  type: "tool_complete", sequence: 1, id: "start", tool_name: "arc_fuzz_start",
  result: JSON.stringify({ error: { code: "tool_call_failed", message: "unknown field `status`" } }),
} as unknown as Event;

it("shows rejected startup arguments while the model turn remains processing", () => {
  const { rerender } = render(<CampaignProgress trace={new CampaignTrace([failed])} busy preparing={false} stopped={false} failure={null} />);
  expect(screen.getByRole("heading").textContent).toBe("Startup failed");
  expect(screen.getByRole("alert").textContent).toContain("unknown field `status`");
  expect(screen.getByRole("status").textContent).toContain("correct it and retry");
  const retry = { type: "message", sequence: 2, sender: "assistant", tool_name: "arc_fuzz_start", tool_call_id: "retry", tool_arguments: {} } as unknown as Event;
  rerender(<CampaignProgress trace={new CampaignTrace([failed, retry])} busy preparing={false} stopped={false} failure={null} />);
  expect(screen.queryByRole("alert")).toBeNull();
  expect(screen.getByRole("status").textContent).toBe("Building the first execution batch");
});

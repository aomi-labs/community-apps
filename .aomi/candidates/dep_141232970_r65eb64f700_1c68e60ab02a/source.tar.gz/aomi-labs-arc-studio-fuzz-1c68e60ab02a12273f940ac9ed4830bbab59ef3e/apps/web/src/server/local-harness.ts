import "@tanstack/react-start/server-only";

import { readFile } from "node:fs/promises";
import { join } from "node:path";

import type { SeedWorld } from "@aomi-labs/arc-studio-fuzz-core";

import type { TargetData } from "@/app/actions";

/** One contract of a seeded protocol, at its real address. */
export interface HarnessContract {
  name: string;
  address: string;
  /** The contract under test; the others are its dependencies. */
  target: boolean;
}

/** How the browser reaches the self-hosted stack, and as whom. */
export interface HarnessStack {
  /** The web app's own origin; the dev server proxies /v1 and /api/thread to the stack. */
  webOrigin: string;
  apiUrl: string;
  backendUrl: string;
  applicationId: number;
  /** User bearer for api-server (agent calls), minted by scripts/harness-bearers.mjs. */
  portalBearer: string;
  /** User bearer for the backend's thread routes (model pin, world seeding). */
  backendBearer: string;
  /** When both bearers expire (epoch ms). */
  expires: number;
}

/** Everything the harness workspace needs: the protocol, its seed, and the stack. */
export interface HarnessProtocol {
  target: TargetData;
  contracts: HarnessContract[];
  /** Source files split out of the artifact, in artifact order. */
  files: Array<{ path: string; source: string }>;
  seed: SeedWorld;
  /** Where the arc-studio-fuzzer app downloads the artifact: this web app. */
  artifactUrl: string;
  stack: HarnessStack;
}

/** The artifact `scripts/seed-protocol.mjs` writes next to the seed. */
interface ProtocolArtifact {
  name: string;
  source_code: string;
  abi: string;
  deployed_bytecode: string;
  chain_id: number;
  deployment: { address: string; chain_id: number; installed?: boolean };
  protocol: Array<{ name: string; address: string }>;
}

/** What `scripts/harness-bearers.mjs` writes. */
interface Bearers {
  portal: string;
  backend: string;
  expires: number;
}

const LOCAL_ORIGIN = /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/;
const FILE_HEADER = /^\/\/ File: (.+)$/gm;
/** Bearers this close to expiry would die mid-campaign. */
const BEARER_MARGIN_MS = 60_000;

/**
 * A self-hosted Aomi stack with a protocol seeded by `scripts/seed-protocol.mjs`.
 * Development only: it reads the seed directory from disk, and the user
 * bearers it hands the browser were minted outside this process by
 * `scripts/harness-bearers.mjs`, so the web app never holds the operator key.
 * Off in production builds and when HARNESS_SEED_DIR is unset.
 */
export class LocalHarness {
  private constructor(
    readonly dir: string,
    readonly apiUrl: string,
    readonly backendUrl: string,
    readonly applicationId: number,
  ) {}

  static current(): LocalHarness | null {
    if (process.env.NODE_ENV === "production") return null;
    const dir = process.env.HARNESS_SEED_DIR;
    if (!dir) return null;
    const apiUrl = (process.env.HARNESS_API_URL ?? "http://127.0.0.1:8182").replace(/\/+$/, "");
    const backendUrl = (process.env.HARNESS_BACKEND_URL ?? "http://127.0.0.1:8180").replace(/\/+$/, "");
    for (const [name, url] of [
      ["HARNESS_API_URL", apiUrl],
      ["HARNESS_BACKEND_URL", backendUrl],
    ]) {
      if (!LOCAL_ORIGIN.test(url)) throw new Error(`${name} must be a local http origin, got ${url}`);
    }
    const applicationId = Number(process.env.HARNESS_APPLICATION_ID ?? 302);
    if (!Number.isSafeInteger(applicationId) || applicationId <= 0) {
      throw new Error("HARNESS_APPLICATION_ID must be a positive integer");
    }
    return new LocalHarness(dir, apiUrl, backendUrl, applicationId);
  }

  /**
   * Forwards a browser request to the stack so the page stays same-origin:
   * `/v1/*` (agent calls) to api-server, `/api/thread/*` (model pin, world
   * seeding) to the backend. Streams the response through, SSE included.
   */
  async forward(request: Request, upstream: "api" | "backend"): Promise<Response> {
    const url = new URL(request.url);
    const target = new URL(url.pathname + url.search, upstream === "api" ? this.apiUrl : this.backendUrl);
    const headers = new Headers(request.headers);
    for (const name of ["host", "connection", "accept-encoding"]) headers.delete(name);
    const init: RequestInit & { duplex: "half" } = {
      method: request.method,
      headers,
      body: request.method === "GET" || request.method === "HEAD" ? undefined : request.body,
      duplex: "half",
      redirect: "manual",
      signal: request.signal,
    };
    let response: Response;
    try {
      response = await fetch(target, init);
    } catch (error) {
      const reason = error instanceof Error ? error.message : String(error);
      return new Response(`The harness stack at ${target.origin} is not reachable: ${reason}`, { status: 502 });
    }
    const out = new Headers(response.headers);
    for (const name of ["content-encoding", "content-length", "transfer-encoding"]) out.delete(name);
    return new Response(response.body, { status: response.status, statusText: response.statusText, headers: out });
  }

  /** Route handlers that forward every method to `upstream`, or 404 when the harness is off. */
  static handlers(upstream: "api" | "backend") {
    const forward = ({ request }: { request: Request }) =>
      LocalHarness.current()?.forward(request, upstream) ?? Promise.resolve(new Response("Not found", { status: 404 }));
    return { GET: forward, POST: forward, PUT: forward, PATCH: forward, DELETE: forward, OPTIONS: forward };
  }

  /** The artifact as the fuzzer app downloads it, byte for byte. */
  artifact(): Promise<string> {
    return readFile(join(this.dir, "artifact.json"), "utf8");
  }

  /** The seeded protocol for the page, with links and bearers for `webOrigin`. */
  async protocol(webOrigin: string): Promise<HarnessProtocol> {
    const [seed, artifact, bearers] = await Promise.all([
      this.json<SeedWorld>("seed.json"),
      this.json<ProtocolArtifact>("artifact.json"),
      this.json<Bearers>("bearers.json", "run `E2E_AUTH_KEY=... node scripts/harness-bearers.mjs` first"),
    ]);
    if (!bearers.portal || !bearers.backend || !(bearers.expires > Date.now() + BEARER_MARGIN_MS)) {
      throw new Error("bearers.json is missing a bearer or about to expire; run `node scripts/harness-bearers.mjs` again");
    }
    const sourcePath = `src/${artifact.name}.sol`;
    return {
      target: {
        name: artifact.name,
        sourcePath,
        source: artifact.source_code,
        abi: JSON.parse(artifact.abi) as TargetData["abi"],
        deployedBytecode: artifact.deployed_bytecode,
        chainId: artifact.chain_id,
        deployment: { address: artifact.deployment.address, chainId: artifact.deployment.chain_id },
        protocol: artifact.protocol.map(({ name, address }) => ({ name, address })),
      },
      contracts: [
        { name: artifact.name, address: artifact.deployment.address, target: true },
        ...artifact.protocol.map(({ name, address }) => ({ name, address, target: false })),
      ],
      files: LocalHarness.files(artifact.source_code),
      seed,
      artifactUrl: `${webOrigin}/api/harness/artifact`,
      stack: {
        webOrigin,
        apiUrl: this.apiUrl,
        backendUrl: this.backendUrl,
        applicationId: this.applicationId,
        portalBearer: bearers.portal,
        backendBearer: bearers.backend,
        expires: bearers.expires,
      },
    };
  }

  /** The `// File: <path>` sections the seed script joins the sources with. */
  static files(source: string): Array<{ path: string; source: string }> {
    const headers = [...source.matchAll(FILE_HEADER)];
    if (headers.length === 0) return [{ path: "source.sol", source }];
    return headers.map((header, index) => ({
      path: header[1] as string,
      source: source
        .slice((header.index ?? 0) + header[0].length + 1, headers[index + 1]?.index ?? source.length)
        .trimEnd(),
    }));
  }

  private async json<T>(name: string, hint?: string): Promise<T> {
    const path = join(this.dir, name);
    try {
      return JSON.parse(await readFile(path, "utf8")) as T;
    } catch (error) {
      const reason = error instanceof Error ? error.message : String(error);
      throw new Error(`${path}: ${reason}${hint ? ` (${hint})` : ""}`);
    }
  }
}

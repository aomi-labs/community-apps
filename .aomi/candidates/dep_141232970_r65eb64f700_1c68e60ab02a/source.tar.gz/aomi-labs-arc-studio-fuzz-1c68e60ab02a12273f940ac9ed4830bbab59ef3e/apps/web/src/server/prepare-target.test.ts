import { beforeEach, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  launch: vi.fn(),
  saved: vi.fn(),
  save: vi.fn(),
  timed: vi.fn(async (_label: string, work: () => Promise<unknown>) => work()),
}));

vi.mock("@tanstack/react-start/server-only", () => ({}));
vi.mock("@/server/snapshot-store", () => ({
  launchSnapshot: mocks.launch,
  savedSnapshot: mocks.saved,
  saveSnapshot: mocks.save,
}));
vi.mock("@/server/studio-session", () => ({ StudioSession: { timed: mocks.timed } }));

import type { StudioSession } from "@/server/studio-session";
import { prepareTarget } from "./prepare-target";

const selection = {
  appId: "11111111-1111-4111-8111-111111111111",
  sourcePath: "contracts/Vault.sol",
  contract: "Vault",
};
const target = {
  name: "Vault", sourcePath: selection.sourcePath, source: "contract Vault {}",
  abi: [], deployedBytecode: "0x6000", chainId: 5042,
};

beforeEach(() => vi.clearAllMocks());

it("launches the selected snapshot without any Arc Studio request", async () => {
  const app = vi.fn(() => { throw new Error("Arc Studio must not be called at Run"); });
  const session = { token: "arc-token", app } as unknown as StudioSession;
  mocks.launch.mockResolvedValue({ ...target, snapshotId: "pinned" });
  const result = await prepareTarget(session, { ...selection, snapshotId: "pinned" });
  expect(result.snapshotId).toBe("pinned");
  expect(mocks.launch).toHaveBeenCalledWith("arc-token", selection.appId, selection.sourcePath, selection.contract, "pinned");
  expect(app).not.toHaveBeenCalled();
  expect(mocks.saved).not.toHaveBeenCalled();
  expect(mocks.timed).not.toHaveBeenCalled();
});

it("reuses a saved preview and calls Arc only for an explicit refresh", async () => {
  const arc = { target: vi.fn().mockResolvedValue(target) };
  const app = vi.fn().mockResolvedValue(arc);
  const session = { token: "arc-token", app } as unknown as StudioSession;
  mocks.saved.mockResolvedValue({ ...target, snapshotId: "saved" });
  expect((await prepareTarget(session, selection)).snapshotId).toBe("saved");
  expect(app).not.toHaveBeenCalled();
  mocks.save.mockResolvedValue({ ...target, snapshotId: "new" });
  expect((await prepareTarget(session, { ...selection, refresh: true })).snapshotId).toBe("new");
  expect(arc.target).toHaveBeenCalledWith(selection.sourcePath, selection.contract);
  expect(app).toHaveBeenCalledTimes(1);
});

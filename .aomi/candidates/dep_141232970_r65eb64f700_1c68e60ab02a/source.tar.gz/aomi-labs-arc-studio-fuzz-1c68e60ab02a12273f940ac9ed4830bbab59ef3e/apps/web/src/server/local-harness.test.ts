import { mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, beforeEach, expect, test, vi } from "vitest";

import { LocalHarness } from "./local-harness";

const seed = { forks: [{ chain_id: 5_042_002, overrides: [{ address: "0x1", code: "0x60" }] }] };
const artifact = {
  name: "LendingPool",
  source_code: "// File: src/LendingPool.sol\ncontract LendingPool {}\n// File: src/Token.sol\ncontract Token {}\n",
  abi: JSON.stringify([{ type: "function", name: "supply", stateMutability: "payable", inputs: [] }]),
  deployed_bytecode: "0x60",
  chain_id: 5_042_002,
  deployment: { address: "0x00000000000000000000000000000000000000a1", chain_id: 5_042_002, installed: true },
  protocol: [{ name: "Token", address: "0x00000000000000000000000000000000000000a2", abi: "[]" }],
};
let dir: string;
beforeEach(() => {
  dir = mkdtempSync(join(tmpdir(), "harness-"));
  writeFileSync(join(dir, "seed.json"), JSON.stringify(seed));
  writeFileSync(join(dir, "artifact.json"), JSON.stringify(artifact));
  writeFileSync(join(dir, "bearers.json"), JSON.stringify({ portal: "p", backend: "b", expires: Date.now() + 3_600_000 }));
  vi.stubEnv("NODE_ENV", "development");
  vi.stubEnv("HARNESS_SEED_DIR", dir);
});
afterEach(() => {
  vi.unstubAllEnvs();
  rmSync(dir, { recursive: true, force: true });
});

test("off without a seed directory and in production builds", () => {
  vi.stubEnv("HARNESS_SEED_DIR", "");
  expect(LocalHarness.current()).toBeNull();
  vi.stubEnv("HARNESS_SEED_DIR", dir);
  vi.stubEnv("NODE_ENV", "production");
  expect(LocalHarness.current()).toBeNull();
});

test("only a local stack is allowed", () => {
  vi.stubEnv("HARNESS_API_URL", "https://api-staging.aomi.dev");
  expect(() => LocalHarness.current()).toThrow(/HARNESS_API_URL must be a local http origin/);
});

test("reads the seeded protocol, splits its sources and links the artifact to this web app", async () => {
  const protocol = await LocalHarness.current()!.protocol("http://127.0.0.1:3108");
  expect(protocol.target).toMatchObject({
    name: "LendingPool",
    sourcePath: "src/LendingPool.sol",
    chainId: 5_042_002,
    deployment: { address: artifact.deployment.address, chainId: 5_042_002 },
    protocol: [{ name: "Token", address: artifact.protocol[0]!.address }],
  });
  expect(protocol.contracts.map((c) => [c.name, c.target])).toEqual([["LendingPool", true], ["Token", false]]);
  expect(protocol.files).toEqual([
    { path: "src/LendingPool.sol", source: "contract LendingPool {}" },
    { path: "src/Token.sol", source: "contract Token {}" },
  ]);
  expect(protocol.seed).toEqual(seed);
  expect(protocol.artifactUrl).toBe("http://127.0.0.1:3108/api/harness/artifact");
  expect(protocol.stack).toMatchObject({
    webOrigin: "http://127.0.0.1:3108",
    apiUrl: "http://127.0.0.1:8182",
    backendUrl: "http://127.0.0.1:8180",
    applicationId: 302,
    portalBearer: "p",
    backendBearer: "b",
  });
  expect(JSON.parse(await LocalHarness.current()!.artifact())).toEqual(artifact);
});

test("refuses expired bearers and says how to mint new ones", async () => {
  writeFileSync(join(dir, "bearers.json"), JSON.stringify({ portal: "p", backend: "b", expires: Date.now() + 10_000 }));
  await expect(LocalHarness.current()!.protocol("http://127.0.0.1:3108")).rejects.toThrow(/harness-bearers\.mjs/);
  rmSync(join(dir, "bearers.json"));
  await expect(LocalHarness.current()!.protocol("http://127.0.0.1:3108")).rejects.toThrow(/harness-bearers\.mjs/);
});

test("a source without file headers is one file", () => {
  expect(LocalHarness.files("contract A {}")).toEqual([{ path: "source.sol", source: "contract A {}" }]);
});

test("forwards browser requests to the stack and reports an unreachable stack", async () => {
  const local = LocalHarness.current()!;
  const calls: Array<{ url: string; method: string; authorization: string | null; body: string | null }> = [];
  vi.stubGlobal(
    "fetch",
    vi.fn(async (url: URL, init: RequestInit) => {
      calls.push({ url: String(url), method: init.method ?? "GET", authorization: new Headers(init.headers).get("authorization"), body: init.body ? await new Response(init.body as ReadableStream).text() : null });
      return new Response("event: ok\n\n", { status: 201, headers: { "content-type": "text/event-stream", "content-encoding": "gzip" } });
    }),
  );
  try {
    const seeded = await local.forward(
      new Request("http://127.0.0.1:3108/api/thread/sim/world?user_state=%7B%7D", { method: "POST", headers: { authorization: "Bearer b", host: "127.0.0.1:3108" }, body: "{}" }),
      "backend",
    );
    expect(calls).toEqual([{ url: "http://127.0.0.1:8180/api/thread/sim/world?user_state=%7B%7D", method: "POST", authorization: "Bearer b", body: "{}" }]);
    expect(seeded.status).toBe(201);
    expect(seeded.headers.get("content-type")).toBe("text/event-stream");
    expect(seeded.headers.get("content-encoding")).toBeNull();
    expect(await seeded.text()).toBe("event: ok\n\n");
    await local.forward(new Request("http://127.0.0.1:3108/v1/agent/chat"), "api");
    expect(calls[1]?.url).toBe("http://127.0.0.1:8182/v1/agent/chat");
    vi.mocked(fetch).mockRejectedValueOnce(new Error("ECONNREFUSED"));
    const down = await local.forward(new Request("http://127.0.0.1:3108/v1/agent/chat"), "api");
    expect(down.status).toBe(502);
    expect(await down.text()).toContain("http://127.0.0.1:8182");
  } finally {
    vi.unstubAllGlobals();
  }
});

test("the forwarding routes are off without the harness", async () => {
  vi.stubEnv("HARNESS_SEED_DIR", "");
  const response = await LocalHarness.handlers("api").GET({ request: new Request("http://127.0.0.1:3108/v1/agent/chat") });
  expect(response.status).toBe(404);
});

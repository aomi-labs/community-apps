import { createFileRoute, Link } from "@tanstack/react-router";
import { workspace } from "@/server/loaders";
import { FuzzWorkspace } from "@/components/fuzz-workspace";
export const Route = createFileRoute("/apps/$appId")({
  loader: ({ params }) => workspace({ data: params }),
  component: App,
});
function App() {
  const data = Route.useLoaderData();
  if (data.error)
    return (
      <main className="p-8">
        <p role="alert">{data.error}</p>
        <Link to="/">Back to apps</Link>
      </main>
    );
  return <FuzzWorkspace key={data.appId} {...data} />;
}

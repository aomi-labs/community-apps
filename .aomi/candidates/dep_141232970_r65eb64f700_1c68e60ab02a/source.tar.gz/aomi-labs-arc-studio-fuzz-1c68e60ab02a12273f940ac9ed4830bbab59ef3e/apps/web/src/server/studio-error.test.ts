import { expect, test } from "vitest";
import { studioErrorMessage } from "./studio-error";

test("hides an upstream gateway's HTML response", () => {
  expect(studioErrorMessage(new Error("POST /api/sandbox-file-batch-read failed: 502 <!DOCTYPE html><html>bad gateway</html>")))
    .toBe("Arc Studio is temporarily unavailable (HTTP 502). Try again shortly.");
});

test("keeps actionable build errors", () => {
  expect(studioErrorMessage(new Error("Build this contract before running."))).toBe("Build this contract before running.");
});

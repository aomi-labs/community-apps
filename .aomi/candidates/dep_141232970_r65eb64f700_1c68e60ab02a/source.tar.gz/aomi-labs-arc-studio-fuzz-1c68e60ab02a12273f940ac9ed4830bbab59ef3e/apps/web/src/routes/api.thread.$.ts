import { createFileRoute } from "@tanstack/react-router";

import { LocalHarness } from "@/server/local-harness";

/** Thread routes (model pin, world seeding) from the /harness page, forwarded to the self-hosted backend. Development only. */
export const Route = createFileRoute("/api/thread/$")({
  server: { handlers: LocalHarness.handlers("backend") },
});

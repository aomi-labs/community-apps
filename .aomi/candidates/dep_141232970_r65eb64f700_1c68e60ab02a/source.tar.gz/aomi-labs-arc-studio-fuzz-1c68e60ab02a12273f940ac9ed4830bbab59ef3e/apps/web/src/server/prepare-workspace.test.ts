import { beforeEach, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({ saved: vi.fn(), save: vi.fn() }));
vi.mock("@tanstack/react-start/server-only", () => ({}));
vi.mock("./snapshot-store", () => ({ savedWorkspace: mocks.saved, saveWorkspace: mocks.save }));
vi.mock("./studio-session", () => ({ StudioSession: class {} }));

import type { StudioSession } from "./studio-session";
import { loadWorkspace } from "./prepare-workspace";

const appId = "11111111-1111-4111-8111-111111111111";
const cached = { appName: "Lending", studioUrl: "https://studio.arc.io/apps/example",
  contracts: [], files: [], capturedAt: "2026-10-20T12:00:00Z" };

beforeEach(() => vi.clearAllMocks());

it("opens a previously prepared workspace without an Arc Studio call", async () => {
  const client = vi.fn(() => { throw new Error("Arc Studio must not be called on a cache hit"); });
  const app = vi.fn(client);
  const session = { token: "arc-token", client, app } as unknown as StudioSession;
  mocks.saved.mockResolvedValue(cached);
  expect(await loadWorkspace(session, appId)).toEqual(cached);
  expect(client).not.toHaveBeenCalled();
  expect(app).not.toHaveBeenCalled();
  expect(mocks.save).not.toHaveBeenCalled();
});

it("updates the manifest only when Refresh is explicit", async () => {
  const app = { webUrl: cached.studioUrl, contracts: vi.fn().mockResolvedValue([]), files: vi.fn().mockResolvedValue([]) };
  const session = { token: "arc-token", client: vi.fn(() => ({ listApps: vi.fn().mockResolvedValue([{ id: appId, description: "Lending" }]) })),
    app: vi.fn().mockResolvedValue(app) } as unknown as StudioSession;
  mocks.saved.mockResolvedValue(cached);
  await loadWorkspace(session, appId, true);
  expect(session.app).toHaveBeenCalledWith(appId, { fresh: true });
  expect(mocks.save).toHaveBeenCalledOnce();
  expect(mocks.saved).not.toHaveBeenCalled();
});

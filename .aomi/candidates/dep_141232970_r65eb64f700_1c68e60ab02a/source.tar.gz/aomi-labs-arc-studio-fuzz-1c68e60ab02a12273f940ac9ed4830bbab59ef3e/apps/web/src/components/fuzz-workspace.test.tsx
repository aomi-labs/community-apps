import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, expect, test, vi } from "vitest";
import type { TargetData } from "@/app/actions";
import { FuzzWorkspace } from "./fuzz-workspace";

const runtime = createContext("");
const calls = vi.hoisted(() => ({ send: vi.fn(), load: vi.fn(), resume: vi.fn(async () => null as { address: string; session: () => Promise<string> } | null), next: 0 }));
vi.mock("@aomi-labs/react", () => ({
  AomiRuntimeProvider: ({ children }: { children: ReactNode }) => {
    const [id] = useState(() => `thread-${++calls.next}`);
    return <runtime.Provider value={id}>{children}</runtime.Provider>;
  },
}));
vi.mock("@tanstack/react-router", () => ({ useRouter: () => ({ invalidate: vi.fn() }), Link: ({ children, to }: { children: ReactNode; to: string }) => <a href={to}>{children}</a> }));
vi.mock("@/lib/aomi-account", () => ({ AomiAccount: { resume: calls.resume }, guestSession: () => async () => null }));
vi.mock("@/app/actions", () => ({ loadTarget: calls.load }));
// Keep the real workspace lifecycle; substitute only the network-facing panel.
// A mounted campaign must retain its thread and continue while another is visible.
vi.mock("@/components/fuzz-panel", () => ({
  FuzzPanel: ({ target }: { target: TargetData }) => {
    const thread = useContext(runtime);
    const [started, start] = useState(false);
    useEffect(() => {
      if (!started) return;
      const timer = setInterval(() => calls.send(target.name, thread), 20);
      return () => clearInterval(timer);
    }, [started, target.name, thread]);
    return <button onClick={() => start(true)}>{target.name} {thread} {started ? "running" : "start"}</button>;
  },
}));

const savedRuns = new Map<string, string>();
beforeEach(() => {
  vi.stubGlobal("localStorage", { getItem: (key: string) => savedRuns.get(key) ?? null, setItem: (key: string, value: string) => savedRuns.set(key, value) });
});
afterEach(() => { cleanup(); savedRuns.clear(); vi.clearAllMocks(); vi.unstubAllGlobals(); });

test("A keeps its thread and continuation through B loading and A → B → A", async () => {
  const targets = ["A", "B"].map((name) => ({
    name, sourcePath: `${name}.sol`, source: `contract ${name} {}`, abi: [],
    deployedBytecode: "0x00", chainId: 5042002,
  }));
  let resolveB!: (value: { ok: true; value: TargetData }) => void;
  calls.load.mockImplementation(async ({ data: { contract } }) => contract === "B"
    ? new Promise((resolve) => { resolveB = resolve; })
    : { ok: true, value: targets[0] });
  render(<QueryClientProvider client={new QueryClient()}><FuzzWorkspace appId="test" appName="Protocol" studioUrl="https://example.com"
    files={[]} contracts={targets.map((target) => ({ path: target.sourcePath, source: target.source,
      contracts: [target.name], built: true }))} /></QueryClientProvider>);
  fireEvent.click(screen.getByRole("button", { name: /A A.sol built/ }));
  fireEvent.click(await screen.findByRole("button", { name: /A thread-\d+ start/ }));
  const a = screen.getByRole("button", { name: /A thread-\d+ running/ }).textContent!;
  fireEvent.click(screen.getByRole("button", { name: /B B.sol built/ }));
  await waitFor(() => expect(calls.send).toHaveBeenCalledWith("A", a.split(" ")[1]));
  await act(async () => resolveB({ ok: true, value: targets[1]! }));
  fireEvent.click(await screen.findByRole("button", { name: /B thread-\d+ start/ }));
  const b = screen.getByRole("button", { name: /B thread-\d+ running/ }).textContent!;
  expect(b.split(" ")[1]).not.toBe(a.split(" ")[1]);
  fireEvent.click(screen.getByRole("button", { name: /A A.sol built/ }));
  expect(await screen.findByRole("button", { name: a })).toBeTruthy();
  await waitFor(() => expect(calls.send).toHaveBeenCalledWith("B", b.split(" ")[1]));
});

test("saved account campaigns stay listed without mounting an authenticated runtime", async () => {
  const target: TargetData = { name: "A", sourcePath: "A.sol", source: "contract A {}", abi: [], deployedBytecode: "0x00", chainId: 5042002 };
  const address = "0x8b400FaEFC043C2F68E6243e49D7dE66564D63f9";
  const key = JSON.stringify(["https://chat-staging.aomi.dev", "test", address.toLowerCase()]);
  localStorage.setItem(key, JSON.stringify([{ id: "saved", threadId: "existing", status: "Unavailable", resumes: 1, createdAt: 1, target }]));
  calls.resume.mockResolvedValueOnce({ address, session: vi.fn(async () => "test-bearer") });
  calls.load.mockResolvedValue({ ok: true, value: target });
  const props = { appId: "test", appName: "Protocol", studioUrl: "https://example.com", files: [], contracts: [{ path: "A.sol", source: target.source, contracts: ["A"], built: true }] };
  render(<QueryClientProvider client={new QueryClient()}><FuzzWorkspace {...props} /></QueryClientProvider>);
  const saved = await screen.findByRole("button", { name: /A Incomplete/ });
  expect(screen.queryByRole("button", { name: /A thread-\d+/ })).toBeNull();
  expect(JSON.parse(localStorage.getItem(key)!)[0]).toMatchObject({ threadId: "existing", status: "Incomplete" });
  fireEvent.click(saved);
  expect(await screen.findByRole("button", { name: /A thread-\d+ start/ })).toBeTruthy();
});

test("closing a source tab shows its neighbour, and closing the last tab empties the viewer", async () => {
  const targets: TargetData[] = ["A", "B"].map((name) => ({
    name, sourcePath: `${name}.sol`, source: `contract ${name} {}`, abi: [], deployedBytecode: "0x00", chainId: 5042002,
  }));
  calls.load.mockImplementation(async ({ data: { contract } }) => ({ ok: true, value: targets.find((target) => target.name === contract) }));
  render(<QueryClientProvider client={new QueryClient()}><FuzzWorkspace appId="test" appName="Protocol" studioUrl="https://example.com"
    files={[]} contracts={targets.map((target) => ({ path: target.sourcePath, source: target.source, contracts: [target.name], built: true }))} /></QueryClientProvider>);
  fireEvent.click(screen.getByRole("button", { name: /A A.sol built/ }));
  fireEvent.click(screen.getByRole("button", { name: /B B.sol built/ }));
  expect(screen.getAllByRole("tab", { name: /\.sol/ }).map((tab) => tab.getAttribute("aria-selected"))).toEqual(["false", "true"]);
  fireEvent.click(screen.getByRole("button", { name: "Close B.sol" }));
  expect(screen.queryByRole("tab", { name: "B.sol" })).toBeNull();
  expect(screen.getByRole("tab", { name: "A.sol" }).getAttribute("aria-selected")).toBe("true");
  fireEvent.click(screen.getByRole("button", { name: "Close A.sol" }));
  expect(screen.queryAllByRole("tab", { name: /\.sol/ })).toHaveLength(0);
  expect(screen.getByText("Select a file to view it")).toBeTruthy();
});

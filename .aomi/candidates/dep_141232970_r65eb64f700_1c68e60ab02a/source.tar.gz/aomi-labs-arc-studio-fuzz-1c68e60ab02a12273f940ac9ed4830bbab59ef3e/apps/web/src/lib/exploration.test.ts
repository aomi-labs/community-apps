import { describe, expect, it } from "vitest";
import { CampaignTrace, type TraceRow, type FuzzCampaignReport } from "@aomi-labs/arc-studio-fuzz-core";
import type { Event } from "@aomi-labs/client";
import { exploration, nodeState, campaignPhase } from "./exploration";

const action = {
  label: "Withdraw",
  actor: "attacker",
  function: "withdraw(uint256)",
  arguments: ["10"],
  value: "0",
};
const call = {
  label: "a0",
  from: "0x1",
  to: "0x2",
  data: "0x12340010",
  value: "0",
};
const batch = {
  traces: [
    { id: "1", calls: [call] },
    { id: "2", calls: [call, call] },
  ],
};
const row = (name: string, args: unknown, result: unknown, state: TraceRow["state"] = "complete"): TraceRow => ({
  key: name,
  sequence: 1,
  name,
  arguments: args,
  result,
  state,
});
const start = row("arc_fuzz_start", { actions: [action] }, { next_batch: batch });
const report = (status: FuzzCampaignReport["status"]): FuzzCampaignReport =>
  ({ status, findings: [] }) as unknown as FuzzCampaignReport;

describe("observed exploration", () => {
  it("groups exact call prefixes and keeps executing and queued replays separate", () => {
    const tree = exploration(
      [start, row("sim_replay_traces", { traces: [batch.traces[0]] }, undefined, "calling")],
      null,
    );
    expect(tree.roots).toHaveLength(1);
    expect(tree.roots[0].children).toHaveLength(1);
    expect(nodeState(tree.roots[0], true)).toBe("Executing");
    expect(nodeState(tree.roots[0], false)).toBe("Awaiting result");
    expect(nodeState(tree.roots[0].children[0], true)).toBe("Queued");
  });

  it("preserves call arguments when a message result omits them", () => {
    const trace = new CampaignTrace([
      {
        type: "message",
        sender: "agent",
        content: "",
        tool_name: "arc_fuzz_start",
        tool_call_id: "start",
        turn_id: "t",
        sequence: 1,
        tool_arguments: JSON.stringify({ actions: [action] }),
      },
      {
        type: "message",
        sender: "agent",
        content: "",
        tool_name: "arc_fuzz_start",
        tool_call_id: "start",
        turn_id: "t",
        sequence: 2,
        tool_result: ["start", JSON.stringify({ next_batch: batch })],
      },
    ] as Event[]);
    expect(exploration(trace.rows, null).roots[0].call.action?.actor).toBe("attacker");
  });

  it("never treats a revert or engine error as a confirmed finding", () => {
    for (const [status, expected] of [
      ["reverted", "Reverted"],
      ["engine_error", "Simulation error"],
    ]) {
      const tree = exploration(
        [
          start,
          row("sim_replay_traces", batch, {
            traces: [
              {
                id: "1",
                statuses: [status],
                balances: [{ before: "1", after: "2" }],
                probes: [],
              },
            ],
          }),
        ],
        null,
      );
      expect(nodeState(tree.roots[0], false)).toBe(expected);
      expect(tree.roots[0].confirmed).toEqual([]);
      expect(tree.roots[0].replays[0].balances).toHaveLength(1);
    }
  });

  it("does not count a re-sent batch as another replay and restores evidence from round input", () => {
    const tree = exploration(
      [start, start, row("arc_fuzz_round", { replay: [{ id: "1", statuses: ["succeeded"] }] }, { next_batch: batch })],
      null,
    );
    expect(tree.replays).toHaveLength(2);
    expect(nodeState(tree.roots[0], false)).toBe("Executed");
  });

  it("snapshots accepted plan labels per batch and does not adopt a rejected revision", () => {
    const revised = { ...action, function: "deposit()", arguments: [] };
    const newBatch = {
      traces: [{ id: "3", calls: [{ ...call, data: "0x5678" }] }],
    };
    for (const revision of ["applied", "rejected", "deferred"]) {
      const tree = exploration(
        [start, row("arc_fuzz_round", { plan: { actions: [revised] } }, { revision, next_batch: newBatch })],
        null,
      );
      expect(tree.replays[0].calls[0].action?.function).toBe(action.function);
      expect(tree.replays[2].calls[0].action?.function).toBe(
        revision === "applied" ? revised.function : action.function,
      );
    }
  });

  it("requires a matching reported finding before marking a path confirmed", () => {
    const tree = exploration([start], {
      findings: [{ property: "No theft", minimized_trace: [action], reproductions: 2 }],
    } as FuzzCampaignReport);
    expect(nodeState(tree.roots[0], false)).toBe("Confirmed finding");
    expect(tree.roots[0].children[0].confirmed).toEqual([]);
  });

  it("matches a named primary contract to the engine's canonical finding", () => {
    const namedStart = row("arc_fuzz_start", { actions: [{ ...action, contract: "Vault" }] }, { next_batch: batch });
    const tree = exploration(
      [namedStart],
      { findings: [{ property: "No theft", minimized_trace: [action], reproductions: 2 }] } as FuzzCampaignReport,
      "Vault",
    );
    expect(nodeState(tree.roots[0], false)).toBe("Confirmed finding");
  });

  it("handles partial history without fabricating calls or success", () => {
    const missing = exploration([start, row("sim_replay_traces", batch, {})], null);
    expect(nodeState(missing.roots[0], false)).toBe("Awaiting result");
    expect(
      exploration(
        [
          row("sim_replay_traces", undefined, {
            traces: [{ id: "lost", statuses: ["succeeded"] }],
          }),
        ],
        null,
      ).roots,
    ).toEqual([]);
    const tree = exploration(
      [
        start,
        row("sim_replay_traces", batch, {
          traces: [{ id: "2", statuses: ["succeeded"] }],
        }),
      ],
      null,
    );
    expect(nodeState(tree.roots[0].children[0], false)).toBe("Incomplete result");
  });

  it("distinguishes exhausted budget, confirmation, waiting, and completion", () => {
    expect(campaignPhase(report("budget_exhausted"), [], false, false)).toBe("Budget exhausted");
    expect(campaignPhase(report("confirming"), [], true, false)).toBe("Confirming violation");
    expect(campaignPhase(report("complete"), [], false, false)).toBe("Finished");
    expect(campaignPhase(null, [], true, false)).toBe("Planning");
  });
});

import { afterEach, expect, test, vi } from "vitest";
import { FuzzTarget } from "@aomi-labs/arc-studio-fuzz-core";

vi.mock("@tanstack/react-start/server-only", () => ({}));
vi.mock("@tanstack/react-start/server", () => ({ getCookie: vi.fn(), setCookie: vi.fn(), deleteCookie: vi.fn() }));
vi.mock("@tanstack/react-router", () => ({ createFileRoute: () => (options: unknown) => options }));
const state = vi.hoisted(() => ({ redeem: vi.fn() }));
vi.mock("@/server/studio-session", async (original) => {
  const actual = await original<typeof import("@/server/studio-session")>();
  return { ...actual, StudioSession: { fromArtifactTicket: state.redeem, timed: async (_: string, work: () => Promise<unknown>) => work() } };
});
import { artifactDigest } from "@/server/studio-session";
import { Route } from "./api.artifacts.$ticket";

afterEach(() => vi.clearAllMocks());

test("an old ticket cannot hand the agent code different from the prepared target", async () => {
  const original = new FuzzTarget("Vault", "Vault.sol", "contract Vault {}", [], "0x6000");
  let target = original;
  state.redeem.mockReturnValue({
    session: { app: async () => ({ target: async () => target }) },
    appId: "app", sourcePath: "Vault.sol", contract: "Vault", installed: true,
    digest: artifactDigest([original.source, original.abi, original.deployedBytecode, original.chainId, null, []]),
  });
  const get = (Route as unknown as { server: { handlers: { GET: (value: unknown) => Promise<Response> } } }).server.handlers.GET;
  const request = { request: new Request("https://example.test/api/artifacts/ticket"), params: { ticket: "ticket" } };
  expect((await get(request)).status).toBe(200);
  target = new FuzzTarget("Vault", "Vault.sol", "contract Vault { /* patched */ }", [], "0x6001");
  const changed = await get(request);
  expect(changed.status).toBe(409);
  expect(await changed.text()).toContain("compiled target changed");
});

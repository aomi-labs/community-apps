import type { TargetData } from "@/app/actions";

/** A run owns its immutable contract snapshot; navigation only chooses a view. */
export interface Campaign {
  id: string;
  target: TargetData;
  threadId?: string;
  status: string;
  resumes: number;
  createdAt: number;
}

export function readCampaigns(key: string): Campaign[] {
  try {
    const rows: unknown = JSON.parse(localStorage.getItem(key) ?? "[]");
    if (!Array.isArray(rows)) return [];
    return rows.filter(
      (row): row is Campaign =>
        row &&
        typeof row.id === "string" &&
        typeof row.threadId === "string" &&
        typeof row.status === "string" &&
        Number.isFinite(row.createdAt) &&
        Number.isInteger(row.resumes) &&
        row.resumes >= 0 &&
        row.resumes <= 6 &&
        typeof row.target?.name === "string" &&
        typeof row.target?.sourcePath === "string" &&
        typeof row.target?.source === "string" &&
        typeof row.target?.deployedBytecode === "string" &&
        Number.isSafeInteger(row.target?.chainId) &&
        Array.isArray(row.target?.abi),
    );
  } catch {
    return [];
  }
}

export function saveCampaigns(key: string, campaigns: Campaign[]): void {
  try {
    localStorage.setItem(
      key,
      JSON.stringify(
        campaigns
          .filter((run) => run.threadId)
          .map((run) => {
            const { artifactUrl: _artifact, installedArtifactUrl: _installed, ...target } = run.target;
            return { ...run, target };
          }),
      ),
    );
  } catch {
    /* A full or disabled browser store must not stop execution. */
  }
}

/** Preserve the actionable admission reason instead of the SDK's generic fallback. */
export function campaignError(error: unknown): string {
  const details = error && typeof error === "object" && "details" in error ? error.details : null;
  const code = error && typeof error === "object" && "code" in error
    ? error.code
    : details && typeof details === "object" && "error" in details ? details.error : null;
  if (code === "guest_concurrency_limit")
    return "Another guest campaign is running. Wait for it to finish, stop it, or sign in to run concurrent campaigns.";
  if (code === "app_loading") return "The fuzzer is loading on this backend. Retry shortly.";
  return error instanceof Error ? error.message : String(error);
}

"use client";

import { AomiRuntimeProvider } from "@aomi-labs/react";
import { FileCode2, Layers } from "lucide-react";
import { useMemo, useState } from "react";

import { Brand } from "@/components/brand";
import { FuzzPanel } from "@/components/fuzz-panel";
import { highlight } from "@/components/fuzz-workspace";
import type { HarnessProtocol } from "@/server/local-harness";

/**
 * The fuzz workspace for a harness-seeded protocol: its contracts on the left,
 * their source in the middle, and the agent on the right, talking to the
 * self-hosted stack through the dev server's proxy as the harness user.
 */
export function HarnessWorkspace({ protocol }: { protocol: HarnessProtocol }) {
  const { stack } = protocol;
  // Stands in for the portal: attaches the user's bearer (the web app forwards
  // /v1 to api-server) and answers the account profile lookup as "no profile",
  // the client's normal signed-out case.
  const localFetch = useMemo<typeof fetch>(
    () => (input, init = {}) => {
      const url = new URL(input instanceof Request ? input.url : String(input), stack.webOrigin);
      if (url.pathname === "/api/account" || url.pathname === "/v1/account") {
        return Promise.resolve(new Response(null, { status: 401 }));
      }
      const headers = new Headers(init.headers ?? (input instanceof Request ? input.headers : undefined));
      headers.set("authorization", `Bearer ${stack.portalBearer}`);
      return fetch(input, { ...init, headers });
    },
    [stack.portalBearer, stack.webOrigin],
  );
  const [opened, setOpened] = useState(protocol.files[0]?.path);
  const file = protocol.files.find((candidate) => candidate.path === opened);
  const expiresIn = Math.max(0, Math.round((stack.expires - Date.now()) / 60_000));

  return (
    <AomiRuntimeProvider
      backendUrl={stack.webOrigin}
      clientOptions={{ fetch: localFetch, getAccountBearer: async () => stack.portalBearer }}
      accountSessionAvailable
      agentTarget={{ mode: "direct", applicationId: stack.applicationId, app: "arc-studio-fuzzer" }}
      persistThread={false}
      threadPersistenceScope="arc-studio-fuzz:harness"
    >
      <main className="flex h-screen flex-col overflow-hidden text-[13px]">
        <header className="flex h-14 shrink-0 items-center justify-between gap-4 border-b border-border bg-surface px-4">
          <div className="flex min-w-0 items-center gap-4">
            <Brand />
            <div className="h-5 w-px bg-border" />
            <span className="truncate text-[14px] font-medium text-ink">
              {protocol.target.name} protocol · seeded by the harness
            </span>
          </div>
          <div className="flex shrink-0 items-center gap-3">
            <span className="text-[12px] text-ink-muted" title="Minted by scripts/harness-bearers.mjs">
              harness user · bearers expire in {expiresIn} min
            </span>
            <div className="flex items-center gap-2 rounded-pill border border-accent/45 bg-accent/10 px-3 py-1.5 text-[12px] text-accent-strong">
              <span className="size-1.5 rounded-pill bg-accent" />
              Arc fork · {protocol.target.chainId} · {protocol.contracts.length} contracts
            </div>
          </div>
        </header>

        <div className="flex min-h-0 flex-1">
          <aside className="flex w-[280px] shrink-0 flex-col overflow-auto border-r border-border bg-surface">
            <h2 className="px-3 pb-2 pt-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-ink-muted">
              Protocol
            </h2>
            <ul data-testid="protocol-contracts" className="space-y-0.5 px-2 pb-4">
              {protocol.contracts.map((contract) => {
                const path = `src/${contract.name}.sol`;
                return (
                  <li key={contract.address}>
                    <button
                      onClick={() => setOpened(path)}
                      className={`flex w-full items-center gap-2 rounded-md px-2 py-2 text-left ${
                        opened === path ? "bg-accent-subtle text-ink" : "text-ink hover:bg-hover"
                      }`}
                    >
                      {contract.target ? (
                        <FileCode2 className="size-4 shrink-0 text-accent" />
                      ) : (
                        <Layers className="size-4 shrink-0 text-ink-muted" />
                      )}
                      <span className="min-w-0 flex-1">
                        <span className="block truncate font-medium">{contract.name}</span>
                        <span className="block truncate font-mono text-[11px] text-ink-muted">
                          {contract.address.slice(0, 8)}…{contract.address.slice(-6)}
                        </span>
                      </span>
                      {contract.target && (
                        <span className="shrink-0 rounded-pill bg-accent/10 px-2 py-0.5 text-[11px] text-accent-strong">
                          target
                        </span>
                      )}
                    </button>
                  </li>
                );
              })}
            </ul>
          </aside>

          <section className="flex min-w-0 flex-1 flex-col bg-bg">
            <div className="flex h-11 shrink-0 items-center gap-2 border-b border-border bg-surface px-4 text-[13px] text-ink">
              <FileCode2 className="size-4 text-accent" />
              <span className="truncate">{file?.path ?? "Select a contract"}</span>
            </div>
            <div className="min-h-0 flex-1 overflow-auto py-4 font-mono text-[13px] leading-[1.75]">
              {file?.source.split("\n").map((line, index) => (
                <div key={index} className="flex min-h-[23px]">
                  <span className="w-14 shrink-0 select-none pr-4 text-right text-ink-muted/60">{index + 1}</span>
                  <span className="whitespace-pre pr-6 text-ink">{highlight(line)}</span>
                </div>
              ))}
            </div>
          </section>

          <aside className="flex min-h-0 w-[460px] shrink-0 flex-col border-l border-border bg-surface">
            <FuzzPanel
              appId="local-harness"
              backendUrl={stack.webOrigin}
              applicationId={stack.applicationId}
              account={null}
              target={protocol.target}
              onRefresh={() => undefined}
              harness={{
                seed: protocol.seed,
                backendBearer: stack.backendBearer,
                artifactUrl: protocol.artifactUrl,
                contracts: protocol.contracts.map((contract) => contract.name),
              }}
            />
          </aside>
        </div>
      </main>
    </AomiRuntimeProvider>
  );
}

import { afterEach, expect, test, vi } from "vitest";
import { campaignError, readCampaigns, saveCampaigns, type Campaign } from "./campaign";

const saved = new Map<string, string>();
afterEach(() => { saved.clear(); vi.unstubAllGlobals(); });

test("recovery preserves thread/snapshot and isolates accounts without saving capability links", () => {
  vi.stubGlobal("localStorage", { getItem: (key: string) => saved.get(key), setItem: (key: string, value: string) => saved.set(key, value) });
  const run: Campaign = { id: "run", threadId: "thread-a", status: "Running", resumes: 2, createdAt: 123,
    target: { name: "A", sourcePath: "A.sol", source: "contract A {}", abi: [], chainId: 5042002, deployedBytecode: "0x00",
      artifactUrl: "https://example.test/secret-ticket", installedArtifactUrl: "https://example.test/other-ticket" } };
  saveCampaigns("account-a", [run]);
  expect(saved.get("account-a")).not.toContain("ticket");
  expect(readCampaigns("account-a")[0]).toMatchObject({ threadId: "thread-a", resumes: 2, target: { source: "contract A {}" } });
  expect(readCampaigns("account-b")).toEqual([]);
  saved.set("account-a", '{"broken":true}');
  expect(readCampaigns("account-a")).toEqual([]);
});

test("unavailable storage does not interrupt execution", () => {
  vi.stubGlobal("localStorage", { getItem: () => { throw Error("denied"); }, setItem: () => { throw Error("full"); } });
  expect(readCampaigns("account")).toEqual([]);
  expect(() => saveCampaigns("account", [])).not.toThrow();
});

test("admission errors explain guest limits and backend readiness", () => {
  expect(campaignError({ code: "guest_concurrency_limit", details: "guest_concurrency_limit" })).toContain("Another guest campaign");
  expect(campaignError({ code: "app_loading", details: "app_loading" })).toContain("loading on this backend");
  expect(campaignError({ details: { error: "app_loading" } })).toContain("loading on this backend");
  expect(campaignError(new Error("Provider unavailable"))).toBe("Provider unavailable");
});

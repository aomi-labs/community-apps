import { createStart, createMiddleware, createCsrfMiddleware } from "@tanstack/react-start";
import { setResponseHeader } from "@tanstack/react-start/server";

const privateResponses = createMiddleware().server(async ({ next }) => {
  setResponseHeader("cache-control", "private, no-store");
  return next();
});

export const startInstance = createStart(() => ({
  requestMiddleware: [
    privateResponses,
    createCsrfMiddleware({
      filter: ({ request }) => !["GET", "HEAD", "OPTIONS"].includes(request.method),
    }),
  ],
}));

import "@tanstack/react-start/server-only";

import { StudioSession } from "./studio-session";
import { savedWorkspace, saveWorkspace, type WorkspaceSnapshot } from "./snapshot-store";

export async function loadWorkspace(session: StudioSession, appId: string, refresh = false): Promise<WorkspaceSnapshot> {
  if (!refresh) {
    const saved = await savedWorkspace(session.token, appId);
    if (saved) return saved;
  }
  const client = session.client();
  const [described, app] = await Promise.all([
    client.listApps().then((apps) => apps.find((app) => app.id === appId)),
    session.app(appId, { fresh: true }),
  ]);
  const [contracts, files] = await Promise.all([app.contracts(), app.files()]);
  const result = {
    appName: described?.description || "Untitled app",
    studioUrl: app.webUrl,
    contracts,
    files: files.map((file) => file.path),
  };
  await saveWorkspace(session.token, appId, result);
  return { ...result, capturedAt: new Date().toISOString() };
}

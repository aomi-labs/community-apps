import { createFileRoute } from "@tanstack/react-router";

import { LocalHarness } from "@/server/local-harness";

/** Agent calls from the /harness page, forwarded to the self-hosted api-server. Development only. */
export const Route = createFileRoute("/v1/$")({
  server: { handlers: LocalHarness.handlers("api") },
});

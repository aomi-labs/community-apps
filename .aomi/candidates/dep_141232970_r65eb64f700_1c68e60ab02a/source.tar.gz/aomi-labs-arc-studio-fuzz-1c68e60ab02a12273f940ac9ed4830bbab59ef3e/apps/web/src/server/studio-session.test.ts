import { afterEach, expect, test, vi } from "vitest";

vi.mock("@tanstack/react-start/server-only", () => ({}));
vi.mock("@tanstack/react-start/server", () => ({ getCookie: vi.fn(), setCookie: vi.fn(), deleteCookie: vi.fn() }));
import { artifactDigest, StudioSession } from "./studio-session";

afterEach(() => { vi.unstubAllEnvs(); vi.useRealTimers(); });

test("artifact tickets bind a code snapshot and fresh tickets replace expired capabilities", () => {
  vi.stubEnv("SESSION_SECRET", "synthetic-test-secret-with-at-least-32-characters");
  vi.useFakeTimers();
  vi.setSystemTime(new Date("2026-10-20T00:00:00Z"));
  const digest = artifactDigest(["source", [], "0x6000", 5042002, null, []]);
  const issue = () => StudioSession.prototype.artifactTicket.call({ token: "synthetic" } as StudioSession, "app", "Vault.sol", "Vault", false, digest);
  const old = issue();
  expect(StudioSession.fromArtifactTicket(old)?.digest).toBe(digest);
  expect(artifactDigest(["patched source", [], "0x6001", 5042002, null, []])).not.toBe(digest);
  vi.advanceTimersByTime(30 * 60_000 + 1);
  expect(StudioSession.fromArtifactTicket(old)).toBeNull();
  expect(StudioSession.fromArtifactTicket(issue())?.digest).toBe(digest);
});

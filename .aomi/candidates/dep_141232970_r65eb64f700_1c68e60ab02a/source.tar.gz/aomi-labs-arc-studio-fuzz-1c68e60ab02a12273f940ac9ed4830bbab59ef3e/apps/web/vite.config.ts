import { defineConfig, loadEnv } from "vite";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { nitro } from "nitro/vite";
import { fileURLToPath } from "node:url";

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "");
  for (const key of [
    "SESSION_SECRET",
    "ARC_STUDIO_API_URL",
    "HARNESS_SEED_DIR",
    "HARNESS_API_URL",
    "HARNESS_BACKEND_URL",
    "HARNESS_APPLICATION_ID",
    "HARNESS_PUBLIC_ORIGIN",
  ]) {
    if (!process.env[key] && env[key]) process.env[key] = env[key];
  }
  return {
    resolve: { alias: { "@": fileURLToPath(new URL("./src", import.meta.url)) } },
    define: Object.fromEntries(
      ["NEXT_PUBLIC_AOMI_BACKEND_URL", "NEXT_PUBLIC_AOMI_APPLICATION_ID", "NEXT_PUBLIC_AOMI_MODEL"].map((key) => [
        `process.env.${key}`,
        JSON.stringify(process.env[key] ?? env[key]) ?? "undefined",
      ]),
    ),
    plugins: [tailwindcss(), tanstackStart(), nitro(), react()],
    server: { port: 3108 },
  };
});

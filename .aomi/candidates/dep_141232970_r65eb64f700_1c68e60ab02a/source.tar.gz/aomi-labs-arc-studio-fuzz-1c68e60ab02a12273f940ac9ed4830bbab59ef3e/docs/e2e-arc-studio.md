# Runbook: an Arc Studio e2e run from nothing

This takes a fresh Arc Studio account to a live, buggy lending protocol on Arc Testnet that the fuzzer then finds the bug in. Everything Arc Studio-specific lives in `scripts/e2e/`. For the fuzzer's own design, read `how-the-fuzzer-works.md`. For a local run with no Studio account at all, use `packages/fuzz-core/scripts/e2e-seeded-protocol.mjs` instead.

| Step | What | Tool |
|---|---|---|
| 0 | Account, wallet and funds | You, in the browser |
| 1–3 | Create the app, clone the protocol, deploy + wire + seed through the Studio agent | `scripts/e2e/seed-studio-app.sh` |
| 4 | Check the protocol on chain | `scripts/e2e/verify-onchain.sh` (run by step 1–3) |
| 5 | Fuzz it | The web app or `arc-studio fuzz` |
| — | Clean up stuck or stale Aomi sessions | `scripts/e2e/aomi-sessions.js` |

## The target

[`aomi-labs/lending-protocol-example`](https://github.com/aomi-labs/lending-protocol-example) is public and is the same code as `examples/lending-protocol/`. It has four contracts with the planted oracle bug: `PriceOracle.price()` reads `SimpleAMM.spotPrice()` with no time-weighting, so one large `buy` inflates collateral value. `CollateralToken` takes its minter as a constructor argument. That is what makes a Studio-registered deployment operable, because the sandbox key can then mint and wire after Studio deploys it. Keep the two copies in sync.

## 0. Before you start (user clicks)

1. Sign in to Arc Studio and accept the Circle consent card. Back up the entity secret when asked. Both are user clicks that no script can do.
2. Fund the sandbox key with at least **15 native USDC plus gas** (5 for the AMM, 10 for the pool). The in-Studio faucet needs the **`DEVELOPER_ADMIN`** role and spends the user's funds, so someone with that role clicks it.
3. Log the CLI in: `node packages/arc-studio-cli/bin/arc-studio.mjs login` (or `--paste`, or set `ARC_STUDIO_TOKEN`). Never paste the token into chat or commit it.
4. Install `jq` and Foundry (`cast`) locally.

## 1–4. Seed the Studio app

```sh
scripts/e2e/seed-studio-app.sh lending    # session name, default "lending"
```

It runs, in order:

1. `arc-studio run --prompt-file scripts/e2e/prompts/01-create-app.txt --session lending` creates the app and its sandbox. **An app is named from its first prompt**, so that prompt is descriptive. A bare `"hello"` gives you an app called "Hello World Chat".
2. `arc-studio clone aomi-labs/lending-protocol-example --session lending` clones the repo into the sandbox. The sandbox has to exist first, which is why step 1 comes before it.
3. It polls `arc-studio ls` until the clone is readable. **A cold sandbox can take minutes to serve its first batch read**, so the budget is 4 minutes.
4. `arc-studio run --prompt-file scripts/e2e/prompts/02-deploy-and-wire.txt` is the prompt that actually worked:
   - Deploy all four contracts with **`deploy_contract`**, in order: `CollateralToken(<sandbox key address>)`, `SimpleAMM(token)`, `PriceOracle(amm)`, `LendingPool(token, oracle)`. This is what lands them in Studio's deployment registry.
   - Five `cast send` calls from the sandbox `.env` key: `setPool`, `mint 10000e18`, `approve AMM 5e18`, `AMM.seed(5e18) --value 5ether`, `LendingPool.supply() --value 10ether`.
   - Six `cast call` checks.
   - **Do not** route through `forge script --broadcast` or `forge create`, because those deployments are not registered and the fuzzer cannot see them. **Do not** use the Circle SDK either: the platform SCP wallet is deploy-only, and a provisioned key is a separate entity that is not the minter.
5. `arc-studio deployments --json` reads the registry. The script takes the newest Arc Testnet deployment per contract name, which is what the fuzz app does too. It writes the addresses to `.e2e/<session>.env` (gitignored).
6. It then runs `scripts/e2e/verify-onchain.sh .e2e/lending.env`.

If a turn stops with `needs_input`, `budget_exceeded` or a dropped stream, the script exits and prints how to answer or `attach`. Re-running with the same session continues that app. To start clean, use a new session name.

## 4. On-chain checks

`scripts/e2e/verify-onchain.sh .e2e/lending.env` runs six read-only checks against `https://rpc.testnet.arc.io` (override with `ARC_TESTNET_RPC`):

| Check | Expected |
|---|---|
| `CollateralToken.pool()` | the `LendingPool` address |
| `CollateralToken.balanceOf(SimpleAMM)` | `5e18` |
| `SimpleAMM.spotPrice()` | `1e18` |
| `PriceOracle.price()` | `1e18` (the same as spot, which is the bug) |
| native balance of `SimpleAMM` | `5e18` |
| native balance of `LendingPool` | `10e18` |

If you seed different amounts, set `E2E_AMM_WGLD`, `E2E_AMM_USDC` and `E2E_POOL_USDC` (wei).

## 5. Fuzz it

- **Web:** open https://arc-studio-fuzz.vercel.app, connect the Studio account, pick the app (`E2E_APP_ID` in the env file) and fuzz `LendingPool`. The app hands the fuzzer the whole deployed protocol. Sign in with a wallet (SIWE), because guest model calls are capped at 64 KB of input.
- **CLI:** `node packages/arc-studio-cli/bin/arc-studio.mjs fuzz LendingPool --app "$E2E_APP_ID"`. It exits 2 on a finding.

The expected finding is the oracle manipulation: `SimpleAMM.buy` → `LendingPool.depositCollateral` → `LendingPool.borrow`, reproduced twice.

## Staging account hygiene

Paste `scripts/e2e/aomi-sessions.js` into the DevTools console of a tab signed in to https://chat-staging.aomi.dev. It calls `/v1/agent/*` same-origin, so no token leaves the browser.

- `aomi.sessions()` lists the account's agent sessions.
- `aomi.turn(id)` shows a session's last turn state, error and notice.
- `aomi.interrupt(id)` stops a turn stuck in `processing`.
- `aomi.statement()` shows which model a campaign really ran on.
- `aomi.archive(id)` hides a finished campaign thread.

## Gotchas that cost days

- **The faucet needs `DEVELOPER_ADMIN`** and spends the user's funds.
- **The Circle consent card and the entity-secret backup are user clicks.** Nothing scripted gets past them.
- **One project tab per Chrome profile.** A second Studio tab in the same profile fights the first for the session.
- **A cold sandbox** can take minutes on its first batch read (`ls`/`cat`/`pull`). Budget 4 minutes before calling it broken.
- **The fuzz app picks the newest registered deployment per contract name.** A stale half-wired deploy from an earlier attempt is shadowed by a newer one, but a newer *broken* one shadows a good one. Re-run the whole seed rather than redeploying one contract.
- **`.circle/recovery_*` files show up in the file tree** after the entity-secret backup. They are expected. Don't delete them, and don't let a prompt treat them as project files.
- **`forge --broadcast` deployments are invisible** to Studio's registry and therefore to the fuzzer.
- **The first prompt names the app.** A bare `"hello"` gives you "Hello World Chat".

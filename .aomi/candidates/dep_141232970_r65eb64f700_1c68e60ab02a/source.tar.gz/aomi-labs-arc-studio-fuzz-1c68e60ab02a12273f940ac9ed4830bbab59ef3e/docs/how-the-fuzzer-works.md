# How the Arc Studio fuzzer works

A builder makes an app in **Arc Studio** (Circle's prompt-to-app tool). **Aomi** then attacks its Solidity contracts on a held Arc fork. It runs ordered, multi-actor transaction sequences, shrinks any property violation to the shortest reproduction, and only reports it after **two clean replays**. Everything is simulation only: nothing is signed, deployed or broadcast.

## The pieces (all in this repo)

| Path | What it is |
|---|---|
| `apps/web` | Next.js site, live at https://arc-studio-fuzz.vercel.app. You connect Arc Studio, pick an app and contract, and watch the live agent trace. |
| `packages/arc-studio-cli` | Fork of Circle's MIT `@circle-fin/arc-studio-cli`, plus the `arc-studio fuzz` command. Its `StudioClient` is also used as a library. |
| `packages/fuzz-core` | Shared TypeScript. `ArcStudioApp` reads an Arc Studio workspace, `FuzzTarget` holds one compiled contract and builds the prompt, and `CampaignTrace` folds Aomi events into the trace, ledger, report and errors. |
| `apps/arc-studio-fuzzer` | The Rust **Aomi app**, deployed as an Aomi Build Project. It owns the campaign: plan validation, the breadth-first frontier, dedup, minimization and the 2× reproduction. |
| `scripts/mock-arc-studio.mjs` | A local Arc Studio API with a known-vulnerable `UnsafeVault`, for development without an account. |

Outside this repo, the Aomi backend (`product-mono`) runs the model and the **`evm-sim`** tools (`sim_open`, `sim_set_code`, `sim_set_balance`, `sim_snapshot`, `sim_replay_traces`, `sim_call`, `sim_close`). Each Arc sim world runs on its own `arc-anvil` fork, pinned at a block and never re-synced.

## End-to-end flow

```mermaid
sequenceDiagram
  participant U as Builder (browser)
  participant W as Web (Vercel)
  participant S as studio.arc.io
  participant P as Aomi portal (chat-staging)
  participant A as arc-studio-fuzzer app
  participant E as evm-sim (Arc fork)
  U->>W: paste Arc Studio token (origin_pat_…), Sign in to Aomi (SIWE)
  W->>S: list apps, sandbox files, Foundry out/ artifact
  W-->>U: contracts + source; mint 30-min artifact link
  U->>P: prompt (name, signatures, artifact_url)
  P->>A: arc_map_attack_surface(artifact_url)
  A->>W: GET /api/artifacts/:ticket → source, ABI, runtime bytecode
  P->>E: sim_open (pin Arc fork)
  P->>A: arc_fuzz_start(plan) → setup + first batch
  P->>E: sim_set_code, sim_set_balance, sim_snapshot
  loop until next_batch is null
    P->>E: sim_replay_traces(batch, compact)
    P->>A: arc_fuzz_round(replay) → next batch
  end
  P->>A: arc_fuzz_report, arc_fuzz_close
  P->>E: sim_close
```

## Who owns what

- **The model** writes the threat model, actors, properties and action templates.
- **The app** decides what counts as a fact. It treats each `next_batch` as an opaque recipe. It checks properties, prunes duplicate states, generates minimization candidates, and promotes a violation to a **finding** only after 2 reproductions from the baseline. A violation that doesn't reproduce stays "unconfirmed".
- **`evm-sim`** decides what actually executed: fork lifetime, code install, ordered calls, balances, return data. An `engine_error` means the host failed, never something the contract did.

## Auth and transport

- **Arc Studio:** the web app uses the paste flow. The token is held in an AES-256-GCM, httpOnly cookie, and every call goes through the forked `StudioClient`. The CLI keeps Circle's own `arc-studio login`.
- **Aomi:** the base URL is the **portal**, `https://chat-staging.aomi.dev`, not `api-staging` (which has no auth routes). The target is `{mode:"direct", app:"arc-studio-fuzzer", applicationId: 2937813}`, and the model is the label `Claude Sonnet 5`. The user state carries a keyless placeholder address, `0x…f022a`, because `sim_open` needs a "connected" wallet.
- **Artifact by link:** a sealed, 30-minute ticket for exactly one artifact. The app fetches it over https only, from the exact host `arc-studio-fuzz.vercel.app`, with no userinfo or port, a 20 s timeout, no redirects, and a 4 MB bounded read.

## Limits that shaped the design

| Limit | Effect | Handling |
|---|---|---|
| A chat message can be at most **32,000 chars** | Inlining the source, ABI and bytecode fails for real contracts | Artifact by link. Inline mode throws a clear error. |
| A **guest** model call can carry at most **64 KB** of input | Campaign history passes that after about 15 tool calls | "Sign in to Aomi" (SIWE). Signed-in accounts have no per-call cap. Short replay labels and compact round progress slow the growth. |
| A turn can make at most **32 model calls** | `execution_limit_reached` | The client auto-continues, up to 6 times. Campaign and world state persist. |
| A failed turn carries no reason | Silent `turn_state: failed` | The runtime records a typed notice. The UI shows it (guest cap typed in product-mono). |

## Run it

```bash
pnpm install && cp apps/web/.env.example apps/web/.env.local   # set SESSION_SECRET
node scripts/mock-arc-studio.mjs                               # optional mock on :4100
pnpm dev                                                       # web on :3100
cargo test --manifest-path apps/arc-studio-fuzzer/Cargo.toml   # app
pnpm --filter @aomi-labs/arc-studio-fuzz-core test             # core
```

## Seeded worlds (signed-in runs)

Before the first message, the website calls Aomi's `POST /api/thread/sim/world` (product-mono #1309) with the account bearer, the thread id and the same `user_state` the chat sends. The body comes from `FuzzTarget.seedWorld()`: the contract's Arc chain, plus its runtime bytecode installed at `INSTALL_ADDRESS` unless it's a live deployment. There's no snapshot, so setup stays open for the agent to fund its actors.

The chat then gets `FuzzTarget.seededPrompt()`, a few hundred characters of references (name, chain, address, artifact link). Its artifact link says `deployment: {address, chain_id, installed: true}`, so `arc_fuzz_start` returns `setup.set_code: null`. The bytecode never passes through the model.

Long source (over 300 lines) comes back from `arc_map_attack_surface` as `source_lines`, and the agent reads slices with `arc_source`. Guests, and any refused seeding call (for example a backend without the route), fall back to the agent opening the world itself.

## Two ways to get a contract onto the fork

- **Live deployment (preferred):** when Arc Studio has deployed the contract to Arc, the campaign fuzzes it at its real address on that chain (mainnet 5042 or testnet 5042002). Its constructor state is real, and actors can act as real accounts such as the owner. Nothing is sent to the chain.
- **Installed bytecode:** otherwise the runtime bytecode is installed at a fresh address. The constructor doesn't run, so the owner, tokens and oracle are empty.

## Known gaps (good next tasks)

1. **Never-deployed contracts:** run the constructor on the fork with chosen args and mock dependencies.
2. **Web sign-in is token paste.** Ask Circle to allow our origin as a `/cli-auth` redirect.
3. **CLI and large contracts.** The CLI can't mint artifact links, because it has no public host, so large contracts are web-only.

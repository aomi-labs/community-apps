-- App-owned, immutable Arc build artifacts. This migration belongs only to
-- the dedicated Fuzzer Studio Supabase project, never an Aomi canonical DB.
insert into storage.buckets (id, name, public, file_size_limit)
values ('arc-snapshots', 'arc-snapshots', false, 4194304)
on conflict (id) do nothing;

create table if not exists public.arc_snapshots (
  id uuid primary key default gen_random_uuid(),
  owner_hash text not null check (owner_hash ~ '^[0-9a-f]{64}$'),
  app_id uuid not null,
  source_path text not null,
  contract_name text not null,
  digest text not null check (digest ~ '^[0-9a-f]{64}$'),
  storage_path text not null,
  installed_path text,
  captured_at timestamptz not null default now(),
  unique (owner_hash, app_id, source_path, contract_name, digest)
);

create index if not exists arc_snapshots_latest
  on public.arc_snapshots (owner_hash, app_id, source_path, contract_name, captured_at desc);

alter table public.arc_snapshots enable row level security;
revoke all on public.arc_snapshots from anon, authenticated;
grant usage on schema public to service_role;
grant select, insert on public.arc_snapshots to service_role;

-- Last observed workspace listing. This lets a returning builder select a
-- pinned build even while Arc Studio is slow or temporarily unavailable.
create table if not exists public.arc_workspaces (
  owner_hash text not null check (owner_hash ~ '^[0-9a-f]{64}$'),
  app_id uuid not null,
  app_name text not null,
  studio_url text not null,
  contracts jsonb not null,
  files jsonb not null,
  captured_at timestamptz not null default now(),
  primary key (owner_hash, app_id)
);

alter table public.arc_workspaces enable row level security;
revoke all on public.arc_workspaces from anon, authenticated;
grant select, insert, update on public.arc_workspaces to service_role;

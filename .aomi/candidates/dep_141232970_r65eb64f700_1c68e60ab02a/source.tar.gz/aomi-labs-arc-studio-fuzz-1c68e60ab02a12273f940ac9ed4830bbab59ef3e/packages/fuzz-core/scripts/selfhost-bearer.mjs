// EdDSA JWTs in the AomiBearer shape, signed with a self-hosted stack's
// user-issuer key: what the portal would mint for a signed-in user.
import { sign } from "node:crypto";

/**
 * @param {{ key: import("node:crypto").KeyObject; kid: string; issuer: string; user: string; ttlSeconds?: number }} signer
 * @param {Record<string, string>} claims
 */
export function selfhostBearer(signer, claims) {
  const b64 = (value) => Buffer.from(JSON.stringify(value)).toString("base64url");
  const now = Math.floor(Date.now() / 1000);
  const header = { alg: "EdDSA", typ: "JWT", kid: signer.kid };
  const body = {
    sub: signer.user,
    iss: signer.issuer,
    role: "user",
    iat: now,
    exp: now + (signer.ttlSeconds ?? 3600),
    principal_class: "user",
    ...claims,
  };
  const unsigned = `${b64(header)}.${b64(body)}`;
  return `${unsigned}.${sign(null, Buffer.from(unsigned), signer.key).toString("base64url")}`;
}

/** Claims api-server expects from the portal for agent calls. */
export const portalClaims = (apiUrl) => ({
  aud: "aomi-api-server",
  scope: "agent:read agent:write agent:actions:resolve",
  resource: `${apiUrl}/v1/agent`,
  auth_source: "session",
});

/** Claims the backend expects on its thread routes (model pin, world seeding). */
export const backendClaims = () => ({ aud: "aomi-backend" });

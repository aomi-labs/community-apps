export const ARC_MAINNET_CHAIN_ID = 5042;

/**
 * Placeholder account for the Aomi session's user state. evm-sim requires a
 * "connected" address to open a fork, but campaigns never sign or broadcast:
 * nobody holds a key for this address and actors are app-derived.
 */
export const SIMULATION_ACCOUNT = "0x00000000000000000000000000000000000f022a";

type AbiItem = {
  type?: string;
  name?: string;
  stateMutability?: string;
  inputs?: Array<{ type?: string }>;
};

/** Aomi rejects a chat message longer than this (api-server MAX_MESSAGE_CHARS). */
export const MAX_MESSAGE_CHARS = 32_000;

export const ARC_TESTNET_CHAIN_ID = 5_042_002;

/** Where the harness installs runtime bytecode when the contract has no Arc deployment. */
export const INSTALL_ADDRESS = "0x00000000000000000000000000000000fa22c0de";

/** Body of Aomi's `POST /api/thread/sim/world`: forks with their setup. */
export interface SeedWorld {
  forks: Array<{ chain_id: number; overrides: Array<{ address: string; code: string }> }>;
  code_checks?: Array<{ chain_id: number; address: string; code: string; immutable_references: Array<{ start: number; length: number }> }>;
}

/** Where the builder already deployed the contract on Arc. */
export interface Deployment {
  address: string;
  chainId: number;
}

/** One compiled contract from an Arc Studio app, ready to hand to the Aomi fuzzer. */
export class FuzzTarget {
  constructor(
    readonly name: string,
    /** Workspace path of the defining file, e.g. `contracts/Vault.sol`. */
    readonly sourcePath: string,
    /** The defining file plus any workspace imports, concatenated with path headers. */
    readonly source: string,
    readonly abi: AbiItem[],
    readonly deployedBytecode: string,
    readonly chainId: number = ARC_MAINNET_CHAIN_ID,
    /** Live deployment to fuzz in place (constructor state included); absent installs the bytecode. */
    readonly deployment?: Deployment,
    readonly immutableReferences: Array<{ start: number; length: number }> = [],
  ) {
    if (deployment && deployment.chainId !== chainId) {
      throw new Error(`${name} is deployed on chain ${deployment.chainId}, not ${chainId}`);
    }
    if (!/^0x[0-9a-fA-F]+$/.test(deployedBytecode) || deployedBytecode === "0x") {
      throw new Error(`${name} has no deployed bytecode (abstract contract or interface?)`);
    }
  }

  /** Builds a target from a Foundry `out/<File>.sol/<Contract>.json` artifact. */
  static fromFoundryArtifact(
    name: string,
    sourcePath: string,
    source: string,
    artifact: unknown,
    chainId?: number,
    deployment?: Deployment,
  ): FuzzTarget {
    const json = artifact as {
      abi?: AbiItem[];
      deployedBytecode?: { object?: string; immutableReferences?: Record<string, Array<{ start: number; length: number }>> } | string;
    };
    const deployed =
      typeof json.deployedBytecode === "string"
        ? json.deployedBytecode
        : json.deployedBytecode?.object;
    if (!Array.isArray(json.abi) || !deployed) {
      throw new Error(`${sourcePath}:${name} artifact is missing abi or deployedBytecode`);
    }
    return new FuzzTarget(
      name,
      sourcePath,
      source,
      json.abi,
      deployed.startsWith("0x") ? deployed : `0x${deployed}`,
      deployment?.chainId ?? chainId,
      deployment,
      typeof json.deployedBytecode === "object" ? Object.values(json.deployedBytecode.immutableReferences ?? {}).flat() : [],
    );
  }

  /** Aomi session user state for fuzzing this target from an Arc Studio app. */
  userState(arcStudioAppId: string, providerLabel: string) {
    return {
      connection: { is_connected: true, provider: "arc-studio", provider_label: providerLabel },
      evm: { address: SIMULATION_ACCOUNT, chain_id: this.chainId },
      ext: { host: "arc-studio", execution: "isolated-fork", arc_studio_app_id: arcStudioAppId },
    };
  }

  /** Writable entrypoints, in ABI order, as `name(...)` labels for display. */
  get writableFunctions(): string[] {
    return this.abi
      .filter(
        (item) =>
          item.type === "function" &&
          item.stateMutability !== "view" &&
          item.stateMutability !== "pure",
      )
      .map((item) => item.name ?? "?");
  }

  /**
   * The thread's world as the harness seeds it before the first message: the
   * contract's chain, with the runtime installed at INSTALL_ADDRESS unless it
   * is a live deployment. No snapshot, so the agent still funds its actors.
   */
  seedWorld(): SeedWorld {
    return {
      ...(this.deployment && { code_checks: [{ chain_id: this.chainId, address: this.deployment.address, code: this.deployedBytecode, immutable_references: this.immutableReferences }] }),
      forks: [
        {
          chain_id: this.chainId,
          overrides: this.deployment ? [] : [{ address: INSTALL_ADDRESS, code: this.deployedBytecode }],
        },
      ],
    };
  }

  /**
   * The opening message once the harness has seeded the world: references
   * only. The app downloads the artifact and the preamble carries the loop.
   */
  seededPrompt(artifactUrl: string, protocol: string[] = []): string {
    const wired =
      protocol.length > 0
        ? `, wired to the deployed ${protocol.join(", ")} at their real addresses (fuzz across these contracts, not only ${this.name})`
        : "";
    const where = this.deployment
      ? `the live deployment at ${this.deployment.address}${wired}`
      : `its runtime bytecode installed at ${INSTALL_ADDRESS} (no constructor ran)`;
    return `Fuzz ${this.name} (${this.sourcePath}) from a builder's Arc Studio app. The harness already seeded this thread's simulation world on Arc chain ${this.chainId} with ${where}, so do not call sim_open or sim_set_code. Call arc_map_attack_surface with artifact_url ${artifactUrl} (source_code and contract null), then run the full campaign loop from your instructions: plan, arc_fuzz_start, fund the actors with sim_set_balance and take the setup.snapshot checkpoint, then sim_replay_traces and arc_fuzz_round until next_batch is null, minimization and both reproductions included. Report each confirmed finding with its minimized call order, or say plainly that none reproduced and what was covered.`;
  }

  /**
   * The opening message for a whole protocol the harness seeded, code, storage
   * and liquidity at their real addresses; `contracts` lists every contract in
   * the world, the target first. References only, like `seededPrompt`.
   */
  seededProtocolPrompt(artifactUrl: string, contracts: string[]): string {
    return `Fuzz ${this.name} (${this.sourcePath}), the core of a protocol made of ${contracts.join(", ")}. The harness already seeded this thread's simulation world on Arc chain ${this.chainId} with the whole deployed protocol (code, storage and liquidity) at its real addresses, so do not call sim_open or sim_set_code. Call arc_map_attack_surface with artifact_url ${artifactUrl} (source_code and contract null), then run the full campaign loop from your instructions across the protocol's contracts: plan, arc_fuzz_start, fund the actors with sim_set_balance and take the setup.snapshot checkpoint, then sim_replay_traces and arc_fuzz_round until next_batch is null, minimization and both reproductions included. Report each confirmed finding with its minimized call order, or say plainly that none reproduced and what was covered.`;
  }

  /**
   * The user message that starts an autonomous campaign in the Aomi fuzzer app.
   * With `artifactUrl` the app downloads source, ABI and bytecode itself, so the
   * message stays small whatever the contract size; without it everything is
   * inlined, which only fits small contracts (throws past MAX_MESSAGE_CHARS).
   */
  prompt(artifactUrl?: string): string {
    const signatures = this.abi
      .filter((item) => item.type === "function")
      .map(
        (item) =>
          `${item.name}(${(item.inputs ?? []).map((input) => input.type).join(",")}) ${item.stateMutability ?? ""}`.trim(),
      )
      .join("\n");
    const mapStep = artifactUrl
      ? `call arc_map_attack_surface once with artifact_url set to ${artifactUrl} and source_code and contract null; the app downloads the source, ABI, and runtime bytecode and returns the source for your threat model`
      : "pass the complete compiler artifact below once to arc_map_attack_surface (Copy deployed_bytecode verbatim; never abbreviate or alter its hex)";
    const where = this.deployment
      ? ` It is already deployed at ${this.deployment.address} on Arc chain ${this.deployment.chainId}; fuzz that live instance (its real constructor state) rather than installing code, and read privileged roles such as owner() with sim_call before planning.`
      : "";
    const instructions = `Arc Studio has handed you a compiled contract from a builder's app: ${this.name} (${this.sourcePath}).${where} Run a real, complete adversarial fuzz campaign against a held Arc fork. Do not stop after static analysis and do not merely suggest tests.

Use the app-owned breadth-first campaign loop: ${mapStep}. Then open chain ${this.chainId}, author a comprehensive executable plan covering every writable entrypoint with the actor roles and properties your threat model calls for, then call arc_fuzz_start with chain_id and the plan fields at the top level (do not nest them under plan). Actor addresses are app-derived, so provide only lowercase names and balances. Before anything else in the world, install the returned runtime with sim_set_code and the actor balances with sim_set_balance, then take the setup.snapshot checkpoint (overrides are refused after it), execute every returned replay batch, feed every full replay result back into the campaign, and continue through minimization and two successful reproductions. Read the final report before closing the campaign and fork. Explain any confirmed finding with the exact minimized call order and observed fork evidence. If no property is violated within budget, say so plainly and list what was and was not covered.

Tool wire format: serialize each ABI array to a JSON string when calling the plugin. Every FuzzCall argument is a string; encode array or tuple values as JSON text. Treat every returned next_batch as an opaque app-owned recipe: do not invent, remove, reorder, relabel, or rewrite its traces or IDs. Call sim_replay_traces with that exact snapshot, chain_id, watch, and traces plus compact=true, then pass its returned traces array unchanged to arc_fuzz_round.replay. Put state-building actions before extraction actions in the plan so breadth-first expansion reaches meaningful ordered prefixes early. Labels are prose and functions are exact canonical ABI signatures. Use expected_status=reverted for unauthorized actions that must fail; succeeded is coverage pressure only because it has no scenario precondition. Probes must be view/pure only; add a getter probe for each important piece of state so storage-only changes stay distinguishable. An engine_error status means the host could not run the call and is never evidence about the contract. The campaign is finished when next_batch is null.

Critical handoff rule: immediately after every sim_replay_traces result, your very next tool call must be arc_fuzz_round with replay set to that exact returned traces array and plan=null. Never synthesize your own minimization or reproduction traces; the app returns those recipes only after it ingests the preceding replay.

Functions:
\`\`\`
${signatures}
\`\`\``;

    // arc_map_attack_surface returns the downloaded source, so inlining it here
    // too would put it in the conversation twice (guests hit the input cap).
    if (artifactUrl) return instructions;

    const artifact = {
      chain_id: this.chainId,
      contract: {
        name: this.name,
        abi: JSON.stringify(this.abi),
        deployed_bytecode: this.deployedBytecode,
        ...(this.deployment && {
          deployment: { address: this.deployment.address, chain_id: this.deployment.chainId },
        }),
      },
    };
    const inline = `${instructions}

Source:
\`\`\`solidity
${this.source}
\`\`\`

Compiler artifact:
\`\`\`json
${JSON.stringify(artifact)}
\`\`\``;
    if (inline.length > MAX_MESSAGE_CHARS) {
      throw new Error(
        `${this.name} is too large to send inline (${inline.length.toLocaleString()} > ${MAX_MESSAGE_CHARS.toLocaleString()} characters). Fuzz it from the web app, which hands the artifact over by link.`,
      );
    }
    return inline;
  }
}

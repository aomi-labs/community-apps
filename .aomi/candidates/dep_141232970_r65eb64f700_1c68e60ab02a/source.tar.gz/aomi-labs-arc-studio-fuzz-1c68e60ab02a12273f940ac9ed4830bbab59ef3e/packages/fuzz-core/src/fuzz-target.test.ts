import { expect, test } from "vitest";

import { FuzzTarget } from "./fuzz-target.ts";

test("a seeded protocol prompt references the artifact and every contract, and forbids world setup", () => {
  const target = new FuzzTarget("LendingPool", "src/LendingPool.sol", "contract LendingPool {}", [], "0x60", 5_042_002, {
    address: "0x00000000000000000000000000000000000000a1",
    chainId: 5_042_002,
  });
  const prompt = target.seededProtocolPrompt("http://127.0.0.1:3108/api/harness/artifact", ["LendingPool", "Token", "Oracle"]);
  expect(prompt).toContain("LendingPool (src/LendingPool.sol)");
  expect(prompt).toContain("made of LendingPool, Token, Oracle");
  expect(prompt).toContain("artifact_url http://127.0.0.1:3108/api/harness/artifact");
  expect(prompt).toContain("do not call sim_open or sim_set_code");
  expect(prompt).toContain("Arc chain 5042002");
});

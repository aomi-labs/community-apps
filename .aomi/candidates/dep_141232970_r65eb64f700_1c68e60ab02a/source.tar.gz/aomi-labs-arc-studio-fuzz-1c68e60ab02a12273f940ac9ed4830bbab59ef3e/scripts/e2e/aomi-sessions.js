// Staging account hygiene for e2e runs: list Aomi agent sessions, read a
// session's turn state, interrupt a stuck turn, and read the account
// statement to see which model a campaign really ran on.
//
// Paste this into the DevTools console of a tab signed in to the Aomi portal
// (https://chat-staging.aomi.dev). Requests go same-origin, so the portal
// attaches that tab's account; no token leaves the browser. Then:
//
//   await aomi.sessions()            // newest first: id, title, updated, archived
//   await aomi.turn("<sessionId>")   // last turn's id and state, last error and notice
//   await aomi.interrupt("<sessionId>")   // stop the turn aomi.turn shows as processing
//   await aomi.statement()           // raw /v1/account/statement (models and usage)
//   await aomi.archive("<sessionId>")     // hide a finished campaign thread
(() => {
  const json = async (method, path, body) => {
    const response = await fetch(path, {
      method,
      credentials: "include",
      headers: {
        accept: "application/json",
        ...(body && { "content-type": "application/json" }),
        ...(method !== "GET" && { "idempotency-key": crypto.randomUUID() }),
        ...(path.startsWith("/v1/agent/chat/") && {
          "x-session-id": path.split("/")[4],
          "x-thread-id": path.split("/")[4],
        }),
      },
      ...(body && { body: JSON.stringify(body) }),
    });
    const text = await response.text();
    if (!response.ok) throw new Error(`${method} ${path}: HTTP ${response.status} ${text.slice(0, 500)}`);
    return text ? JSON.parse(text) : undefined;
  };
  const chat = (id) => `/v1/agent/chat/${encodeURIComponent(id)}`;

  /** Every event of a session, following the cursor to the end. */
  async function events(id) {
    const all = [];
    let cursor;
    do {
      const page = await json("GET", `${chat(id)}${cursor ? `?cursor=${encodeURIComponent(cursor)}` : ""}`);
      all.push(...page.events);
      cursor = page.has_more ? page.cursor : undefined;
    } while (cursor);
    return all;
  }

  const aomi = {
    async sessions(limit = 25) {
      const page = await json("GET", `/v1/agent/sessions?limit=${limit}`);
      const rows = page.sessions.map((s) => ({
        id: s.id,
        title: s.title ?? "",
        updated: new Date(s.updatedAt).toISOString(),
        archived: s.archived,
      }));
      console.table(rows);
      return rows;
    },

    async turn(id) {
      const all = await events(id);
      const state = all.filter((e) => e.type === "turn_state_changed").at(-1);
      const error = all.filter((e) => e.type === "error").at(-1);
      const notice = all.filter((e) => e.type === "message" && e.sender === "notice").at(-1);
      const summary = {
        session: id,
        events: all.length,
        turnId: state?.turn_id ?? null,
        state: state?.state ?? "none",
        at: state ? new Date(state.occurred_at).toISOString() : null,
        lastError: error ?? null,
        lastNotice: notice?.content ?? null,
      };
      console.log(summary);
      return summary;
    },

    async interrupt(id) {
      const { turnId, state } = await aomi.turn(id);
      if (!turnId || !["processing", "awaiting_action"].includes(state)) {
        console.log(`nothing to interrupt: last turn is ${state}`);
        return null;
      }
      return json("POST", `${chat(id)}/interrupt`, { turnId });
    },

    async statement() {
      const statement = await json("GET", "/v1/account/statement");
      console.log(statement);
      return statement;
    },

    archive(id) {
      return json("PATCH", `/v1/agent/sessions/${encodeURIComponent(id)}`, { archived: true });
    },
  };
  globalThis.aomi = aomi;
  console.log("aomi.sessions(), aomi.turn(id), aomi.interrupt(id), aomi.statement(), aomi.archive(id)");
})();

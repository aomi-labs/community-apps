#!/usr/bin/env bash
# Builds the e2e target in an Arc Studio account from nothing: a new app,
# aomi-labs/lending-protocol-example cloned into its sandbox, the four
# contracts deployed through Studio's deploy_contract (so they land in its
# deployment registry), wired and seeded on Arc Testnet. Then it writes the
# addresses to .e2e/<session>.env and runs verify-onchain.sh on them.
#
# Needs `arc-studio login` (or ARC_STUDIO_TOKEN) first, and a Studio account
# whose sandbox key holds at least 15 native USDC plus gas (see the runbook).
#
#   scripts/e2e/seed-studio-app.sh [session]          # default session: lending
#
# Env: ARC_STUDIO (CLI command, default: the vendored CLI), ARC_STUDIO_API_URL,
#      E2E_RUN_TIMEOUT (minutes for the deploy turn, default 30).
set -euo pipefail

root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
here="$root/scripts/e2e"
session="${1:-lending}"
repo="aomi-labs/lending-protocol-example"
clone_dir="lending-protocol-example"
out="$root/.e2e"
read -r -a studio <<<"${ARC_STUDIO:-node $root/packages/arc-studio-cli/bin/arc-studio.mjs}"

log() { printf '[%s] %s\n' "$(date +%H:%M:%S)" "$*" >&2; }
die() { log "error: $*"; exit 1; }
command -v jq >/dev/null || die "jq is required"

# One turn; stops the script unless the turn completed.
turn() {
  local prompt_file="$1" timeout="$2" doc status
  set +e
  doc="$("${studio[@]}" run --session "$session" --prompt-file "$prompt_file" --output json --timeout "$timeout")"
  set -e
  status="$(jq -r '.status // "error"' <<<"$doc" 2>/dev/null || echo error)"
  jq -r '.finalText // empty' <<<"$doc" >&2 2>/dev/null || true
  case "$status" in
    completed) ;;
    needs_input) die "the agent asked a question: $(jq -c '.questions' <<<"$doc"). Answer it with: ${studio[*]} run --session $session --answers-json '[...]'" ;;
    budget_exceeded) die "Arc Studio budget exceeded: $(jq -c '.budget' <<<"$doc")" ;;
    *) die "turn ended with status '$status' (resume with: ${studio[*]} attach --session $session)" ;;
  esac
}

log "1/5 creating the app (session $session)"
turn "$here/prompts/01-create-app.txt" 10

log "2/5 cloning $repo into the sandbox"
"${studio[@]}" clone "$repo" --session "$session"

# A cold sandbox can take minutes to serve its first file listing.
log "3/5 waiting for the clone to be readable (up to 4 minutes)"
deadline=$((SECONDS + 240))
until "${studio[@]}" ls --session "$session" --paths "$clone_dir/src/LendingPool.sol" 2>/dev/null | grep -q LendingPool.sol; do
  ((SECONDS < deadline)) || die "$clone_dir/src/LendingPool.sol never appeared in the sandbox"
  sleep 15
done

log "4/5 deploying, wiring and seeding through the Studio agent"
turn "$here/prompts/02-deploy-and-wire.txt" "${E2E_RUN_TIMEOUT:-30}"

log "5/5 reading Studio's deployment registry"
deployments="$("${studio[@]}" deployments --session "$session" --json)"
# The fuzz app takes the newest registered deployment per contract name, so do the same.
address_of() {
  jq -r --arg name "$1" '
    [.[] | select(.contract == $name or (.contract | endswith(":" + $name)))
         | select(.network | test("testnet"; "i"))]
    | sort_by(.deployedAt // "") | last | .address // empty' <<<"$deployments"
}
mkdir -p "$out"
env_file="$out/$session.env"
{
  echo "# Written by scripts/e2e/seed-studio-app.sh on $(date -u +%FT%TZ)"
  echo "E2E_SESSION=$session"
  echo "E2E_APP_ID=$("${studio[@]}" sessions --json | jq -r --arg s "$session" '.[] | select(.name == $s) | .appId')"
  for contract in CollateralToken SimpleAMM PriceOracle LendingPool; do
    address="$(address_of "$contract")"
    [[ -n "$address" ]] || die "no Arc Testnet deployment of $contract in the registry: $deployments"
    echo "$contract=$address"
  done
} >"$env_file"
log "wrote $env_file"
cat "$env_file" >&2

"$here/verify-onchain.sh" "$env_file"

#!/usr/bin/env bash
# shellcheck disable=SC2154  # the contract addresses come from the sourced env file
# Checks on Arc Testnet that the lending protocol is deployed, wired and
# seeded the way seed-studio-app.sh leaves it. Read-only; needs Foundry's cast.
#
#   scripts/e2e/verify-onchain.sh .e2e/lending.env
#
# The env file holds CollateralToken, SimpleAMM, PriceOracle and LendingPool
# addresses. Override the expected seed with E2E_AMM_WGLD, E2E_AMM_USDC and
# E2E_POOL_USDC (wei), and the RPC with ARC_TESTNET_RPC.
set -euo pipefail

env_file="${1:?usage: verify-onchain.sh <addresses.env>}"
# shellcheck disable=SC1090
source "$env_file"
rpc="${ARC_TESTNET_RPC:-https://rpc.testnet.arc.io}"
amm_wgld="${E2E_AMM_WGLD:-5000000000000000000}"
amm_usdc="${E2E_AMM_USDC:-5000000000000000000}"
pool_usdc="${E2E_POOL_USDC:-10000000000000000000}"
command -v cast >/dev/null || { echo "cast is required (Foundry)" >&2; exit 1; }
for name in CollateralToken SimpleAMM PriceOracle LendingPool; do
  [[ -n "${!name:-}" ]] || { echo "$env_file has no $name address" >&2; exit 1; }
done

# cast prints "5000000000000000000 [5e18]"; keep the first field.
call() { cast call --rpc-url "$rpc" "$@" | awk '{print $1}'; }
# SimpleAMM.spotPrice() = reserveNative * 1e18 / reserveToken; too big for bash math.
spot="$(node -e 'console.log((BigInt(process.argv[1]) * 10n ** 18n / BigInt(process.argv[2])).toString())' "$amm_usdc" "$amm_wgld")"

failed=0
check() {
  local label="$1" got="$2" want="$3"
  # Lowercase for addresses; macOS ships bash 3, which has no ${var,,}.
  if [[ "$(tr '[:upper:]' '[:lower:]' <<<"$got")" == "$(tr '[:upper:]' '[:lower:]' <<<"$want")" ]]; then
    printf '  ok    %-38s %s\n' "$label" "$got"
  else
    printf '  FAIL  %-38s got %s, want %s\n' "$label" "$got" "$want"
    failed=1
  fi
}

echo "Arc Testnet ($rpc)"
check "CollateralToken.pool()" "$(call "$CollateralToken" 'pool()(address)')" "$LendingPool"
check "CollateralToken.balanceOf(SimpleAMM)" "$(call "$CollateralToken" 'balanceOf(address)(uint256)' "$SimpleAMM")" "$amm_wgld"
check "SimpleAMM.spotPrice()" "$(call "$SimpleAMM" 'spotPrice()(uint256)')" "$spot"
check "PriceOracle.price()" "$(call "$PriceOracle" 'price()(uint256)')" "$spot"
check "native balance of SimpleAMM" "$(cast balance --rpc-url "$rpc" "$SimpleAMM")" "$amm_usdc"
check "native balance of LendingPool" "$(cast balance --rpc-url "$rpc" "$LendingPool")" "$pool_usdc"

if ((failed)); then
  echo "The protocol is not in its seeded state." >&2
  exit 1
fi
echo "All six checks passed."

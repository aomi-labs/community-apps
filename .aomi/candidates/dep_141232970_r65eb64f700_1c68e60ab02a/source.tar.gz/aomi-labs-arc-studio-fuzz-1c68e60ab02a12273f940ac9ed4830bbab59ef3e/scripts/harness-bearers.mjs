#!/usr/bin/env node
// Mints the two hour-lived user bearers the web app's /harness page sends to a
// self-hosted stack, so the web process never holds the operator key:
//   E2E_AUTH_KEY=keys/operator.pem node scripts/harness-bearers.mjs [seedDir]
// Writes <seedDir>/bearers.json next to scripts/seed-protocol.mjs's output.
// Env names match packages/fuzz-core/scripts/e2e-seeded-protocol.mjs.
import { createPrivateKey } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

import { backendClaims, portalClaims, selfhostBearer } from "../packages/fuzz-core/scripts/selfhost-bearer.mjs";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const dir = process.argv[2] ?? join(root, ".seed");
const env = (name, fallback) => process.env[name] ?? fallback;
const keyPath = env("E2E_AUTH_KEY");
if (!keyPath) {
  console.error("E2E_AUTH_KEY (the stack's user-issuer Ed25519 PEM) is required");
  process.exit(64);
}
const ttlSeconds = 3600;
const signer = {
  key: createPrivateKey(readFileSync(keyPath)),
  kid: env("E2E_AUTH_KID", "selfhost-auth-1"),
  issuer: env("E2E_AUTH_ISSUER", "selfhost-auth"),
  user: env("E2E_USER", "harness-user"),
  ttlSeconds,
};
const apiUrl = env("E2E_API_URL", "http://127.0.0.1:8182");
const bearers = {
  portal: selfhostBearer(signer, portalClaims(apiUrl)),
  backend: selfhostBearer(signer, backendClaims()),
  expires: Date.now() + ttlSeconds * 1000,
};
const out = join(dir, "bearers.json");
writeFileSync(out, `${JSON.stringify(bearers, null, 2)}\n`, { mode: 0o600 });
console.log(JSON.stringify({ out, user: signer.user, apiUrl, expires: new Date(bearers.expires).toISOString() }, null, 2));

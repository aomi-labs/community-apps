#!/usr/bin/env node
// Deploys examples/lending-protocol on a throwaway local anvil, then dumps
// every contract's code, balance and storage into:
//   <out>/seed.json      body of Aomi's POST /api/thread/sim/world
//   <out>/artifact.json  what the arc-studio-fuzzer app downloads
// The seeded world then holds the whole wired protocol, constructor and
// liquidity state included, at the same addresses.
//
//   node scripts/seed-protocol.mjs [outDir] [chainId]
import { execFileSync, spawn } from "node:child_process";
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { gunzipSync } from "node:zlib";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const project = join(root, "examples/lending-protocol");
const out = process.argv[2] ?? join(root, ".seed");
const chainId = Number(process.argv[3] ?? 5_042_002);
const port = 18_546;
const rpc = `http://127.0.0.1:${port}`;
const usdc = (n) => `${BigInt(n) * 10n ** 18n}`;

const cast = (...args) => execFileSync("cast", args, { encoding: "utf8" }).trim();
const call = async (method, params = []) => {
  const response = await fetch(rpc, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }),
  });
  const body = await response.json();
  if (body.error) throw new Error(`${method}: ${body.error.message}`);
  return body.result;
};
const artifact = (name) => JSON.parse(readFileSync(join(project, `out/${name}.sol/${name}.json`), "utf8"));

execFileSync("forge", ["build"], { cwd: project, stdio: "ignore" });
const anvil = spawn(
  "anvil",
  ["--port", `${port}`, "--chain-id", `${chainId}`, "--mnemonic-random", "--balance", "1000000", "--silent"],
  { stdio: "ignore" },
);
try {
  for (let i = 0; ; i++) {
    try {
      await call("eth_chainId");
      break;
    } catch (error) {
      if (i > 50) throw error;
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
  }
  const [deployer] = await call("eth_accounts");
  const send = (...args) => cast("send", "--unlocked", "--from", deployer, "--rpc-url", rpc, "--json", ...args);
  const create = (name, signature, ...args) => {
    const bytecode = artifact(name).bytecode.object;
    const receipt = JSON.parse(send("--create", bytecode, ...(signature ? [signature, ...args] : [])));
    return receipt.contractAddress;
  };

  const token = create("CollateralToken");
  const amm = create("SimpleAMM", "constructor(address)", token);
  const oracle = create("PriceOracle", "constructor(address)", amm);
  const pool = create("LendingPool", "constructor(address,address)", token, oracle);
  send(token, "setPool(address)", pool);
  send(token, "mint(address,uint256)", deployer, usdc(10_000));
  send(token, "approve(address,uint256)", amm, usdc(20));
  // 2,000 USDC against 20 WGLD: 100 USDC per WGLD.
  send(amm, "seed(uint256)", usdc(20), "--value", usdc(2_000));
  // Lenders' liquidity the borrowers draw on.
  send(pool, "supply()", "--value", usdc(100_000));

  const state = JSON.parse(gunzipSync(Buffer.from((await call("anvil_dumpState")).slice(2), "hex")).toString());
  const word = (hex) => `0x${BigInt(hex).toString(16).padStart(64, "0")}`;
  const contracts = { LendingPool: pool, CollateralToken: token, SimpleAMM: amm, PriceOracle: oracle };
  const account = (address) => {
    const entry = Object.entries(state.accounts).find(([key]) => key.toLowerCase() === address.toLowerCase())?.[1];
    if (!entry?.code || entry.code === "0x") throw new Error(`no code at ${address}`);
    return entry;
  };
  const seed = {
    forks: [
      {
        chain_id: chainId,
        overrides: Object.values(contracts).map((address) => {
          const entry = account(address);
          return {
            address,
            code: entry.code,
            balance: BigInt(entry.balance).toString(),
            storage: Object.fromEntries(Object.entries(entry.storage ?? {}).map(([slot, value]) => [word(slot), word(value)])),
          };
        }),
      },
    ],
  };
  const sources = ["LendingPool", "PriceOracle", "SimpleAMM", "CollateralToken"]
    .map((name) => `// File: src/${name}.sol\n${readFileSync(join(project, `src/${name}.sol`), "utf8")}`)
    .join("\n");
  const download = {
    name: "LendingPool",
    source_code: sources,
    abi: JSON.stringify(artifact("LendingPool").abi),
    deployed_bytecode: account(pool).code,
    chain_id: chainId,
    deployment: { address: pool, chain_id: chainId, installed: true },
    protocol: ["CollateralToken", "SimpleAMM", "PriceOracle"].map((name) => ({
      name,
      address: contracts[name],
      abi: JSON.stringify(artifact(name).abi),
    })),
  };
  mkdirSync(out, { recursive: true });
  writeFileSync(join(out, "seed.json"), `${JSON.stringify(seed, null, 2)}\n`);
  writeFileSync(join(out, "artifact.json"), `${JSON.stringify(download, null, 2)}\n`);
  console.log(JSON.stringify({ out, chainId, deployer, contracts }, null, 2));
} finally {
  anvil.kill();
}

#!/usr/bin/env python3
"""Immutable Project deploy. Admin key stays in memory; short-lived tokens never enter logs."""
import argparse, base64, json, os, re, subprocess, time, urllib.request, urllib.error
from cryptography.hazmat.primitives import serialization

def admin_bearer():
    key = serialization.load_pem_private_key(os.environ['AOMI_ADMIN_SERVICE_PRIVATE_KEY_STAGING'].encode(), password=None)
    def b64(v): return base64.urlsafe_b64encode(json.dumps(v,separators=(',',':')).encode()).rstrip(b'=')
    now=int(time.time())
    data=b64({'alg':'EdDSA','kid':'aomi-admin-staging-1'})+b'.'+b64({'sub':'daiko-deploy','iss':'aomi-admin','aud':'aomi-backend','role':'admin','iat':now,'exp':now+300})
    return (data+b'.'+base64.urlsafe_b64encode(key.sign(data)).rstrip(b'=')).decode()

def call(base,path,token,body=None,method=None):
    req=urllib.request.Request(base+path,data=json.dumps(body).encode() if body is not None else None,method=method,headers={'Authorization':'Bearer '+token,'Content-Type':'application/json','User-Agent':'daiko-deployer/0.1'})
    try:
        with urllib.request.urlopen(req,timeout=90) as r:return json.load(r)
    except urllib.error.HTTPError as e:
        # Server JSON may contain nested source data: log only safe error code/message.
        try:d=json.load(e)
        except Exception:d={}
        raise RuntimeError(f"{path}: HTTP {e.code}, {d.get('error_code','request_failed')}: {d.get('error','')[:350]}") from None

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--commit');ap.add_argument('--project-id',type=int);ap.add_argument('--preflight',action='store_true');ap.add_argument('--connect',action='store_true');ap.add_argument('--activate',metavar='DEPLOYMENT_ID');ap.add_argument('--status',metavar='DEPLOYMENT_ID');args=ap.parse_args()
    base=os.environ['AOMI_DEPLOY_BACKEND_URL'].rstrip('/')
    if base!='https://api-staging.aomi.dev': raise RuntimeError('This deployment job is scoped to staging')
    admin=admin_bearer();mint=call(base,'/api/platforms/community/tokens',admin,{'scope':'platform'});token=mint['token']
    try:
        if args.connect:
            result=call(base,'/api/platforms/community/projects',token,{'repo':'aomi-labs/daiko-bot','github_user_id':os.environ['AOMI_BUILDER_GITHUB_ID']})
        elif args.status:result=call(base,f'/api/platforms/community/deployments/{args.status}/status',token)
        elif args.activate:
            result=call(base,'/api/platforms/community/apps/activate',token,{'target':{'kind':'deployment','value':args.activate},'apps':['daiko'],'actor':'CeciliaZ030'})
        else:
            sha=args.commit or subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
            if not re.fullmatch('[0-9a-f]{40}',sha):raise RuntimeError('Deploy requires a full immutable SHA')
            project=args.project_id or int(os.environ['AOMI_PROJECT_ID'])
            result=call(base,f'/api/projects/{project}/deploy',token,{'source_ref':sha,'preflight':True})
            if not args.preflight:result=call(base,f'/api/projects/{project}/deploy',token,{'source_ref':sha,'preflight':False})
        # This endpoint contract has no bearer in successful deployment/status outputs.
        print(json.dumps(result,indent=2))
    finally:
        call(base,f"/api/platforms/community/tokens/{mint['id']}",admin_bearer(),method='DELETE')
if __name__=='__main__':main()

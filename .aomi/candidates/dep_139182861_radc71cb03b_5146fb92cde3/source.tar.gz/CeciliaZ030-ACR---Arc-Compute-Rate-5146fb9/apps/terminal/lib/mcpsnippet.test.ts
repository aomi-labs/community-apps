import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { AOMI_CHAT, EXAMPLES, TOOLS, snippetApi, snippets } from "../components/chain/McpSnippet";

test("the MCP config names the API this page looks at, and is JSON a host can paste", () => {
  const s = snippets("https://acr.test");
  assert.match(s.config, /"ACR_API": "https:\/\/acr.test"/);
  assert.ok(JSON.parse(s.config).mcpServers["acr-tca"], "the config must be valid JSON a host can paste");

  // The paying tab is prose around JSON, so parse the braces out of it.
  const payJson = s.pay.slice(s.pay.indexOf("{"), s.pay.lastIndexOf("}") + 1);
  assert.match(payJson, /"ACR_API": "https:\/\/acr.test"/);
  assert.ok(JSON.parse(payJson).mcpServers["acr-tca"], "the paying config must parse too");
});

test("the config is one a visitor can paste unedited, with no path in it", () => {
  /* RENAMED, because the old title asserted something that is not true. It read
     "the config installs the published package" and justified itself with "the
     published package name, so there is nothing to clone" — and `npm view
     acr-mcp` is a 404: it has never been published. The CONSTRAINT this test
     holds is still exactly right (a snippet whose point is that it pastes
     unedited must not carry a placeholder path), so the assertions stand. Only
     the claim about the registry goes, because a green test whose comment
     states a falsehood is how a reader concludes everything is fine.
     What a 404 means is now said on the page itself, pinned below. */
  const s = snippets("https://acr.test");
  for (const tab of [s.config, s.pay]) {
    assert.match(tab, /"npx"/);
    assert.match(tab, /"-y", "acr-mcp"/, "the package name a host resolves, once it is on npm");
    // It used to say `["tsx", "/path/to/ACR/mcp/src/server.ts"]`: a placeholder
    // path, in a package that was `private: true` and had no bin, so pasting this
    // could not work without first cloning the monorepo and editing the string.
    assert.ok(!tab.includes("/path/to/"), "a placeholder path is not a config a visitor can paste");
    assert.ok(!/\.ts"/.test(tab), "a host runs the built binary, not TypeScript source");
  }
});

test("the page never claims the package is unpublished", () => {
  /* THE GATE INVERTED, which is the point of keeping one here at all.
     For one day this page carried a clause reading "Not on npm yet, so a 404
     here is expected", because `npm view acr-mcp` really was a 404 while the
     page handed out two configs built around `npx -y acr-mcp`. A test then
     asserted that clause EXISTED, so it could not be dropped while the dead
     end was real.
     `acr-mcp@0.3.0` published on 2026-10-10 and `npx -y acr-mcp` answers
     `tools/list` from a clean cache, so the claim became false and the clause
     came out. This holds the other direction: the page must not re-acquire a
     sentence asserting the package is missing from npm. A published package
     described as unpublished is the same class of defect as an archive naming
     the live gate, or a 25-day-old print badged LIVE — a surface asserting
     something it has not checked. */
  const src = readFileSync(
    join(dirname(fileURLToPath(import.meta.url)), "..", "components", "chain", "McpSnippet.tsx"),
    "utf8",
  );
  for (const claim of [/x="Not on npm yet/, /p="If that command is not found/]) {
    assert.ok(
      !claim.test(src),
      `acr-mcp is published; this page must not say otherwise (${claim})`,
    );
  }
  // And the command it does advertise is still the published one.
  assert.match(src, /npx -y acr-mcp/, "the install row must still name the package");
});

test("every tool the server registers is named on this page", () => {
  const s = snippets("https://acr.test");
  // Deliberately NOT `s.ask + s.config + TOOLS.join()`: that third term satisfies
  // every match on its own, so the assertion could not fail. The tool list is
  // rendered from TOOLS, so what needs proving is that the WORKED EXAMPLES
  // exercise the tools worth demonstrating.
  for (const t of [
    "can_i_pay",
    "wallet_tca",
    // The tool the page exists to teach now: check_spend answers one bill and
    // spend_report answers the question behind it, so an example that shows the
    // first without the second teaches half a product.
    "spend_report",
    "reroute_suggestion",
    "seller_rating",
    "query_tape",
  ]) {
    assert.match(s.ask, new RegExp(t), `the examples should demonstrate ${t}`);
  }
  assert.match(s.pay, /pay_and_read/, "the paying tab must name the tool it unlocks");
});

test("the tools this page teaches ARE the tools the server registers", () => {
  /* READ FROM mcp/src/tools.ts, not pinned as a second list.
     
     This test used to assert a hardcoded array of names. That is a snapshot, not
     a cross-check: when `check_spend` was added to the plugin, this file went on
     passing against its own stale copy and the page quietly taught nine tools of
     ten. A literal list in a test cannot catch the drift it exists to catch.
     
     So it reads the other language's source, which is the discipline
     `tests/test_canonical_host.py` and `lib/mainnetOnly.test.ts` already use:
     when the alternative is a second copy of the truth, read the first one.
     `pay_and_read` is included because the plugin HAS it — the server withholds
     it at runtime until a payer key is set (`toolsFor`), which is a different
     question from whether it exists. */
  const src = readFileSync(join(dirname(fileURLToPath(import.meta.url)), "..", "..", "..", "mcp", "src", "tools.ts"), "utf8");
  // The `TOOLS` array's entries, each `name: "…"` at the head of a tool record.
  const registered = [...src.matchAll(/^\s{4}name: "([a-z_]+)",$/gm)].map((m) => m[1]);
  assert.ok(registered.length >= 9, `expected to find the tool names, found ${registered.length}`);
  assert.deepEqual([...TOOLS].sort(), registered.sort(), "the page and the plugin must agree");
});

test("the paying tab states the cap and which balance a settlement spends", () => {
  const s = snippets("https://acr.test");
  assert.match(s.pay, /ACR_MAX_SPEND_USDC/, "a $0.0001 call is what makes a loop expensive quietly");
  assert.match(s.pay, /GATEWAY balance, not the wallet/, "the rung that surprises people");
  assert.match(s.pay, /ACR_PAYER_PRIVATE_KEY/);
  assert.ok(
    !s.config.includes("ACR_PAYER_PRIVATE_KEY"),
    "the default config must not invite a spending key into a host that only wants reads",
  );
});

test("the worked examples use addresses that have rows at the plugin's default window", () => {
  const s = snippets("https://acr.test");
  // Measured 2026-10-09 on the press this page calls: this payer has 3 purchases
  // at -1139.8 bp over 30 days, and this seller answers Unrated with its reason
  // given. BOTH reported zero over 7 days, which is what the page used to
  // demonstrate. `mcp/scripts/smoke.ts` probes the same two addresses, so a press
  // that stops answering for them fails there rather than quietly here.
  assert.match(s.ask, /0xc2903b52a3ad365fd237b78389a2fde99e886999/);
  assert.match(s.ask, /0xefe0E4625AFf072c3FCff230b47f8150A17aDF19/);
  assert.ok(
    !s.ask.includes("0x674055533B05Ec3fD135fC21c4d91a4A2D3193d3"),
    "that payer has no rows on the host this page calls — an example that demonstrates nothing",
  );
  assert.ok(!/this week/.test(s.ask), "the default window is 30 days, so the question must not say a week");
});

test("the bill example names no vendor, because an ACR seller cannot be priced against the market", () => {
  /* MEASURED 2026-10-13 through the published plugin. The example read "billed
     0.47 USDC for 23 thousand tokens BY 0xefe0…" — and 0xefe0… is ACR's own
     seller, which the press prices only against ACR's fleet, never the open
     market. The answer was "pay, unbenchmarked" on mainnet and "pay, −9,609 bp"
     on testnet, while the same bill with no vendor was "escalate, +500,870 bp"
     against five cited market prices. The page's demo of token spend was the one
     case the tool is built to refuse.

     The seller_rating example SHOULD keep that address (it rates a seller); only
     the question check_spend answers must not carry one. */
  const lines = snippets("https://acr.test").ask.split("\n");
  const arrow = lines.findIndex((l) => /->\s*check_spend\b/.test(l));
  assert.ok(arrow > 0, "the ask tab must still teach check_spend");
  const question = lines.slice(0, arrow).reverse().find((l) => l.startsWith('"')) ?? "";
  assert.match(question, /tokens/, "the check_spend example should be a token bill");
  assert.doesNotMatch(
    question,
    /0x[0-9a-fA-F]{40}/,
    `the check_spend example names a vendor address: ${question}`,
  );
});

test("a press that cannot serve the tools is not pinned into the config", () => {
  /* THE CONFIG USED TO BE WORSE THAN NONE. `ACR_API` was pinned to
     `baseState().active` — whichever host last answered, which for most of this
     deployment's life was `acr-api-mainnet`. That host serves /terminal/data
     and answers 404 for /par and all five /operator/*, so the paste-ready
     block OVERRODE the npm package's own correct default (`acr-probe-free`)
     with the one host where five of eleven tools cannot work.

     Null omits the line. The caller decides by asking the host —
     `servesPath(served, "/par")` — not from a hostname list that would go
     stale the moment an image is rebuilt. */
  const pinned = snippets("https://acr.test");
  const unpinned = snippets(null);

  assert.match(pinned.config, /"ACR_API": "https:\/\/acr.test"/);
  assert.doesNotMatch(unpinned.config, /ACR_API/, "a host that cannot serve it must not be named");
  assert.doesNotMatch(unpinned.pay, /ACR_API/, "and the paying config is the same decision");

  // BOTH SHAPES MUST STILL PARSE. This is pasted into a JSON config file, so a
  // dangling comma or an orphaned brace is a support question rather than a
  // typo. JSON has no comments, which is why the explanation for the missing
  // line lives in the component's prose and not in the snippet.
  for (const [name, snip] of [["pinned", pinned.config], ["unpinned", unpinned.config]] as const) {
    const parsed = JSON.parse(snip) as {
      mcpServers: { "acr-tca": { env: Record<string, string>; args: string[] } };
    };
    const server = parsed.mcpServers["acr-tca"];
    assert.deepEqual(server.args, ["-y", "acr-mcp"], `${name}: still installs the package`);
    assert.ok(
      "ACR_AGENT_PRIVATE_KEY" in server.env,
      `${name}: the card key is what makes the tools carded, and must survive`,
    );
  }
  assert.equal(
    "ACR_API" in JSON.parse(unpinned.config).mcpServers["acr-tca"].env,
    false,
  );
});

// ── an outside team testing its own agents (the Aomi team, 2026-10-14) ─────────

test("on testnet the worked examples name testnet's own subjects, over a window that has rows", () => {
  /* Measured 2026-10-14 on the testnet press: 0x784e… bought 144 times and
     0x8366… is the seller it paid, inside 90 days, and NOTHING inside the
     plugin's 30-day default. The page used to hand a testnet visitor the
     mainnet pair, whose honest answer there is "never seen". */
  const t = snippets("https://press.test", "testnet").ask;
  assert.ok(t.includes(EXAMPLES.testnet.payer), "the testnet payer");
  assert.ok(t.includes(EXAMPLES.testnet.seller), "the testnet seller");
  assert.match(t, /in the last 90 days/);
  assert.ok(!t.includes(EXAMPLES.mainnet.payer), "never the other chain's wallet");
  const m = snippets("https://press.test", "mainnet").ask;
  assert.ok(m.includes(EXAMPLES.mainnet.payer) && !m.includes(EXAMPLES.testnet.payer));
});

test("the ask tab's heading counts the questions it actually lists", () => {
  /* It said "Five things to ask" over six questions. */
  const words = ["Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten"];
  for (const chain of ["mainnet", "testnet"] as const) {
    const ask = snippets(null, chain).ask;
    const said = words.indexOf(ask.split(" ")[1]);
    const listed = ask.split("\n").filter((l) => l.startsWith('"')).length;
    assert.equal(said, listed, `${chain}: heading says ${ask.split(" ")[1]}, lists ${listed}`);
  }
});

test("testnet always pins its own press; mainnet still leaves out a press without /par", () => {
  /* Null means the package default, and that default is a MAINNET press: on
     testnet, leaving the line out silently tested the other chain. */
  assert.equal(snippetApi("testnet", "https://t.test", false), "https://t.test");
  assert.equal(snippetApi("testnet", "https://t.test", null), "https://t.test");
  assert.equal(snippetApi("mainnet", "https://m.test", false), null);
  assert.equal(snippetApi("mainnet", "https://m.test", true), "https://m.test");
  assert.equal(snippetApi("mainnet", "https://m.test", null), "https://m.test", "unread is not 'lacks /par'");
});

test("the card key is marked optional, because the tools answer without it", () => {
  /* mcp/src/card.ts: "Opt-in. No ACR_AGENT_PRIVATE_KEY means no header and an
     anonymous call". The line read as a requirement. */
  assert.match(snippets(null).config, /"ACR_AGENT_PRIVATE_KEY": "0x<optional:/);
});

test("the testnet paying tab starts with free test money; mainnet's names no faucet", () => {
  const t = snippets("https://press.test", "testnet").pay;
  assert.match(t, /faucet\.circle\.com/);
  assert.match(t, /Gateway/);
  assert.match(t, /can_i_pay/);
  assert.doesNotMatch(snippets("https://press.test", "mainnet").pay, /faucet/, "mainnet has no faucet");
});

test("the Aomi tab opens the App pinned, the way Aomi's own dashboard does", () => {
  /* Unpinned, chat.aomi.dev routes on its own and answered our bill question
     without ACR. aomi-labs/aomi chat-url.ts builds ?app=…&application_id=…&lock_app=1. */
  const a = snippets(null, "testnet").aomi;
  assert.ok(a.includes(AOMI_CHAT));
  assert.match(AOMI_CHAT, /app=acr-compute-rate&application_id=2938642&lock_app=1$/);
  assert.match(a, /Arc mainnet/, "the App reads mainnet, whichever chain this page shows");
  assert.ok(a.includes(EXAMPLES.mainnet.payer) && !a.includes(EXAMPLES.testnet.payer));
});

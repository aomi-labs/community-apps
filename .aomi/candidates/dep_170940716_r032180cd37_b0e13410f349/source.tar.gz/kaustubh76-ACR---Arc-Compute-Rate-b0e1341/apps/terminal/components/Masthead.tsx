"use client";

import Link from "next/link";
import { ChainToggle } from "./ChainToggle";
import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { useHealth } from "@/lib/useLive";
import { useConnection, type Connection } from "@/lib/useConnection";
import { useEdition } from "@/lib/useEdition";
import { Ed } from "@/components/Ed";
import { EditionToggle } from "@/components/EditionToggle";
import { WorkloadChip } from "@/components/WorkloadChip";
import type { Envelope, TerminalData } from "@/lib/types";

/* [href, expert label, plain label] — the plain edition renames the sections
   in the reader's own words; the pages themselves swap with the same click. */
const NAV: Array<[href: string, label: string, plain: string]> = [
  ["/", "Fixing", "The Rate"],
  // The reader's primer sits second, not last. It existed for a week reachable
  // only from the footer and the 404 page — the one page written for a
  // first-time reader was the one no first-time reader could find.
  ["/companion", "Companion", "Start Here"],
  // Third, ahead of the lab, because of what a reader wants in this order: they
  // meet a rate, and the next question is not "can it be gamed" but "what does
  // it say about MY bill". /attack defends the rate, which only matters once
  // somebody cares about it. This is also the only page here that takes an
  // input from a stranger and answers without an account, a key or a signup.
  ["/check", "Check a Bill", "Is This Fair?"],
  ["/attack", "Attack Lab", "Try to Cheat It"],
  ["/curve", "Curve", "Future Prices"],
  // The tape used to sit after a seller registry that no longer exists. It
  // stays here because the order still reads: a reader meets a price, then asks
  // what buying at it actually cost. Seller grades live on the tape itself.
  ["/tape", "The Tape", "Receipts"],
  // The loop after the tape: a reader sees what buying cost, then drives the
  // decision the cost produces.
  ["/loop", "The Loop", "Drive It"],
  // Spend after the loop: the loop drives ONE decision, this is a business's
  // whole book of them. In the nav rather than operator-only like /ops,
  // because a reviewer should be able to find the owner's page without us in
  // the room, and it is the page that shows the agent refusing.
  ["/spend", "Spend", "Money Agent"],
  // Traction after Spend: a reader sees one business's money, then how many
  // businesses there are. In the nav because these are the numbers a reviewer
  // came to check, and they should not have to be told the URL.
  ["/traction", "Traction", "Who Uses It"],
  ["/developers", "Developers", "For Coders"],
];

function isActive(pathname: string, href: string): boolean {
  if (href === "/") return pathname === "/" || pathname.startsWith("/index/");
  return pathname.startsWith(href);
}

/* The honest mode signal, always visible: which tier of reality is on screen.
   The full connection ladder (lib/connection.ts) — live / stale / waking /
   on-chain-only / archived / linking — not just a live-or-sim binary. */
function StatusPill({ conn }: { conn: Connection }) {
  const health = useHealth();
  const gate = health?.live ? health.data?.gate : null;
  const plain = useEdition() === "plain";

  switch (conn.state) {
    case "live":
      return gate === "circle" ? (
        <span className="chip chip-teal nav-pulse">
          <i className="dot breathe" />
          live · circle gateway
        </span>
      ) : (
        <span className="chip chip-sky nav-pulse">
          <i className="dot breathe" />
          <Ed x="live · dev gate" p="live · practice paywall" />
        </span>
      );
    case "linking":
      return (
        <span
          className="chip chip-sky nav-pulse"
          title={
            plain
              ? "first load: reaching our live server"
              : "first edition: contacting the press"
          }
        >
          <Ed x="linking · first edition" p="connecting · first load" />
        </span>
      );
    case "stale":
      return (
        <span
          className="chip chip-gold nav-pulse"
          title={
            plain
              ? "our server stopped answering: showing the last live numbers while retrying"
              : "the press stopped answering: showing the last live edition while retrying"
          }
        >
          <i className="dot breathe" />
          stale · {conn.ageS ?? 0}s · retrying
        </span>
      );
    case "waking":
      return (
        <span
          className="chip chip-gold nav-pulse"
          title={
            plain
              ? "our server naps between visits to save money; it is waking up now"
              : "the press sleeps between visits (free tier); a wake call is in flight"
          }
        >
          <i className="dot breathe" />
          <Ed
            x={<>waking the press · ~{conn.wakeRemainingS ?? 0}s</>}
            p={<>waking our server · ~{conn.wakeRemainingS ?? 0}s</>}
          />
        </span>
      );
    case "onchain-only":
      return (
        <span
          className="chip chip-teal nav-pulse"
          title={
            plain
              ? "our server is down but the public scoreboard answers directly; the numbers are the official record"
              : "the press is down but ACROracle answers direct reads; prints are settlement-grade"
          }
        >
          <i className="dot breathe" />
          <Ed x="live · on-chain reads" p="live · read off the blockchain" />
        </span>
      );
    default:
      return (
        <span
          className="chip chip-sim nav-pulse"
          title={
            plain
              ? "a saved snapshot: the live server is not answering"
              : "bundled snapshot: the press is not answering"
          }
        >
          <Ed x="sim · archived" p="simulation · saved copy" />
        </span>
      );
  }
}

export function Masthead({ initial }: { initial: Envelope<TerminalData> }) {
  const conn = useConnection(initial);
  const pathname = usePathname() ?? "/";
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className={`masthead-shell${scrolled ? " scrolled" : ""}`}>
      <header className="masthead container">
        <div className="masthead-top">
          <div className="nameplate">
            ACR <em>· Arc Compute Rate</em>
          </div>
          <Ed
            x="the reference rate for machine commerce"
            p="the going rate for machine work, in plain words"
            className="label"
          />
        </div>
        <div className="horizon-rule" />
        <nav className="nav">
          {/* The links are wrapped so a phone can scroll them sideways as one
              strip. `.nav-links` is `display: contents` above 640px, so the
              links remain direct flex children of `.nav` and the desktop
              layout is byte-identical to before this element existed. */}
          <span className="nav-links">
            {NAV.map(([href, label, plain]) => (
              <Link key={href} href={href} className={isActive(pathname, href) ? "active" : ""}>
                <Ed x={label} p={plain} />
              </Link>
            ))}
          </span>
          <span className="nav-right">
            {/* Renders only once a reader has priced their workload — quiet
                chrome is the rule, and the invitation lives on the home page. */}
            <WorkloadChip initial={initial} />
            {/* Weight tracks the risk of being on the wrong network: a footnote
                on the default, a gold chip off it. Not the dateline chip, which
                keeps reporting what ANSWERED — the two cross-check. */}
            <ChainToggle />
            <EditionToggle />
            <StatusPill conn={conn} />
          </span>
        </nav>
      </header>
    </div>
  );
}

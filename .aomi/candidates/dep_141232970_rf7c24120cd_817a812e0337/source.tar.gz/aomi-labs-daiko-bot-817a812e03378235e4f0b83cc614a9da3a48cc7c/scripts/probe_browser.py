#!/usr/bin/env python3
"""Run one hosted logged-out probe. Never prints credentials or image bytes."""
import argparse
import json
from pathlib import Path
import subprocess
import urllib.request
import urllib.error
import base64


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('site', choices=['fomo', 'gmgn'])
    parser.add_argument('mint')
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--authenticated', action='store_true', help='Restore operator-provisioned Fomo auth state')
    args = parser.parse_args()
    raw = subprocess.run(['op', 'item', 'get', 'Daiko hosted browser', '--vault', 'Aomi Dev', '--format', 'json'], capture_output=True, text=True, check=True).stdout
    fields = {f.get('label'): f.get('value') for f in json.loads(raw)['fields']}
    request = urllib.request.Request(fields['worker_url'] + '/probe',
        data=json.dumps({'site': args.site, 'mint': args.mint, 'restore_state': args.authenticated}).encode(),
        headers={'Authorization': 'Bearer ' + fields['service_key'], 'Content-Type': 'application/json',
                 'User-Agent': 'DaikoBrowserProbe/1.0'})
    try:
        with urllib.request.urlopen(request, timeout=120) as response:
            result = json.load(response)
    except urllib.error.HTTPError as error:
        result = {'status': 'probe_http_error', 'http_status': error.code,
                  'response_excerpt': error.read(2000).decode(errors='replace')}
    screenshot = result.pop('screenshot_base64', None)
    args.out.mkdir(parents=True, exist_ok=True)
    if screenshot:
        image = args.out / (args.site + '.png')
        image.write_bytes(base64.b64decode(screenshot))
        result['local_screenshot'] = str(image)
    evidence = args.out / (args.site + '.json')
    evidence.write_text(json.dumps(result, indent=2))
    summary = {k: v for k, v in result.items() if k not in ['text', 'panels']}
    summary['panels'] = {k: {a: b for a, b in v.items() if a != 'text'} for k, v in result.get('panels', {}).items()}
    print(json.dumps(summary, indent=2))
    print('Evidence:', evidence)


if __name__ == '__main__':
    try:
        main()
    except subprocess.CalledProcessError:
        print('1Password configuration access failed. Complete its CLI authorization prompt and retry. No browser probe was run.')
        raise SystemExit(2)

#!/usr/bin/env python3
"""Deploy the isolated probe; private configuration stays in 1Password/stdin."""
import json
import os
from pathlib import Path
import re
import secrets
import subprocess

ROOT = Path(__file__).resolve().parents[1]
TITLE = 'Daiko hosted browser'


def run(args, data=None, env=None):
    return subprocess.run(args, input=data, text=True, capture_output=True, env=env, check=True).stdout


def main():
    items = json.loads(run(['op', 'item', 'list', '--vault', 'Aomi Dev', '--format', 'json']))
    existing = next((x for x in items if x['title'] == TITLE), None)
    if existing:
        item = json.loads(run(['op', 'item', 'get', existing['id'], '--vault', 'Aomi Dev', '--format', 'json']))
    else:
        relay = json.loads(run(['op', 'item', 'get', 'Daiko fomo relay', '--vault', 'Aomi Dev', '--format', 'json']))
        account = next(f['value'] for f in relay['fields'] if f.get('label') == 'account_id')
        item = json.loads(run(['op', 'item', 'template', 'get', 'API Credential', '--format', 'json']))
        item['title'] = TITLE
        item['fields'] = [
            {'id': 'service_key', 'label': 'service_key', 'type': 'CONCEALED', 'value': secrets.token_urlsafe(32)},
            {'id': 'account_id', 'label': 'account_id', 'type': 'STRING', 'value': account},
            {'id': 'worker_url', 'label': 'worker_url', 'type': 'STRING', 'value': ''},
        ]
        item = json.loads(run(['op', 'item', 'create', '--vault', 'Aomi Dev', '--format', 'json', '-'], json.dumps(item)))
    fields = {f.get('label'): f for f in item['fields']}
    env = os.environ.copy()
    env.pop('CLOUDFLARE_API_TOKEN', None)
    env['CLOUDFLARE_ACCOUNT_ID'] = fields['account_id']['value']
    wrangler = ['node', str(ROOT / 'browser/node_modules/wrangler/bin/wrangler.js')]
    config = ['--config', str(ROOT / 'browser/wrangler.jsonc')]
    output = run(wrangler + ['deploy'] + config, env=env)
    url = re.search(r'https://daiko-browser-candidate\.[a-z0-9-]+\.workers\.dev', output)
    if not url:
        raise RuntimeError('No candidate URL reported; inspect provider deployment state')
    run(wrangler + ['secret', 'bulk'] + config, json.dumps({'SERVICE_KEY': fields['service_key']['value']}), env)
    fields['worker_url']['value'] = url[0]
    run(['op', 'item', 'edit', item['id'], '--vault', 'Aomi Dev', '--format', 'json', '-'], json.dumps(item))
    print('Candidate deployed:', url[0])
    version = re.search(r'Current Version ID:\s*(\S+)', output)
    if version:
        print('Code deployment version:', version[1])
    deployments = json.loads(run(wrangler + ['deployments', 'list', '--json'] + config, env=env))
    current = max(deployments, key=lambda entry: entry['created_on'])
    print('Effective deployment:', current['id'])
    print('Effective versions:', ', '.join(v['version_id'] for v in current['versions']))
    print('Separate service key provisioned. Existing bot/bridge and shared routes unchanged.')


if __name__ == '__main__':
    try:
        main()
    except subprocess.CalledProcessError as error:
        print('Deployment command failed:', (error.stderr or '')[-1800:])
        raise SystemExit(error.returncode)

// Run before pairing the real extension; never replace an active reader.
import {execFileSync} from 'node:child_process';
const item=JSON.parse(execFileSync('op',['item','get','Daiko fomo relay','--vault','Aomi Dev','--format','json'],{encoding:'utf8'}));
const field=label=>item.fields.find(f=>f.label===label)?.value;
const base=field('bridge_url'),headers={Authorization:`Bearer ${field('relay_key')}`};
const health=async()=>{const r=await fetch(base+'/health',{headers});if(!r.ok)throw Error('Authenticated health failed');return r.json();};
if((await fetch(base+'/health')).status!==401)throw Error('Missing authentication was accepted');
if((await health()).browser_running)throw Error('A real browser is already paired; refusing to replace it');
const ws=new WebSocket(base.replace('https:','wss:')+'/browser');
await new Promise((resolve,reject)=>{
 const timer=setTimeout(()=>reject(Error('Pairing timed out')),10000);
 ws.onopen=()=>ws.send(JSON.stringify({type:'auth',key:field('browser_key')}));
 ws.onmessage=event=>{if(JSON.parse(event.data).type==='ready'){clearTimeout(timer);resolve();}};
 ws.onerror=()=>{clearTimeout(timer);reject(Error('Websocket connection failed'));};
});
if(!(await health()).browser_running)throw Error('Pairing was not visible to HTTP reads');
await new Promise(resolve=>{ws.onclose=resolve;ws.close();});
const final=await health();
if(final.browser_running)throw Error('Closed browser was reported as connected');
const value=await(await fetch(base+'/thesis/So11111111111111111111111111111111111111112',{headers})).json();
if(value.status!=='browser_offline'||value.data!==null)throw Error('Offline browser fabricated data');
console.log(JSON.stringify({authentication:'required',pairing:'verified',disconnect:'verified',offline_read:value.status,no_thesis_data_injected:true}));

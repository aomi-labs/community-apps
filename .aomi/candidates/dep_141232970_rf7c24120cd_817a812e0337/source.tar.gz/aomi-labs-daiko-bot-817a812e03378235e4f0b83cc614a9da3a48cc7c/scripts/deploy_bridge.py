#!/usr/bin/env python3
"""Deploy only Daiko's workers.dev bridge, resolving private configuration from 1Password."""
import json
import os
import re
import secrets
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def run(args, *, data=None, env=None):
    return subprocess.run(args, input=data, text=True, capture_output=True, env=env, check=True).stdout

def main():
    item = json.loads(run(['op', 'item', 'get', 'Daiko fomo relay', '--vault', 'Aomi Dev', '--format', 'json']))
    fields = {f.get('label'): f for f in item['fields']}
    for label, value, kind in [
        ('browser_key', secrets.token_urlsafe(32), 'CONCEALED'),
        ('account_id', '210e3092c7936592ca2078b5e26f7ea2', 'STRING'),
        ('bridge_url', '', 'STRING'),
    ]:
        if label not in fields:
            field = {'id': label, 'label': label, 'type': kind, 'value': value}
            item['fields'].append(field)
            fields[label] = field
    item = json.loads(run(['op', 'item', 'edit', item['id'], '--vault', 'Aomi Dev', '--format', 'json', '-'], data=json.dumps(item)))
    fields = {f.get('label'): f for f in item['fields']}
    env = os.environ.copy()
    # The shell's generic token is invalid. Use the existing vendor-managed Wrangler OAuth session.
    env.pop('CLOUDFLARE_API_TOKEN', None)
    env['CLOUDFLARE_ACCOUNT_ID'] = fields['account_id']['value']
    wrangler = ['node', str(ROOT / 'bridge/node_modules/wrangler/bin/wrangler.js')]
    output = run(wrangler + ['deploy', '--config', str(ROOT / 'bridge/wrangler.jsonc')], env=env)
    match = re.search(r'https://daiko-fomo-bridge\.[a-z0-9-]+\.workers\.dev', output)
    if not match:
        raise RuntimeError('Worker deployed but no workers.dev URL was reported; inspect provider state')
    url = match[0]
    payload = json.dumps({'FOMO_RELAY_KEY': fields['relay_key']['value'], 'FOMO_BROWSER_KEY': fields['browser_key']['value']})
    run(wrangler + ['secret', 'bulk', '--config', str(ROOT / 'bridge/wrangler.jsonc')], data=payload, env=env)
    fields['bridge_url']['value'] = url
    run(['op', 'item', 'edit', item['id'], '--vault', 'Aomi Dev', '--format', 'json', '-'], data=json.dumps(item))
    print('Deployed:', url)
    version = re.search(r'Current Version ID:\s*(\S+)', output)
    if version:
        print('Code deployment version:', version[1])
    print('Relay and browser keys provisioned from 1Password. No shared routes or DNS changed.')

if __name__ == '__main__':
    try:
        main()
    except subprocess.CalledProcessError as error:
        # Never dump child input or credentials. Provider diagnostics contain no request bodies.
        print('Deployment command failed:', error.stderr[-2000:])
        raise SystemExit(error.returncode)

import { Aomi } from '@aomi-labs/client';
const baseUrl=process.env.AOMI_CLIENT_BASE_URL;
const applicationId=Number(process.env.AOMI_APPLICATION_ID);
if (!baseUrl || !Number.isSafeInteger(applicationId) || applicationId<=0) throw new Error('Resolve AOMI_CLIENT_BASE_URL and AOMI_APPLICATION_ID from 1Password');
const aomi=new Aomi({baseUrl});
const prompts=process.argv.slice(2);
if (!prompts.length) prompts.push('In two sentences, explain what you help a memecoin group do. Do not call tools, trade or create a wallet request.');
for(const prompt of prompts){
 const run=aomi.agent.run(prompt,{target:{mode:'direct',applicationId}});
 try{
  const result=await run;
  const replies=result.messages.filter(m=>m.sender==='agent'&&m.content?.trim());
  if(!replies.length)throw new Error('Completed chat has no assistant text');
  console.log(JSON.stringify({prompt,session_id:run.session.sessionId,reply:replies.at(-1).content},null,2));
 }finally{run.session?.close();}
}

import { GMGN_PANELS, validMint } from './contract.mjs';
import { readThesis } from '../browser-extension/reader.js';
export const PANELS = { fomo: ['overview', 'thesis', 'holders'], gmgn: ['overview', 'trades', ...Object.keys(GMGN_PANELS)] };
export function researchArgs(value) {
  if (!value || !Object.hasOwn(PANELS, value.site) || Object.keys(value).some(k => !['site','mint','panel','page','screenshot'].includes(k)) || !validMint(value.mint)) throw new Error('invalid_request');
  const panel = value.panel ?? (value.site === 'fomo' ? 'thesis' : 'overview');
  if (!PANELS[value.site].includes(panel)) throw new Error('invalid_panel');
  const page = value.page ?? 0;
  if (!Number.isInteger(page) || page < 0 || page > 2 || (value.screenshot !== undefined && typeof value.screenshot !== 'boolean')) throw new Error('invalid_request');
  return { site: value.site, mint: value.mint, panel, page, screenshot: value.screenshot === true };
}
export async function researchPage(page, args) {
  let selected = true;
  if (args.site === 'gmgn' && args.panel !== 'overview') {
    const label = args.panel === 'trades' ? 'Trades' : GMGN_PANELS[args.panel];
    const control = page.getByText(label, { exact: true }).first();
    selected = await control.count() > 0;
    if (selected) { await control.click(); await page.waitForTimeout(1500); }
  }
  if (args.site === 'fomo' && args.panel === 'holders') {
    const control = page.getByText('Holders', { exact: true }).first();
    selected = await control.count() > 0;
    if (selected) { await control.click(); await page.waitForTimeout(1000); }
  }
  const scrolls = [];
  for (let i = 0; i < args.page * 2; i++) {
    scrolls.push(await page.evaluate(() => {
      const candidates = [...document.querySelectorAll('div')].filter(e => {
        const r = e.getBoundingClientRect();
        return r.width > innerWidth * .3 && r.height > 100 && r.left < innerWidth * .65 && r.top >= 80 && e.scrollHeight > e.clientHeight + 50;
      }).sort((a,b) => b.clientWidth * b.clientHeight - a.clientWidth * a.clientHeight);
      const target = candidates[0];
      if (!target) return null;
      const before = target.scrollTop; target.scrollTop += 600;
      return { before, after: target.scrollTop };
    }));
    await page.waitForTimeout(500);
  }
  const evidence = args.site === 'fomo' ? await page.evaluate(readThesis, args.mint) : { text: (await page.locator('body').innerText()).slice(0, 16000) };
  const coverage = [args.site === 'fomo' ? 'Public thesis comments only; token/account positions and trading panels are excluded. Overview/holder requests currently include available public comments, not complete holder holdings.' : 'Logged-out token page and selected public research table. Rendered rows only; chart pixels are not numerical price-history evidence.'];
  if (!selected) coverage.push('Requested panel control was not present.');
  if (args.page && !scrolls.some(x => x && x.after > x.before)) coverage.push('No advancing research scroll container was observed; this is not an additional page.');
  let screenshot;
  if (args.screenshot) {
    if (args.site === 'fomo') {
      // Fail closed: hide the entire page, reveal only the comment-text nodes
      // already verified by the public reader. No ancestor/account area is revealed.
      const count = await page.evaluate(() => {
        let count = 0;
        for (const control of document.querySelectorAll('[aria-label="Like comment"]')) {
          if (control.closest('button')) continue;
          const content = control.parentElement?.parentElement?.children?.[1];
          if (content?.className?.includes('whitespace-pre-line')) { content.setAttribute('data-daiko-public-comment', ''); count++; }
        }
        return count;
      });
      if (count) {
        await page.evaluate(() => {
          for (const node of document.querySelectorAll('*')) node.style?.setProperty('visibility', 'hidden', 'important');
          for (const node of document.querySelectorAll('iframe')) node.style.setProperty('display', 'none', 'important');
          for (const content of document.querySelectorAll('[data-daiko-public-comment]')) for (const node of [content, ...content.querySelectorAll('*')]) node.style.setProperty('visibility', 'visible', 'important');
          const observer = new MutationObserver(records => {
            for (const record of records) for (const added of record.addedNodes) if (added.nodeType === 1 && !added.closest('[data-daiko-public-comment]')) for (const node of [added, ...added.querySelectorAll('*')]) node.style?.setProperty('visibility', 'hidden', 'important');
          });
          observer.observe(document.body, { childList: true, subtree: true });
        });
        await page.addStyleTag({ content: '*::before,*::after{visibility:hidden!important}' });
        screenshot = await page.screenshot({ type: 'png', fullPage: false });
        coverage.push('Native page screenshot reveals public comment text only; account, balances, positions and remaining page areas are masked.');
      } else coverage.push('Screenshot omitted: no verified public comment nodes available for safe masking.');
    } else {
      // Fresh logged-out context; additionally cover account/trade chrome.
      await page.evaluate(() => {
        for (const [left,top,width,height] of [['65%','0','35%','100%'],['0','0','100%','75px'],['0','calc(100% - 55px)','100%','55px']]) {
          const cover = document.createElement('div');
          Object.assign(cover.style,{position:'fixed',left,top,width,height,background:'#111',zIndex:'2147483647'});
          document.body.append(cover);
        }
      });
      screenshot = await page.screenshot({ type: 'png', fullPage: false });
      coverage.push('Logged-out native page capture; account/trading sidebar and header/footer are covered.');
    }
  }
  return { evidence, coverage, panel_found: selected, scrolls, screenshot };
}

// Operator-only setup. Session values are password inputs and never reflected
// into markup, URLs, logs, or the successful response.
export function setupPage() {
  const nonce = crypto.randomUUID();
  const html = `<!doctype html><meta charset="utf-8"><title>Daiko operator setup</title>
<h1>Fomo test-account setup</h1><p>This provisions the Cloudflare candidate only. No live-bot cutover.</p>
<form><p><label>Service key <input name="key" type="password" autocomplete="off" required></label></p>
<p><label>Fomo auth state <input name="state" type="password" autocomplete="off" required></label></p>
<button>Save Fomo session</button></form><p role="status"></p>
<script nonce="${nonce}">document.querySelector('form').addEventListener('submit',async event=>{
event.preventDefault();const form=event.target;const status=document.querySelector('[role=status]');
try{const state=JSON.parse(form.elements.state.value);const response=await fetch('/session',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+form.elements.key.value},body:JSON.stringify(state)});
const result=await response.json();status.textContent=result.status; if(response.ok)form.reset();
}catch{status.textContent='Setup failed. No session values are displayed.'}});</script>`;
  return new Response(html, { headers: {
    'Content-Type': 'text/html;charset=utf-8', 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer',
    'Content-Security-Policy': `default-src 'none'; script-src 'nonce-${nonce}'; connect-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'`
  } });
}

# Hosted-browser acceptance candidate

This is an isolated, authenticated **feasibility probe**, not the Daiko research
service. It does not change the live app, extension, or bridge. Probes default
to logged-out browsers. An operator can provision a minimal Fomo test-account
session separately and explicitly request restoration for acceptance testing.

```sh
npm ci --prefix browser
npm test --prefix browser
npm run bundle --prefix browser
python3 scripts/deploy_browser.py
python3 scripts/probe_browser.py fomo 4kjruqGHDsSqkMdFfCjV7Vb62HPFhtXyWc2t6JpQzDnz --out /tmp/daiko-browser-evidence
python3 scripts/probe_browser.py gmgn 4kjruqGHDsSqkMdFfCjV7Vb62HPFhtXyWc2t6JpQzDnz --out /tmp/daiko-browser-evidence
python3 scripts/probe_browser.py fomo 4kjruqGHDsSqkMdFfCjV7Vb62HPFhtXyWc2t6JpQzDnz --authenticated --out /tmp/daiko-browser-auth-evidence
```

Deployment uses the existing Wrangler OAuth session and a separate service key
from **Aomi Dev / Daiko hosted browser** in 1Password. Account and URL also live
there. The existing Fomo relay key is not reused. `/health` and `/probe` require
the candidate service key; the probe accepts only supported sites and exact
Solana mints. Never pass a service key in a URL or commit probe output containing
account information.

Each probe creates a new browser context, opens only its site's token
page, optionally opens Fomo's known public thesis panel, scrolls, captures a
viewport screenshot, and closes the browser. It never submits forms and blocks
non-GET/HEAD/OPTIONS network requests except four exact GMGN read-only token-info
and price POST endpoints, Fomo session refresh, Fomo feature flags, and six exact Fomo token-read proxy endpoints identified
in its frontend. The operator-approved account bootstrap is a separate exception.
These
allowances are exact origin/path matches observed during the probe. It does not allow generic
batch handlers, trading, notifications or analytics POSTs. Other legitimate
research POST endpoints need review before use.
The coordinator serializes probes and admits at most 100 attempts per UTC day.
It stores only the last public text/metadata result per site. Logged-out
screenshot bytes are returned to the authenticated operator and stored only in
the requested local output directory. Authenticated probes return the existing
public-only thesis extraction and omit screenshots/account text entirely until
a separate masking policy is verified. No R2 resources are provisioned yet.

## Operator session setup

`GET /setup` serves a no-store, same-origin setup form with masked inputs.
`POST /session` requires the separate candidate service key. It accepts a
Playwright-style state object but retains only Fomo's observed Privy auth keys
and explicitly allowed Fomo auth cookies. Other origins, Google state, wallet
connections/secrets, preferences, and IndexedDB contents are excluded. The small
auth subset lives in private Durable Object storage, with no custom encryption.
The response never returns session values. Setup is outside user requests and
is not a bot tool. Saving state does not prove the remote site will accept it.

`--authenticated` restores this subset only for Fomo, then creates and closes a
fresh browser. A successful public-thesis read refreshes the filtered state in
storage; failed reads do not overwrite the last good state. Missing imported
state reports `login_required`. No automatic interactive login is attempted.

`page_observed` means HTML rendered, **not** acceptance of all token panels.
Review the evidence before enabling a site. Challenges or browser errors fail
the hosted-access gate. If authentication is needed, implement operator-only
setup and private saved state, then prove five browser recreations, Worker
redeployment, and overnight idle before the app refactor or activation.

Owner: Cecilia / Daiko. The existing extension bridge is the rollback path;
retire it only after both sites pass hosted acceptance and live Telegram tests.

## Private acceptance runner

When the local service-key resolver is unavailable, the development-only
`acceptance-runner.mjs` can invoke the existing coordinator through Wrangler's
authenticated remote preview and external Durable Object binding:

```sh
env -u CLOUDFLARE_API_TOKEN node browser/node_modules/wrangler/bin/wrangler.js dev --remote --config browser/acceptance.wrangler.jsonc --ip 127.0.0.1 --port 18789
curl --user-agent DaikoBrowserProbe/1.0 http://127.0.0.1:18789/run
```

Run the curl command in a separate terminal. This runner must never be deployed
as a public service. Stop the preview after testing. `/run` returns only a safe
summary of up to five fresh Fomo browsers, stops on the first failed read, and
caches the verdict by explicit verification version and operator import time.
`/setup` accepts masked state and scoped cookies through same-origin POST only.
Include the authentication subdomain cookies; local storage alone is insufficient
for Fomo’s observed server-cookie mode. A
cached verdict does not prove a new deployment, login import, or overnight idle.
There is no recurring Cron. After recreation/redeployment proof, an operator
can arm one 12-hour Durable Object alarm through the private runner:

```sh
curl --user-agent DaikoBrowserProbe/1.0 --request POST http://127.0.0.1:18789/overnight
curl --user-agent DaikoBrowserProbe/1.0 http://127.0.0.1:18789/acceptance-status
```

Read status before starting any fresh probes. Another successful read or login
import invalidates the idle interval. The alarm launches one fresh browser and
stores a safe verdict; it does not keep a browser warm or initiate login.
 The operator explicitly approved Fomo’s existing-account initialization
(`POST /v2/users`). Its exact origin/path and two-address body are checked,
and it is allowed only with restored Fomo state. This is separate from the
research allowlist and never a model operation. Other account/wallet/trade
POSTs remain blocked; the research gate still requires successful fresh reads. See the recreation results and remaining
acceptance work in [the implementation record](../docs/hosted-browser.md).

import { timingSafeEqual } from 'node:crypto';

export function authorized(header, key) {
  if (!key || key.length < 32 || !header) return false;
  const actual = Buffer.from(header), expected = Buffer.from(`Bearer ${key}`);
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

// Exact 32-byte base58 mints, without accepting symbols or arbitrary URLs.
export function validMint(mint) {
  if (typeof mint !== 'string' || mint.length < 32 || mint.length > 44) return false;
  const alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
  let value = 0n;
  for (const char of mint) {
    const digit = alphabet.indexOf(char);
    if (digit < 0) return false;
    value = value * 58n + BigInt(digit);
  }
  let bytes = 0;
  for (; value; value >>= 8n) bytes++;
  return bytes + (mint.match(/^1*/)?.[0].length ?? 0) === 32;
}

export function tokenUrl(site, mint) {
  if (!validMint(mint)) throw new Error('invalid_mint');
  if (site === 'fomo') return `https://fomo.family/tokens/solana/${mint}`;
  if (site === 'gmgn') return `https://gmgn.ai/sol/token/${mint}`;
  throw new Error('invalid_site');
}

export function classify(text) {
  if (/just a moment|verify you are human|checking your browser|performing security verification/i.test(text)) return 'challenge';
  if (/application error|internal server error|this site can.t be reached|something went wrong/i.test(text)) return 'page_error';
  return 'page_observed'; // Seeing HTML is deliberately not an acceptance pass.
}

export function probeStatus(text, expected, landed) {
  const status = classify(text);
  if (status !== 'page_observed') return status;
  const source = new URL(expected), actual = new URL(landed);
  return source.origin === actual.origin && source.pathname === actual.pathname ? status : 'token_page_redirected';
}

export const GMGN_PANELS = Object.freeze({
  holders: 'Holders', top_traders: 'Top Traders', early_buyers: 'Early Buyers', dev_token: /^Dev Token(?: \d+)?$/
});

// Read-only POST endpoints observed on GMGN's logged-out token page. Exact
// origin/path matching intentionally excludes batch handlers and trade routes.
const GMGN_READ_POSTS = new Set([
  '/mrwapi/v1/multi_token_full_info', '/mrwapi/v1/multi_token_info',
  '/api/v1/major_coin_prices', '/api/v1/mutil_window_token_info'
]);
const FOMO_READ_POSTS = new Set(['/proxy/filterTokens', '/proxy/filterTokensSearch', '/proxy/tokenDetails', '/proxy/tokenWarnings', '/proxy/getBars', '/proxy/getTokenPrices']);

// Operator-approved exception for the existing restored test account. This is
// automatic site startup, never an operation exposed to the model.
export function fomoBootstrapAllowed(value, method, body) {
  const url = new URL(value);
  if (method !== 'POST' || url.origin !== 'https://prod-api.fomo.family' || url.pathname !== '/v2/users' || url.search || typeof body !== 'string' || body.length > 256) return false;
  try {
    const account = JSON.parse(body);
    return Object.keys(account).sort().join(',') === 'address,evmAddress' && validMint(account.address) && typeof account.evmAddress === 'string' && /^0x[0-9a-fA-F]{40}$/.test(account.evmAddress);
  } catch { return false; }
}

export function researchRequestAllowed(site, value, method) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(method)) return true;
  const url = new URL(value);
  if (site === 'fomo' && method === 'POST') {
    return (url.origin === 'https://privy.fomo.family' && url.pathname === '/api/v1/sessions') ||
      (url.origin === 'https://app-actions.fomo.family' && url.pathname === '/flags/') ||
      (url.origin === 'https://prod-api.fomo.family' && FOMO_READ_POSTS.has(url.pathname));
  }
  return site === 'gmgn' && method === 'POST' && url.origin === 'https://gmgn.ai' && GMGN_READ_POSTS.has(url.pathname);
}

const FOMO_AUTH_KEYS = new Set(['privy:token', 'privy:refresh_token', 'privy:caid', 'privy:cm6h485o300n3zj9yl6vpedq7:recent-login-method']);
const FOMO_AUTH_COOKIES = new Set(['privy-access-token', 'privy-token', 'privy-session', 'privy-refresh-token', 'privy-id-token', 'privy-ca-id']);
export function fomoAuthState(value) {
  if (!value || !Array.isArray(value.origins) || !Array.isArray(value.cookies)) throw new Error('invalid_state');
  const localStorage = value.origins.filter(x => x.origin === 'https://fomo.family')
    .flatMap(x => x.localStorage ?? []).filter(x => FOMO_AUTH_KEYS.has(x.name) && typeof x.value === 'string');
  if (!localStorage.some(x => x.name === 'privy:token') || !localStorage.some(x => x.name === 'privy:refresh_token')) throw new Error('missing_auth_state');
  const cookies = value.cookies.filter(x => ['fomo.family', '.fomo.family', 'privy.fomo.family', '.privy.fomo.family'].includes(x.domain) && FOMO_AUTH_COOKIES.has(x.name));
  const state = { cookies, origins: [{ origin: 'https://fomo.family', localStorage }] };
  if (JSON.stringify(state).length > 500000) throw new Error('state_too_large');
  return state;
}

// Privy's SDK stores the same credentials in local storage and first-party
// cookies. Recreate only that cookie representation, never Google/wallet state.
// Source: @privy-io/js-sdk-core 0.79.4 storeRefreshTokenForUser /
// storeCustomerAccessTokenForUser. The upstream still validates the credentials.
export function fomoBrowserState(value, now = Date.now()) {
  const state = fomoAuthState(value);
  // Preserve observed server-cookie mode. Fomo's session cookie is not the
  // generic SDK marker; adding a refresh cookie changes its authentication flow.
  if (state.cookies.some(x => x.name === 'privy-session')) return state;
  const entries = new Map(state.origins[0].localStorage.map(x => [x.name, x.value]));
  const unpack = value => { try { return JSON.parse(value); } catch { return value; } };
  const refresh = unpack(entries.get('privy:refresh_token'));
  const token = unpack(entries.get('privy:token'));
  const cookie = (name, value, expires) => ({ name, value, domain: 'fomo.family', path: '/', secure: true, httpOnly: false, sameSite: 'Strict', expires });
  const add = (name, value, expires) => {
    if (!state.cookies.some(x => x.name === name) && typeof value === 'string' && value) state.cookies.push(cookie(name, value, expires));
  };
  if (typeof refresh === 'string' && refresh) {
    const expires = Math.floor(now / 1000) + 30 * 86400;
    add('privy-session', 't', expires);
    add('privy-refresh-token', refresh, expires);
  }
  try {
    const expiry = JSON.parse(Buffer.from(token.split('.')[1], 'base64url').toString()).exp;
    if (Number.isFinite(expiry) && expiry > now / 1000) add('privy-token', token, expiry);
  } catch { /* No access cookie is synthesized for an invalid or expired JWT. */ }
  return state;
}

export function verificationSummary(result) {
  return {
    status: result.status, authenticated_research: result.authenticated_research === true,
    visible_theses: result.visible_theses ?? 0, opened_thesis: result.opened_thesis, research_dom: result.research_dom, duration_ms: result.duration_ms,
    restored_cookie_count: result.restored_cookie_count, session_refresh_succeeded: result.session_refresh_succeeded,
    phase: result.phase, reason: result.reason,
    blocked_requests: result.blocked_requests ?? [], blocked_request_shapes: result.blocked_request_shapes ?? [], failed_responses: result.failed_responses ?? []
  };
}

// One operator acceptance check after a real 12-hour idle interval. No polling,
// warm browser, credential output, login handoff, or automatic login retries.
export const OVERNIGHT_IDLE_MS = 12 * 60 * 60 * 1000;
const JOB = 'acceptance:fomo:overnight';
export class OvernightAcceptance {
  constructor(storage, probe, now = Date.now) { this.storage = storage; this.probe = probe; this.now = now; }
  async status() {
    return { ...(await this.storage.get(JOB) ?? { status: 'not_scheduled' }), alarm_at: await this.storage.getAlarm() };
  }
  async arm() {
    const proof = await this.storage.get('acceptance:fomo:recreation');
    const importedAt = await this.storage.get('state:fomo:imported_at');
    if (proof?.status !== 'passed' || proof.imported_at !== importedAt || proof.checks?.length !== 5 || !proof.checks.every(x => x.authenticated_research)) return { status: 'prerequisite_missing' };
    const revision = await this.storage.get('state:fomo:updated_at');
    const prior = await this.storage.get(JOB);
    if (prior?.status === 'pending' && prior.expected_updated_at === revision && prior.imported_at === importedAt) return this.status();
    const started = this.now();
    const job = { status: 'pending', imported_at: importedAt, expected_updated_at: revision, idle_from: started, due_at: started + OVERNIGHT_IDLE_MS };
    await this.storage.put(JOB, job);
    await this.storage.setAlarm(job.due_at);
    return this.status();
  }
  async run() {
    const job = await this.storage.get(JOB);
    if (!job || !['pending', 'running'].includes(job.status)) return;
    if (job.status === 'running') {
      await this.storage.put(JOB, { ...job, status: 'interrupted', finished_at: this.now() });
      return; // A repeated delivery must not silently repeat a browser job.
    }
    if (this.now() < job.due_at) { await this.storage.setAlarm(job.due_at); return; }
    if (await this.storage.get('state:fomo:updated_at') !== job.expected_updated_at || await this.storage.get('state:fomo:imported_at') !== job.imported_at) {
      await this.storage.put(JOB, { ...job, status: 'idle_invalidated', finished_at: this.now() });
      return;
    }
    const started = this.now();
    await this.storage.put(JOB, { ...job, status: 'running', started_at: started });
    try {
      const check = await this.probe();
      await this.storage.put(JOB, { ...job, status: check.authenticated_research ? 'passed' : 'failed', started_at: started, finished_at: this.now(), idle_ms: started - job.idle_from, check });
    } catch {
      await this.storage.put(JOB, { ...job, status: 'failed', started_at: started, finished_at: this.now(), reason: 'probe_failed' });
    }
  }
}

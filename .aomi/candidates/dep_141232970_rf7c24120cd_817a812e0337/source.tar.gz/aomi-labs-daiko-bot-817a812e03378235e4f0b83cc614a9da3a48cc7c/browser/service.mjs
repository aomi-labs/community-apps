import { researchArgs } from './pages.mjs';
const json = body => Response.json(body, { headers: { 'Cache-Control': 'no-store' } });
const TTL = 300000, RETENTION = 86400000;
export function siteId(site) { return `research:${site}:${site === 'fomo' ? 'test' : 'public'}`; }
export async function imageSignature(key, id, expiry) {
  const bytes = new TextEncoder();
  const cryptoKey = await crypto.subtle.importKey('raw', bytes.encode(key), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const signature = await crypto.subtle.sign('HMAC', cryptoKey, bytes.encode(`${id}:${expiry}`));
  return [...new Uint8Array(signature)].map(x => x.toString(16).padStart(2, '0')).join('');
}
export class JobManager {
  constructor(ctx, env) { this.ctx = ctx; this.env = env; }
  async jobRoute(path, request) {
    if (path === '/quota') {
      const admitted = await this.ctx.storage.transaction(async store => {
        const day = new Date().toISOString().slice(0, 10), prior = await store.get('shared-quota');
        const count = prior?.day === day ? prior.count : 0;
        if (count >= 100) return false;
        await store.put('shared-quota', { day, count: count + 1 }); return true;
      });
      return json({ admitted });
    }
    if (path.startsWith('/jobs/')) {
      const job = await this.ctx.storage.get(`job:${path.slice(6)}`);
      return json(job && job.created_at + RETENTION > Date.now() ? job.result ?? { status: job.status, job_id: job.id, site: job.args.site, mint: job.args.mint } : { status: 'job_not_found' });
    }
    if (path !== '/research') return;
    const args = researchArgs(await request.json()), identity = JSON.stringify(args);
    const cached = await this.ctx.storage.get(`cache:${identity}`);
    if (cached && cached.at + TTL > Date.now()) return json({ ...cached.value, cached: true });
    const active = await this.ctx.storage.get('active-job');
    if (active) {
      const prior = await this.ctx.storage.get(`job:${active}`);
      if (prior?.status === 'pending') return json(identity === JSON.stringify(prior.args) ? { status: 'pending', job_id: active, site: args.site, mint: args.mint } : { status: 'busy', retry_after_seconds: 20 });
    }
    const quota = this.env.PROBES.get(this.env.PROBES.idFromName('shared-budget'));
    if (!(await (await quota.fetch(new Request('https://internal/quota'))).json()).admitted) return json({ status: 'daily_cap', coverage: ['Shared limit: 100 fresh browser jobs per UTC day.'] });
    // Migrate only the scoped test login internally. It is never returned publicly.
    if (args.site === 'fomo' && !await this.ctx.storage.get('state:fomo')) {
      const old = this.env.PROBES.get(this.env.PROBES.idFromName('acceptance'));
      const saved = await (await old.fetch(new Request('https://internal/export-state'))).json();
      if (!saved.state) return json({ status: 'login_required', coverage: ['Fomo maintenance login required; public APIs/GMGN remain available.'] });
      await this.ctx.storage.put('state:fomo', saved.state);
    }
    const id = crypto.randomUUID(), job = { id, args, created_at: Date.now(), status: 'pending' };
    await this.ctx.storage.put({ [`job:${id}`]: job, 'active-job': id });
    await this.ctx.storage.setAlarm(Date.now() + 120000);
    this.ctx.waitUntil(this.executeJob(job, identity));
    return json({ status: 'pending', job_id: id, site: args.site, mint: args.mint });
  }
  async executeJob(job, identity) {
    let result;
    try {
      const response = await this.fetch(new Request('https://internal/run', { method: 'POST', body: JSON.stringify({ ...job.args, restore_state: job.args.site === 'fomo', research: true }) }));
      const raw = await response.json();
      const ok = raw.status === 'authenticated_research_observed' || (job.args.site === 'gmgn' && raw.status === 'page_observed');
      result = { status: ok ? 'ok' : raw.failed_responses?.some(x => x.startsWith('401 ')) || raw.status === 'token_page_redirected' ? 'login_required' : raw.status, site: job.args.site, mint: job.args.mint, job_id: job.id, source_url: raw.source_url, fetched_at: raw.fetched_at, cached: false, panel: job.args.panel, page: job.args.page, evidence: raw.page_evidence?.evidence ?? null, coverage: raw.page_evidence?.coverage ?? [raw.coverage ?? 'Hosted browser read did not complete.'], panel_found: raw.page_evidence?.panel_found, scrolls: raw.page_evidence?.scrolls, duration_ms: raw.duration_ms };
      if (raw.screenshot_base64 && ok && !this.env.EVIDENCE) result.coverage.push('Screenshot delivery unavailable: Cloudflare R2 is not enabled.');
      if (raw.screenshot_base64 && ok && this.env.EVIDENCE) {
        const bytes = Uint8Array.from(atob(raw.screenshot_base64), c => c.charCodeAt(0));
        if (bytes.length <= 5000000) {
          try {
          const expiry = Date.now() + RETENTION;
          await this.env.EVIDENCE.put(job.id, bytes, { httpMetadata: { contentType: 'image/png' }, customMetadata: { expires: String(expiry) } });
          const signature = await imageSignature(this.env.SERVICE_KEY, job.id, expiry);
          result.screenshot_url = `${this.env.PUBLIC_URL}/image/${job.id}?expires=${expiry}&signature=${signature}`;
          result.screenshot_expires_at = new Date(expiry).toISOString();
          } catch { result.coverage.push('Screenshot storage/delivery unavailable; research evidence is still valid.'); }
        } else result.coverage.push('Screenshot omitted: image exceeds delivery size limit.');
      }
      if (ok) await this.ctx.storage.put(`cache:${identity}`, { at: Date.now(), value: result });
    } catch { result = { status: 'unavailable', site: job.args.site, mint: job.args.mint, coverage: ['Hosted job failed; no login handoff was initiated.'] }; }
    await this.ctx.storage.put(`job:${job.id}`, { ...job, status: 'complete', result });
    await this.ctx.storage.delete('active-job');
    await this.ctx.storage.setAlarm(Date.now() + RETENTION);
  }
  async jobsAlarm() {
    const active = await this.ctx.storage.get('active-job');
    if (active) {
      const job = await this.ctx.storage.get(`job:${active}`);
      if (job?.status === 'pending') await this.ctx.storage.put(`job:${active}`, { ...job, status: 'complete', result: { status: 'interrupted', job_id: active, coverage: ['Browser worker restarted or exceeded its deadline. Submit a new read if still needed.'] } });
      await this.ctx.storage.delete('active-job');
    }
    for (const prefix of ['job:', 'cache:']) {
      const rows = await this.ctx.storage.list({ prefix });
      for (const [key, row] of rows) if ((row.created_at ?? row.at) + (prefix === 'cache:' ? TTL : RETENTION) <= Date.now()) await this.ctx.storage.delete(key);
    }
  }
}

import { researchArgs } from './pages.mjs';
import { siteId } from './service.mjs';
import { fomoAuthState } from './contract.mjs';

// Development-only runner. Wrangler's authenticated remote preview supplies
// access to the existing candidate namespace; never deploy as a public service.
export default {
  async fetch(request, env) {
    const path = new URL(request.url).pathname;
    if (path === '/research' && request.method === 'POST') {
      const args = researchArgs(await request.json());
      return env.PROBES.get(env.PROBES.idFromName(siteId(args.site))).fetch(new Request('https://internal/research', {method:'POST',body:JSON.stringify(args)}));
    }
    const job = path.match(/^\/jobs\/(fomo|gmgn)\/([0-9a-f-]{36})$/);
    if (job) return env.PROBES.get(env.PROBES.idFromName(siteId(job[1]))).fetch(new Request('https://internal/jobs/' + job[2]));
    const coordinator = env.PROBES.get(env.PROBES.idFromName('acceptance'));
    if ((request.method === 'POST' && ['/overnight', '/cancel-overnight'].includes(path)) || (request.method === 'GET' && path === '/acceptance-status')) {
      return coordinator.fetch(new Request('https://probe' + path, { method: request.method }));
    }
    if (request.method === 'GET' && path === '/run') {
      return coordinator.fetch(new Request('https://probe/verify', { method: 'POST' }));
    }
    if (request.method === 'GET' && path === '/setup') {
      const nonce = crypto.randomUUID();
      return new Response(`<!doctype html><title>Daiko private preview setup</title>
<h1>Fomo candidate session setup</h1><p>Private operator preview. No bot cutover.</p>
<form><label>Fomo auth state <input name="state" type="password" autocomplete="off" required></label><label>Fomo cookies <input name="cookies" type="password" autocomplete="off"></label><button>Save session</button></form><p role="status"></p>
<script nonce="${nonce}">document.querySelector('form').onsubmit=async e=>{e.preventDefault();const f=e.target;try{const r=await fetch('/session',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...JSON.parse(f.elements.state.value),cookies:JSON.parse(f.elements.cookies.value||'[]')})});document.querySelector('[role=status]').textContent=(await r.json()).status;if(r.ok)f.reset()}catch{document.querySelector('[role=status]').textContent='setup_failed'}};</script>`, { headers: {
        'Content-Type': 'text/html;charset=utf-8', 'Cache-Control': 'no-store',
        'Content-Security-Policy': `default-src 'none'; script-src 'nonce-${nonce}'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'`,
        'Referrer-Policy': 'no-referrer'
      } });
    }
    // Same-origin browser submission only; reject cross-origin/local-site CSRF.
    if (request.method === 'POST' && path === '/session' && request.headers.get('Sec-Fetch-Site') === 'same-origin' && request.headers.get('Content-Type') === 'application/json') {
      if (Number(request.headers.get('Content-Length')) > 500000) return Response.json({ status: 'state_too_large' }, { status: 413 });
      try {
        const body = await request.text();
        if (body.length > 500000) return Response.json({ status: 'state_too_large' }, { status: 413 });
        const state = fomoAuthState(JSON.parse(body));
        return coordinator.fetch(new Request('https://probe/session', { method: 'POST', body: JSON.stringify(state) }));
      } catch { return Response.json({ status: 'invalid_session_state' }, { status: 400 }); }
    }
    return new Response('Not found', { status: 404 });
  }
};

# Daiko Helper

An Aomi research app for fast Solana memecoin groups. A member posts a CA, checks its identity and market context, asks what the meme is and who's discussing or trading it, then returns to Daiko's trading UI. Daiko Helper supplies the evidence and concise English/Japanese answers.

`apps/daiko` is a Rust SDK 7 plugin. Its wallet policy matches Sol Dottie: `agent = true`, `families = ["svm"]`, `suggest = "instant"`. Research needs no deposit. The host owns wallet creation and authorized signing. App tools never sign or broadcast.

## Tools and sources

- `daiko_token`: exact-mint DEX Screener, Jupiter Tokens and RugCheck reads.
- `daiko_x_pulse`: one twitterapi.io CA-search page; recent posts and attributed links, not a census or original-author guarantee.
- `daiko_tiktok`: ScrapeCreators meme keyword search; matching a meme does not verify token affiliation.
- `daiko_thesis`: fomo comments via the authenticated browser bridge; existing-profile Chrome reader or optional Playwright service.
- `daiko_wallets`: token-specific Solana Tracker KOL trades; labels and historical trades are not proof of identity/current positions.
- `daiko_trending`: Solana Tracker candidates; its fallback is explicitly labelled DEX Screener paid boosts.
- `daiko_about`: build and configuration diagnostics, not proof that a feed works.

Every source returns its own status, fetch time and cache marker. An absent credential or failed service is unavailable, never an empty successful result. Paid APIs run on demand, read only one page, and reuse cached results across sessions with the same service credential. The runtime has bounded cache/request guards per process. These guards are **not a fleetwide monthly spend guarantee**: use vendor prepaid balances and quotas as the account-level bound. No automatic top-ups.

## Configuration

Optional app secret slots: `TWITTERAPI_IO_KEY`, `SCRAPECREATORS_KEY`, `SOLANA_TRACKER_KEY`, `JUPITER_API_KEY`, `FOMO_RELAY_URL`, `FOMO_RELAY_KEY`. Store values in 1Password and provision the app vault; never commit `.env` files. Public-source reads work without these slots. Missing services are reported explicitly.

## Build and verify

```
cargo fmt --check
cargo clippy --workspace --all-targets --locked -- -D warnings
cargo test --workspace --locked
npm ci --prefix relay
npm test --prefix relay
cargo run -p daiko --example read -- manifest
cargo run -p daiko --example read -- daiko_token '{"mint":"So11111111111111111111111111111111111111112"}'
```

## Persistent browser

The primary reader uses Cecilia's existing signed-in Chrome profile. `browser-extension/` requests access only to `https://fomo.family/*`, plus scripting, extension-local storage and reconnect alarms. It opens one background token tab and sends only public author/comment/like/link fields. It has no cookie, all-sites, debugger or trading permissions. Google/fomo session credentials remain in Chrome.

`bridge/` is a separate authenticated workers.dev Worker and Durable Object. App reads and browser pairing use different 1Password keys. It caches successful reads for five minutes, bounds queued work, and admits at most 100 fresh browser reads per UTC day across the entire bridge. The browser connection hibernates when idle. A cold page can return `refresh_pending`; a subsequent request can use the completed cached result. Offline Chrome, a missing login or changed page layout returns unavailable. Keep this Chrome profile running for fresh reads; cached data is not a browser uptime guarantee.

See [browser setup and acceptance](docs/browser.md). Deploy with `npm ci --prefix bridge` and `python3 scripts/deploy_bridge.py` using the existing Wrangler OAuth account. Keys and environment-specific configuration resolve from 1Password. This isolated deployment changes no shared Aomi routes or DNS.

A separate Cloudflare Browser Run replacement is being validated before cutover.
See the [migration plan and hosted acceptance evidence](docs/hosted-browser.md).
The candidate probe does not replace the installed reader or change the live bot.

`relay/` retains the original Playwright option for an independently signed-in private profile on a persistent host. It is maintained as an alternative deployment mode, not used to copy the personal Chrome session. Resolve `FOMO_PROFILE_DIR` and `FOMO_RELAY_KEY` from 1Password and run `npm start --prefix relay` after that profile has a valid login. Its fixed read-only destination, bounded queue and five-minute cache remain available. Do not expose a Playwright debugging port or profile volume. The existing-profile reader is the selected pilot path.

## Deployment

`.aomi/config.json` binds this repository to the community platform. The GitHub workflow checks the app and relay, then mints a fresh staging deployment token using the protected staging admin credential, preflights and builds the immutable push SHA, then activates only after every release is ready. Token revocation runs in `finally`. The deployment script is deliberately restricted to the staging backend; production promotion is a separate operation.

Deployment needs `AOMI_DEPLOY_BACKEND_URL` and `AOMI_PROJECT_ID` repository variables and the `AOMI_ADMIN_SERVICE_PRIVATE_KEY_STAGING` environment secret, mirrored from 1Password. The deployment record, candidate CI, activation, runtime loading and completed chat must all be verified. A pushed plugin is not a live bot.

Telegram uses the existing Aomi bot host, as Hoodit and Dottie do. Register a dedicated bot token with that host and select this application's id; do not start a second Telegram polling service. The app prompt answers mentions/replies but does not manufacture automatic CA monitoring or inline buttons. Those are host capabilities and need separate acceptance in a real group.

import { readThesis, openThesisPanel } from './reader.js';
let socket, sequence=Promise.resolve();
const mintPattern=/^[1-9A-HJ-NP-Za-km-z]{32,44}$/;
async function connect(){
  if(socket && socket.readyState<2)return;
  const {bridgeUrl,browserKey}=await chrome.storage.local.get(['bridgeUrl','browserKey']);
  if(!bridgeUrl || !browserKey)return;
  let url;try{url=new URL(bridgeUrl);}catch{return;}
  if(url.protocol!=='https:' || !/^daiko-fomo-bridge\.[a-z0-9-]+\.workers\.dev$/.test(url.hostname))return;
  url.protocol='wss:';url.pathname='/browser';url.search='';url.hash='';
  const connection=new WebSocket(url.href);socket=connection;let heartbeat;
  connection.onopen=()=>{connection.send(JSON.stringify({type:'auth',key:browserKey}));heartbeat=setInterval(()=>{if(connection.readyState===1)connection.send('{"type":"ping"}');},25000);};
  connection.onmessage=event=>{
    let message;try{message=JSON.parse(event.data);}catch{return;}
    if(message.type==='ready'){chrome.storage.local.set({readerStatus:'Connected to Daiko'});return;}
    if(message.type!=='read' || !mintPattern.test(message.mint) || typeof message.id!=='string')return;
    sequence=sequence.then(async()=>{
      let value;try{value=await read(message.mint);}catch{value={status:'browser_unavailable'};}
      await chrome.storage.local.set({lastReadStatus:value.status,lastReadMint:message.mint,lastReadCount:value.comments?.length??0,lastReadDetail:value.detail??''});
      if(connection.readyState===1)connection.send(JSON.stringify({type:'result',id:message.id,mint:message.mint,value}));
    }).catch(()=>{});
  };
  connection.onclose=()=>{clearInterval(heartbeat);if(socket===connection){socket=undefined;chrome.storage.local.set({readerStatus:'Disconnected; reconnecting automatically'});}};
  connection.onerror=()=>connection.close();
}
async function read(mint){
  // Reuse only the tab created by this extension; never navigate a user's existing tab.
  let {readerTabId}=await chrome.storage.session.get('readerTabId');
  let tab;try{tab=await chrome.tabs.get(readerTabId);}catch{}
  const url=`https://fomo.family/tokens/solana/${mint}`;
  if(!tab || !tab.url?.startsWith('https://fomo.family/')){
    tab=await chrome.tabs.create({url,active:false});readerTabId=tab.id;
    await chrome.storage.session.set({readerTabId});
  }else if(new URL(tab.url).pathname!==`/tokens/solana/${mint}`){await chrome.tabs.update(tab.id,{url});}
  const deadline=Date.now()+22000;let panelOpened=false,lastDetail='Waiting for the public panel';
  while(Date.now()<deadline){
    try{
      if(!panelOpened){const [prepared]=await chrome.scripting.executeScript({target:{tabId:readerTabId},func:openThesisPanel,args:[mint]});panelOpened=prepared?.result===true;}
      const [result]=await chrome.scripting.executeScript({target:{tabId:readerTabId},func:readThesis,args:[mint]});
      if(result?.result?.status==='ok')return result.result;
      lastDetail=`Panel opened: ${panelOpened}; page result: ${result?.result?.status??'no result'}`;
    }catch(error){lastDetail=String(error?.message??'Page injection failed').slice(0,200);}
    await new Promise(resolve=>setTimeout(resolve,700));
  }
  return {status:'no_visible_theses',detail:lastDetail,coverage:'No thesis rows could be read. The browser may require login, the token may have no visible comments, or the page layout may have changed.'};
}
chrome.runtime.onInstalled.addListener(()=>{chrome.alarms.create('reconnect',{periodInMinutes:1});connect();});
chrome.runtime.onStartup.addListener(()=>{chrome.alarms.create('reconnect',{periodInMinutes:1});connect();});
chrome.alarms.onAlarm.addListener(()=>connect());
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&(changes.bridgeUrl||changes.browserKey)){socket?.close();connect();}});
chrome.action.onClicked.addListener(()=>chrome.runtime.openOptionsPage());
connect();

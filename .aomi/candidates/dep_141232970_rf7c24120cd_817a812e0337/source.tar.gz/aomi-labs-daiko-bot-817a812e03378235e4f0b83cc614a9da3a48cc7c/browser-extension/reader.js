// This function runs in the isolated content-script world. Only rendered thesis rows leave the page.
export function readThesis(mint) {
  if (location.origin !== 'https://fomo.family' || location.pathname !== `/tokens/solana/${mint}`) return {status:'page_mismatch'};
  const comments=[];
  const controls=Array.from(document.querySelectorAll('[aria-label="Like comment"]'));
  // fomo uses an HTML button for holder rows and a role=button div for floating-feed cards.
  const feedControls=controls.filter(control=>!control.closest('button'));
  const selected=feedControls.length?feedControls:controls;
  for (const control of selected) {
    const row=control.closest('button');
    const stack=control.parentElement?.parentElement;
    const feedContent=stack?.children?.[1];
    const content=row
      ?Array.from(control.parentElement?.children ?? []).find(x=>x!==control)
      :feedContent?.className?.includes('whitespace-pre-line')?feedContent:null;
    const header=row?.firstElementChild ?? stack?.firstElementChild;
    const text=content?.innerText?.trim();
    const author=header?.innerText?.trim().split('\n')[0]?.trim();
    if(!text || !author || comments.some(x=>x.author===author && x.text===text.slice(0,1600)))continue;
    const links=Array.from(content.querySelectorAll('a[href]')).map(a=>a.href).filter(h=>/^https:\/\//.test(h)).slice(0,3).map(h=>h.slice(0,300));
    comments.push({author:author.slice(0,80),text:text.slice(0,1600),likes:control.innerText?.trim().slice(0,20) ?? null,links});
    if(comments.length===20)break;
  }
  if(!comments.length) return {status:'no_visible_theses'};
  return {status:'ok',mint,layout:feedControls.length?'thesis_feed':'holder_table',source_url:`https://fomo.family/tokens/solana/${mint}`,comments,
    coverage:'Up to 20 rendered public comments in the page\'s current order. Not all comments, not a vote ranking. Comments may be truncated by the site; community opinions are unverified.'};
}

// Open only the public read panel on the extension-owned token tab. Never click trading controls.
export function openThesisPanel(mint) {
  if(location.origin!=='https://fomo.family'||location.pathname!==`/tokens/solana/${mint}`)return false;
  if(document.querySelector('[aria-label="Like comment"]'))return true;
  const opener=document.getElementById(`thesis-trigger-token-page-thesis-${mint}:1399811149`);
  if(!opener)return false;
  opener.click();return true;
}

const url=document.querySelector('#url'),key=document.querySelector('#key'),status=document.querySelector('#status');
chrome.storage.local.get(['bridgeUrl','browserKey']).then(x=>{url.value=x.bridgeUrl??'';key.value=x.browserKey??'';});
document.querySelector('form').addEventListener('submit',async event=>{event.preventDefault();
  try{const u=new URL(url.value);if(u.protocol!=='https:' || !/^daiko-fomo-bridge\.[a-z0-9-]+\.workers\.dev$/.test(u.hostname))throw Error();
    await chrome.storage.local.set({bridgeUrl:u.origin,browserKey:key.value});status.textContent='Saved. Connection will resume while Chrome is running.';
  }catch{status.textContent='Enter the deployed Daiko HTTPS workers.dev URL.';}
});

async function showConnection(){const x=await chrome.storage.local.get(['readerStatus','lastReadStatus','lastReadMint','lastReadCount','lastReadDetail']);document.querySelector('#connection').textContent=[x.readerStatus??'Waiting for pairing',x.lastReadStatus?`Last read: ${x.lastReadStatus}, ${x.lastReadCount??0} comments for ${x.lastReadMint}`:''].filter(Boolean).join('. ')+(x.lastReadDetail?' — '+x.lastReadDetail:'');}
chrome.storage.onChanged.addListener(showConnection);showConnection();
document.querySelector('#restart').addEventListener('click',()=>chrome.runtime.reload());

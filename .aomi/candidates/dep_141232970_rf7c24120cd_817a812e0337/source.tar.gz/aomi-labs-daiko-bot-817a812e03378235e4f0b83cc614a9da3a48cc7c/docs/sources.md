# Source contracts checked 2026-11-06

- https://docs.dexscreener.com/api/reference — `GET /token-pairs/v1/solana/{mint}`, `GET /token-boosts/top/v1`.
- https://developers.jup.ag/docs/tokens/token-information — `GET /tokens/v2/search?query={mint}`; filter exact `id`.
- https://api.rugcheck.xyz/swagger/doc.json — `GET /v1/tokens/{mint}/report/summary`.
- https://docs.twitterapi.io/api-reference/endpoint/tweet_advanced_search — `/twitter/tweet/advanced_search`, one Latest page. $0.15 per 1k returned posts: https://twitterapi.io/pricing.
- https://docs.scrapecreators.com/v1/tiktok/search/keyword/ — keyword search. Prepaid $47/25k credits; endpoint-specific costs apply: https://scrapecreators.com/.
- https://docs.solanatracker.io/guides/whale-kol.md — `/trades/kols/{mint}` with `hideArb=true`, `limit=20`; https://www.solanatracker.io/data-api — Advanced €50/mo, 200k requests.
- https://fomo.family/ — public token-page thesis panels, read through the installed fomo-only Chrome extension and the existing signed-in profile. A real 20-comment read and a hosted Telegram summary passed. There is no claim of an official public fomo API. The optional Playwright adapter is based on community evidence for a private route, not an official API contract: https://github.com/ColinEdw/fomo-mcp/blob/main/src/client.ts.

Price and API documentation checks do not prove credential-backed production connectivity. Do not present unavailable integrations as live.

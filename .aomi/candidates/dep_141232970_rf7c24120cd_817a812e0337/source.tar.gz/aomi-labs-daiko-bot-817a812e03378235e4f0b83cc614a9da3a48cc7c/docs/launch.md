# Daiko bot pilot

Open [@daiko_aomi_bot](https://t.me/daiko_aomi_bot). In a direct message, `/start` provisions the same managed Solana wallet configuration as Dottie: agent wallet enabled, SVM only, Instant suggested. Research needs no deposit.

The intended group entry is `/ask@daiko_aomi_bot <exact Solana contract address, venue link or question>`, or a reply to a Daiko answer. The backend group update must pass acceptance before this is advertised as available. Daiko resolves that address, returns a short identity/market/risk card, and offers focused follow-ups: X discussion, fomo theses, TikTok meme context or labelled wallet activity. English and Japanese replies were verified. A meme match never establishes token affiliation; a provider risk/verification label is never a guarantee.

Seven selected sources: DEX Screener, Jupiter, RugCheck, TwitterAPI.io, ScrapeCreators TikTok, fomo and Solana Tracker. Every source has completed a credential-backed or public hosted read. This is point-in-time acceptance, not a guarantee that vendors or browser sessions stay available forever.

## Cost behavior

A bare CA uses the three token identity/market/risk reads. Paid social and wallet sources are requested on demand, one page per call, with credential-scoped caching. TikTok results are compacted to ten video links. Vendor prepaid balances/quotas remain their account-level bound. The fomo bridge has a global cap of 100 fresh attempts per UTC day and a five-minute success cache. Cold pages may briefly report refreshing. The browser reader uses the existing Chrome session and must have Chrome running for fresh reads.

## Deployed pilot

- App 2937821, community Project 1675, on staging.
- Active runtime release: `apps-141232970-rf7c24120cd-daiko-e31873b51005`.
- [Application checks and activation](https://github.com/aomi-labs/daiko-bot/actions/runs/42153005264).
- [Build project](https://build-staging.aomi.dev/projects/1675?platform=community).
- [Browser chat](https://chat-staging.aomi.dev/?app=daiko&application_id=2937821&lock_app=1).
- A separate workers.dev bridge serves only Daiko. Its deployment settings and keys live in the Aomi Dev 1Password item **Daiko fomo relay**. App reads and browser pairing use distinct keys.
- The private acceptance group contains only Cecilia and the bot. Its group reply path returned a five-line exact-mint response and attributed real fomo opinions with the original cached fetch time.

The app is an operational staging pilot. Production backend promotion and posting into the partner's real group have not been performed. No funding, trade, signature or broadcast was used during acceptance.

## Group rollout contract

Keep Telegram privacy on and install Daiko as an ordinary member. Plain @mentions are not a supported trigger in this mode; commands and replies are. A group `/help@daiko_aomi_bot` explains the entry points. Answers are visible to the group, with separate model history and billing per member within each topic. Replying to Daiko carries a bounded quote into the requester's own research thread. No personal DM history is copied into the group.

Group conversations have a durable read-only signing credential, no personal wallet state and no approval-card sink. Trading continues in the requester's own DM. The backend must preserve these restrictions after recovery and when a group tool-result button is tapped. No new tables or hosted schema changes are needed.

Before launching: verify two members keep separate owners and admission accounts; verify commands/replies in a real supergroup and forum topic; verify ordinary chatter causes no typing/model turn; verify a group buy request leads to DM with no transaction staged or committed. Admin/privacy-off mention support is optional and is not enabled for the pilot.

# Daiko pilot acceptance

## Verified 2026-11-06

- Community Project 1675 belongs to aomi-labs/daiko-bot under Cecilia's builder account.
- App 2937821 activated, artifact-ready and runtime-loaded on staging. Source checks and automatic activation passed through commit e31873b; release apps-141232970-rf7c24120cd-daiko-e31873b51005 is active.
- SDK 7.0.0 and Dottie's exact managed Solana wallet manifest accepted by manager preflight.
- Hosted no-tool and exact-mint token checks completed; DEX Screener, Jupiter and RugCheck results included source timestamps.
- TwitterAPI.io, ScrapeCreators and Solana Tracker credentials are in 1Password and the app vault. Hosted X, compact TikTok, token-specific KOL and source-labelled trending reads succeeded. The KOL/trending response was also verified in Japanese over Telegram.
- TikTok output is capped at 10 unique video links and about 7 KB in the real sample, rather than the multi-megabyte raw response. Meme matches do not establish token affiliation.
- Telegram @daiko_aomi_bot is registered with the shared Aomi host, active, mapped only to Daiko app 2937821, with group privacy enabled. Its webhook is configured on api-staging.aomi.dev with no pending updates or errors.
- A real /start provisioned Daiko's managed Solana wallet using the same Instant suggestion as Dottie. A subsequent Telegram exact-mint query returned a concise wSOL identity, pool-specific market evidence and risk limitations. No funds or trades were used.
- Existing Chrome profile is signed into fomo. The approved fomo-only extension is installed and paired. After a reader restart and a cold token-page load it returned 20 real thesis-feed comments through the hosted bridge, without position/PnL fields. A later read reused the original 03:13:59 UTC timestamp and cache.
- A real private group containing only Cecilia and Daiko returned a five-line exact-mint card and a fomo summary attributing Mastush and 6rabbuh, linking the source and stating the fetch time and sample limitations. The bot is an ordinary member, not an administrator.
- Seven Rust tests, three Playwright relay tests and ten bridge/reader tests cover schemas, identity, cost/cache guards, TikTok bounds, authenticated pairing, offline semantics and rejection of unsolicited browser results.

## Still required before group launch

- Ordinary @mention delivery remains failing: both a pasted mention and the native Telegram member-picker mention produced no answer, while /help@daiko_aomi_bot and replies to the bot succeeded. Diagnose and fix this rather than claiming full group readiness. The active host on staging backend-2 is revision 212d3cefc718bd65c2abe91caf1d525f5baed825; its logs show successful group reply turns and no admitted turn for the mention tests.
- Cold-page/floating-feed reader fixes and the launch handoff passed CI at 9145137.
- Group backend update: `/ask`, per-member conversation ownership, durable read-only signing restrictions, quiet ignored messages, and UTF-16 mention handling. Local and hosted group acceptance must finish before launch.

The extension's own restart/reconnect was tested without another fomo login. The entire personal Chrome browser was not closed/reopened during acceptance. Chrome must remain running for new reads. Production backend promotion and posting in the partner's real trading group have not been performed.

No trade, signature, broadcast or funding was performed during research acceptance. Optional credentials never justify fabricated evidence. Vendor quotas/prepaid balances and the bridge-wide browser cap bound their respective sources; app per-process guards are not a fleetwide dollar cap.

# Existing-profile fomo reader

The selected pilot browser is the already signed-in Chrome account zhangyixin319@gmail.com. There is no separate Google login step.

## Review and install

The complete extension is in [`browser-extension/`](../browser-extension/manifest.json). It reads only public thesis rows on fomo.family, up to 20 per request, in the site's current order. This is not all discussion or a vote ranking. It never clicks trading forms, likes or comment submission. It does not send position/PnL fields or authentication credentials.

Loading this local extension grants persistent access to fomo.family, so installation needs an action-time approval under the browser tool's confirmation policy. This is a new extension permission, not another login permission.

After approval: open `chrome://extensions` in the selected profile, enable Developer mode if necessary, choose **Load unpacked**, and select the repository's `browser-extension` directory. Open its Options page. Resolve `bridge_url` and `browser_key` from the **Daiko fomo relay** item in **Aomi Dev** 1Password. Save and connect. The extension creates its own background token tab and never navigates existing user tabs. Chrome must remain running for new reads.

## Service contract

- `GET /health` and `GET /thesis/:mint`: app bearer `relay_key` from 1Password.
- `WSS /browser`: a first-frame pairing message with the distinct `browser_key`; unauthenticated sockets close after five seconds.
- Only exact 32-byte base58 mint addresses are accepted. Browser results must match the request id and mint.
- Successful comments retain their original fetch time and expire after five minutes. One browser read is admitted at a time; late reads can fill the cache. A bridge-wide UTC-day cap allows 100 fresh attempts. There are no polling vendor API charges, retries or automatic top-ups.
- No live browser, no rendered comments, mismatched pages, request timeout or rejected pairing yields unavailable, never fabricated comments or freshness.
- The original optional `relay/` Playwright service is still supported for a separately authenticated persistent host. The Chrome extension is the selected existing-profile pilot deployment.

## Acceptance evidence

2026-11-06: the extraction algorithm read 20 public thesis rows from the actual signed-in fomo page for mint `4kjruqGHDsSqkMdFfCjV7Vb62HPFhtXyWc2t6JpQzDnz`. Author `pointfarmcap` and its public X citation were present. No position/PnL fields were extracted.

Ten bridge/reader tests cover app authentication, browser pairing, offline and quota semantics, bounded results, cache timestamps, wrong-request rejection and unauthenticated disconnect isolation. The Worker bundles successfully with pinned Wrangler 4.158.0. The installed reader was restarted with pairing preserved. A cold token page opened its public thesis panel automatically and returned 20 actual comments through the live bridge at 03:13:59 UTC. A subsequent Telegram group reply attributed Mastush and 6rabbuh, linked the source, preserved that cached fetch time and stated the sample limitation. Closing and reopening the entire personal Chrome browser was not exercised; it must remain running for live reads.

use aomi_sdk::{DynToolCallCtx, resolve_secret_value};
use reqwest::blocking::Client;
use serde_json::{Value, json};
use std::{
    collections::HashMap,
    io::Read,
    sync::{Mutex, OnceLock},
    time::{Duration, Instant, SystemTime, UNIX_EPOCH},
};
#[derive(Clone, Default)]
pub struct DaikoApp;
pub fn now() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}
pub fn mint(value: &str) -> Result<&str, String> {
    if value.trim() != value || !matches!(bs58::decode(value).into_vec(), Ok(v) if v.len() == 32) {
        return Err("Provide an exact base58 Solana mint (32 bytes); symbols are ambiguous".into());
    }
    Ok(value)
}
pub fn key(ctx: &DynToolCallCtx, name: &str) -> Option<String> {
    resolve_secret_value(ctx, None, name, "not configured")
        .ok()
        .filter(|v| !v.trim().is_empty())
}
pub fn unavailable(source: &str, status: &str) -> Value {
    json!({"source":source,"status":status,"fetched_at":null,"data":null})
}
struct Entry {
    at: Instant,
    value: Value,
}
#[derive(Default)]
struct State {
    cache: HashMap<String, Entry>,
    calls: HashMap<String, (u64, u32)>,
}
static STATE: OnceLock<Mutex<State>> = OnceLock::new();
/// Cache identities include a one-way key fingerprint so different credential scopes never share reads.
fn fingerprint(value: Option<&str>) -> u64 {
    use std::hash::{Hash, Hasher};
    let mut h = std::collections::hash_map::DefaultHasher::new();
    value.hash(&mut h);
    h.finish()
}
pub fn get(
    source: &str,
    url: &str,
    query: &[(&str, &str)],
    auth: Option<(&str, &str)>,
    ttl: u64,
    cap: u32,
) -> Value {
    let cache_key = format!(
        "{source}:{url}:{query:?}:{}",
        fingerprint(auth.map(|(_, v)| v))
    );
    let Ok(mut state) = STATE.get_or_init(Default::default).lock() else {
        return unavailable(source, "busy");
    };
    if let Some(e) = state.cache.get(&cache_key)
        && e.at.elapsed().as_secs() < ttl
    {
        let mut v = e.value.clone();
        v["cached"] = json!(true);
        return v;
    }
    let budget_key = format!("{source}:{}", fingerprint(auth.map(|(_, v)| v)));
    let b = state.calls.entry(budget_key).or_insert((now() / 86400, 0));
    if b.0 != now() / 86400 {
        *b = (now() / 86400, 0);
    }
    if b.1 >= cap {
        return unavailable(source, "local_daily_limit");
    }
    b.1 += 1;
    // One shared gate bounds concurrent requests and coalesces repeated research.
    let result = (|| -> Result<Value, &'static str> {
        let client = Client::builder()
            .timeout(Duration::from_secs(12))
            .connect_timeout(Duration::from_secs(4))
            .redirect(reqwest::redirect::Policy::none())
            .user_agent("daiko-helper/0.1")
            .build()
            .map_err(|_| "unavailable")?;
        let mut req = client.get(url).query(query);
        if let Some((h, v)) = auth {
            req = req.header(h, v);
        }
        let response = req.send().map_err(|_| "unavailable")?;
        match response.status().as_u16() {
            200..=299 => (),
            401 | 403 => return Err("access_unavailable"),
            404 => return Err("not_found"),
            429 => return Err("rate_limited"),
            _ => return Err("upstream_error"),
        }
        let max_bytes = if source == "scrapecreators" {
            8_000_000
        } else {
            2_000_000
        };
        let mut bytes = Vec::new();
        response
            .take(max_bytes + 1)
            .read_to_end(&mut bytes)
            .map_err(|_| "unavailable")?;
        if bytes.len() as u64 > max_bytes {
            return Err("invalid_response");
        }
        let mut data: Value = serde_json::from_slice(&bytes).map_err(|_| "invalid_response")?;
        if source == "scrapecreators" {
            data = compact_tiktok(&data)?;
        }
        if data.is_null() {
            return Err("no_data");
        }
        Ok(json!({"source":source,"status":"ok","fetched_at":now(),"cached":false,"data":data}))
    })();
    let value = result.unwrap_or_else(|e| unavailable(source, e));
    state.cache.retain(|_, e| e.at.elapsed().as_secs() < 1800);
    if state.cache.len() >= 512 {
        state.cache.clear();
    }
    // Cache failures briefly too: do not hammer an expired session or failed vendor.
    state.cache.insert(
        cache_key,
        Entry {
            at: Instant::now(),
            value: value.clone(),
        },
    );
    value
}
pub fn select(v: &Value, fields: &[&str]) -> Value {
    Value::Object(
        fields
            .iter()
            .filter_map(|k| v.get(*k).map(|v| ((*k).into(), v.clone())))
            .collect(),
    )
}
pub fn limit(v: &mut Value, field: &str, n: usize) {
    if let Some(a) = v.pointer_mut(field).and_then(Value::as_array_mut) {
        a.truncate(n);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::{
        io::{Read, Write},
        net::TcpListener,
        thread,
    };
    #[test]
    fn rejects_ambiguous_or_malformed_identity() {
        for v in [
            "SOL",
            "../token",
            "So11111111111111111111111111111111111111112 ",
            "111111111111111111111111111111111",
        ] {
            assert!(mint(v).is_err());
        }
        assert!(mint("So11111111111111111111111111111111111111112").is_ok());
    }
    #[test]
    fn unknown_is_not_empty_success() {
        let v = unavailable("fomo", "login_required");
        assert!(v["fetched_at"].is_null());
        assert!(v["data"].is_null());
        assert_ne!(v["status"], "ok");
    }
    #[test]
    fn cache_preserves_freshness_and_caps_prevent_network() {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let url = format!("http://{}", listener.local_addr().unwrap());
        let worker = thread::spawn(move || {
            let (mut s, _) = listener.accept().unwrap();
            let mut b = [0; 2048];
            let _ = s.read(&mut b);
            s.write_all(
                b"HTTP/1.1 200 OK\r\nContent-Length: 7\r\nConnection: close\r\n\r\n{\"x\":1}",
            )
            .unwrap();
        });
        let first = get("test-cache", &url, &[], None, 600, 1);
        worker.join().unwrap();
        assert_eq!(first["status"], "ok");
        let second = get("test-cache", &url, &[], None, 600, 1);
        assert_eq!(second["cached"], true);
        assert_eq!(first["fetched_at"], second["fetched_at"]);
        let capped = get("test-cache", &url, &[("different", "yes")], None, 600, 1);
        assert_eq!(capped["status"], "local_daily_limit");
        // Different credentials must not get the previous credential's cached private data.
        let isolated = get(
            "test-cache",
            &url,
            &[],
            Some(("x-api-key", "another-credential")),
            600,
            0,
        );
        assert_eq!(isolated["status"], "local_daily_limit");
    }
}

/// Remove multi-megabyte playback manifests and duplicate videos before caching/model input.
pub fn compact_tiktok(raw: &Value) -> Result<Value, &'static str> {
    if raw.get("success") == Some(&json!(false)) {
        return Err("upstream_error");
    }
    let rows = raw
        .get("search_item_list")
        .and_then(Value::as_array)
        .ok_or("invalid_response")?;
    let mut seen = std::collections::HashSet::new();
    let mut videos = Vec::new();
    for row in rows {
        let a = &row["aweme_info"];
        let Some(id) = a["aweme_id"].as_str().filter(|id| !id.is_empty()) else {
            continue;
        };
        if !seen.insert(id) {
            continue;
        }
        let link = a["share_info"]["share_url"].as_str().and_then(|url| {
            let mut u = reqwest::Url::parse(url).ok()?;
            let host = u.host_str()?;
            if u.scheme() != "https" || !(host == "tiktok.com" || host.ends_with(".tiktok.com")) {
                return None;
            }
            u.set_query(None);
            u.set_fragment(None);
            Some(u.to_string())
        });
        videos.push(json!({
            "id":id,"url":link,
            "caption":a["desc"].as_str().map(|s|s.chars().take(1200).collect::<String>()),
            "created_at":a.get("create_time"),
            "author":select(&a["author"], &["unique_id","nickname"]),
            "metrics":select(&a["statistics"], &["play_count","digg_count","comment_count","share_count"]),
        }));
        if videos.len() == 10 {
            break;
        }
    }
    if !rows.is_empty() && videos.is_empty() {
        return Err("invalid_response");
    }
    Ok(
        json!({"videos":videos,"has_more":raw.get("has_more"),"coverage":"One search page, up to 10 unique videos; sampled engagement, not aggregate trend volume"}),
    )
}

#[cfg(test)]
mod tiktok_tests {
    use super::*;
    #[test]
    fn bounds_and_deduplicates_large_vendor_results() {
        let rows:Vec<_>=(0..30).map(|n|json!({"aweme_info":{"aweme_id":format!("{}",n/2),"desc":"犬".repeat(2000),"author":{"unique_id":"creator","private_field":"omit"},"statistics":{"play_count":123},"share_info":{"share_url":"https://www.tiktok.com/@creator/video/123?tracking=omit"},"video":{"download":"x".repeat(10000)}}})).collect();
        let v = compact_tiktok(&json!({"success":true,"search_item_list":rows})).unwrap();
        let a = v["videos"].as_array().unwrap();
        assert_eq!(a.len(), 10);
        assert_eq!(a[0]["caption"].as_str().unwrap().chars().count(), 1200);
        assert_eq!(a[0]["url"], "https://www.tiktok.com/@creator/video/123");
        assert_eq!(a[0]["metrics"]["play_count"], 123);
        assert!(a[0]["metrics"].get("digg_count").is_none());
        assert!(a[0]["author"].get("private_field").is_none());
        assert!(v.to_string().len() < 50000);
    }
    #[test]
    fn rejects_vendor_errors_and_unrecognized_shapes() {
        for v in [
            json!({"success":false}),
            json!({"data":[]}),
            json!({"search_item_list":[{}]}),
        ] {
            assert!(compact_tiktok(&v).is_err());
        }
        assert!(compact_tiktok(&json!({"success":true,"search_item_list":[]})).is_ok());
    }
}

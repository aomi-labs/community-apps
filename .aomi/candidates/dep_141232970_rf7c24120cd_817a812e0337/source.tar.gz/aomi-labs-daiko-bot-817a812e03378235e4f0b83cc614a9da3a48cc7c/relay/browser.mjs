import { chromium } from 'playwright';
import { mkdir, chmod } from 'node:fs/promises';
import { resolve } from 'node:path';
export async function openBrowser({ headed = false } = {}) {
  const profile = process.env.FOMO_PROFILE_DIR;
  if (!profile) throw new Error('FOMO_PROFILE_DIR must point at a persistent private volume');
  await mkdir(resolve(profile), { recursive: true, mode: 0o700 });
  await chmod(resolve(profile), 0o700);
  const context = await chromium.launchPersistentContext(resolve(profile), {
    headless: !headed,
    ...(process.platform === "darwin" && process.env.CHROME_CHANNEL === "chrome" ? {ignoreDefaultArgs:["--password-store=basic","--use-mock-keychain"]} : {}),
    ...(process.env.CHROME_CHANNEL ? { channel: process.env.CHROME_CHANNEL } : {}),
  });
  let identity;
  context.on('request', request => {
    if (new URL(request.url()).origin === 'https://prod-api.fomo.family') {
      const auth = request.headers().authorization;
      if (auth?.startsWith('Bearer ')) identity = auth;
    }
  });
  const page = context.pages()[0] ?? await context.newPage();
  await page.goto('https://fomo.family', { waitUntil: 'domcontentloaded', timeout: 30000 });
  return { context, page, token: () => identity, clear: () => { identity = undefined; } };
}

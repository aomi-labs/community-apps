import { test } from 'node:test';
import assert from 'node:assert/strict';
import { authorized, validMint, unavailable } from './contract.mjs';
test('auth rejects missing/short/wrong keys and accepts exact bearer',()=>{
const key='a'.repeat(40);assert(!authorized(undefined,key));assert(!authorized('Bearer x',key));assert(!authorized('Bearer short','short'));assert(authorized(`Bearer ${key}`,key));});
test('only exact 32-byte base58 mints pass',()=>{
assert(validMint('So11111111111111111111111111111111111111112'));assert(validMint('11111111111111111111111111111111'));for(const v of ['SOL','../x','0'.repeat(32),'1'.repeat(33),'1'.repeat(31)])assert(!validMint(v));});
test('unavailable never fabricates freshness or empty success',()=>{assert.equal(unavailable('login_required').fetched_at,null);assert.equal(unavailable('login_required').data,null);});

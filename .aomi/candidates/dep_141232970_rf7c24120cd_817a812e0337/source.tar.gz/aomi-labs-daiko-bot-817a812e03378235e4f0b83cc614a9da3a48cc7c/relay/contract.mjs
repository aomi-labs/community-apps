import { timingSafeEqual } from 'node:crypto';
export function authorized(header, key) {
  if (!key || key.length < 32) return false;
  const a = Buffer.from(header ?? ''); const b = Buffer.from(`Bearer ${key}`);
  return a.length === b.length && timingSafeEqual(a,b);
}
const alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
export function validMint(mint) {
  if (typeof mint !== 'string' || mint.length < 32 || mint.length > 44) return false;
  let n = 0n;
  for (const c of mint) { const i = alphabet.indexOf(c); if (i < 0) return false; n = n * 58n + BigInt(i); }
  let bytes = 0; while (n > 0n) { bytes++; n >>= 8n; }
  return bytes + (mint.match(/^1*/)?.[0].length ?? 0) === 32;
}
export const unavailable = status => ({ source: 'fomo', status, fetched_at: null, data: null });

import http from 'node:http';
import { openBrowser } from './browser.mjs';
import { authorized, validMint, unavailable } from './contract.mjs';
const key = process.env.FOMO_RELAY_KEY;
if (!key || key.length < 32) throw new Error('A relay key of at least 32 characters is required');
const browser = await openBrowser({ headed: process.env.FOMO_HEADED === 'true' });
const cache = new Map();
let queued = 0, sequence = Promise.resolve(), lastRead = 0;
const server = http.createServer(async (req,res) => {
  res.setHeader('Content-Type','application/json'); res.setHeader('Cache-Control','no-store');
  const send = (code, body) => { res.writeHead(code); res.end(JSON.stringify(body)); };
  if (!authorized(req.headers.authorization,key)) return send(401,unavailable('unauthorized'));
  const url = new URL(req.url,'http://relay');
  if (req.method !== 'GET') return send(405,unavailable('method_not_allowed'));
  if (url.pathname === '/health') return send(200,{ source:'fomo', status:browser.token() ? 'session_observed' : 'login_required', browser_running:!browser.page.isClosed() });
  const mint = /^\/thesis\/([^/]+)$/.exec(url.pathname)?.[1];
  if (!validMint(mint)) return send(400,unavailable('invalid_mint'));
  const hit = cache.get(mint);
  if (hit && Date.now()-hit.at<300000) return send(200,{...hit.value,cached:true});
  if (!browser.token()) return send(200,unavailable('login_required'));
  if (queued >= 5) return send(429,unavailable('busy'));
  queued++;
  const work = sequence.then(async () => {
    // Requests that queued while the same mint was being fetched reuse it.
    const hit = cache.get(mint);
    if (hit && Date.now()-hit.at<300000) return {...hit.value,cached:true};
    await new Promise(r=>setTimeout(r,Math.max(0,1500-(Date.now()-lastRead))));
    lastRead = Date.now();
    const result = await browser.page.evaluate(async ({mint,token}) => {
      const url = new URL('https://prod-api.fomo.family/feed/token/thesis');
      for (const [k,v] of Object.entries({tokenAddress:mint,networkId:'1399811149',limit:'20',threshold:'1000'})) url.searchParams.set(k,v);
      try {
        const r = await fetch(url,{headers:{authorization:token,accept:'application/json'},signal:AbortSignal.timeout(10000)});
        if (!r.ok) return {status:r.status};
        const body = await r.text(); if (body.length>500000) return {status:502};
        return {status:r.status,body:JSON.parse(body)};
      } catch { return {status:502}; }
    },{mint,token:browser.token()});
    if (result.status === 401) {browser.clear();return unavailable('login_required');}
    if (result.status !== 200) return unavailable(result.status === 429 ? 'rate_limited' : 'upstream_unavailable');
    if (result.body?.success === false) return unavailable('upstream_unavailable');
    const data=result.body?.responseObject ?? result.body;
    if (data == null) return unavailable('no_data');
    const value={source:'fomo',status:'ok',mint,fetched_at:Math.floor(Date.now()/1000),cached:false,data,coverage:'Up to 20 thesis comments from this session; community opinions, not verified facts.'};
    if(cache.size>=256) cache.delete(cache.keys().next().value);
    cache.set(mint,{at:Date.now(),value});return value;
  });
  sequence=work.catch(()=>{});
  try {send(200,await work);} catch {send(200,unavailable('browser_unavailable'));} finally {queued--;}
});
server.requestTimeout=15000;
server.listen(Number(process.env.PORT ?? 8788),process.env.RELAY_BIND ?? '127.0.0.1');
async function close(){server.close();await browser.context.close();process.exit(0);}
process.on('SIGTERM',close);process.on('SIGINT',close);
console.log('Daiko relay listening; credentials and browser content are never logged.');

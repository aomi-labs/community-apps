export const unavailable=status=>({source:'fomo',status,data:null,fetched_at:null});
export function validMint(mint){
 if(typeof mint!=='string'||mint.length<32||mint.length>44)return false;
 const alphabet='123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';let n=0n;
 for(const c of mint){const i=alphabet.indexOf(c);if(i<0)return false;n=n*58n+BigInt(i);}
 let bytes=0;while(n){bytes++;n>>=8n;}return bytes+(mint.match(/^1*/)?.[0].length??0)===32;
}
export async function sameSecret(a,b){
 if(typeof a!=='string'||typeof b!=='string'||b.length<32||a.length>256)return false;
 const encoder=new TextEncoder();
 const [x,y]=await Promise.all([a,b].map(s=>crypto.subtle.digest('SHA-256',encoder.encode(s))));
 let mismatch=0;const bx=new Uint8Array(x),by=new Uint8Array(y);for(let i=0;i<32;i++)mismatch|=bx[i]^by[i];return mismatch===0;
}
export function cleanResult(value,mint){
 if(value?.status!=='ok')return unavailable(['browser_unavailable','no_visible_theses','page_mismatch'].includes(value?.status)?value.status:'invalid_browser_response');
 if(value.mint!==mint||!Array.isArray(value.comments)||!value.comments.length)return unavailable('invalid_browser_response');
 const comments=value.comments.slice(0,20).filter(x=>typeof x.author==='string'&&typeof x.text==='string').map(x=>({author:x.author.slice(0,80),text:x.text.slice(0,1600),likes:typeof x.likes==='string'?x.likes.slice(0,20):null,links:Array.isArray(x.links)?x.links.filter(h=>typeof h==='string'&&h.startsWith('https://')).slice(0,3).map(h=>h.slice(0,300)):[]}));
 if(!comments.length)return unavailable('invalid_browser_response');
 return {source:'fomo',status:'ok',mint,fetched_at:Math.floor(Date.now()/1000),cached:false,data:{comments,layout:value.layout==='thesis_feed'?'thesis_feed':'holder_table',source_url:`https://fomo.family/tokens/solana/${mint}`},coverage:'Up to 20 rendered public thesis comments, in the page\'s current order. Not all comments or a vote ranking; site text may be truncated. Community opinions, not verified facts.'};
}

import {researchArgs} from '../browser/pages.mjs';
import {siteId} from '../browser/service.mjs';
import {sameSecret,validMint,unavailable,cleanResult} from './contract.mjs';
const json=(body,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'no-store'}});
export default {async fetch(request,env){
 const u=new URL(request.url);
 if(u.pathname!=='/browser'){
  if(!(await sameSecret(request.headers.get('Authorization'),`Bearer ${env.FOMO_RELAY_KEY}`)))return json(unavailable('unauthorized'),401);
 }else if(request.headers.get('Upgrade')?.toLowerCase()!=='websocket')return json(unavailable('websocket_required'),426);
 if(u.pathname==='/research'&&request.method==='POST'){
  try{const body=await request.text();if(body.length>2048)throw new Error();const args=researchArgs(JSON.parse(body));return env.HOSTED.get(env.HOSTED.idFromName(siteId(args.site))).fetch(new Request('https://internal/research',{method:'POST',body:JSON.stringify(args)}));}catch{return json(unavailable('invalid_request'),400);}
 }
 const job=u.pathname.match(/^\/jobs\/(fomo|gmgn)\/([0-9a-f-]{36})$/);
 if(job&&request.method==='GET')return env.HOSTED.get(env.HOSTED.idFromName(siteId(job[1]))).fetch(new Request('https://internal/jobs/'+job[2]));
 if(request.method!=='GET')return json(unavailable('method_not_allowed'),405);
 if(u.pathname!=='/browser'&&u.pathname!=='/health'&&!/^\/thesis\/[^/]+$/.test(u.pathname))return json(unavailable('not_found'),404);
 return env.BROWSER.get(env.BROWSER.idFromName('daiko')).fetch(request);
}};
export class BrowserBridge{
 constructor(ctx,env){this.ctx=ctx;this.env=env;this.pending=new Map();}
 browser(){return this.ctx.getWebSockets().find(ws=>ws.deserializeAttachment()?.authenticated);}
 async fetch(request){
  const u=new URL(request.url);
  if(u.pathname==='/browser'){
   if(this.ctx.getWebSockets().length>=5)return json(unavailable('busy'),429);
   const pair=new WebSocketPair();const [client,server]=Object.values(pair);
   this.ctx.acceptWebSocket(server);server.serializeAttachment({authenticated:false,connectedAt:Date.now()});
   this.ctx.waitUntil(new Promise(resolve=>setTimeout(()=>{if(!server.deserializeAttachment()?.authenticated)server.close(1008,'Pairing required');resolve();},5000)));
   return new Response(null,{status:101,webSocket:client});
  }
  const browser=this.browser();
  if(u.pathname==='/health')return json({source:'fomo',status:browser?'browser_connected':'browser_offline',browser_running:!!browser});
  const mint=u.pathname.slice('/thesis/'.length);if(!validMint(mint))return json(unavailable('invalid_mint'),400);
  const cacheKey=`cache:${mint}`;const cached=await this.ctx.storage.get(cacheKey);
  if(cached&&Date.now()/1000-cached.fetched_at<300)return json({...cached,cached:true});
  if(!browser)return json(unavailable('browser_offline'));
  const last=browser.deserializeAttachment()?.request;
  if(last&&Date.now()-last.at<30000)return json(unavailable(last.mint===mint?'refresh_pending':'busy'));
  const existing=Array.from(this.pending.values()).find(p=>p.mint===mint);
  if(existing)return json(await existing.promise);
  if(this.pending.size>=1)return json(unavailable('busy'),429);
  const day=new Date().toISOString().slice(0,10);
  const allowed=await this.ctx.storage.transaction(async store=>{
   const prior=await store.get('quota');const count=prior?.day===day?prior.count:0;if(count>=100)return false;
   await store.put('quota',{day,count:count+1});return true;
  });
  if(!allowed)return json(unavailable('daily_cap'));
  const id=crypto.randomUUID();let resolve;
  const promise=new Promise(r=>{resolve=r;});
  const timer=setTimeout(()=>{this.pending.delete(id);resolve(unavailable('refresh_pending'));},8500);
  this.pending.set(id,{mint,resolve,promise,timer,socket:browser});
  // Keep late reads eligible for cache without claiming success until they arrive.
  browser.serializeAttachment({...browser.deserializeAttachment(),request:{id,mint,at:Date.now()}});
  try{browser.send(JSON.stringify({type:'read',id,mint}));}catch{clearTimeout(timer);this.pending.delete(id);resolve(unavailable('browser_offline'));}
  return json(await promise);
 }
 async webSocketMessage(ws,message){
  if(typeof message!=='string'||message.length>65000){ws.close(1009,'Invalid message');return;}
  let data;try{data=JSON.parse(message);}catch{ws.close(1008,'Invalid message');return;}
  const attachment=ws.deserializeAttachment();
  if(!attachment?.authenticated){
   if(data.type!=='auth'||!(await sameSecret(data.key,this.env.FOMO_BROWSER_KEY))){ws.close(1008,'Pairing rejected');return;}
   for(const old of this.ctx.getWebSockets())if(old!==ws&&old.deserializeAttachment()?.authenticated)old.close(1000,'Replaced');
   ws.serializeAttachment({authenticated:true});ws.send('{"type":"ready"}');return;
  }
  if(data.type==='ping'){ws.send('{"type":"pong"}');return;}
  const request=attachment.request;
  if(data.type!=='result'||!request||data.id!==request.id||data.mint!==request.mint||Date.now()-request.at>30000)return;
  const value=cleanResult(data.value,request.mint);
  if(value.status==='ok'){
   await this.ctx.storage.put(`cache:${request.mint}`,value);
   const keys=await this.ctx.storage.list({prefix:'cache:',limit:257});if(keys.size>256)await this.ctx.storage.delete(keys.keys().next().value);
  }
  ws.serializeAttachment({authenticated:true});
  const pending=this.pending.get(data.id);if(pending){clearTimeout(pending.timer);this.pending.delete(data.id);pending.resolve(value);}
 }
 webSocketClose(ws){ws.close();for(const [id,p]of this.pending){if(p.socket===ws){clearTimeout(p.timer);p.resolve(unavailable('browser_offline'));this.pending.delete(id);}}}
 webSocketError(ws){ws.close(1011,'Connection failed');}
}

import {test} from 'node:test';
import assert from 'node:assert/strict';
import {openThesisPanel,readThesis} from '../browser-extension/reader.js';
const mint='So11111111111111111111111111111111111111112';
test('cold page opens only its exact public thesis panel, once',()=>{
 globalThis.location={origin:'https://fomo.family',pathname:`/tokens/solana/${mint}`};
 let clicks=0,rows=false;
 globalThis.document={querySelector:()=>rows?{}:null,getElementById(id){assert.equal(id,`thesis-trigger-token-page-thesis-${mint}:1399811149`);return{click(){clicks++;rows=true;}};}};
 assert(openThesisPanel(mint));assert(openThesisPanel(mint));assert.equal(clicks,1);
 location.pathname='/discover';assert(!openThesisPanel(mint));assert.equal(clicks,1);
});
test('reader exports bounded comment fields and never holder positions',()=>{
 globalThis.location={origin:'https://fomo.family',pathname:`/tokens/solana/${mint}`};
 const text='public opinion';const content={innerText:text,querySelectorAll:()=>[{href:'https://x.com/public'},{href:'javascript:bad'}]};
 const control={innerText:'12',parentElement:{children:[]},closest:()=>({firstElementChild:{innerText:'alice\n$private position'}})};control.parentElement.children=[control,content];
 globalThis.document={querySelectorAll:()=>[control,control]};
 const result=readThesis(mint);assert.equal(result.comments.length,1);assert.equal(result.comments[0].author,'alice');assert.equal(result.comments[0].text,text);assert.deepEqual(result.comments[0].links,['https://x.com/public']);assert(!JSON.stringify(result).includes('private position'));
});
test('floating feed cards yield author and comment rather than footer or position',()=>{
 globalThis.location={origin:'https://fomo.family',pathname:`/tokens/solana/${mint}`};
 const header={innerText:'bob\n$private position\n-50%'},content={className:'whitespace-pre-line',innerText:'A public thesis',querySelectorAll:()=>[]};
 const stack={children:[header,content],firstElementChild:header};
 const footer={parentElement:stack};
 const control={innerText:'3',parentElement:footer,closest:()=>null};
 globalThis.document={querySelectorAll:()=>[control]};
 const result=readThesis(mint);assert.equal(result.status,'ok');assert.equal(result.layout,'thesis_feed');assert.equal(result.comments[0].author,'bob');assert.equal(result.comments[0].text,'A public thesis');assert(!JSON.stringify(result).includes('private position'));
});

"""SQLAlchemy 2.0 ORM — receipts, audits, positions, scan candidates.

Single engine for both SQLite (dev) and Postgres (prod via Neon). The DATABASE_URL
in `.env` decides — no code branch needed.
"""

from __future__ import annotations

import os
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path

from sqlalchemy import (
    BigInteger,
    Column,
    DateTime,
    Float,
    Index,
    Integer,
    LargeBinary,
    String,
    Text,
    create_engine,
)
from sqlalchemy.orm import DeclarativeBase, sessionmaker
from sqlalchemy.orm import Session as OrmSession

_DEFAULT_DB_URL = "sqlite:///./data/reasoning_receipt.db"


def normalize_database_url(url: str) -> str:
    """Select psycopg 3 for provider URLs that omit an explicit driver."""
    if url.startswith("postgres://"):
        url = "postgresql+psycopg://" + url.removeprefix("postgres://")
    elif url.startswith("postgresql://") and "+psycopg" not in url.split("://", 1)[0]:
        url = "postgresql+psycopg://" + url.removeprefix("postgresql://")
    return url


def _db_url() -> str:
    url = normalize_database_url(os.getenv("DATABASE_URL", _DEFAULT_DB_URL))
    if url.startswith("sqlite:///./"):
        Path(url.replace("sqlite:///./", "")).parent.mkdir(parents=True, exist_ok=True)
    return url


class Base(DeclarativeBase):
    """ORM base."""


def _now() -> datetime:
    return datetime.now(UTC)


class Receipt(Base):
    """One row per published receipt. Mirrors the on-chain Receipt event."""

    __tablename__ = "receipts"

    id = Column(Integer, primary_key=True, autoincrement=True)
    chain_receipt_id = Column(Integer, nullable=True, index=True)
    market_id = Column(String(80), nullable=False, index=True)
    market_question = Column(Text, nullable=True)
    market_source = Column(String(16), nullable=False, default="polymarket")
    probability = Column(Float, nullable=False)
    confidence = Column(Float, nullable=False)
    trace_hash = Column(String(70), nullable=False, index=True)
    trace_cid = Column(String(120), nullable=False)
    consumer_address = Column(String(64), nullable=True, index=True)
    publisher_address = Column(String(64), nullable=False)
    paid_micro_usdc = Column(Integer, nullable=False, default=0)
    arc_tx_hash = Column(String(80), nullable=True, index=True)
    arc_block_number = Column(Integer, nullable=True)
    latency_ms = Column(Integer, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=False, default=_now, index=True)

    # Backtest: filled in later when the underlying market resolves.
    # resolved_outcome in [0.0, 1.0] (binary outcome for YES/NO markets).
    resolved_at = Column(DateTime(timezone=True), nullable=True, index=True)
    resolved_outcome = Column(Float, nullable=True)

    # rr-trace/3 columns: schema lineage + multi-agent disagreement signal +
    # the trace's category for per-category calibration (Phase 5).
    # Defaults preserve back-compat — existing rr-trace/2 rows read as such.
    schema_version = Column(String(16), nullable=False, default="rr-trace/2", index=True)
    disagreement_pp = Column(Float, nullable=True)
    merkle_root = Column(String(70), nullable=True, index=True)
    category = Column(String(16), nullable=True, index=True)

    __table_args__ = (Index("ix_receipts_market_created", "market_id", "created_at"),)


class Position(Base):
    """One row per portfolio bet placed by the trader."""

    __tablename__ = "positions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    market_id = Column(String(80), nullable=False, index=True)
    side = Column(String(8), nullable=False)
    outcome = Column(String(64), nullable=True)
    size_usdc = Column(Float, nullable=False)
    entry_price = Column(Float, nullable=False)
    receipt_id = Column(Integer, nullable=True, index=True)
    polymarket_order_id = Column(String(80), nullable=True)
    status = Column(String(16), nullable=False, default="open")
    realized_pnl_usdc = Column(Float, nullable=False, default=0.0)
    opened_at = Column(DateTime(timezone=True), nullable=False, default=_now)
    closed_at = Column(DateTime(timezone=True), nullable=True)


class ScanCandidate(Base):
    """One row per market the scanner considers eligible for analysis."""

    __tablename__ = "scan_candidates"

    id = Column(Integer, primary_key=True, autoincrement=True)
    market_id = Column(String(80), nullable=False, unique=True, index=True)
    source = Column(String(16), nullable=False, default="polymarket")
    question = Column(Text, nullable=False)
    liquidity_usd = Column(Float, nullable=False)
    end_date = Column(DateTime(timezone=True), nullable=True)
    last_priced_at = Column(DateTime(timezone=True), nullable=True)
    last_probability = Column(Float, nullable=True)
    discovered_at = Column(DateTime(timezone=True), nullable=False, default=_now)


class MemoryItem(Base):
    """Cached embedding of a resolved market, keyed by its receipt.

    The memory loop (`agent.memory`) embeds the question of each resolved
    receipt once and caches the raw float32 vector here. Retrieval loads every
    cached vector and runs cosine similarity in-process — no vector-DB
    extension needed for the small resolved-market set. One row per receipt;
    re-embedding is skipped when a row already exists (idempotent backfill).
    """

    __tablename__ = "memory_items"

    receipt_id = Column(Integer, primary_key=True)  # FK-ish to receipts.id
    market_id = Column(String(80), nullable=False, index=True)
    question = Column(Text, nullable=False)
    category = Column(String(16), nullable=True)
    probability = Column(Float, nullable=False)
    resolved_outcome = Column(Float, nullable=False)
    embedding = Column(LargeBinary, nullable=False)  # float32 bytes, model-native dim
    embed_model = Column(String(48), nullable=False, default="mock")
    embedded_at = Column(DateTime(timezone=True), nullable=False, default=_now)


class Audit(Base):
    """One oracle trace awaiting, refused by, or carrying an independent audit.

    In ``RR_AUDIT_MODE=aomi`` the loop stores the critic-approved trace here
    instead of sealing it. The auditor's findings become extra trace nodes and
    the auditor's own wallet publishes the sealed trace (see ``server.audit``).
    """

    __tablename__ = "audits"

    id = Column(Integer, primary_key=True, autoincrement=True)
    market_id = Column(String(80), nullable=False, index=True)
    market_question = Column(Text, nullable=True)
    market_source = Column(String(16), nullable=False, default="polymarket")
    status = Column(String(16), nullable=False, default="pending", index=True)
    trace = Column(Text, nullable=False)  # the oracle's trace exactly as produced
    sealed_trace = Column(Text, nullable=True)
    findings = Column(Text, nullable=True)  # what the auditor reported, approved or not
    auditor = Column(String(64), nullable=True)
    chain_id = Column(Integer, nullable=True)
    registry = Column(String(64), nullable=True)
    trace_hash = Column(String(70), nullable=True, unique=True)
    merkle_root = Column(String(70), nullable=True)
    trace_cid = Column(String(120), nullable=True)
    calldata = Column(Text, nullable=True)
    transaction_hash = Column(String(80), nullable=True, unique=True)
    receipt_id = Column(Integer, nullable=True)  # receipts.id once published
    created_at = Column(DateTime(timezone=True), nullable=False, default=_now, index=True)
    updated_at = Column(DateTime(timezone=True), nullable=True)


class Settlement(Base):
    """One wallet-approved transfer linked to one published audit.

    ``source_receipt_hash`` is the audited trace hash and ``source_receipt`` the
    audit reference as it was when the payment was prepared. A successful
    transfer adds a separate outcome receipt that references it. Unique source hash and transaction hash keep repeated verification from
    creating a second success record.
    """

    __tablename__ = "settlements"

    id = Column(Integer, primary_key=True, autoincrement=True)
    source_receipt_hash = Column(String(70), nullable=False, unique=True, index=True)
    source_receipt = Column(Text, nullable=False)
    chain_id = Column(Integer, nullable=False)
    token = Column(String(42), nullable=False)
    recipient = Column(String(42), nullable=False)
    amount_units = Column(String(40), nullable=False)
    payer = Column(String(42), nullable=False)
    # Payments must be mined after the chain head observed at first preparation.
    # NULL identifies legacy attempts that cannot safely establish this boundary.
    prepared_after_block = Column(BigInteger, nullable=True)
    status = Column(String(16), nullable=False, default="prepared", index=True)
    transaction_hash = Column(String(66), nullable=True, unique=True)
    outcome_receipt = Column(Text, nullable=True)
    prepared_at = Column(DateTime(timezone=True), nullable=False, default=_now)
    settled_at = Column(DateTime(timezone=True), nullable=True)


_engine = None
_Session: sessionmaker | None = None


def init_db(url: str | None = None) -> None:
    """Create tables if missing. Idempotent. Pre-warms the global engine."""
    global _engine, _Session
    _engine = create_engine(url or _db_url(), future=True, pool_pre_ping=True)
    Base.metadata.create_all(_engine)
    _Session = sessionmaker(bind=_engine, expire_on_commit=False, future=True)
    _migrate(_engine)


def _migrate(engine) -> None:
    """Idempotent ALTER TABLE migrations for columns added after table creation.

    SQLite-friendly. Each ADD COLUMN is wrapped in a try/except so re-runs are safe.
    """
    from sqlalchemy import text

    statements = [
        # rr-trace/2 backtest columns
        "ALTER TABLE receipts ADD COLUMN resolved_at DATETIME",
        "ALTER TABLE receipts ADD COLUMN resolved_outcome FLOAT",
        # rr-trace/3 columns — schema lineage + ensemble signal + category
        "ALTER TABLE receipts ADD COLUMN schema_version VARCHAR(16) DEFAULT 'rr-trace/2'",
        "ALTER TABLE receipts ADD COLUMN disagreement_pp FLOAT",
        "ALTER TABLE receipts ADD COLUMN merkle_root VARCHAR(70)",
        "ALTER TABLE receipts ADD COLUMN category VARCHAR(16)",
        "ALTER TABLE settlements ADD COLUMN prepared_after_block BIGINT",
    ]
    import contextlib

    for sql in statements:
        # PostgreSQL aborts a transaction after an already-existing column error.
        # Give each migration its own transaction so later additions still run.
        with contextlib.suppress(Exception), engine.begin() as conn:
            conn.execute(text(sql))


@contextmanager
def Session() -> Iterator[OrmSession]:
    """Scoped session contextmanager. Auto-commits on success, rolls back on error."""
    if _Session is None:
        init_db()
    assert _Session is not None
    session = _Session()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()

# Hoodit cards

`hoodit_card` draws a square PnL card from the wallet's trade records. In Telegram the image arrives as a photo after your reply, with redraw buttons attached to your text reply. These rules come first.

## When
- A sell that closes a position just landed (the host reported it): call `hoodit_card` with the coin's `token` and that `tx_hash`. Don't ask first.
- A partial sell: don't make one; offer it in a few words at the end of your reply ("want a pnl card?").
- The user asks for a PnL card, a flex card or their gains on a coin: call it with the `token` (and `wallet` only if they name another one).

## Buttons and redraws
A message "Redraw my $X card (card ID) …" comes from a button under a card. Call `hoodit_card` with `redraw` = ID and only the change it names:
- "in a different random style" → `another_style: true`.
- "as the S style" → `style`.
- "with … as the big number" → `big`.
- "without dollar amounts" → `show` = the previous `shown` minus usd and inout.
A redraw keeps the style and everything else unless the message changes it. Never pass `token` with `redraw`. The user can ask the same things in their own words ("make it the wanted poster", "hide the dollars"): use the last card's `card_id`.

## Style
Pass `style` only when the user names one. Otherwise leave it out: the card picks one that fits the result. If `style_note` comes back, say it in a few words ("bag is for wins, so here's a receipt").

## Your reply
- The photo is the answer. Write one short line ("+80% on TADA, here's the card" or "wanted poster it is"). Always write that line: without it the buttons don't attach.
- Quote only the card's own numbers (`card`). Don't restate them all or describe the picture.
- `NO_DATA` saying GMGN hasn't indexed the trade yet: say the card needs a minute and offer to try again.
- `NOT_FOUND` on a redraw: the card expired; make a new one with the coin.

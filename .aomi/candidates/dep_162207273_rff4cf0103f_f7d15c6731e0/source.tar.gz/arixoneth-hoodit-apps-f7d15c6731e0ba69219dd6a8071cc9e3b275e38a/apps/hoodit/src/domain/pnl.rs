//! A wallet's profit on one coin, from GMGN's trade records. A round runs
//! from the buy that opens a position to the sell that closes it (GMGN
//! flags both). Cost basis includes buy fees, as GMGN computes it; a
//! round with a transfer in, or sells with no buys on record, has no known
//! cost, and the card says so instead of guessing.
use crate::card::Card;
use crate::providers::chain::Chain;
use crate::providers::gmgn::{Gmgn, types::Activity};
use crate::runtime::{Fail, Runtime, Turn};
use std::collections::BTreeSet;
use std::time::Duration;

/// Pages of 50 trades read before giving up on finding the round's start.
const MAX_PAGES: usize = 4;
/// How long to wait for GMGN to index a trade that just landed.
const INDEX_WAIT: [u64; 3] = [0, 3, 5];

/// The latest round (or the one holding `tx`) as card figures.
pub async fn card(
    rt: &Runtime,
    turn: &Turn,
    wallet: &str,
    token: &str,
    tx: Option<&str>,
) -> Result<Card, Fail> {
    let gmgn = Gmgn::new(rt, turn);
    let tx = tx.map(str::trim).map(str::to_lowercase);
    if let Some(t) = &tx
        && (t.len() != 66 || !t.starts_with("0x") || !t[2..].bytes().all(|b| b.is_ascii_hexdigit()))
    {
        return Err(Fail::Invalid(
            "tx_hash must be a 0x transaction hash".into(),
        ));
    }
    let mut rows = vec![];
    for wait in INDEX_WAIT {
        tokio::time::sleep(Duration::from_secs(wait)).await;
        rows = history(gmgn, wallet, token, tx.as_deref()).await?;
        if tx
            .as_ref()
            .is_none_or(|t| rows.iter().any(|r| r.tx_hash.to_lowercase() == *t))
        {
            break;
        }
    }
    if let Some(t) = &tx
        && !rows.iter().any(|r| r.tx_hash.to_lowercase() == *t)
    {
        return Err(Fail::NoData(format!(
            "GMGN hasn't indexed {} yet; try again in a minute",
            &t[..t.len().min(12)]
        )));
    }
    let round = round(rows, tx.as_deref())?;
    if round
        .rows
        .iter()
        .filter(|r| r.event_type == "sell")
        .any(|r| r.cost_usd.get().is_none())
    {
        return Err(Fail::NoData(
            "sell proceeds are unavailable; try again later".into(),
        ));
    }
    let now = crate::view::now();
    if !round.open {
        return Ok(round.closed(now));
    }
    let chain = Chain::new(rt, turn);
    let (info, decimals, balance) = tokio::join!(
        gmgn.token_info(token),
        chain.decimals(token),
        chain.balance(token, wallet)
    );
    let price = info.ok().and_then(|i| i.price.price.get());
    let held = match (decimals, balance) {
        (Ok(d), Ok(b)) => Some(b as f64 / 10f64.powi(i32::from(d))),
        _ => None,
    };
    round.open_card(now, price, held)
}

/// Every record GMGN has for the pair, oldest first, up to [`MAX_PAGES`].
async fn history(
    gmgn: Gmgn<'_>,
    wallet: &str,
    token: &str,
    tx: Option<&str>,
) -> Result<Vec<Activity>, Fail> {
    let mut rows = vec![];
    let mut cursor: Option<String> = None;
    for _ in 0..MAX_PAGES {
        let (mut page, next) = gmgn
            .token_activity(wallet, token, cursor.as_deref())
            .await?;
        // GMGN is newest first. Preserve its order for trades sharing a
        // timestamp, including fills that straddle two pages.
        page.reverse();
        page.extend(rows);
        rows = page;
        rows.sort_by_key(|r| r.timestamp.ts().unwrap_or(0));
        let opened = history_complete(&rows, tx);
        match next {
            // Read through the requested round, which can precede the latest one.
            Some(c) if !opened && cursor.as_ref() != Some(&c) => cursor = Some(c),
            _ => break,
        }
    }
    rows.sort_by_key(|r| r.timestamp.ts().unwrap_or(0));
    Ok(rows)
}

fn history_complete(rows: &[Activity], tx: Option<&str>) -> bool {
    round(rows.to_vec(), tx).is_ok_and(|r| r.rows.first().is_some_and(opening_buy))
}

fn opening_buy(row: &Activity) -> bool {
    row.event_type == "buy" && row.is_open_or_close.get() == Some(1.0)
}

pub struct Round {
    rows: Vec<Activity>,
    open: bool,
}

/// Splits records (oldest first) into rounds and picks the one with `tx`,
/// else the latest.
pub fn round(rows: Vec<Activity>, tx: Option<&str>) -> Result<Round, Fail> {
    let mut rounds: Vec<Vec<Activity>> = vec![vec![]];
    for row in rows.into_iter().filter(|r| {
        matches!(
            r.event_type.as_str(),
            "buy" | "sell" | "transferIn" | "transferOut"
        )
    }) {
        if opening_buy(&row) && !rounds.last().expect("one round").is_empty() {
            rounds.push(vec![]);
        }
        let closes = row.event_type == "sell" && row.is_open_or_close.get() == Some(1.0);
        rounds.last_mut().expect("one round").push(row);
        if closes {
            rounds.push(vec![]);
        }
    }
    let open_tail = rounds.last().is_some_and(|r| {
        r.iter()
            .any(|a| matches!(a.event_type.as_str(), "buy" | "transferIn"))
    });
    if !open_tail {
        rounds.pop();
    }
    let index = match tx {
        Some(t) => rounds
            .iter()
            .position(|r| r.iter().any(|a| a.tx_hash.eq_ignore_ascii_case(t))),
        None => rounds.len().checked_sub(1),
    }
    .ok_or_else(|| Fail::NotFound("no trades of this coin from this wallet on record".into()))?;
    let open = open_tail && index + 1 == rounds.len();
    Ok(Round {
        rows: rounds.swap_remove(index),
        open,
    })
}

fn sum(rows: &[&Activity], f: impl Fn(&Activity) -> Option<f64>) -> f64 {
    rows.iter().filter_map(|r| f(r)).sum()
}

impl Round {
    fn side(&self, side: &str) -> Vec<&Activity> {
        self.rows.iter().filter(|r| r.event_type == side).collect()
    }

    fn txs(rows: &[&Activity]) -> u32 {
        rows.iter()
            .map(|r| r.tx_hash.as_str())
            .collect::<BTreeSet<_>>()
            .len() as u32
    }

    /// Paid for the buys, fees included; None when the record is incomplete.
    fn bought(&self) -> Option<f64> {
        let buys = self.side("buy");
        if !self.rows.first().is_some_and(opening_buy)
            || !self.side("transferIn").is_empty()
            || !self.side("transferOut").is_empty()
        {
            return None;
        }
        buys.iter()
            .map(|r| {
                Some(
                    r.cost_usd.get()?
                        + r.gas_usd.get().unwrap_or(0.0)
                        + r.dex_usd.get().unwrap_or(0.0),
                )
            })
            .sum()
    }

    fn entry(&self) -> Option<f64> {
        let buys = self.side("buy");
        let amount: f64 = buys
            .iter()
            .map(|r| r.token_amount.get())
            .sum::<Option<_>>()?;
        let cost: f64 = buys.iter().map(|r| r.cost_usd.get()).sum::<Option<_>>()?;
        (amount > 0.0).then_some(cost / amount)
    }

    fn base(&self, now: i64) -> Card {
        let (buys, sells) = (self.side("buy"), self.side("sell"));
        let first = self.rows.first().and_then(|r| r.timestamp.ts());
        let last = self.rows.last();
        Card {
            symbol: self
                .rows
                .iter()
                .find_map(|r| r.token.symbol.clone())
                .map(|s| crate::card::format::clamp(&s, 20))
                .unwrap_or_else(|| "COIN".into()),
            open: false,
            cost: None,
            out: 0.0,
            entry: self.entry(),
            exit: None,
            held_s: first.map(|f| last.and_then(|l| l.timestamp.ts()).unwrap_or(now).max(f) - f),
            buys: Self::txs(&buys),
            sells: Self::txs(&sells),
            gas: None,
            ts: last.and_then(|l| l.timestamp.ts()).unwrap_or(now),
            tx: last.map(|l| l.tx_hash.clone()).unwrap_or_default(),
        }
    }

    pub fn closed(&self, now: i64) -> Card {
        let sells = self.side("sell");
        let out = sum(&sells, |r| r.cost_usd.get());
        let sold = sum(&sells, |r| r.token_amount.get());
        // GMGN prorates the basis to what each sell sold.
        let basis_known = sells.iter().all(|r| r.buy_cost_usd.get().is_some());
        let cost = match self.bought() {
            Some(_) if basis_known => Some(sum(&sells, |r| r.buy_cost_usd.get())),
            other => other,
        };
        Card {
            cost,
            out,
            exit: (sold > 0.0).then(|| out / sold),
            gas: Some(sum(&sells, |r| r.gas_usd.get())),
            ..self.base(now)
        }
    }

    /// Everything bought vs everything sold plus what's held now.
    pub fn open_card(&self, now: i64, price: Option<f64>, held: Option<f64>) -> Result<Card, Fail> {
        let sells = self.side("sell");
        let value = price.zip(held).map(|(p, h)| p * h).ok_or_else(|| {
            Fail::NoData("current position value is unavailable; try again later".into())
        })?;
        Ok(Card {
            open: true,
            cost: self.bought(),
            out: sum(&sells, |r| r.cost_usd.get()) + value,
            exit: price,
            gas: Some(sum(&self.rows.iter().collect::<Vec<_>>(), |r| {
                r.gas_usd.get()
            })),
            held_s: self
                .rows
                .first()
                .and_then(|r| r.timestamp.ts())
                .map(|f| now - f),
            ts: now,
            ..self.base(now)
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    fn row(
        kind: &str,
        ts: i64,
        tx: &str,
        amount: f64,
        usd: f64,
        basis: Option<f64>,
        flag: i64,
    ) -> Activity {
        serde_json::from_value(json!({
            "timestamp": ts, "event_type": kind, "tx_hash": tx,
            "token": {"address": "0x69f1", "symbol": "TADA"},
            "token_amount": amount.to_string(), "cost_usd": usd.to_string(),
            "buy_cost_usd": basis.map(|b| b.to_string()),
            "gas_usd": "0.02", "dex_usd": "0.05", "is_open_or_close": flag,
        }))
        .unwrap()
    }

    /// Senpai's TADA round as GMGN recorded it on 2026-10-20.
    fn tada() -> Vec<Activity> {
        let mut buy = row("buy", 1_792_491_129, "0x6e8f", 24_413.51, 2.9302, None, 1);
        buy.gas_usd = crate::providers::Num(Some(0.0190));
        buy.dex_usd = crate::providers::Num(Some(0.0662));
        let mut sell = row(
            "sell",
            1_792_495_294,
            "0x4f6a",
            24_352.48,
            5.4216,
            Some(3.007_968_338),
            1,
        );
        sell.gas_usd = crate::providers::Num(Some(0.0316));
        vec![buy, sell]
    }

    #[test]
    fn tada_is_up_80_percent_not_2x() {
        let card = round(tada(), None).unwrap().closed(0);
        assert!(!card.open);
        assert_eq!(card.symbol, "TADA");
        assert!((card.pnl().unwrap() - 2.4136).abs() < 0.001);
        assert!((card.pct().unwrap() - 80.24).abs() < 0.05);
        assert!((card.mult().unwrap() - 1.802).abs() < 0.001);
        assert_eq!(card.held_s, Some(4165));
        assert_eq!((card.buys, card.sells), (1, 1));
        assert!((card.gas.unwrap() - 0.0316).abs() < 1e-9);
    }

    #[test]
    fn partial_sells_and_split_fills_add_up() {
        let rows = vec![
            row("buy", 1, "a", 1000.0, 10.0, None, 1),
            row("sell", 2, "b", 300.0, 6.0, Some(3.0), 0),
            row("sell", 3, "c", 200.0, 3.0, Some(2.0), 0),
            row("sell", 3, "c", 500.0, 4.0, Some(5.0), 1),
        ];
        let card = round(rows, None).unwrap().closed(0);
        assert_eq!(card.cost, Some(10.0));
        assert_eq!(card.out, 13.0);
        assert_eq!((card.buys, card.sells), (1, 2));
    }

    #[test]
    fn rounds_split_on_close_and_pick_by_tx() {
        let rows = vec![
            row("buy", 1, "a", 100.0, 1.0, None, 1),
            row("sell", 2, "b", 100.0, 3.0, Some(1.1), 1),
            row("buy", 3, "c", 100.0, 2.0, None, 1),
        ];
        let latest = round(rows.clone(), None).unwrap();
        assert!(latest.open);
        let first = round(rows, Some("B")).unwrap();
        assert!(!first.open);
        assert_eq!(first.closed(0).out, 3.0);
    }

    #[test]
    fn transfers_and_missing_buys_mean_unknown_cost() {
        let gift = vec![
            row("transferIn", 1, "a", 100.0, 0.0, None, 0),
            row("sell", 2, "b", 100.0, 18.2, Some(0.0), 1),
        ];
        assert_eq!(round(gift, None).unwrap().closed(0).cost, None);
        let orphan = vec![row("sell", 2, "b", 100.0, 18.2, None, 1)];
        let card = round(orphan, None).unwrap().closed(0);
        assert_eq!((card.cost, card.pct()), (None, None));
        assert!(round(vec![], None).is_err());
    }

    #[test]
    fn open_positions_count_value_now() {
        let rows = vec![row("buy", 100, "a", 1000.0, 10.0, None, 1)];
        let card = round(rows, None)
            .unwrap()
            .open_card(200, Some(0.012), Some(1000.0))
            .unwrap();
        assert!(card.open);
        assert!((card.out - 12.0).abs() < 1e-9);
        assert!((card.cost.unwrap() - 10.07).abs() < 1e-9);
        assert_eq!(card.held_s, Some(100));
    }
    #[test]
    fn incomplete_history_does_not_invent_cost_basis() {
        let rows = vec![
            row("buy", 1, "a", 100.0, 10.0, None, 0),
            row("sell", 2, "b", 200.0, 30.0, None, 1),
        ];
        assert_eq!(round(rows, None).unwrap().closed(0).cost, None);
        let mut rows = tada();
        rows[0].cost_usd = Default::default();
        assert_eq!(round(rows, None).unwrap().closed(0).cost, None);
    }

    #[test]
    fn transferred_out_positions_do_not_merge_with_a_new_round() {
        let rows = vec![
            row("buy", 1, "a", 100.0, 10.0, None, 1),
            row("transferOut", 2, "b", 100.0, 0.0, None, 0),
            row("buy", 3, "c", 100.0, 20.0, None, 1),
            row("sell", 4, "d", 100.0, 30.0, None, 1),
        ];
        let card = round(rows, None).unwrap().closed(0);
        assert!((card.cost.unwrap() - 20.07).abs() < 1e-9);
        assert_eq!(card.buys, 1);
        assert_eq!(card.held_s, Some(1));
    }
    #[test]
    fn unavailable_position_value_is_not_a_total_loss() {
        let round = round(vec![row("buy", 100, "a", 1000.0, 10.0, None, 1)], None).unwrap();
        assert!(round.open_card(200, None, Some(1000.0)).is_err());
        assert!(round.open_card(200, Some(0.012), None).is_err());
        assert_eq!(
            round.open_card(200, Some(0.0), Some(1000.0)).unwrap().out,
            0.0
        );
    }

    #[test]
    fn pagination_needs_the_requested_rounds_opening_buy() {
        let latest = row("buy", 300, "new", 100.0, 10.0, None, 1);
        assert!(!history_complete(
            std::slice::from_ref(&latest),
            Some("old-sell")
        ));
        assert!(history_complete(std::slice::from_ref(&latest), None));
        let mut rows = vec![row("sell", 200, "old-sell", 100.0, 30.0, None, 1), latest];
        assert!(!history_complete(&rows, Some("old-sell")));
        rows.insert(0, row("buy", 100, "old-buy", 100.0, 10.0, None, 1));
        assert!(history_complete(&rows, Some("old-sell")));
    }
}

//! Exercise the card tool through the SDK and its recorded provider boundary.
use aomi_sdk::testing::{TestCtxBuilder, run_tool};
use hoodit::runtime::{GMGN_KEY, HooditApp};
use hoodit::tools::CardTool;
use hoodit::view::{MAX_REPLY, size};
use serde_json::{Value, json};
use std::collections::BTreeMap;

const WALLET: &str = "0x1111111111111111111111111111111111111111";
const TOKEN: &str = "0x2222222222222222222222222222222222222222";
const SELL: &str = "0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";

fn activity(kind: &str, ts: i64, tx: &str, cost: f64) -> Value {
    json!({
        "event_type": kind, "timestamp": ts, "tx_hash": tx,
        "token": {"address": TOKEN, "symbol": "TADA"},
        "token_amount": "100", "cost_usd": cost,
        "is_open_or_close": 1,
    })
}

fn key(cursor: Option<&str>) -> String {
    let tail = cursor.map(|c| format!("&cursor={c}")).unwrap_or_default();
    format!(
        "gmgn:/v1/user/wallet_activity?chain=robinhood&wallet_address={WALLET}&token_address={TOKEN}&limit=50{tail}"
    )
}

fn app() -> HooditApp {
    HooditApp::replaying(BTreeMap::from([(
        key(None),
        json!({"activities": [activity("sell", 200, SELL, 20.0), activity("buy", 100, "buy", 10.0)]}),
    )]))
}

fn call(app: &HooditApp, session: &str, args: Value) -> Value {
    let ctx = TestCtxBuilder::new("hoodit_card")
        .session_id(session)
        .secret(GMGN_KEY, "recorded")
        .build();
    let out = run_tool::<CardTool>(app, args, ctx).unwrap().value;
    assert!(size(&out) <= MAX_REPLY, "{out}");
    out
}

fn new_card(app: &HooditApp, session: &str) -> Value {
    call(
        app,
        session,
        json!({"token": TOKEN, "wallet": WALLET, "style": "receipt"}),
    )
}

fn check_photo(out: &Value) {
    assert_eq!(out["status"], "ok", "{out}");
    let path = out["image_path"].as_str().unwrap();
    assert!(std::path::Path::new(path).is_absolute());
    let png = std::fs::read(path).unwrap();
    assert_eq!(&png[..8], b"\x89PNG\r\n\x1a\n");
    assert_eq!(u32::from_be_bytes(png[16..20].try_into().unwrap()), 1080);
    assert_eq!(u32::from_be_bytes(png[20..24].try_into().unwrap()), 1080);
    assert_eq!(out["controls"].as_array().unwrap().len(), 2);
    assert_eq!(out["controls"][0]["action"], "say");
    std::fs::remove_file(path).unwrap();
}

#[test]
fn photo_and_redraw_keep_frozen_figures_and_the_requested_look() {
    let app = app();
    let original = new_card(&app, "first");
    check_photo(&original);
    assert_eq!(original["card"]["profit"], "+$10.00");
    let redraw = call(
        &app,
        "first",
        json!({"redraw": original["card_id"], "big": "mult"}),
    );
    check_photo(&redraw);
    assert_eq!(redraw["card_id"], original["card_id"]);
    assert_eq!(redraw["card"], original["card"]);
    assert_eq!(redraw["style_used"], "Receipt");
    assert_eq!(redraw["big"], "mult");
    assert_ne!(redraw["image_path"], original["image_path"]);

    let shuffled = call(
        &app,
        "first",
        json!({"redraw": original["card_id"], "another_style": true}),
    );
    check_photo(&shuffled);
    assert_ne!(shuffled["style_used"], "Receipt");
    assert_eq!(shuffled["big"], "mult");
    assert_eq!(shuffled["card"], original["card"]);
}

#[test]
fn redraws_are_independent_and_scoped_to_the_chat() {
    let app = app();
    let original = new_card(&app, "first");
    check_photo(&original);
    let other = new_card(&app, "second");
    check_photo(&other);
    assert_ne!(original["card_id"], other["card_id"]);
    let denied = call(&app, "second", json!({"redraw": original["card_id"]}));
    assert_eq!(denied["error"]["code"], "NOT_FOUND");
    assert!(denied.get("image_path").is_none());

    let another = new_card(&app, "first");
    check_photo(&another);
    assert_ne!(original["card_id"], another["card_id"]);
}

#[test]
fn older_sell_is_found_beyond_the_latest_opening_buy() {
    let app = HooditApp::replaying(BTreeMap::from([
        (
            key(None),
            json!({"activities": [activity("buy", 300, "new-buy", 50.0)], "next": "older"}),
        ),
        (
            key(Some("older")),
            json!({"activities": [activity("sell", 200, SELL, 20.0), activity("buy", 100, "old-buy", 10.0)]}),
        ),
    ]));
    let out = call(
        &app,
        "history",
        json!({"token": TOKEN, "wallet": WALLET, "tx_hash": SELL}),
    );
    check_photo(&out);
    assert_eq!(out["card"]["state"], "closed");
    assert_eq!(out["card"]["profit"], "+$10.00");
}

#[test]
fn missing_market_value_returns_no_data_instead_of_a_loss_image() {
    let app = HooditApp::replaying(BTreeMap::from([(
        key(None),
        json!({"activities": [activity("buy", 100, "buy", 10.0)]}),
    )]));
    let out = new_card(&app, "no-price");
    assert_eq!(out["error"]["code"], "NO_DATA");
    assert!(out.get("image_path").is_none());
}

#[test]
fn invalid_transaction_hash_is_rejected_before_fetching() {
    let out = call(
        &app(),
        "bad-hash",
        json!({"token": TOKEN, "wallet": WALLET, "tx_hash": "🚀🚀🚀🚀"}),
    );
    assert_eq!(out["error"]["code"], "INVALID_ARGUMENT");
}

#[test]
fn a_buy_and_sell_in_the_same_second_remain_in_chronological_order() {
    let app = HooditApp::replaying(BTreeMap::from([
        (
            key(None),
            json!({"activities": [activity("sell", 100, SELL, 20.0)], "next": "older"}),
        ),
        (
            key(Some("older")),
            json!({"activities": [activity("buy", 100, "buy", 10.0)]}),
        ),
    ]));
    let out = new_card(&app, "same-second");
    check_photo(&out);
    assert_eq!(out["card"]["state"], "closed");
    assert_eq!(out["card"]["profit"], "+$10.00");
}

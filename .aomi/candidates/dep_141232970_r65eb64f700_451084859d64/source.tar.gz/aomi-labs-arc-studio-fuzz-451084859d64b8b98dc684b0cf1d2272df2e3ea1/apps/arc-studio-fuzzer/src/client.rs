use std::collections::{BTreeSet, HashMap};
use std::sync::{Arc, Mutex, MutexGuard};
use std::time::Instant;

use aomi_sdk::schemars::JsonSchema;
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};

use crate::abi::ContractAbi;
use crate::campaign::{CampaignCheckpoint, FuzzCampaign, FuzzRoundArgs, FuzzStartArgs};
use crate::plan::{FuzzContract, FuzzDeployment, ProtocolContract};

#[derive(Clone, Default)]
pub(crate) struct ArcStudioFuzzerApp {
    sessions: Arc<Mutex<Sessions>>,
}

impl ArcStudioFuzzerApp {
    pub(crate) fn sessions(&self) -> MutexGuard<'_, Sessions> {
        self.sessions
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
    }
}

pub(crate) struct Session {
    pub contract: FuzzContract,
    /// Kept so `arc_source` can serve slices without another download.
    pub source_code: String,
    pub campaign: Option<FuzzCampaign>,
    pub checkpoint: SessionCheckpoint,
    snapshot_path: Option<String>,
    persisted: Option<Value>,
    revision: u64,
    touched: Instant,
}

impl Session {
    const MAX_SOURCE_SLICE: usize = 200;

    /// Numbered source lines `from_line..=to_line`, capped per call.
    pub fn source(&self, args: SourceArgs) -> Result<Value, String> {
        if args.from_line == 0 || args.to_line < args.from_line {
            return Err("from_line must be at least 1 and no greater than to_line".into());
        }
        let total = self.source_code.lines().count();
        let to = args
            .to_line
            .min(args.from_line + Self::MAX_SOURCE_SLICE - 1)
            .min(total);
        let source = self
            .source_code
            .lines()
            .enumerate()
            .skip(args.from_line - 1)
            .take((to + 1).saturating_sub(args.from_line))
            .map(|(index, line)| format!("{:>5}  {line}", index + 1))
            .collect::<Vec<_>>()
            .join("\n");
        Ok(json!({
            "from_line": args.from_line,
            "to_line": to,
            "total_lines": total,
            "source": source,
        }))
    }
}

/// Per-chat-session state. Bounded: a session the model never closes is
/// evicted once newer sessions need the room.
#[derive(Default)]
pub(crate) struct Sessions(HashMap<String, Session>);

impl Sessions {
    const MAX: usize = 64;

    /// Start (or restart) a session with a new compiler artifact.
    pub fn open(&mut self, id: String, artifact: CompilerArtifact) {
        if !self.0.contains_key(&id) && self.0.len() >= Self::MAX {
            let oldest = self
                .0
                .iter()
                .min_by_key(|(_, session)| session.touched)
                .map(|(id, _)| id.clone());
            if let Some(oldest) = oldest {
                self.0.remove(&oldest);
            }
        }
        self.0.insert(
            id,
            Session {
                checkpoint: SessionCheckpoint {
                    contract: artifact.contract.clone(),
                    source_code: artifact.source_code.clone(),
                    start: None,
                    rounds: Vec::new(),
                },
                snapshot_path: artifact.snapshot_path,
                persisted: None,
                revision: 0,
                contract: artifact.contract,
                source_code: artifact.source_code,
                campaign: None,
                touched: Instant::now(),
            },
        );
    }

    pub fn get_mut(&mut self, id: &str) -> Result<&mut Session, String> {
        let session = self.0.get_mut(id).ok_or_else(|| {
            "no compiler artifact for this session; call arc_map_attack_surface first".to_string()
        })?;
        session.touched = Instant::now();
        Ok(session)
    }

    pub fn close(&mut self, id: &str) -> bool {
        self.0.remove(id).is_some()
    }
}

#[derive(Debug, Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub(crate) struct MapAttackSurfaceArgs {
    /// HTTPS link to the compiled artifact, issued by the Arc Studio fuzz site.
    /// Preferred: the app downloads the source, ABI, and runtime bytecode itself,
    /// so they never pass through the conversation. When set, leave
    /// `source_code` and `contract` null.
    pub artifact_url: Option<String>,
    /// Complete Solidity source, only when no `artifact_url` was given.
    pub source_code: Option<String>,
    /// The compiler artifact, only when no `artifact_url` was given.
    pub contract: Option<FuzzContract>,
}

#[derive(Debug, Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub(crate) struct SourceArgs {
    /// First line to read, 1-based.
    pub from_line: usize,
    /// Last line to read, inclusive. At most 200 lines come back per call.
    pub to_line: usize,
}

/// Source plus compiler artifact for one fuzz session.
pub(crate) struct CompilerArtifact {
    pub source_code: String,
    pub contract: FuzzContract,
    /// Downloaded rather than inlined, so the model has not seen the source yet.
    pub downloaded: bool,
    /// Private object path of a pinned app snapshot, if downloaded from Supabase.
    pub snapshot_path: Option<String>,
}

#[derive(Deserialize)]
struct Download {
    name: String,
    source_code: String,
    abi: String,
    deployed_bytecode: String,
    #[serde(default)]
    deployment: Option<FuzzDeployment>,
    #[serde(default)]
    protocol: Vec<ProtocolContract>,
}

impl CompilerArtifact {
    fn valid_snapshot_path(path: &str) -> bool {
        let parts: Vec<&str> = path.split('/').collect();
        parts.len() == 3
            && parts[0].len() == 64
            && parts[0].bytes().all(|b| b.is_ascii_hexdigit())
            && parts[1].len() == 36
            && parts[1].bytes().all(|b| b.is_ascii_hexdigit() || b == b'-')
            && parts[2]
                .strip_suffix(".json")
                .is_some_and(|hash| hash.len() == 64 && hash.bytes().all(|b| b.is_ascii_hexdigit()))
    }

    fn decode(body: &[u8], snapshot_path: Option<String>) -> Result<Self, String> {
        let download: Download =
            serde_json::from_slice(body).map_err(|e| format!("artifact is not valid JSON: {e}"))?;
        Ok(Self {
            source_code: download.source_code,
            contract: FuzzContract {
                name: download.name,
                abi: download.abi,
                deployed_bytecode: download.deployed_bytecode,
                deployment: download.deployment,
                protocol: download.protocol,
            },
            downloaded: true,
            snapshot_path,
        })
    }

    fn restore_snapshot(ctx: &aomi_sdk::DynToolCallCtx, path: &str) -> Result<Self, String> {
        if !Self::valid_snapshot_path(path) {
            return Err("saved snapshot path is invalid".into());
        }
        let parts: Vec<&str> = path.split('/').collect();
        let origin = ctx.secrets.get("SUPABASE_SNAPSHOT_URL").ok_or(
            "snapshot store URL is unavailable; retry after app configuration is restored",
        )?;
        let key = ctx
            .secrets
            .get("SUPABASE_SNAPSHOT_SERVICE_ROLE_KEY")
            .ok_or("snapshot store credential is unavailable; retry after app configuration is restored")?;
        let url = reqwest::Url::parse(origin).map_err(|_| "snapshot store URL is invalid")?;
        if url.scheme() != "https"
            || url.path() != "/"
            || url.query().is_some()
            || url.fragment().is_some()
        {
            return Err("snapshot store URL must be an HTTPS origin".into());
        }
        let client = reqwest::blocking::Client::builder()
            .timeout(std::time::Duration::from_secs(20))
            .redirect(reqwest::redirect::Policy::none())
            .build()
            .map_err(|e| format!("snapshot client: {e}"))?;
        let mut request = client
            .get(format!(
                "{origin}/storage/v1/object/authenticated/arc-snapshots/{path}"
            ))
            .header("apikey", key);
        if !key.starts_with("sb_secret_") {
            request = request.bearer_auth(key);
        }
        let response = request
            .send()
            .map_err(|e| format!("saved snapshot unavailable: {e}"))?;
        if !response.status().is_success() {
            return Err(format!(
                "saved snapshot unavailable: HTTP {}",
                response.status()
            ));
        }
        let mut body = Vec::new();
        std::io::Read::read_to_end(
            &mut std::io::Read::take(response, MapAttackSurfaceArgs::MAX_ARTIFACT_BYTES + 1),
            &mut body,
        )
        .map_err(|e| format!("saved snapshot unavailable: {e}"))?;
        if body.len() as u64 > MapAttackSurfaceArgs::MAX_ARTIFACT_BYTES {
            return Err("saved snapshot exceeds 4 MB".into());
        }
        let expected = parts[2].trim_end_matches(".json");
        if format!("{:x}", Sha256::digest(&body)) != expected {
            return Err("saved snapshot content hash mismatch".into());
        }
        Self::decode(&body, Some(path.to_owned()))
    }
}

impl MapAttackSurfaceArgs {
    /// The only origin allowed to serve artifacts: the fuzz site's production
    /// domain, matched exactly, so no lookalike or preview host is admitted.
    /// A local build may set `ARC_FUZZ_ARTIFACT_ORIGIN` at compile time to
    /// test against a local site; release builds never do.
    const ARTIFACT_ORIGIN: &'static str = match option_env!("ARC_FUZZ_ARTIFACT_ORIGIN") {
        Some(origin) => origin,
        None => "https://fuzzer.aomi.dev",
    };
    const MAX_ARTIFACT_BYTES: u64 = 4 * 1024 * 1024;

    pub fn artifact(self, ctx: &aomi_sdk::DynToolCallCtx) -> Result<CompilerArtifact, String> {
        let Some(url) = self.artifact_url else {
            return Ok(CompilerArtifact {
                source_code: self
                    .source_code
                    .ok_or("source_code is required without artifact_url")?,
                contract: self
                    .contract
                    .ok_or("contract is required without artifact_url")?,
                downloaded: false,
                snapshot_path: None,
            });
        };
        let url = reqwest::Url::parse(&url).map_err(|_| "artifact_url is not a valid URL")?;
        let allowed = reqwest::Url::parse(Self::ARTIFACT_ORIGIN).expect("valid artifact origin");
        let snapshot_origin = ctx
            .secrets
            .get("SUPABASE_SNAPSHOT_URL")
            .and_then(|value| reqwest::Url::parse(value).ok());
        let snapshot_path = snapshot_origin.as_ref().and_then(|origin| {
            let path = url
                .path()
                .strip_prefix("/storage/v1/object/sign/arc-snapshots/")?;
            (origin.scheme() == "https"
                && origin.path() == "/"
                && url.origin() == origin.origin()
                && CompilerArtifact::valid_snapshot_path(path)
                && url.query_pairs().any(|(name, _)| name == "token"))
            .then(|| path.to_owned())
        });
        if (url.origin() != allowed.origin() && snapshot_path.is_none())
            || !url.username().is_empty()
            || url.password().is_some()
        {
            return Err(format!(
                "artifact_url must be {}/... with no credentials",
                Self::ARTIFACT_ORIGIN
            ));
        }

        let response = reqwest::blocking::Client::builder()
            .timeout(std::time::Duration::from_secs(20))
            .redirect(reqwest::redirect::Policy::none())
            .build()
            .map_err(|e| format!("artifact client: {e}"))?
            .get(url)
            .send()
            .map_err(|e| format!("artifact download failed: {e}"))?;
        if !response.status().is_success() {
            let status = response.status();
            let detail = response.text().unwrap_or_default();
            return Err(format!(
                "artifact download returned {status}: {}",
                detail.chars().take(300).collect::<String>()
            ));
        }
        if response
            .content_length()
            .is_some_and(|length| length > Self::MAX_ARTIFACT_BYTES)
        {
            return Err("artifact exceeds 4 MB".into());
        }
        // Bounded read: an oversized or unannounced body is never buffered past the cap.
        let mut body = Vec::new();
        std::io::Read::read_to_end(
            &mut std::io::Read::take(response, Self::MAX_ARTIFACT_BYTES + 1),
            &mut body,
        )
        .map_err(|e| format!("artifact download failed: {e}"))?;
        if body.len() as u64 > Self::MAX_ARTIFACT_BYTES {
            return Err("artifact exceeds 4 MB".into());
        }
        if let Some(path) = &snapshot_path {
            let expected = path
                .rsplit('/')
                .next()
                .and_then(|name| name.strip_suffix(".json"))
                .ok_or("snapshot object name is invalid")?;
            let actual = format!("{:x}", Sha256::digest(&body));
            if actual != expected {
                return Err("snapshot content hash does not match its object path".into());
            }
        }
        CompilerArtifact::decode(&body, snapshot_path)
    }
}

#[derive(Debug, Serialize)]
struct EntryPoint {
    signature: String,
    mutability: alloy_json_abi::StateMutability,
    outputs: Vec<String>,
}

#[derive(Debug, Serialize)]
struct ProtocolSurface {
    name: String,
    address: String,
    writable: BTreeSet<String>,
    observers: Vec<String>,
}

#[derive(Debug, Serialize)]
pub(crate) struct AttackSurface {
    contract: String,
    /// The downloaded source, when it is short; read longer source in slices
    /// with `arc_source`.
    #[serde(skip_serializing_if = "Option::is_none")]
    source_code: Option<String>,
    source_lines: usize,
    /// The rest of the protocol: each contract's address and callable
    /// surface. Target one with a call's `contract` field.
    #[serde(skip_serializing_if = "Vec::is_empty")]
    protocol: Vec<ProtocolSurface>,
    /// Where the code already sits: a live deployment, or a harness install.
    #[serde(skip_serializing_if = "Option::is_none")]
    deployment: Option<FuzzDeployment>,
    entry_points: Vec<EntryPoint>,
    state_observers: Vec<String>,
    events: Vec<String>,
    custom_errors: Vec<String>,
    attack_hypothesis_seeds: BTreeSet<&'static str>,
    agent_next_action: &'static str,
}

impl AttackSurface {
    /// Function-name fragments and the attack family they suggest.
    const NAME_SEEDS: [(&'static [&'static str], &'static str); 4] = [
        (
            &["withdraw", "redeem", "claim", "transfer", "sweep", "drain"],
            "Unauthorized or over-sized value extraction across user roles",
        ),
        (
            &["deposit", "mint", "stake", "borrow", "repay"],
            "Cross-call accounting and ordering around asset/share creation",
        ),
        (
            &[
                "owner",
                "admin",
                "role",
                "pause",
                "upgrade",
                "initialize",
                "set",
            ],
            "Privilege escalation, unsafe initialization, or role confusion",
        ),
        (
            &["execute", "call", "hook", "callback", "flash"],
            "Arbitrary call, callback ordering, or reentrancy reachability",
        ),
    ];

    /// Source fragments and the attack family they suggest.
    const SOURCE_SEEDS: [(&'static str, &'static str); 9] = [
        (
            "delegatecall",
            "Delegatecall target/control and storage-context takeover",
        ),
        (
            "selfdestruct",
            "Destruction reachability and forced value movement",
        ),
        (
            "tx.origin",
            "tx.origin authorization confusion through an intermediary",
        ),
        (
            "ecrecover",
            "Signature replay, malleability, nonce, and domain separation",
        ),
        (
            "block.timestamp",
            "Timestamp-dependent state transitions at boundary values",
        ),
        (
            ".call{",
            "External callback/reentrancy before state finalization",
        ),
        (
            "assembly",
            "Assembly memory/storage assumptions and arbitrary slot access",
        ),
        (
            "initializer",
            "Initialization ordering and uninitialized takeover",
        ),
        (
            "upgrade",
            "Upgrade authorization and implementation-slot takeover",
        ),
    ];

    /// Downloaded source up to this many lines comes back whole.
    const INLINE_SOURCE_LINES: usize = 300;

    const PAYABLE_SEED: &'static str =
        "Native-USDC accounting: vary msg.value across callers and ordering";

    pub fn map(artifact: &CompilerArtifact) -> Result<Self, String> {
        if artifact.contract.name.trim().is_empty() {
            return Err("contract name is required".into());
        }
        if artifact.source_code.trim().is_empty() {
            return Err("complete source_code is required for agentic analysis".into());
        }
        artifact.contract.runtime()?;
        let abi = ContractAbi::parse(&artifact.contract.abi)?;

        let mut seeds = BTreeSet::new();
        let mut entry_points = Vec::new();
        let mut observers = Vec::new();
        for function in abi.functions() {
            let signature = function.signature();
            if ContractAbi::read_only(function) {
                observers.push(signature.clone());
            } else {
                let name = function.name.to_ascii_lowercase();
                seeds.extend(
                    Self::NAME_SEEDS
                        .iter()
                        .filter(|(parts, _)| parts.iter().any(|part| name.contains(part)))
                        .map(|(_, seed)| *seed),
                );
            }
            if function.state_mutability == alloy_json_abi::StateMutability::Payable {
                seeds.insert(Self::PAYABLE_SEED);
            }
            entry_points.push(EntryPoint {
                signature,
                mutability: function.state_mutability,
                outputs: function
                    .outputs
                    .iter()
                    .map(|output| output.selector_type().into_owned())
                    .collect(),
            });
        }
        let source = artifact.source_code.to_ascii_lowercase();
        seeds.extend(
            Self::SOURCE_SEEDS
                .iter()
                .filter(|(needle, _)| source.contains(needle))
                .map(|(_, seed)| *seed),
        );

        Ok(Self {
            contract: artifact.contract.name.clone(),
            source_code: (artifact.downloaded
                && artifact.source_code.lines().count() <= Self::INLINE_SOURCE_LINES)
                .then(|| artifact.source_code.clone()),
            source_lines: artifact.source_code.lines().count(),
            protocol: artifact
                .contract
                .protocol
                .iter()
                .map(|contract| {
                    let abi = ContractAbi::parse(&contract.abi)
                        .map_err(|e| format!("protocol contract `{}`: {e}", contract.name))?;
                    Ok(ProtocolSurface {
                        name: contract.name.clone(),
                        address: contract.address.clone(),
                        writable: abi.writable(),
                        observers: abi
                            .functions()
                            .filter(|function| ContractAbi::read_only(function))
                            .map(|function| function.signature())
                            .collect(),
                    })
                })
                .collect::<Result<_, String>>()?,
            deployment: artifact.contract.deployment.clone(),
            entry_points,
            state_observers: observers,
            events: abi
                .inner()
                .events()
                .map(|event| event.name.clone())
                .collect(),
            custom_errors: abi
                .inner()
                .errors()
                .map(|error| error.name.clone())
                .collect(),
            attack_hypothesis_seeds: seeds,
            agent_next_action: "Read the source (arc_source for slices when source_code is absent), turn the threat model into executable properties and ABI-level action templates, then run arc_fuzz_start and arc_fuzz_round until the campaign completes. These seeds are prompts, not findings.",
        })
    }
}

/// A deterministic journal of accepted campaign transitions. The host saves it
/// outside model history and injects it when another worker handles this thread.
#[derive(Clone, Serialize, Deserialize)]
pub(crate) struct SessionCheckpoint {
    pub contract: FuzzContract,
    pub source_code: String,
    pub start: Option<FuzzStartArgs>,
    pub rounds: Vec<FuzzRoundArgs>,
}

#[derive(Serialize, Deserialize)]
struct InlineArtifact {
    contract: FuzzContract,
    source_code: String,
}

/// Host-owned app_state value. The canonical Aomi thread snapshot remains the
/// authority; the app Supabase project stores only immutable build artifacts.
#[derive(Serialize, Deserialize)]
struct VersionedCheckpoint {
    version: u8,
    revision: u64,
    snapshot_path: Option<String>,
    inline_artifact: Option<InlineArtifact>,
    chain_id: Option<u64>,
    start: Option<FuzzStartArgs>,
    campaign: Option<CampaignCheckpoint>,
}

impl Sessions {
    pub fn restore(&mut self, ctx: &aomi_sdk::DynToolCallCtx) -> Result<(), String> {
        let Some(value) = ctx.state_attributes.get("app_state") else {
            return Ok(());
        };
        if value.is_null() {
            self.close(&ctx.session_id);
            return Ok(());
        }
        if self
            .0
            .get(&ctx.session_id)
            .is_some_and(|session| session.persisted.as_ref() == Some(value))
        {
            return Ok(());
        }
        if value.get("version").is_some() {
            let saved: VersionedCheckpoint = serde_json::from_value(value.clone())
                .map_err(|e| format!("campaign checkpoint: {e}"))?;
            if saved.version != 2 {
                return Err(format!(
                    "unsupported campaign checkpoint version {}",
                    saved.version
                ));
            }
            let artifact = match (saved.snapshot_path, saved.inline_artifact) {
                (Some(path), None) => CompilerArtifact::restore_snapshot(ctx, &path)?,
                (None, Some(inline)) => CompilerArtifact {
                    contract: inline.contract,
                    source_code: inline.source_code,
                    downloaded: true,
                    snapshot_path: None,
                },
                _ => return Err("campaign checkpoint has no unique artifact".into()),
            };
            self.open(ctx.session_id.clone(), artifact);
            let session = self.get_mut(&ctx.session_id)?;
            let start = saved.start.or_else(|| {
                saved
                    .chain_id
                    .zip(saved.campaign.as_ref())
                    .map(|(chain_id, state)| state.start_args(chain_id))
            });
            session.checkpoint.start = start.clone();
            if let (Some(start), Some(state)) = (start, saved.campaign) {
                session.campaign = Some(FuzzCampaign::restore(
                    session.contract.clone(),
                    start,
                    state,
                )?);
            }
            session.revision = saved.revision;
            session.persisted = Some(value.clone());
            return Ok(());
        }
        let checkpoint: SessionCheckpoint = serde_json::from_value(value.clone())
            .map_err(|e| format!("campaign checkpoint: {e}"))?;
        self.open(
            ctx.session_id.clone(),
            CompilerArtifact {
                contract: checkpoint.contract.clone(),
                source_code: checkpoint.source_code.clone(),
                downloaded: true,
                snapshot_path: None,
            },
        );
        let session = self.get_mut(&ctx.session_id)?;
        if let Some(start) = checkpoint.start.clone() {
            let mut campaign = FuzzCampaign::new(checkpoint.contract.clone(), start)?;
            campaign.start();
            for round in &checkpoint.rounds {
                campaign.round(round.clone())?;
            }
            session.campaign = Some(campaign);
        }
        session.checkpoint = checkpoint;
        session.persisted = Some(value.clone());
        Ok(())
    }

    pub fn output(&mut self, id: &str, mut result: Value) -> Result<Value, String> {
        let session = self.get_mut(id)?;
        let saved = VersionedCheckpoint {
            version: 2,
            revision: session.revision,
            snapshot_path: session.snapshot_path.clone(),
            inline_artifact: session.snapshot_path.is_none().then(|| InlineArtifact {
                contract: session.contract.clone(),
                source_code: session.source_code.clone(),
            }),
            chain_id: session.campaign.as_ref().and_then(|_| {
                session
                    .checkpoint
                    .start
                    .as_ref()
                    .map(|start| start.chain_id)
            }),
            start: session
                .campaign
                .is_none()
                .then(|| session.checkpoint.start.clone())
                .flatten(),
            campaign: session.campaign.as_ref().map(FuzzCampaign::checkpoint),
        };
        let mut value = serde_json::to_value(saved).map_err(|e| e.to_string())?;
        if session.persisted.as_ref() != Some(&value) {
            session.revision += 1;
            value["revision"] = json!(session.revision);
        }
        session.persisted = Some(value.clone());
        result["__aomi_app_state"] = value;
        Ok(result)
    }
}

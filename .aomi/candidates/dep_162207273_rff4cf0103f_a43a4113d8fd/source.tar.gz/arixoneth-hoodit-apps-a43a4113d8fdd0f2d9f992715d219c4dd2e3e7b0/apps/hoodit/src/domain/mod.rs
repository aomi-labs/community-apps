//! Hoodit's knowledge as typed structs and rules: what a coin is, where it
//! is in its life, who is buying, who holds it, and whether a size gets
//! back out. Providers supply raw reads; view turns these into replies.
pub mod amount;
pub mod boards;
pub mod chart;
pub mod exit;
pub mod find;
pub mod holders;
pub mod market;
pub mod pons;
pub mod signals;
pub mod token;
pub mod trades;
pub mod wallet;

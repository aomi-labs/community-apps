//! Every GraphQL document Hoodit sends to Codex, in one place. Tokens are
//! `address:4663` ids on Robinhood Chain.
use crate::providers::CHAIN_ID;

pub fn id(token: &str) -> String {
    format!("{token}:{CHAIN_ID}")
}

/// Fields read from `filterTokens` for the fallback card and price reads.
const TOKEN_FIELDS: &str = "createdAt priceUSD marketCap liquidity volume24 change1 change4 \
change24 buyVolume1 sellVolume1 buyVolume24 sellVolume24 holders \
devHeldPercentage sniperHeldPercentage athPrice lastTransaction \
pair { address token0 token1 } \
token { address symbol name createdAt creatorAddress info { totalSupply } \
launchpad { launchpadName completed migrated } }";

pub fn tokens(tokens: &[String]) -> String {
    let ids: Vec<String> = tokens.iter().map(|t| format!("\"{}\"", id(t))).collect();
    format!(
        "{{ s: filterTokens(tokens: [{}], limit: {}) {{ results {{ {TOKEN_FIELDS} }} }} }}",
        ids.join(", "),
        tokens.len()
    )
}

/// Tokens matching a ticker or name, most holders first.
pub fn search(phrase: &str) -> String {
    let phrase: String = phrase
        .chars()
        .filter(|c| c.is_alphanumeric() || " .-_".contains(*c))
        .take(64)
        .collect();
    format!(
        "{{ s: filterTokens(phrase: \"{phrase}\", filters: {{network: [{CHAIN_ID}]}}, rankings: [{{attribute: holders, direction: DESC}}], limit: 8) {{ results {{ {TOKEN_FIELDS} }} }} }}"
    )
}

/// The 1h trending board; only used while GMGN is unavailable.
pub fn trending(limit: u32) -> String {
    format!(
        "{{ s: filterTokens(filters: {{network: [{CHAIN_ID}], volume24: {{gte: 5000}}, liquidity: {{gte: 5000}}}}, rankings: [{{attribute: trendingScore1, direction: DESC}}], limit: {limit}) {{ results {{ {TOKEN_FIELDS} }} }} }}"
    )
}

pub fn holders(token: &str, limit: u32) -> String {
    format!(
        "{{ h: holders(input: {{tokenId: \"{}\", limit: {limit}}}) {{ count items {{ address shiftedBalance balanceUsd firstHeldTimestamp }} }} \
s: filterTokens(tokens: [\"{}\"], limit: 1) {{ results {{ priceUSD pair {{ address }} token {{ symbol info {{ totalSupply }} }} }} }} }}",
        id(token),
        id(token)
    )
}

/// The token's busiest pools with per-pool flow. Codex's token-level flow
/// covers only the deepest pool.
pub fn pools(token: &str, limit: u32) -> String {
    format!(
        "{{ p: filterPairs(filters: {{network: [{CHAIN_ID}], tokenAddress: \"{token}\"}}, rankings: [{{attribute: volumeUSD24, direction: DESC}}], limit: {limit}) {{ results {{ \
buyVolumeUSD1 sellVolumeUSD1 uniqueBuys1 uniqueSells1 quoteToken pair {{ address token0 token1 }} }} }} }}"
    )
}

/// Recent trades plus recent trades of at least `big` USD, per pool.
pub fn events(pools: &[String], buys: bool, sells: bool, min_usd: f64, big_usd: f64) -> String {
    let sides = match (buys, sells) {
        (true, false) => "[Buy]",
        (false, true) => "[Sell]",
        _ => "[Buy, Sell]",
    };
    let one = |alias: String, pool: &str, limit: u32, floor: f64| {
        let floor = if floor > 0.0 {
            format!(", priceUsdTotal: {{gte: {floor}}}")
        } else {
            String::new()
        };
        format!(
            "{alias}: getTokenEvents(limit: {limit}, query: {{address: \"{pool}\", networkId: {CHAIN_ID}, eventDisplayType: {sides}{floor}}}) {{ items {{ maker timestamp eventDisplayType transactionHash walletLabels data {{ ... on SwapEventData {{ priceUsdTotal }} }} }} }}"
        )
    };
    let aliases: Vec<String> = pools
        .iter()
        .enumerate()
        .flat_map(|(i, pool)| {
            [
                one(format!("e{i}"), pool, 60, min_usd),
                one(format!("b{i}"), pool, 20, big_usd),
            ]
        })
        .collect();
    format!("{{ {} }}", aliases.join(" "))
}

/// Main bars plus, optionally, a wider context range as closes only.
pub fn bars(token: &str, main: &BarSpan, context: Option<&BarSpan>) -> String {
    let mut query = format!(
        "{{ m: getTokenBars(symbol: \"{}\", from: {}, to: {}, resolution: \"{}\", removeEmptyBars: true, countback: {}) {{ t o h l c volume buyVolume sellVolume }}",
        id(token),
        main.from,
        main.to,
        main.resolution,
        main.bars
    );
    if let Some(x) = context {
        // Empty bars kept so the closes are evenly spaced.
        query.push_str(&format!(
            " x: getTokenBars(symbol: \"{}\", from: {}, to: {}, resolution: \"{}\", removeEmptyBars: false) {{ t c }}",
            id(token),
            x.from,
            x.to,
            x.resolution
        ));
    }
    query.push_str(" }");
    query
}

/// A bar request: Codex resolution string, unix-second bounds, bar count.
#[derive(Clone, Debug, PartialEq)]
pub struct BarSpan {
    pub resolution: &'static str,
    pub from: i64,
    pub to: i64,
    pub bars: i64,
}

pub fn balances(wallet: &str) -> String {
    format!(
        "{{ b: balances(input: {{walletAddress: \"{wallet}\", networks: [{CHAIN_ID}], removeScams: true, limit: 12}}) {{ items {{ tokenAddress shiftedBalance balanceUsd firstHeldTimestamp token {{ symbol }} }} }} }}"
    )
}

use super::{address, run};
use crate::domain::exit::Exits;
use crate::domain::token::{Depth, snapshot};
use crate::runtime::{HooditApp, Lane};
use aomi_sdk::schemars::JsonSchema;
use aomi_sdk::{DynAomiTool, DynToolCallCtx};
use serde::Deserialize;
use serde_json::Value;

#[derive(Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct TokenArgs {
    /// Exact 0x token contract. Resolve tickers with hoodit_find first.
    pub token: String,
}

pub struct Token;

impl DynAomiTool for Token {
    type App = HooditApp;
    type Args = TokenArgs;
    const NAME: &'static str = "hoodit_token";
    const DESCRIPTION: &'static str = "The full card for one Robinhood Chain token: stage and curve, trade support, price, FDV, liquidity, change and buy/sell flow by window, holders and top-10 share, the holder mix (dev, snipers, bundlers, bots, fresh wallets) and how many holders are smart money or KOLs, ATH, the dev, a contract security screen, socials, and exit_check: a small round trip quoted now that catches honeypots. Read it before any opinion on a coin.";

    fn run(app: &HooditApp, args: TokenArgs, ctx: DynToolCallCtx) -> Result<Value, String> {
        run(app, &ctx, Lane::Chat, async |rt, turn| {
            let token = address(&args.token)?;
            // The exit probe runs alongside the reads; it is the only test
            // that catches traps the security screen calls clean.
            let (snap, probe) = tokio::join!(
                snapshot(rt, turn, &token, Depth::Card),
                Exits::new(rt, turn).probe(&token)
            );
            Ok(crate::view::token::card(&snap?, Some(&probe)))
        })
    }
}

//! LI.FI same-chain quotes on Robinhood Chain: the router the host trades
//! through, so a quote here is the best proof a size can get out.
use crate::providers::{CHAIN_ID, num};
use crate::runtime::{Cost, Fail, Request, Runtime, Source, Turn};
use serde_json::Value;
use std::time::Duration;

const URL: &str = "https://li.quest/v1/quote";
const TTL: Duration = Duration::from_secs(20);

#[derive(Debug, Clone, PartialEq)]
pub struct Quote {
    /// Atomic units of the output token.
    pub to_amount: String,
    pub to_amount_min: String,
    pub route: Vec<String>,
    pub fee_usd: Option<f64>,
    pub gas_usd: Option<f64>,
}

#[derive(Clone, Copy)]
pub struct Lifi<'a> {
    rt: &'a Runtime,
    turn: &'a Turn,
}

impl<'a> Lifi<'a> {
    pub fn new(rt: &'a Runtime, turn: &'a Turn) -> Self {
        Self { rt, turn }
    }

    /// A quote for `amount` atomic units. `from` matters: curve sells only
    /// quote from a wallet that holds the token.
    pub async fn quote(
        &self,
        from_token: &str,
        to_token: &str,
        amount: &str,
        from: &str,
        slippage: f64,
    ) -> Result<Quote, Fail> {
        let key = self.turn.key(Source::Lifi).map(str::to_string);
        let request = Request::new(
            Source::Lifi,
            format!("lifi:{from_token}>{to_token}:{amount}:{from}:{slippage}"),
            Cost::Lifi {
                keyed: key.is_some(),
            },
            TTL,
        )
        .live_only();
        let query = vec![
            ("fromChain", CHAIN_ID.to_string()),
            ("toChain", CHAIN_ID.to_string()),
            ("fromToken", from_token.to_string()),
            ("toToken", to_token.to_string()),
            ("fromAmount", amount.to_string()),
            ("fromAddress", from.to_string()),
            ("slippage", slippage.to_string()),
            // LI.FI drops routes above this impact and calls them "no quotes";
            // ask for nearly everything so a terrible exit shows as its loss.
            ("maxPriceImpact", "0.99".to_string()),
            ("integrator", "hoodit".to_string()),
        ];
        let value = self
            .rt
            .fetch(self.turn, request, || async {
                match self.send(&query, key.as_deref()).await {
                    // A rejected key falls back to the keyless allowance.
                    Err(Fail::Unconfigured(_)) if key.is_some() => {
                        let cost = Cost::Lifi { keyed: false };
                        self.rt
                            .gates
                            .admit(cost, self.turn.lane, &self.turn.thread)?;
                        self.send(&query, None).await
                    }
                    other => other,
                }
            })
            .await?;
        parse_quote(&value)
    }

    async fn send(self, query: &[(&str, String)], key: Option<&str>) -> Result<Value, Fail> {
        let mut request = self
            .rt
            .http
            .get(URL)
            .timeout(Duration::from_secs(25))
            .query(query);
        if let Some(key) = key {
            request = request.header("x-lifi-api-key", key);
        }
        let response = request
            .send()
            .await
            .map_err(|_| Fail::unavailable(Source::Lifi, "quote request failed"))?;
        let status = response.status().as_u16();
        let body: Value = response.json().await.unwrap_or(Value::Null);
        match status {
            429 => Err(Fail::RateLimited {
                source: Source::Lifi,
                retry_after_s: 600,
            }),
            401 | 403 => Err(Fail::Unconfigured(Source::Lifi)),
            _ if body.get("estimate").is_some() => Ok(body),
            // "No available quotes" (code 1002) is the only real no-route;
            // other 4xx are bad requests, not traps.
            _ if no_quotes(&body) => Err(Fail::NoRoute(message(&body))),
            400..=499 => Err(Fail::bad(Source::Lifi, message(&body))),
            _ => Err(Fail::unavailable(Source::Lifi, format!("HTTP {status}"))),
        }
    }
}

fn no_quotes(body: &Value) -> bool {
    body["code"].as_i64() == Some(1002)
        || body["message"]
            .as_str()
            .is_some_and(|m| m.to_ascii_lowercase().contains("no available quotes"))
}

fn message(body: &Value) -> String {
    body["message"]
        .as_str()
        .unwrap_or("no route")
        .chars()
        .take(160)
        .collect()
}

fn parse_quote(body: &Value) -> Result<Quote, Fail> {
    let estimate = &body["estimate"];
    let amount = |k: &str| estimate[k].as_str().map(str::to_string);
    let sum = |k: &str| {
        estimate[k].as_array().map(|items| {
            items
                .iter()
                .filter_map(|c| num(&c["amountUSD"]))
                .sum::<f64>()
        })
    };
    let route = body["includedSteps"]
        .as_array()
        .map(|steps| {
            steps
                .iter()
                .filter_map(|s| {
                    s.pointer("/toolDetails/name")
                        .or_else(|| s.get("tool"))
                        .and_then(Value::as_str)
                        .map(str::to_string)
                })
                .collect()
        })
        .unwrap_or_default();
    Ok(Quote {
        to_amount: amount("toAmount")
            .ok_or_else(|| Fail::bad(Source::Lifi, "quote without amount"))?,
        to_amount_min: amount("toAmountMin").unwrap_or_else(|| "0".into()),
        route,
        fee_usd: sum("feeCosts"),
        gas_usd: sum("gasCosts"),
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    #[test]
    fn quotes_parse() {
        let body = json!({
            "estimate": { "toAmount": "123", "toAmountMin": "120",
                "feeCosts": [{ "amountUSD": "0.5" }], "gasCosts": [{ "amountUSD": 0.01 }] },
            "includedSteps": [{ "tool": "uniswap", "toolDetails": { "name": "Uniswap V4" } }]
        });
        let q = parse_quote(&body).unwrap();
        assert_eq!((q.to_amount.as_str(), q.fee_usd), ("123", Some(0.5)));
        assert_eq!(q.route, ["Uniswap V4"]);
        assert!(parse_quote(&json!({})).is_err());
        assert!(no_quotes(
            &json!({ "message": "No available quotes for the requested transfer", "code": 1002 })
        ));
        assert!(!no_quotes(
            &json!({ "message": "/fromAmount must pass validation", "code": 1011 })
        ));
    }
}

//! Codex response shapes, only the fields Hoodit reads. `change*` fields
//! are fractions (0.25 = +25%).
use crate::providers::Num;
use serde::Deserialize;

#[derive(Debug, Default, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct Token {
    pub created_at: Num,
    #[serde(rename = "priceUSD")]
    pub price_usd: Num,
    pub market_cap: Num,
    pub liquidity: Num,
    pub volume24: Num,
    pub change1: Num,
    pub change4: Num,
    pub change24: Num,
    pub buy_volume1: Num,
    pub sell_volume1: Num,
    pub buy_volume24: Num,
    pub sell_volume24: Num,
    pub holders: Num,
    pub dev_held_percentage: Num,
    pub sniper_held_percentage: Num,
    pub ath_price: Num,
    pub last_transaction: Num,
    pub pair: Pair,
    pub token: TokenMeta,
}

#[derive(Debug, Default, Deserialize)]
#[serde(default)]
pub struct Pair {
    pub address: Option<String>,
    pub token0: Option<String>,
    pub token1: Option<String>,
}

#[derive(Debug, Default, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct TokenMeta {
    pub address: String,
    pub symbol: Option<String>,
    pub name: Option<String>,
    pub created_at: Num,
    pub creator_address: Option<String>,
    pub info: TokenInfo,
    pub launchpad: Option<Launchpad>,
}

#[derive(Debug, Default, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct TokenInfo {
    pub total_supply: Num,
}

#[derive(Debug, Default, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct Launchpad {
    pub launchpad_name: Option<String>,
    pub completed: Option<bool>,
    pub migrated: Option<bool>,
}

#[derive(Debug, Default, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct Holder {
    pub address: String,
    pub shifted_balance: Num,
    pub balance_usd: Num,
    pub first_held_timestamp: Num,
}

/// A holder list with the token's price, pool and supply for context.
#[derive(Debug, Default)]
pub struct Holders {
    pub count: Option<f64>,
    pub items: Vec<Holder>,
    pub price_usd: Option<f64>,
    pub pool: Option<String>,
    pub symbol: Option<String>,
    pub supply: Option<f64>,
}

#[derive(Debug, Default, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct Pool {
    /// Which side (`token0`/`token1`) is the coin being traded.
    pub quote_token: Option<String>,
    pub pair: Pair,
    #[serde(rename = "buyVolumeUSD1")]
    pub buy_volume_usd1: Num,
    #[serde(rename = "sellVolumeUSD1")]
    pub sell_volume_usd1: Num,
    pub unique_buys1: Num,
    pub unique_sells1: Num,
}

impl Pool {
    /// The coin this pool trades (Codex's token of interest).
    pub fn traded(&self) -> Option<&str> {
        match self.quote_token.as_deref() {
            Some("token0") => self.pair.token0.as_deref(),
            Some("token1") => self.pair.token1.as_deref(),
            _ => None,
        }
    }
}

#[derive(Debug, Default, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct Event {
    pub maker: String,
    pub timestamp: Num,
    pub event_display_type: String,
    pub transaction_hash: String,
    pub wallet_labels: Vec<String>,
    pub data: EventData,
}

#[derive(Debug, Default, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct EventData {
    pub price_usd_total: Num,
}

/// Bars as parallel arrays, one entry per bar.
#[derive(Debug, Default, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct Bars {
    pub t: Vec<i64>,
    pub o: Vec<Num>,
    pub h: Vec<Num>,
    pub l: Vec<Num>,
    pub c: Vec<Num>,
    pub volume: Vec<Num>,
    pub buy_volume: Vec<Num>,
    pub sell_volume: Vec<Num>,
}

#[derive(Debug, Default, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct Balance {
    pub token_address: String,
    pub shifted_balance: Num,
    pub balance_usd: Num,
    pub first_held_timestamp: Num,
    pub token: BalanceToken,
}

#[derive(Debug, Default, Deserialize)]
#[serde(default)]
pub struct BalanceToken {
    pub symbol: Option<String>,
}

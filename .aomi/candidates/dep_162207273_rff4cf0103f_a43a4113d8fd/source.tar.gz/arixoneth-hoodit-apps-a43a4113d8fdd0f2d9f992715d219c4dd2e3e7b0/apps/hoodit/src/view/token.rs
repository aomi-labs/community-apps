//! Token-shaped replies: the card, the watcher's flat numbers, board rows
//! and search candidates.
use super::{int, label, pct, price, put_span, usd};
use crate::domain::boards::Listing;
use crate::domain::exit::Probe;
use crate::domain::find::Candidate;
use crate::domain::token::{Security, TokenSnapshot, Window, watch_progress};
use serde_json::{Map, Value, json};

fn put(out: &mut Map<String, Value>, key: &str, value: Value) {
    if !value.is_null() {
        out.insert(key.to_string(), value);
    }
}

fn identity(out: &mut Map<String, Value>, s: &TokenSnapshot) {
    put(out, "symbol", label(s.symbol.as_deref(), 20));
    put(out, "token", json!(s.token));
    put(out, "launchpad", json!(s.launchpad));
    put(out, "stage", json!(s.stage));
    put(out, "pair", json!(s.pair.as_ref().map(|p| &p.symbol)));
    put(out, "trade_support", json!(s.trade_support()));
    put_span(out, "age", s.created_at);
}

/// The full card for one token.
pub fn card(s: &TokenSnapshot, probe: Option<&Probe>) -> Value {
    let mut out = Map::new();
    identity(&mut out, s);
    put(&mut out, "name", label(s.name.as_deref(), 40));
    put(&mut out, "price_usd", price(s.price_usd));
    put(&mut out, "fdv_usd", usd(s.fdv_usd));
    put(&mut out, "liquidity_usd", usd(s.liquidity_usd));
    put(&mut out, "volume_24h_usd", usd(s.volume_24h_usd));
    for (w, v) in &s.change_pct {
        put(
            &mut out,
            &format!("change_{}_pct", w.label()),
            pct(Some(*v)),
        );
    }
    for (w, f) in &s.flow {
        if *w == Window::M5 {
            continue;
        }
        let w = w.label();
        put(&mut out, &format!("buy_{w}_usd"), usd(f.buy_usd));
        put(&mut out, &format!("sell_{w}_usd"), usd(f.sell_usd));
        put(&mut out, &format!("buys_{w}"), int(f.buys));
        put(&mut out, &format!("sells_{w}"), int(f.sells));
    }
    holder_fields(&mut out, s);
    put(&mut out, "ath_usd", price(s.ath_usd));
    put(&mut out, "from_ath_pct", from_ath(s));
    if let Some(c) = &s.curve {
        out.insert(
            "curve".into(),
            json!({
                "pct": pct(c.pct),
                "raised": c.raised.map(|r| super::sig(r, 4)),
                "target": super::sig(c.target, 4),
                "pair": c.pair.symbol,
            }),
        );
    } else {
        put(&mut out, "curve_pct", pct(s.curve_pct));
    }
    put(&mut out, "creator_tax_pct", pct(s.creator_tax_pct));
    if let Some(dev) = &s.dev {
        let mut d = Map::new();
        d.insert("wallet".into(), json!(dev.wallet));
        if s.creator.as_deref() == Some(dev.wallet.as_str()) {
            put(&mut d, "sold_out", json!(s.dev_sold_out));
        }
        out.insert("dev".into(), Value::Object(d));
    }
    put_span(&mut out, "last_trade", s.last_trade_at);
    if let Some(sec) = &s.security {
        out.insert("security".into(), security(sec));
    }
    if let Some(p) = probe {
        out.insert(
            "exit_check".into(),
            json!({
                "eth_in": p.eth_in,
                "loss_pct": pct(p.loss_pct),
                "sell": if p.no_sell_route { json!("no_route") } else { Value::Null },
                "result": p.result,
            }),
        );
    }
    let x = s.socials.x();
    let socials = json!({
        "x": x.as_ref().map(|(_, path)| label(Some(path), 60)),
        "x_link": x.as_ref().map(|(kind, _)| kind),
        "x_shared_by_tokens": int(s.socials.x_shared_by_tokens.filter(|n| *n > 1.0)),
        "x_renames": s.socials.x_renames.filter(|n| *n > 0),
        "community_takeover": s.socials.community_takeover.filter(|t| *t),
        "web": label(s.socials.website.as_deref(), 80),
        "tg": label(s.socials.telegram.as_deref(), 60),
    });
    out.insert("socials".into(), socials);
    out.insert(
        "explorer_url".into(),
        json!(format!("https://robin.etherscan.io/token/{}", s.token)),
    );
    Value::Object(out)
}

fn holder_fields(out: &mut Map<String, Value>, s: &TokenSnapshot) {
    put(out, "holders", int(s.holders));
    put(out, "top10_pct", pct(s.top10_pct));
    let m = &s.mix;
    put(out, "dev_pct", pct(m.dev_pct));
    put(out, "dev_team_pct", pct(m.dev_team_pct));
    put(out, "snipers_pct", pct(m.snipers_pct));
    put(out, "bundler_trading_pct", pct(m.bundler_trading_pct));
    put(out, "rat_trading_pct", pct(m.rat_trading_pct));
    put(out, "bot_degen_pct", pct(m.bot_degen_pct));
    put(out, "fresh_wallet_pct", pct(m.fresh_wallet_pct));
    let t = &s.tagged;
    put(out, "smart_wallets", int(t.smart));
    put(out, "kol_wallets", int(t.kol));
    put(out, "sniper_wallets", int(t.snipers));
    put(out, "bundler_wallets", int(t.bundlers));
    put(out, "whale_wallets", int(t.whales));
}

fn from_ath(s: &TokenSnapshot) -> Value {
    match (s.ath_usd, s.price_usd) {
        (Some(a), Some(p)) if a > 0.0 => pct(Some(((p / a).min(1.0) - 1.0) * 100.0)),
        _ => Value::Null,
    }
}

fn security(s: &Security) -> Value {
    let honeypot = match s.honeypot {
        Some(true) => "yes",
        Some(false) => "no",
        None => "unknown",
    };
    json!({
        "honeypot": honeypot,
        "buy_tax_pct": pct(s.buy_tax_pct),
        "sell_tax_pct": pct(s.sell_tax_pct),
        "renounced": s.renounced,
        "open_source": s.open_source,
        "blacklist": s.blacklist,
        "lp_locked": s.lp_locked,
        "flags": s.flags,
    })
}

/// Flat numbers for watchers: every field always present when known,
/// `curve_pct` 100 once graduated.
pub fn check(s: &TokenSnapshot) -> Value {
    let flow = |w: Window| s.flow(w).copied().unwrap_or_default();
    let change = |w: Window| s.change_pct.iter().find(|(x, _)| *x == w).map(|(_, v)| *v);
    let (curve_pct, graduated) = watch_progress(s);
    json!({
        "symbol": label(s.symbol.as_deref(), 20),
        "token": s.token,
        "price_usd": price(s.price_usd),
        "fdv_usd": usd(s.fdv_usd),
        "liquidity_usd": usd(s.liquidity_usd),
        "holders": int(s.holders),
        "top10_pct": pct(s.top10_pct),
        "dev_pct": pct(s.mix.dev_pct),
        "snipers_pct": pct(s.mix.snipers_pct),
        "kol_wallets": int(s.tagged.kol),
        "smart_wallets": int(s.tagged.smart),
        "buy_5m_usd": usd(flow(Window::M5).buy_usd),
        "sell_5m_usd": usd(flow(Window::M5).sell_usd),
        "change_1h_pct": pct(change(Window::H1)),
        "curve_pct": pct(curve_pct),
        "graduated": graduated.map(u8::from),
    })
}

/// One board row, about 500 chars pretty-printed.
pub fn listing(l: &Listing) -> Value {
    let mut out = Map::new();
    put(&mut out, "symbol", label(l.symbol.as_deref(), 20));
    put(&mut out, "token", json!(l.token));
    put(&mut out, "launchpad", json!(l.launchpad));
    put(&mut out, "stage", json!(l.stage));
    put(&mut out, "pair", json!(l.pair));
    put(&mut out, "trade_support", json!(l.support));
    put_span(&mut out, "age", l.created_at);
    put(&mut out, "fdv_usd", usd(l.fdv_usd));
    put(&mut out, "liquidity_usd", usd(l.liquidity_usd));
    let w = l.window;
    put(&mut out, &format!("volume_{w}_usd"), usd(l.volume_usd));
    put(&mut out, &format!("change_{w}_pct"), pct(l.change_pct));
    put(&mut out, &format!("buys_{w}"), int(l.buys));
    put(&mut out, &format!("sells_{w}"), int(l.sells));
    put(&mut out, "net_buy_24h_usd", usd(l.net_buy_usd));
    put(&mut out, "holders", int(l.holders));
    put(&mut out, "top10_pct", pct(l.top10_pct));
    put(&mut out, "smart_wallets", int(l.smart));
    put(&mut out, "kol_wallets", int(l.kol));
    // Risk fields appear only when GMGN flags something.
    let flagged = |v: Option<f64>| v.filter(|v| *v > 0.0);
    put(&mut out, "sniper_wallets", int(flagged(l.snipers)));
    put(&mut out, "bundler_trading_pct", pct(flagged(l.bundler_pct)));
    put(&mut out, "dev_pct", pct(flagged(l.dev_pct)));
    put(&mut out, "rug_pct", pct(flagged(l.rug_pct)));
    put(&mut out, "curve_pct", pct(l.curve_pct));
    if let (Some(ath), Some(fdv)) = (l.ath_fdv_usd, l.fdv_usd)
        && ath > 0.0
    {
        put(
            &mut out,
            "from_ath_pct",
            pct(Some(((fdv / ath).min(1.0) - 1.0) * 100.0)),
        );
    }
    if let Some((made, graduated)) = l.dev_launches {
        put(&mut out, "dev_launches", int(Some(made)));
        put(&mut out, "dev_graduated", int(Some(graduated)));
    }
    Value::Object(out)
}

pub fn candidate(c: &Candidate) -> Value {
    let mut out = Map::new();
    put(&mut out, "symbol", label(c.symbol.as_deref(), 20));
    put(&mut out, "name", label(c.name.as_deref(), 32));
    put(&mut out, "token", json!(c.token));
    put(
        &mut out,
        "match",
        json!(if c.exact_symbol {
            "exact_symbol"
        } else {
            "partial"
        }),
    );
    put(&mut out, "launchpad", json!(c.launchpad));
    put(&mut out, "stage", json!(c.stage));
    put_span(&mut out, "age", c.created_at);
    put(&mut out, "fdv_usd", usd(c.fdv_usd));
    put(&mut out, "liquidity_usd", usd(c.liquidity_usd));
    put(&mut out, "volume_1h_usd", usd(c.volume_1h_usd));
    put(&mut out, "holders", int(c.holders));
    put(&mut out, "kol_wallets", int(c.kols));
    if c.honeypot == Some(true) {
        put(&mut out, "honeypot", json!("yes"));
    }
    Value::Object(out)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::domain::exit::ExitResult;
    use crate::domain::market::Stage;
    use crate::providers::gmgn::types::TokenInfo;
    use crate::view::{MAX_REPLY, reply, size};

    fn vrax() -> TokenSnapshot {
        let text = std::fs::read_to_string(format!(
            "{}/src/fixtures/gmgn/info_vrax.json",
            env!("CARGO_MANIFEST_DIR")
        ))
        .unwrap();
        let v: Value = serde_json::from_str(&text).unwrap();
        let info: TokenInfo = serde_json::from_value(v["data"].clone()).unwrap();
        TokenSnapshot::from_gmgn(info)
    }

    #[test]
    fn widest_card_fits_one_reply() {
        let mut s = vrax();
        s.name = Some("N".repeat(40));
        s.security = Some(Security {
            honeypot: None,
            buy_tax_pct: Some(1.0),
            sell_tax_pct: Some(1.0),
            renounced: Some(true),
            open_source: Some(true),
            blacklist: Some(false),
            lp_locked: Some(true),
            flags: vec!["x".repeat(20); 6],
        });
        s.socials.website = Some("w".repeat(80));
        let probe = Probe {
            eth_in: "0.01".into(),
            loss_pct: Some(4.2),
            no_sell_route: false,
            result: ExitResult::Ok,
        };
        let turn = crate::runtime::Turn::default();
        turn.gap("Pons launch record unreadable; stage and curve are gmgn's");
        let out = reply(card(&s, Some(&probe)), &turn);
        assert!(size(&out) <= MAX_REPLY, "{}", size(&out));
        assert_eq!(out["status"], "partial");
        assert_eq!(out["kol_wallets"], 17);
        assert_eq!(out["security"]["honeypot"], "unknown");
        assert!(out["buy_1h_usd"].is_i64());
    }

    #[test]
    fn check_reports_curve_100_after_graduation() {
        let mut s = vrax();
        let out = crate::view::compact(check(&s));
        assert_eq!(out["curve_pct"], 100.0);
        assert_eq!(out["graduated"], 1);
        assert!(out.get("buy_5m_usd").is_some());
        // A rescued launch never reads as graduated.
        s.stage = Stage::Rescued;
        let out = crate::view::compact(check(&s));
        assert_eq!(out["graduated"], 0);
        assert!(out.get("curve_pct").is_none());
    }
}

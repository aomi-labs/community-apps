//! Pons V2, Robinhood Chain's main launchpad: stage, curve progress the way
//! Pons shows it (real reserve over the graduation target; matched GMGN's
//! launchpad progress exactly in the 2026-10-04 audit), and the dev wallet.
use super::market::{Pair, Stage, pair_of};
use crate::providers::chain::{Chain, PonsLaunch};

pub fn stage(launch: &PonsLaunch) -> Stage {
    match launch.phase {
        0 => Stage::Curve,
        1 => Stage::Graduating,
        3 => Stage::Rescued,
        _ => Stage::Graduated,
    }
}

/// Curve progress in pair-token units.
#[derive(Clone, Debug, PartialEq)]
pub struct Curve {
    pub pct: Option<f64>,
    pub raised: Option<f64>,
    pub target: f64,
    pub pair: Pair,
}

/// Progress of a launch still on its curve; `None` once it has left it.
pub async fn curve(chain: &Chain<'_>, launch: &PonsLaunch) -> Option<Curve> {
    if launch.phase != 0 {
        return None;
    }
    let pair = pair_of(chain, &launch.pair_token).await?;
    let scale = 10f64.powi(pair.decimals as i32);
    let raised = launch.reserve.map(|r| r as f64 / scale);
    let target = launch.target as f64 / scale;
    Some(Curve {
        pct: raised
            .filter(|_| target > 0.0)
            .map(|r| (r / target * 100.0).min(100.0)),
        raised,
        target,
        pair,
    })
}

/// Curve progress 0–100 while the launch is still on its curve.
pub async fn curve_pct(chain: &Chain<'_>, launch: &PonsLaunch) -> Option<f64> {
    curve(chain, launch).await?.pct
}

/// Who launched a coin, and how we know.
#[derive(Clone, Debug, PartialEq)]
pub struct Dev {
    pub wallet: String,
    pub source: &'static str,
}

/// For Pons, the launch record's deployer is the dev unless it is a
/// contract (a fee splitter); then the launch tx sender is. Otherwise the
/// creator the data provider reports.
pub async fn dev(
    chain: &Chain<'_>,
    launch: Option<&PonsLaunch>,
    creator: Option<&str>,
) -> Option<Dev> {
    let creator = creator
        .map(str::to_ascii_lowercase)
        .filter(|c| c.len() == 42);
    match launch {
        Some(l) => {
            let contract = chain.contracts(std::slice::from_ref(&l.deployer)).await;
            if contract.first() == Some(&Some(true)) {
                creator.map(|wallet| Dev {
                    wallet,
                    source: "launch tx sender (the Pons deployer field is a contract)",
                })
            } else {
                Some(Dev {
                    wallet: l.deployer.clone(),
                    source: "Pons launch record",
                })
            }
        }
        None => creator.map(|wallet| Dev {
            wallet,
            source: "token creator",
        }),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn launch(phase: u8) -> PonsLaunch {
        PonsLaunch {
            curve: "0xc".into(),
            deployer: "0xd".into(),
            pair_token: crate::providers::WETH.into(),
            target: 4_200_000_000_000_000_000,
            creator_tax_bps: 100,
            phase,
            reserve: Some(3_570_000_000_000_000_000),
        }
    }

    #[test]
    fn stages_follow_the_phase() {
        assert_eq!(stage(&launch(0)), Stage::Curve);
        assert_eq!(stage(&launch(1)), Stage::Graduating);
        assert_eq!(stage(&launch(2)), Stage::Graduated);
        assert_eq!(stage(&launch(3)), Stage::Rescued);
    }

    #[test]
    fn progress_is_reserve_over_target_and_only_on_the_curve() {
        let rt = crate::runtime::HooditApp::replaying(Default::default())
            .runtime()
            .unwrap();
        let turn = crate::runtime::Turn::default();
        let chain = Chain::new(&rt, &turn);
        let pct = rt.tokio.block_on(curve_pct(&chain, &launch(0))).unwrap();
        assert!((pct - 85.0).abs() < 1e-9);
        assert_eq!(rt.tokio.block_on(curve_pct(&chain, &launch(2))), None);
    }
}

//! Hoodit: a memecoin trading friend for Robinhood Chain. GMGN finds coins
//! and labels wallets, Codex reads depth and history, LI.FI proves the exit.
//!
//! Layers, one way down: `tools` (thin adapters) → `domain` (Hoodit's
//! rules) → `providers` (one per source) → `runtime` (cache, gates, the
//! one request path); `view` builds every model-facing reply.
use aomi_sdk::*;

pub mod domain;
pub mod providers;
pub mod runtime;
pub mod tools;
pub mod view;

const PREAMBLE: &str = include_str!("preamble.md");

const CODEX: Secret = Secret::new(
    runtime::CODEX_KEY,
    "Payment key for the operator's Codex market-data wallet (MPP on Tempo)",
    false,
);
const GMGN: Secret = Secret::new(
    runtime::GMGN_KEY,
    "GMGN OpenAPI key for discovery boards, KOL and smart-money feeds and wallet labels",
    false,
);
const LIFI: Secret = Secret::new(
    runtime::LIFI_KEY,
    "LI.FI integrator API key for exit quotes",
    false,
);

dyn_aomi_app!(
    app = runtime::HooditApp,
    name = "hoodit",
    version = "3.0.0",
    preamble = PREAMBLE,
    tools = [
        tools::Signals,
        tools::Scan,
        tools::Find,
        tools::Token,
        tools::Chart,
        tools::Trades,
        tools::Holders,
        tools::Wallet,
        tools::Exit,
        tools::Check
    ],
    secrets = [CODEX, GMGN, LIFI],
    namespaces = ["aomi-core", "evm-core"],
    skills = [
        {
            id: "hoodit/research",
            description: "Find and judge Robinhood Chain tokens, memecoins above all: what KOLs and smart money are buying, what's trending in a market-cap band, Pons curves near graduation, opinions on a ticker or contract, charts, who is buying or dumping, holders and the dev, wallets, bag checks, and whether a size can get out. Load for any coin question.",
            tags: ["memecoins", "robinhood", "kol", "smart money", "scan", "pons", "chart", "holders", "exit"],
            sections: { instructions: "skills/research.md" },
        },
        {
            id: "hoodit/trade",
            description: "Buy or sell a Robinhood Chain token the user explicitly asked to trade. Load together with the host lifi_swap skill.",
            tags: ["buy", "sell", "ape", "swap", "slippage"],
            sections: { instructions: "skills/trade.md" },
        },
        {
            id: "hoodit/watch",
            description: "Set, list or cancel alerts on a Robinhood Chain coin: tell me when the curve hits X%, the price crosses a level, the dev sells, KOLs pile in.",
            tags: ["alert", "watch", "notify", "remind"],
            sections: { instructions: "skills/watch.md" },
        },
    ],
);

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn manifest_has_ten_unowned_tools_and_small_prompts() {
        let manifest = runtime::HooditApp::default().manifest();
        assert_eq!(manifest.version, "3.0.0");
        let names: Vec<&str> = manifest.tools.iter().map(|t| t.name.as_str()).collect();
        assert_eq!(
            names,
            [
                "hoodit_signals",
                "hoodit_scan",
                "hoodit_find",
                "hoodit_token",
                "hoodit_chart",
                "hoodit_trades",
                "hoodit_holders",
                "hoodit_wallet",
                "hoodit_exit",
                "hoodit_check"
            ]
        );
        assert!(
            manifest
                .tools
                .iter()
                .all(|t| t.parameters_schema["additionalProperties"] == false)
        );
        let descriptions: usize = manifest.tools.iter().map(|t| t.description.len()).sum();
        assert!(
            descriptions < 4500,
            "tool descriptions are {descriptions} chars"
        );
        for skill in &manifest.skills {
            let chars: usize = skill.sections.iter().map(|s| s.content.len()).sum();
            assert!(chars < 7000, "{} is {chars} chars", skill.id);
        }
        assert!(manifest.preamble.len() < 3000);
    }

    /// The host makes every property required, so optional ones must accept null.
    #[test]
    fn optional_arguments_accept_null() {
        let manifest = runtime::HooditApp::default().manifest();
        for tool in &manifest.tools {
            let schema = &tool.parameters_schema;
            let required: Vec<&str> = schema["required"]
                .as_array()
                .map(|r| r.iter().filter_map(|v| v.as_str()).collect())
                .unwrap_or_default();
            for (name, prop) in schema["properties"].as_object().unwrap() {
                if required.contains(&name.as_str()) {
                    continue;
                }
                let text = prop.to_string();
                assert!(
                    text.contains("\"null\""),
                    "{}.{name} is optional but not nullable: {text}",
                    tool.name
                );
            }
        }
    }
}

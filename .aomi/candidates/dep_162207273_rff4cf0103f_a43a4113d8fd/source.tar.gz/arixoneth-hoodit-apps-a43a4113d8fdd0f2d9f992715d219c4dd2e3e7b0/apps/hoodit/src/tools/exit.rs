use super::{address, run};
use crate::domain::exit::{Exits, Size};
use crate::runtime::{Fail, HooditApp, Lane};
use aomi_sdk::schemars::JsonSchema;
use aomi_sdk::{DynAomiTool, DynToolCallCtx};
use serde::Deserialize;
use serde_json::Value;

#[derive(Deserialize, JsonSchema, Clone, Copy, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum Mode {
    /// Buy with eth_amount (or usd_amount) and sell straight back.
    RoundTrip,
    /// Sell token_amount (or usd_amount worth) for ETH.
    Sell,
}

#[derive(Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct ExitArgs {
    /// Exact 0x token contract.
    pub token: String,
    /// round_trip or sell. null = sell when token_amount is set, else round_trip.
    pub mode: Option<Mode>,
    /// ETH to buy with for a round trip, e.g. "0.1". null = use usd_amount.
    pub eth_amount: Option<String>,
    /// Tokens to sell in whole units, e.g. "250000". null = use usd_amount.
    pub token_amount: Option<String>,
    /// Size in USD instead, converted at the current price. null = not used.
    pub usd_amount: Option<f64>,
    /// Slippage tolerance in percent for the quotes. null = 10.
    pub slippage_pct: Option<f64>,
}

pub struct Exit;

impl DynAomiTool for Exit {
    type App = HooditApp;
    type Args = ExitArgs;
    const NAME: &'static str = "hoodit_exit";
    const DESCRIPTION: &'static str = "Can a size get out? Live LI.FI quotes, the router the host trades through. round_trip buys and sells straight back; sell quotes a position. Both report loss_pct and a result (ok, thin above 10% loss, trap with no sell route or over 50% lost), each leg's route or why it failed. Quotes, not fills.";

    fn run(app: &HooditApp, args: ExitArgs, ctx: DynToolCallCtx) -> Result<Value, String> {
        run(app, &ctx, Lane::Chat, async |rt, turn| {
            let token = address(&args.token)?;
            let slippage = args.slippage_pct.unwrap_or(10.0).clamp(0.5, 30.0) / 100.0;
            let exits = Exits::new(rt, turn);
            let size = match (&args.eth_amount, &args.token_amount, args.usd_amount) {
                (Some(eth), _, _) => Size::Eth(eth.clone()),
                (None, Some(tokens), _) => Size::Tokens(tokens.clone()),
                (None, None, Some(usd)) => Size::Usd(usd),
                _ => {
                    return Err(Fail::Invalid(
                        "give eth_amount, token_amount or usd_amount".into(),
                    ));
                }
            };
            let mode = args.mode.unwrap_or(if args.token_amount.is_some() {
                Mode::Sell
            } else {
                Mode::RoundTrip
            });
            match mode {
                Mode::RoundTrip => {
                    let (trip, eth_usd) = exits.round_trip_sized(&token, size, slippage).await?;
                    Ok(crate::view::market::round_trip(
                        &token,
                        &trip,
                        eth_usd,
                        turn.wallet.is_some(),
                    ))
                }
                Mode::Sell => {
                    let sale = exits.sell_sized(&token, size, slippage).await?;
                    Ok(crate::view::market::sale(&token, &sale))
                }
            }
        })
    }
}

//! Robinhood Chain JSON-RPC: ERC-20 metadata and balances, whether an
//! address is a contract, and the Pons V2 launch record and curve reserve.
use crate::runtime::{Cost, Fail, Request, Runtime, Source, Turn};
use serde_json::{Value, json};
use std::time::Duration;

const RPCS: [&str; 2] = [
    "https://rpc.ordofi.network",
    "https://rpc.mainnet.chain.robinhood.com",
];
const TIMEOUT: Duration = Duration::from_secs(8);
const FOREVER: Duration = Duration::from_secs(7 * 24 * 3600);
/// Curve reserve and phase move with every trade.
const CURVE_TTL: Duration = Duration::from_secs(20);

pub const PONS_FACTORY: &str = "0x7ed598bcef8bd9edd8c97a195c6d13f40801ec7e";

/// What the Pons V2 factory recorded at launch, plus the curve reserve read
/// in the same step so phase and progress never disagree.
#[derive(Clone, Debug, PartialEq)]
pub struct PonsLaunch {
    pub curve: String,
    pub deployer: String,
    pub pair_token: String,
    /// Graduation target in pair-token atomic units.
    pub target: u128,
    pub creator_tax_bps: u128,
    /// 0 curve, 1 sweeping (graduating), 2 on Uniswap v4, 3 rescued.
    pub phase: u8,
    /// Real pair-token reserve on the curve while `phase` is 0.
    pub reserve: Option<u128>,
}

#[derive(Clone, Copy)]
pub struct Chain<'a> {
    rt: &'a Runtime,
    turn: &'a Turn,
}

impl<'a> Chain<'a> {
    pub fn new(rt: &'a Runtime, turn: &'a Turn) -> Self {
        Self { rt, turn }
    }

    pub async fn decimals(self, token: &str) -> Result<u8, Fail> {
        let raw = self
            .eth_call(format!("decimals:{token}"), FOREVER, token, "0x313ce567")
            .await?;
        word_u128(words(&raw).first().ok_or_else(odd)?)
            .and_then(|d| u8::try_from(d).ok())
            .ok_or_else(odd)
    }

    /// ERC-20 symbol, string or bytes32 encoded.
    pub async fn symbol(self, token: &str) -> Result<String, Fail> {
        let raw = self
            .eth_call(format!("symbol:{token}"), FOREVER, token, "0x95d89b41")
            .await?;
        decode_string(&raw).ok_or_else(odd)
    }

    /// Balance in atomic units.
    pub async fn balance(self, token: &str, owner: &str) -> Result<u128, Fail> {
        let data = format!("0x70a08231{:0>64}", owner.trim_start_matches("0x"));
        let key = format!("balance:{token}:{owner}");
        let raw = self
            .eth_call(key, Duration::from_secs(10), token, &data)
            .await?;
        word_u128(words(&raw).first().ok_or_else(odd)?).ok_or_else(odd)
    }

    /// Whether each address is a contract (`None` when unreadable), in one
    /// batched read. Cached forever.
    pub async fn contracts(self, addresses: &[String]) -> Vec<Option<bool>> {
        let mut out: Vec<Option<bool>> = addresses
            .iter()
            .map(|a| self.rt.cache.fresh(&code_key(a)).and_then(|v| v.as_bool()))
            .collect();
        let missing: Vec<usize> = (0..addresses.len()).filter(|&i| out[i].is_none()).collect();
        if missing.is_empty() {
            return out;
        }
        let batch: Vec<Value> = missing
            .iter()
            .map(|&i| json!({"jsonrpc":"2.0","id":i,"method":"eth_getCode","params":[addresses[i],"latest"]}))
            .collect();
        let key = format!(
            "chain:code:{}",
            missing
                .iter()
                .map(|&i| addresses[i].as_str())
                .collect::<Vec<_>>()
                .join(",")
        );
        let request = Request::new(Source::Chain, key, Cost::Free, Duration::ZERO);
        let http = &self.rt.http;
        let sent = self
            .rt
            .fetch(self.turn, request, || async move {
                let response = http
                    .post(RPCS[0])
                    .timeout(TIMEOUT)
                    .json(&batch)
                    .send()
                    .await
                    .map_err(|_| Fail::unavailable(Source::Chain, "rpc request failed"))?;
                response
                    .json::<Value>()
                    .await
                    .map_err(|_| Fail::bad(Source::Chain, "rpc reply not JSON"))
            })
            .await;
        for reply in sent
            .ok()
            .and_then(|v| v.as_array().cloned())
            .unwrap_or_default()
        {
            let (Some(i), Some(code)) = (
                reply["id"].as_u64().map(|i| i as usize),
                reply["result"].as_str(),
            ) else {
                continue;
            };
            if let Some(address) = addresses.get(i) {
                let contract = code != "0x";
                self.rt
                    .cache
                    .put(code_key(address), json!(contract), FOREVER);
                out[i] = Some(contract);
            }
        }
        out
    }

    /// The Pons V2 launch record and, while on the curve, its reserve.
    /// `Ok(None)` when the token wasn't launched on Pons V2.
    pub async fn pons(self, token: &str) -> Result<Option<PonsLaunch>, Fail> {
        let key = format!("chain:pons:{token}");
        let request = Request::new(Source::Chain, key.clone(), Cost::Free, CURVE_TTL);
        let value = self
            .rt
            .fetch(self.turn, request, || async {
                let data = format!("0x3cf28b5a{:0>64}", token.trim_start_matches("0x"));
                let raw = self.call_rpc(PONS_FACTORY, &data).await?;
                let curve = parse_launch(&raw).filter(|l| l.phase == 0).map(|l| l.curve);
                let reserve = match curve {
                    Some(curve) => {
                        let hex = self.call_rpc(&curve, "0x4f1f58fd").await?;
                        words(&hex).first().and_then(|w| word_u128(w))
                    }
                    None => None,
                };
                Ok(json!({ "raw": raw, "reserve": reserve.map(|r| r.to_string()) }))
            })
            .await?;
        let launch = from_cached(&value);
        // Only a live curve changes; graduated launches and non-Pons tokens don't.
        if launch.as_ref().is_none_or(|l| l.phase >= 2) {
            self.rt.cache.put(key, value, FOREVER);
        }
        Ok(launch)
    }

    async fn eth_call(
        self,
        key: String,
        ttl: Duration,
        to: &str,
        data: &str,
    ) -> Result<String, Fail> {
        let request = Request::new(Source::Chain, format!("chain:{key}"), Cost::Free, ttl);
        let value = self
            .rt
            .fetch(self.turn, request, || async {
                self.call_rpc(to, data).await.map(Value::String)
            })
            .await?;
        value.as_str().map(str::to_string).ok_or_else(odd)
    }

    /// One `eth_call`, fast endpoint first. A revert is an error, never
    /// an empty answer.
    async fn call_rpc(self, to: &str, data: &str) -> Result<String, Fail> {
        let body = json!({"jsonrpc":"2.0","id":1,"method":"eth_call","params":[{ "to": to, "data": data }, "latest"]});
        for url in RPCS {
            let Ok(response) = self
                .rt
                .http
                .post(url)
                .timeout(TIMEOUT)
                .json(&body)
                .send()
                .await
            else {
                continue;
            };
            let Ok(value) = response.json::<Value>().await else {
                continue;
            };
            if let Some(result) = value["result"].as_str() {
                return Ok(result.to_string());
            }
            if value.get("error").is_some() {
                return Err(Fail::bad(Source::Chain, "call reverted"));
            }
        }
        Err(Fail::unavailable(Source::Chain, "rpc unreachable"))
    }
}

fn code_key(address: &str) -> String {
    format!("chain:code:{address}")
}

fn odd() -> Fail {
    Fail::bad(Source::Chain, "unexpected call result")
}

fn from_cached(hit: &Value) -> Option<PonsLaunch> {
    let mut launch = parse_launch(hit["raw"].as_str()?)?;
    launch.reserve = hit["reserve"].as_str().and_then(|r| r.parse().ok());
    Some(launch)
}

fn words(hex: &str) -> Vec<&str> {
    let hex = hex.trim_start_matches("0x");
    (0..hex.len() / 64)
        .map(|i| &hex[i * 64..i * 64 + 64])
        .collect()
}

fn word_addr(word: &str) -> String {
    format!("0x{}", &word[24..])
}

fn word_u128(word: &str) -> Option<u128> {
    let (high, low) = word.split_at(word.len().saturating_sub(32));
    high.bytes()
        .all(|b| b == b'0')
        .then(|| u128::from_str_radix(low, 16).ok())?
}

/// `getLaunchedToken(address)`; word 14 is the "launched" flag.
fn parse_launch(raw: &str) -> Option<PonsLaunch> {
    let w = words(raw);
    if w.len() < 15 || word_u128(w[14])? != 1 {
        return None;
    }
    Some(PonsLaunch {
        curve: word_addr(w[1]),
        deployer: word_addr(w[2]),
        pair_token: word_addr(w[4]),
        target: word_u128(w[5])?,
        creator_tax_bps: word_u128(w[8])?,
        phase: u8::try_from(word_u128(w[10])?).ok()?,
        reserve: None,
    })
}

fn decode_string(raw: &str) -> Option<String> {
    let hex = raw.trim_start_matches("0x");
    if !hex.len().is_multiple_of(2) || !hex.bytes().all(|b| b.is_ascii_hexdigit()) {
        return None;
    }
    let bytes: Vec<u8> = (0..hex.len() / 2)
        .filter_map(|i| u8::from_str_radix(&hex[i * 2..i * 2 + 2], 16).ok())
        .collect();
    let text = if bytes.len() >= 96 {
        let len = usize::try_from(word_u128(words(raw).get(1)?)?).ok()?;
        bytes.get(64..64usize.checked_add(len)?)?.to_vec()
    } else {
        bytes.into_iter().take_while(|b| *b != 0).collect()
    };
    let text = String::from_utf8(text).ok()?;
    let clean: String = text.chars().filter(|c| !c.is_control()).take(16).collect();
    (!clean.is_empty()).then_some(clean)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn symbols_decode_both_encodings() {
        let string = "0x000000000000000000000000000000000000000000000000000000000000002000000000000000000000000000000000000000000000000000000000000000045553444700000000000000000000000000000000000000000000000000000000";
        assert_eq!(decode_string(string).as_deref(), Some("USDG"));
        let bytes32 = "0x4d4b520000000000000000000000000000000000000000000000000000000000";
        assert_eq!(decode_string(bytes32).as_deref(), Some("MKR"));
        assert_eq!(decode_string("0xzz"), None);
        let huge_len = format!(
            "0x{}{:0>64x}{}",
            "0".repeat(63) + "2",
            u64::MAX,
            "00".repeat(32)
        );
        assert_eq!(decode_string(&huge_len), None);
    }

    #[test]
    fn launch_record_decodes() {
        // getLaunchedToken for a USDG-paired Pons V2 launch (live read, 2026-10-03).
        let raw = "0x000000000000000000000000c093f78bb9859817072cf7e1d2819511f2860a100000000000000000000000009c69b2a354f73b93b80966b707d797b322c5a4fd0000000000000000000000008d64b1cb8834a9aac51075cddd388f8a47b094d90000000000000000000000008d64b1cb8834a9aac51075cddd388f8a47b094d90000000000000000000000005fc5360d0400a0fd4f2af552add042d716f1d16800000000000000000000000000000000000000000000000000000001e2339a80000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c80000000000000000000000000000000000000000000000000000000000000064000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001";
        let launch = parse_launch(raw).unwrap();
        assert_eq!(
            launch.pair_token,
            "0x5fc5360d0400a0fd4f2af552add042d716f1d168"
        );
        assert_eq!(launch.target, 8_090_000_000);
        assert_eq!(
            launch.deployer,
            "0x8d64b1cb8834a9aac51075cddd388f8a47b094d9"
        );
        assert_eq!(launch.creator_tax_bps, 100);
        assert_eq!(launch.phase, 0);
        assert!(parse_launch("0x").is_none());
        let cached = from_cached(&json!({ "raw": raw, "reserve": "4045000000" })).unwrap();
        assert_eq!(cached.reserve, Some(4_045_000_000));
    }
}

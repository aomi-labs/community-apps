//! Whole tools on recorded provider responses, no network: every reply has
//! the envelope, fits the size limit, carries no nulls and keeps its key
//! facts. Re-record with `HOODIT_RECORD=<file> cargo run --example live`.
use aomi_sdk::testing::{TestCtxBuilder, run_tool};
use hoodit::runtime::{CODEX_KEY, GMGN_KEY, HooditApp, LIFI_KEY};
use hoodit::tools::*;
use hoodit::view::{MAX_REPLY, size};
use serde_json::{Value, json};
use std::collections::BTreeMap;
use std::sync::OnceLock;

const PRIORS: &str = "0xedbf91223639800bcd5756815caf908df3b890be";
const CHFUND: &str = "0x0821df61b58195d21c0c969212c89a2cffddb1b2";
const CHIIKAWA: &str = "0x09d6da82dc6ec5ec882e8d124b1eb919dec492b7";

fn app() -> &'static HooditApp {
    static APP: OnceLock<HooditApp> = OnceLock::new();
    APP.get_or_init(|| {
        let recorded: BTreeMap<String, Value> =
            serde_json::from_str(include_str!("fixtures/replay.json")).unwrap();
        HooditApp::replaying(recorded)
    })
}

fn call<T: aomi_sdk::DynAomiTool<App = HooditApp>>(args: Value) -> Value {
    let mut ctx = TestCtxBuilder::new(T::NAME).session_id("replay");
    for name in [CODEX_KEY, GMGN_KEY, LIFI_KEY] {
        ctx = ctx.secret(name, "recorded");
    }
    let out = run_tool::<T>(app(), args, ctx.build()).unwrap().value;
    assert!(
        size(&out) <= MAX_REPLY,
        "{} is {} chars",
        T::NAME,
        size(&out)
    );
    assert_ne!(out["status"], "error", "{}: {out}", T::NAME);
    assert!(out["as_of"].is_i64());
    assert!(
        !out.to_string().contains("null"),
        "{} has a null: {out}",
        T::NAME
    );
    out
}

#[test]
fn signals_name_the_buyers() {
    let out = call::<Signals>(json!({}));
    let coins = out["coins"].as_array().unwrap();
    assert!(!coins.is_empty());
    assert!(
        coins
            .iter()
            .all(|c| c["token"].as_str().unwrap().starts_with("0x"))
    );
    let lines: Vec<String> = coins
        .iter()
        .flat_map(|c| c["buyers"].as_array().cloned().unwrap_or_default())
        .filter_map(|b| b.as_str().map(str::to_string))
        .collect();
    // "name @handle (kol, 0x…): bought $…": the address lets the model
    // check the wallet's record.
    assert!(!lines.is_empty());
    assert!(
        lines
            .iter()
            .all(|l| (l.contains("(kol, 0x") || l.contains("(smart, 0x")) && l.contains(" ago"))
    );
}

#[test]
fn banded_scan_stays_in_band_without_base_assets() {
    let out = call::<Scan>(json!({ "min_fdv_usd": 50000, "max_fdv_usd": 1000000 }));
    let rows = out["rows"].as_array().unwrap();
    assert!(!rows.is_empty());
    for row in rows {
        let fdv = row["fdv_usd"].as_f64().unwrap();
        assert!((40_000.0..=1_100_000.0).contains(&fdv), "{row}");
        assert!(row["smart_wallets"].is_i64());
    }
}

#[test]
fn curve_board_carries_progress() {
    let out = call::<Scan>(json!({ "board": "near_graduation" }));
    for row in out["rows"].as_array().unwrap() {
        assert_eq!(row["stage"], "curve");
        assert!(row["curve_pct"].as_f64().unwrap() < 100.0);
    }
}

#[test]
fn find_lists_the_real_priors_first() {
    let out = call::<Find>(json!({ "query": "$PRIORS" }));
    assert_eq!(out["candidates"][0]["token"], PRIORS);
    assert!(out["dead_copies_hidden"].as_u64().unwrap() > 0);
}

#[test]
fn card_reads_gmgn_flow_and_exit() {
    let out = call::<Token>(json!({ "token": PRIORS }));
    assert_eq!(out["symbol"], "PRIORS");
    assert_eq!(out["launchpad"], "pons");
    assert!(out["buy_1h_usd"].is_i64() && out["kol_wallets"].is_i64());
    assert_eq!(out["exit_check"]["result"], "ok");
    assert_eq!(out["security"]["honeypot"], "no");
    assert!(out["sources"].as_array().unwrap().contains(&json!("gmgn")));
}

#[test]
fn honeypot_shows_as_a_trap() {
    let out = call::<Token>(json!({ "token": CHFUND }));
    assert_eq!(out["exit_check"]["result"], "trap");
    assert_eq!(out["exit_check"]["sell"], "no_route");
    assert_eq!(out["security"]["honeypot"], "unknown");
}

#[test]
fn dev_record_comes_from_the_launch() {
    let out = call::<Holders>(json!({ "token": PRIORS, "view": "dev" }));
    assert!(out["dev"].as_str().unwrap().starts_with("0x"));
    assert_eq!(out["launches"][0]["this_token"], true);
}

#[test]
fn watcher_numbers_are_flat() {
    let out = call::<Check>(json!({ "token": CHIIKAWA }));
    assert!(out["curve_pct"].as_f64().is_some());
    assert!(out["graduated"].is_u64());
    assert!(out.as_object().unwrap().values().all(|v| !v.is_object()));
}

#[test]
fn wallet_record_is_gmgn() {
    let out = call::<Wallet>(json!({ "wallet": "0x4cfd59ad1d7236af5c98248435b38e96554cd15b" }));
    assert!(out["record"]["win_rate_pct"].as_f64().is_some());
    assert!(!out["bag"].as_array().unwrap().is_empty());
}

#[test]
fn bad_input_is_an_error_the_model_can_fix() {
    let ctx = TestCtxBuilder::new("hoodit_token").build();
    let out = run_tool::<Token>(app(), json!({ "token": "PRIORS" }), ctx)
        .unwrap()
        .value;
    assert_eq!(out["error"]["code"], "INVALID_ARGUMENT");
}

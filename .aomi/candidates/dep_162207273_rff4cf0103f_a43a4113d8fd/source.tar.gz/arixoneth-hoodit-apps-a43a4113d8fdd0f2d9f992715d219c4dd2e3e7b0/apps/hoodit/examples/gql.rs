//! Raw paid Codex GraphQL, for research: `cargo run --example gql -- '<query>'`
//! prints one response; `-- @queries.txt` runs one query per line and
//! prints one JSON response per line. Reads CODEX_MPP_KEY from the
//! environment. About $0.001 a query.
use mpp::client::{Fetch, TempoProvider};

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let signer: mpp::PrivateKeySigner = std::env::var("CODEX_MPP_KEY")?.trim().parse()?;
    let provider =
        TempoProvider::new(signer, "https://rpc.tempo.xyz")?.with_client_id("hoodit-dev");
    let arg = std::env::args().nth(1).expect("query argument or @file");
    let queries: Vec<String> = match arg.strip_prefix('@') {
        Some(path) => std::fs::read_to_string(path)?
            .lines()
            .filter(|l| !l.trim().is_empty())
            .map(str::to_string)
            .collect(),
        None => vec![arg],
    };
    let client = reqwest::Client::new();
    for (i, query) in queries.iter().enumerate() {
        let started = std::time::Instant::now();
        let response = client
            .post("https://graph.codex.io/graphql")
            .header("X-Codex-Payment", "mpp")
            .json(&serde_json::json!({ "query": query }))
            .send_with_payment(&provider)
            .await?;
        eprintln!(
            "{}/{}: {} in {:.1}s",
            i + 1,
            queries.len(),
            response.status(),
            started.elapsed().as_secs_f64()
        );
        let body: serde_json::Value = response.json().await.unwrap_or_default();
        println!("{body}");
    }
    Ok(())
}

//! Runs a plan of real tool calls against live providers and prints each
//! reply with its size and time: `cargo run --example live -- plan.json`.
//! Reads CODEX_MPP_KEY, GMGN_API_KEY and LIFI_API_KEY from the environment
//! (Codex costs ~$0.001 a request). With HOODIT_RECORD=<file>, every
//! provider response is saved for offline replay tests.
use aomi_sdk::testing::{TestCtxBuilder, run_tool};
use hoodit::runtime::{CODEX_KEY, GMGN_KEY, HooditApp, LIFI_KEY};
use hoodit::tools::*;
use hoodit::view::MAX_REPLY;
use serde_json::{Value, json};

fn main() {
    let path = std::env::args().nth(1).expect("plan.json");
    let plan: Vec<Value> = serde_json::from_str(&std::fs::read_to_string(path).unwrap()).unwrap();
    let app = HooditApp::default();
    let mut oversized = vec![];
    for (i, step) in plan.iter().enumerate() {
        let tool = step["tool"].as_str().unwrap();
        let args = step["args"].clone();
        let mut ctx = TestCtxBuilder::new(tool)
            .session_id(format!("live-{i}"))
            .call_id(format!("live-{i}"));
        if let Some(wallet) = step.get("wallet").and_then(Value::as_str) {
            ctx = ctx.attribute("domain", json!({ "evm": { "address": wallet } }));
        }
        for name in [CODEX_KEY, GMGN_KEY, LIFI_KEY] {
            if let Ok(v) = std::env::var(name) {
                ctx = ctx.secret(name, v);
            }
        }
        let ctx = ctx.build();
        let started = std::time::Instant::now();
        let out = match tool {
            "hoodit_signals" => run_tool::<Signals>(&app, args, ctx),
            "hoodit_scan" => run_tool::<Scan>(&app, args, ctx),
            "hoodit_find" => run_tool::<Find>(&app, args, ctx),
            "hoodit_token" => run_tool::<Token>(&app, args, ctx),
            "hoodit_chart" => run_tool::<Chart>(&app, args, ctx),
            "hoodit_trades" => run_tool::<Trades>(&app, args, ctx),
            "hoodit_holders" => run_tool::<Holders>(&app, args, ctx),
            "hoodit_wallet" => run_tool::<Wallet>(&app, args, ctx),
            "hoodit_exit" => run_tool::<Exit>(&app, args, ctx),
            "hoodit_check" => run_tool::<Check>(&app, args, ctx),
            other => Err(format!("unknown tool {other}")),
        };
        let text = match out {
            Ok(r) => serde_json::to_string_pretty(&r.value).unwrap(),
            Err(e) => format!("ERR {e}"),
        };
        let size = text.len();
        println!(
            "=== {tool} {} ({size} chars, {:.1}s)\n{text}\n",
            step["args"],
            started.elapsed().as_secs_f64()
        );
        if size > MAX_REPLY {
            oversized.push(format!("{tool} {}: {size} chars", step["args"]));
        }
    }
    if let Ok(file) = std::env::var("HOODIT_RECORD") {
        let recorded = app.runtime().unwrap().recorded();
        std::fs::write(&file, serde_json::to_string_pretty(&recorded).unwrap()).unwrap();
        eprintln!("recorded {} responses to {file}", recorded.len());
    }
    if !oversized.is_empty() {
        eprintln!("replies over {MAX_REPLY} chars:\n{}", oversized.join("\n"));
        std::process::exit(1);
    }
}

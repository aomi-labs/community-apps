# Hoodit

Hoodit is a Robinhood Chain trading assistant for token and launchpad discovery, market research, exit checks, and user-authorized trades. Canonical Stock Token trading remains available through the host's resolver and execution flow.

## Repository layout

- `app/` and `public/` — Next.js landing page and product UI
- `apps/hoodit/` — Rust v2 dynamic application loaded by Aomi: `src/tools/`
  holds the nine read tools, `src/market.rs` the shared token logic,
  `src/providers.rs` the Codex, LI.FI and chain transport, `src/shape.rs` the
  model-facing JSON rules
- `tests/evals/` and `scripts/hoodit-eval.py` — conversation evals run on Aomi chat
- `docs/hoodit-v1-validation.md` — local and sanitized provider evidence, with deployment work called out separately
- `.aomi/config.json` — Aomi Project manifest used by Build's community repository import
- `Cargo.toml` — shared Rust workspace and backend-compatible Aomi SDK pin

The repository name remains plural so separately permissioned products can live
beside Hoodit without expanding this app's trust boundary.

## Landing page

Requires Node.js 24.3 or newer and npm 10.9.2.

```bash
npm ci
npm run dev
```

Use `npm run lint` and `npm run build` before publishing frontend changes.

### In-page chat

`/app` mounts the native Aomi widget, pinned to the Hoodit application. The
browser talks to the Aomi chat host directly: guest and wallet sessions are
issued by it and bound to the browser origin, and `/v1/agent/*` serves CORS for
any origin, so the site has no server code. Aomi validates identity, scope and
session ownership from the origin-bound session bearer.

| Variable | Default | Purpose |
|---|---|---|
| `NEXT_PUBLIC_AOMI_API_URL` | `https://chat.aomi.dev` | Aomi chat host; set to `https://chat-staging.aomi.dev` for staging |
| `NEXT_PUBLIC_HOODIT_APP_ID` | `2938613` | Hoodit application id on that host |
| `NEXT_PUBLIC_PRIVY_APP_ID` | unset | Enables Privy sign-in; browser wallets otherwise |

Guest credentials are page-scoped, so reloading starts a fresh conversation.
The widget restores the active thread on reload only for a signed-in account,
scoped to that account, so one guest never sees another's conversation.

Two dependency pins are deliberate (re-checked on widget-lib 3.0.10):

- `overrides` holds `@assistant-ui/*` at the versions widget-lib was built
  against. Freely resolved, `react-markdown` 0.14.18 wants `react` ^0.15 and
  the chat hits "Maximum update depth exceeded" as soon as a reply streams.
  The build still passes, so test a real chat reply in the browser.
- `ox` is an optional peer of `permissionless` (under Privy). npm does not
  install optional peers, and the build fails with `Can't resolve 'ox'`
  without the direct dependency.

Wallet signing requires separate tests.

## Aomi application

The workspace pins `aomi-sdk = "=5.1.1"`, matching the Aomi backend runtime.

| Source | Used for |
|---|---|
| [GMGN](https://gmgn.ai) OpenAPI | Discovery and labels: trending boards with market-cap bands and rug, honeypot and wash-trading filters; launchpad sections; what KOL and smart-money wallets are buying, by name; per-token flow, liquidity, ATH, holder mix and wallet-tag counts; contract security; tagged holders and top traders; wallet win rates and PnL; a dev's launch record. Free plan: 5 weight a second per IP, paced at 3.5 with a stop on the first 429 (a burst earns an IP ban for every user on the host). |
| [Codex](https://docs.codex.io) GraphQL | Depth and history: candles (curve phase included), trades with the real wallet behind ERC-4337 bundles across a coin's busiest pools, unique buyers and sellers, holder lists, wallet balances, and the fallback card and board when GMGN is down. Paid with MPP: $0.001 in USDC.e on Tempo per request, several aliased queries billed once. |
| Robinhood Chain RPC | The Pons V2 launch record (true stage, pair token, graduation target, deployer) and curve reserve, read together so `curve_pct` matches what Pons shows; token decimals and symbols; contract checks for holder labels. |
| LI.FI | A 0.01 ETH round trip on every card (`exit_check`, the only test that catches traps the security screen calls clean) and `hoodit_exit` at the user's size. The host's own LI.FI tools still do the trading. |

A 2026-10-04 audit against GMGN found Codex right on price, holders, top
holders, candles and balances, and wrong or inconsistent on liquidity, flow,
ATH and wallet PnL, so those come from GMGN.

Three operator secrets, set per application in Aomi Build → Environment:

| Secret | Value |
|---|---|
| `GMGN_API_KEY` | GMGN OpenAPI key (read-only routes; no signing key needed). |
| `CODEX_MPP_KEY` | Private key of the wallet that pays for Codex requests on Tempo (chain 4217, USDC.e). Keep only a few dollars on it. |
| `LIFI_API_KEY` | LI.FI integrator key. Without it quotes fall back to the keyless allowance (about 40 an hour). |

Missing secrets make the affected tools fall back to the other source or
return `UNCONFIGURED` instead of failing the app.

Code layout, one way down:

| Layer | Job |
|---|---|
| `tools/` | Thin adapters: arguments, a "when to call" description, a call into domain, then view |
| `domain/` | Hoodit's rules as typed structs: token snapshot, boards, signals, Pons, trade support, exits, trades, holders, wallets |
| `providers/` | One module per source (`gmgn`, `codex`, `lifi`, `chain`): auth, endpoints, response types |
| `runtime/` | One request path for every source: cache with honest ages, single-flight, a gate per provider (GMGN weight pacing and ban circuit, Codex spend per thread and per day, LI.FI pacing), chat and watch lanes |
| `view/` | Every model-facing reply: one field vocabulary, units in names, the 3,000-char fit |

Ten read tools, none owned by a skill so they work in every thread:

| Tool | Answers |
|---|---|
| `hoodit_signals` | What KOLs and smart money are buying now, by name, per coin |
| `hoodit_scan` | Trending (by market-cap band), new, near graduation, graduated or established |
| `hoodit_find` | Which contract a ticker means (copycats and dead copies told apart) |
| `hoodit_token` | The card: stage, curve, trade support, flow, holder mix, KOL and smart holders, dev, security, exit check |
| `hoodit_chart` | Candles for a range plus facts computed from the same bars |
| `hoodit_trades` | Buy and sell dollars by window and the largest trades with tagged wallets |
| `hoodit_holders` | Top holders, KOL or smart holders by name, top traders, or the dev's launches |
| `hoodit_wallet` | A wallet's record, how its trades ended, and its bag |
| `hoodit_exit` | Whether a size gets back out, in ETH |
| `hoodit_check` | Flat numbers for watchers (`wake_on_condition`) |

The always-on preamble sets the voice and evidence rules; three short skills
(`hoodit/research`, `hoodit/trade`, `hoodit/watch`) are playbooks. Every reply
stays under 3,000 characters as the model sees it (the host pretty-prints tool
JSON), because guest chats share a 64 kB model input with the whole history.

```bash
cargo test -p hoodit
cargo clippy --workspace --all-targets -- -D warnings
aomi-build sdk check --path . --required-version 5.1.1
```

A live run calls every tool with real secrets and fails on any reply over the
size limit (about $0.02 of Codex and 40 GMGN weight). `HOODIT_RECORD=<file>`
also saves every provider response for offline replay:

```bash
set -a; . ~/.config/hoodit/mpp-test-wallet.env; . ~/.config/hoodit/gmgn.env; set +a
export LIFI_API_KEY=...
cargo run -p hoodit --example live -- apps/hoodit/examples/live-plan.json
cargo run -p hoodit --example gql -- '{ ... }'           # one raw Codex query
```

### Conversation evals

`tests/evals/cases.json` holds casual trader conversations split into `dev`
(used while tuning) and `holdout` (run once per release candidate, never copied
into skills). `scripts/hoodit-eval.py` runs them as fresh guest chats against a
deployed app with a chosen model, checks mechanics (completion, required tools,
tool errors, no signing actions), and saves transcripts for grading the
answers against the evidence the tools returned:

```bash
scripts/hoodit-eval.py --model gpt-6-luna --split dev --out /tmp/hoodit-eval
```

## Connect to Aomi Build

In **Deployments → New app → Connect an existing repository**, enter the fork
that Aomi Build should read. For this checkout, use:

```text
arixoneth/hoodit-apps
```

The root Project manifest selects the `community` platform and publishes `apps/hoodit/aomi.toml`. Commit and push changes before importing so Build can read the same revision.

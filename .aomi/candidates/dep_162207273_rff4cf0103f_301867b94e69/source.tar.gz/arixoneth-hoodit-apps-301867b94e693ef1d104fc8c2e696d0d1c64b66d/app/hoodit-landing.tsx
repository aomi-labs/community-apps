"use client";

import Image from "next/image";
import { useState } from "react";
import { LiveClip } from "./live-clip";
import { TelegramDemo } from "./telegram-demo";
import { ChartScene, MoneyScene } from "./illustrations";

const qrPattern = [
  "111111101011101111111",
  "100000101010101000001",
  "101110101110101011101",
  "101110100101101011101",
  "101110101011101011101",
  "100000100101001000001",
  "111111101010101111111",
  "000000001101100000000",
  "101111111001011101101",
  "011001001111100010110",
  "110101111010111110011",
  "001110001101000101100",
  "101011111011111011101",
  "000000001100100010010",
  "111111101011101110111",
  "100000101100100010101",
  "101110101011111110111",
  "101110100110100010100",
  "101110101101101111111",
  "100000101010000100100",
  "111111101101111111101",
];

export function HooditLanding() {
  const [qrFront, setQrFront] = useState(false);
  const toggleStage = () => setQrFront((value) => !value);
  const stageKey = (event: React.KeyboardEvent) => {
    if (event.key === "Enter" || event.key === " ") { event.preventDefault(); toggleStage(); }
  };
  return (
    <main className="site-shell">
      <div className="hero-zone">
      <header className="nav-shell">
        <a className="brand" href="#top" aria-label="Hoodit home">
          <Image className="brand-mark" src="/hoodit-logo.jpg" alt="" width={512} height={512} />
          <span>HOODIT</span>
        </a>
        <nav className="nav-links" aria-label="Sections">
          <a href="#demo">Demo</a>
          <a href="#edge">The edge</a>
          <a href="#features">Features</a>
          <a href="#how">How it works</a>
          <a href="#join">Join</a>
        </nav>
        <a className="telegram-link" href="#hero-qr">
          <span aria-hidden="true">↗</span> Telegram
        </a>
      </header>

      <section className="hero" id="top">
        <div className="hero-copy">
          <div className="eyebrow"><span className="eyebrow-live"><i /> LIVE ON</span><strong>ROBINHOOD CHAIN</strong></div>
          <h1>Talk it.<br /><em>Trade it.</em></h1>
          <p className="hero-dek">
            Memecoins, stock tokens and established coins on Robinhood Chain.
            Ask in plain English. Hoodit checks who&rsquo;s buying, who holds it
            and whether your bag can get out.
          </p>
          <div className="hero-actions">
            <button className="primary-button" type="button" aria-pressed={qrFront} onClick={() => setQrFront(true)}>Scan to enter <span>↗</span></button>
            <a className="text-link" href="#demo">Try it first <span>↓</span></a>
          </div>
          <div className="hero-proof">
            <div><strong>WHO&rsquo;S IN</strong><span>KOLs · smart money</span></div>
            <div><strong>WHO HOLDS</strong><span>Dev · top 10 · snipers</span></div>
            <div><strong>CAN IT EXIT</strong><span>Sell quotes at your size</span></div>
          </div>
        </div>

        <div className="hero-poster-wrap" id="hero-qr">
          <div className={`hero-stage${qrFront ? " qr-front" : ""}`}>
            <div className="stage-item stage-video" role="button" tabIndex={0} aria-label={qrFront ? "Bring the bot back to the front" : "Show the QR code"} onClick={toggleStage} onKeyDown={stageKey}>
              <div className="hero-poster plate">
                <video className="poster-cat" src="/hero-cat.mp4" poster="/hero-cat.jpg" autoPlay muted loop playsInline aria-label="Hoodit, a cat wearing a hood" />
                <span className="poster-tag">HOODIT IN THE HOOD</span>
              </div>
            </div>
            <div className="stage-item stage-qr" role="button" tabIndex={0} aria-label={qrFront ? "Bring the bot back to the front" : "Show the QR code"} onClick={toggleStage} onKeyDown={stageKey}>
              <div className="qr-sticker">
                <div className="qr-code is-soon" role="img" aria-label="Hoodit Telegram bot, coming soon">
                  {qrPattern.join("").split("").map((cell, index) => <i key={index} className={cell === "1" ? "filled" : ""} />)}
                  <span><Image src="/hoodit-logo.jpg" alt="" width={512} height={512} /></span>
                  <b className="qr-soon">COMING SOON</b>
                </div>
                <div className="qr-caption"><span>SOON ON</span><b>TELEGRAM</b></div>
              </div>
            </div>
          </div>
          <div className="hero-qr-note"><i /> PRIVATE ACCESS · INSTANT SETUP</div>
        </div>
      </section>

      <div className="tape-x" aria-hidden="true">
        <div className="tape tape-a"><div>WHAT&rsquo;S MOVING RN? <span>✦</span> PONS OR CASHCAT? <span>✦</span> WHO&rsquo;S BUYING PONS? <span>✦</span> IS AI A RUG? <span>✦</span> CAN I GET OUT OF $25K? <span>✦</span> SHOULD I COPY ZEPUMP? <span>✦</span> WHAT&rsquo;S MOVING RN? <span>✦</span> PONS OR CASHCAT? <span>✦</span> WHO&rsquo;S BUYING PONS? <span>✦</span> IS AI A RUG? <span>✦</span> CAN I GET OUT OF $25K? <span>✦</span> SHOULD I COPY ZEPUMP? <span>✦</span></div></div>
        <div className="tape tape-b"><div>MEMECOINS <span>✦</span> STOCK TOKENS <span>✦</span> ESTABLISHED COINS <span>✦</span> TALK IT <span>✦</span> TRADE IT <span>✦</span> THE BOT IN THE HOOD <span>✦</span> MEMECOINS <span>✦</span> STOCK TOKENS <span>✦</span> ESTABLISHED COINS <span>✦</span> TALK IT <span>✦</span> TRADE IT <span>✦</span> THE BOT IN THE HOOD <span>✦</span></div></div>
      </div>

      <section className="widget-demo-section section-shell" id="demo">
        <div className="widget-demo-copy">
          <h2>Try the bot before you scan.</h2>
          <p>This is how Hoodit talks in Telegram: a short line while it checks, then a straight answer. Replayed word for word from live runs.</p>
          <div className="demo-scene-frame">
            <video className="demo-scene" src="/demo-cat.mp4" poster="/demo-cat.jpg" autoPlay muted loop playsInline aria-label="Hoodit in a ninja stance" />
          </div>
        </div>
        <div className="widget-wrap">
          <TelegramDemo />
          <a className="join-link demo-web" href="/app">Or ask it on the web <span>↗</span></a>
        </div>
      </section>
      </div>

      <div className="tape" aria-hidden="true">
        <div>WHO&rsquo;S BUYING <span>✦</span> WHO HOLDS IT <span>✦</span> WHO MADE IT <span>✦</span> CAN IT EXIT <span>✦</span> PING ME <span>✦</span> WHO&rsquo;S BUYING <span>✦</span> WHO HOLDS IT <span>✦</span> WHO MADE IT <span>✦</span> CAN IT EXIT <span>✦</span> PING ME <span>✦</span></div>
      </div>

      <section className="thesis section-shell" id="edge">
        <div className="section-number">01 / THE EDGE</div>
        <div className="thesis-copy">
          <p className="overline">YOUR NEW TRADING DESK</p>
          <h2>Less menu.<br /><em>More signal.</em></h2>
          <p>Hoodit does the homework a careful trader would: the boards, the KOL feed, the card, the chart. Then it gives you its honest read, and &ldquo;nothing clean right now&rdquo; counts as an answer.</p>
        </div>
        <ChartScene className="thesis-scene" />
        <div className="desk-readout plate">
          <div className="desk-status"><span><i /> FROM A LIVE RUN · OCT 6, 2026</span><b>NOT ADVICE</b></div>
          <div className="desk-intent">
            <small>YOUR INTENT</small>
            <p>“gm. what&rsquo;s moving on robinhood chain rn? best 3 max”</p>
            <span>ONE TELEGRAM MESSAGE</span>
          </div>
          <div className="desk-resolve">
            <div><small>01 / SHORTLIST</small><strong>Boards + KOL feed</strong><span>6h movers, established names and fresh smart-money buys.</span></div>
            <div><small>02 / READ</small><strong>Card + chart</strong><span>Holders, dev, security and the chart for the top few, side by side.</span></div>
            <div><small>03 / CALL</small><strong>A straight take</strong><span>pons is the cleanest mover. orbio is sliding, stay out.</span></div>
          </div>
          <div className="desk-ticker" aria-hidden="true">
            <span>PONS 6H <b>+3.7%</b></span><i />
            <span>LIQUIDITY <b>$3.1M</b></span><i />
            <span>HOLDERS <b>101K</b></span><i />
            <span>ORBIO TOP 10 <b>51%</b></span>
          </div>
        </div>
      </section>

      <section className="showcase section-shell" id="features">
        <div className="showcase-head">
          <p className="overline">IN TELEGRAM · ON THE WEB</p>
          <h2>One chat.<br /><em>A whole desk.</em></h2>
          <p>Ask the way you&rsquo;d ask a friend who trades. Memecoins, established coins, stock tokens like NVDA. Every clip below is a real Hoodit answer from a live run on Oct 6, 2026.</p>
        </div>

        <article className="show-row">
          <LiveClip id="copy-kol" label="Hoodit in Telegram checking whether to copy the KOL zepump: a 50% win rate, a lead and not a signal" />
          <div className="show-copy">
            <span className="show-index">01 / WHO&rsquo;S BUYING</span>
            <h3>Who&rsquo;s actually buying.</h3>
            <p>KOL and smart-money wallets by name, whether they still hold, and their real record before you copy anyone. Zepump made $31.3k in 30 days, on a 50% win rate.</p>
            <div className="show-ask"><span>should i just copy whatever zepump buys? he&rsquo;s one of the kols holding meme</span></div>
          </div>
        </article>

        <article className="show-row">
          <LiveClip id="rug-check" label="Hoodit in Telegram screening artificial inu for rug levers: no honeypot, no tax, LP locked, dev sold out" />
          <div className="show-copy">
            <span className="show-index">02 / WHO HOLDS IT</span>
            <h3>Is it a rug?</h3>
            <p>Honeypot, taxes, LP lock, the dev&rsquo;s bag and the top 10, read off the chain one by one. No rug levers still doesn&rsquo;t get called safe.</p>
            <div className="show-ask"><span>is ai (artificial inu) a rug?</span></div>
          </div>
        </article>

        <article className="show-row">
          <LiveClip id="size-ladder" label="Hoodit in Telegram quoting MEME exits from $1k to $1.5m" />
          <div className="show-copy">
            <span className="show-index">03 / CAN IT EXIT</span>
            <h3>Can the bag get out?</h3>
            <p>Live sell quotes at your size before you&rsquo;re in. On MEME, $25k exits for about 3.5%. At $1.5m it&rsquo;s a trap. Quotes, not fills.</p>
            <div className="show-ask"><span>how big can i go on meme and still get out clean?</span></div>
          </div>
        </article>

        <article className="show-row">
          <LiveClip id="ping-me" label="Hoodit in Telegram arming an alert for artificial inu above $0.15, then how the ping lands" />
          <div className="show-copy">
            <span className="show-index">04 / PING ME</span>
            <h3>Ping me when it moves.</h3>
            <p>Alerts on price, the Pons curve, the dev selling or KOLs piling in. When one fires you get a fresh take, never an auto-trade.</p>
            <div className="show-ask"><span>ping me if artificial inu gets back above $0.15</span></div>
            <small className="show-note">The alert firing in this clip is an illustration.</small>
          </div>
        </article>
      </section>

      <section className="flow section-shell" id="how">
        <div className="flow-header">
          <p className="overline">ZERO COMMANDS TO MEMORIZE</p>
          <h2>From question to<br />reviewable trade.</h2>
        </div>
        <div className="flow-steps">
          <article>
            <b className="flow-number">1</b>
            <div className="flow-copy"><h3>Scan</h3><p>Open Hoodit from the QR code and link your Telegram.</p><small className="flow-note">SESSION CREATED IN SECONDS</small></div>
            <div className="flow-visual scan-visual" aria-hidden="true"><i className="scan-ring scan-ring-outer" /><i className="scan-ring scan-ring-inner" /><Image className="scan-mark" src="/hoodit-logo.jpg" alt="" width={512} height={512} /><small className="scan-status">LINKED</small></div>
          </article>
          <article>
            <b className="flow-number">2</b>
            <div className="flow-copy"><h3>Fund</h3><p>Bring ETH to your wallet on Robinhood Chain.</p><small className="flow-note">YOUR BALANCE · YOUR CONTROL</small></div>
            <div className="flow-visual balance-visual"><MoneyScene className="balance-scene" /><div><small className="balance-label">AVAILABLE TO TRADE</small><strong className="balance-amount">$1,240.00</strong><span className="balance-chain"><i /> ETH · ROBINHOOD CHAIN</span></div></div>
          </article>
          <article>
            <b className="flow-number">3</b>
            <div className="flow-copy"><h3>Talk</h3><p>Ask about a coin or name a trade. Hoodit checks the exit, stages the swap, and you sign when it looks right.</p><small className="flow-note">NO COMMAND SYNTAX</small></div>
            <div className="flow-visual talk-visual"><span className="talk-command">“check pons, then buy $25.”</span><i className="talk-arrow">→</i><b className="talk-review">REVIEW TX ↗</b></div>
          </article>
        </div>
      </section>

      <section className="join section-shell" id="join">
        <div className="join-card plate">
          <div className="join-copy">
            <p className="overline">EARLY ACCESS</p>
            <h2>Your next trade starts with a text.</h2>
            <p>Open Hoodit in Telegram, or try it on the web today. Same bot, same wallet, your final say.</p>
            <div className="join-actions">
              <a className="primary-button" href="#hero-qr">Open in Telegram <span>↗</span></a>
              <a className="join-link" href="/app">Or try the web app <span>↗</span></a>
            </div>
          </div>
          <div className="cta-poster">
            <Image className="cta-cat" src="/cta-cat.jpg" alt="Hoodit holding a sword, ready to trade" width={1000} height={1000} />
            <div className="closer-details">
              <div className="closer-row closer-account"><span><i /> @HOODIT_AI</span><b>ONLINE</b></div>
              <div className="closer-row"><span>IDENTITY</span><b>TELEGRAM</b></div>
              <div className="closer-row"><span>SETTLEMENT</span><b>ROBINHOOD CHAIN</b></div>
              <div className="closer-row"><span>FINAL SAY</span><b>ALWAYS YOURS</b></div>
            </div>
          </div>
        </div>
      </section>

      <footer className="footer section-shell">
        <div className="brand footer-brand"><Image className="brand-mark" src="/hoodit-logo.jpg" alt="" width={512} height={512} /><span>HOODIT</span></div>
        <p>Trade the idea. Keep the final say.</p>
        <p className="risk">Hoodit does not provide financial advice. Market numbers on this page come from a live run on Oct 6, 2026; the demo trade is illustrative. Nothing executes until you sign.</p>
        <span>© 2026 HOODIT</span>
      </footer>
    </main>
  );
}

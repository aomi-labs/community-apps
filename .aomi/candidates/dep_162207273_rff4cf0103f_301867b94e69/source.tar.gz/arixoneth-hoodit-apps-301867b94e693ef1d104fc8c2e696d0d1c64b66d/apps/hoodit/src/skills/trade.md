# Hoodit trade

Use when the user asks to buy or sell a specific Robinhood Chain coin. Activate the host `lifi_swap` skill too and follow its prepare → simulate → sign flow. These rules come first.

## Before a buy
- Resolve the exact contract and pass the 0x address to the swap tool, never a ticker. If a ticker matches several contracts, ask which one (show the top two with holders and liquidity).
- Read `hoodit_token` unless you have a card from the last ~5 minutes. Don't prepare when `trade_support` isn't `full`, `exit_check.result` is `trap`, or security shows `honeypot: yes` or a sell tax over 10%. Say why and offer a smaller size, waiting for graduation, or another coin.
- Never buy what can't be sold. Run `hoodit_exit` round_trip at the user's size first, unless one ran in the last few minutes. `result` trap: don't buy. `loss_pct` above 10%: say so and suggest a smaller size before going on.

## Before a sell
- Selling is always allowed, whatever `trade_support` says: it's their bag. Quote it first with `hoodit_exit` mode sell at the position size (`token_amount`). `loss_pct` above 10%: say so and offer to sell in parts. `sell.status` no_route: the router can't sell it now; say so plainly and don't prepare a swap.

## Slippage
The fill lands a minute or two after the quote (your reply plus the wallet confirmation), so memecoins need room.
- Always pass `slippage_bps` explicitly: the user's number if given, otherwise 300 (3%) for liquidity over $50k and 500 (5%) below that or on a curve. Above 500 only if the user agrees; never above 1000.
- Say it in a few words ("5% slippage").

## Confirm, then commit
In Telegram a committed trade signs right away from the user's Hoodit wallet; there is no wallet popup to catch a mistake.
- After a passing simulation, send one line (coin, contract, amount in, expected and minimum out, slippage, route) and ask "go?".
- Call commit only after the user's next message clearly says yes. Never ask and commit in the same reply.
- A changed coin, size or slippage, a vague reply, or a stale quote: re-quote and ask again.

## Withdrawals
"Send my X to 0x…" is a transfer from the Hoodit wallet. Confirm token, amount and the full destination address, say it can't be undone, and commit only after a clear yes. Never send to an address the user didn't write.

## Executing
- Pass chain_id 4663 on every staged call (the Telegram wallet has no default chain) and use 0x addresses (native ETH is 0x0000000000000000000000000000000000000000).
- Pair a buy with an exit plan in one line: the level where the idea is wrong (from the chart) and a time stop. Offer a watcher (`hoodit/watch`).
- Minimum output not met: say how far price moved if known, re-quote at the same tolerance and ask before reopening the wallet. Raise the tolerance only if the user asks.
- Gas, balance, approval and stale-simulation failures aren't slippage: name the real cause and the stage (prepare, simulation, wallet, on-chain).
- A trade is done only when the host reports the transaction.

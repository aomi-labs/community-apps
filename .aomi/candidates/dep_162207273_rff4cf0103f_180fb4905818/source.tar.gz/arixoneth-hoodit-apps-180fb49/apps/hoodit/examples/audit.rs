//! Data-truth check: for each token, the numbers Hoodit still takes from
//! Codex or chain, checked against GMGN at the same moment.
//! `cargo run --example audit -- 0xTOKEN [0xTOKEN ...]`
//! Reads CODEX_MPP_KEY and GMGN_API_KEY from the environment; about three
//! Codex requests and nine GMGN weight per token. Exits 1 on a miss.
use hoodit::domain::pons;
use hoodit::providers::chain::Chain;
use hoodit::providers::codex::{BarSpan, Codex};
use hoodit::providers::gmgn::Gmgn;
use hoodit::runtime::{CODEX_KEY, GMGN_KEY, HooditApp, Turn};
use std::collections::HashSet;

/// Thresholds from the v3 plan.
const PRICE_TOLERANCE: f64 = 0.05;
const CANDLE_TOLERANCE: f64 = 0.02;
const MIN_HOLDER_OVERLAP: usize = 8;
const CURVE_TOLERANCE_PTS: f64 = 1.0;

fn main() {
    let tokens: Vec<String> = std::env::args()
        .skip(1)
        .map(|t| t.to_ascii_lowercase())
        .collect();
    assert!(!tokens.is_empty(), "usage: audit 0xTOKEN [0xTOKEN ...]");
    let app = HooditApp::default();
    let rt = app.runtime().unwrap();
    let ctx = aomi_sdk::testing::TestCtxBuilder::new("audit")
        .secret(CODEX_KEY, std::env::var(CODEX_KEY).expect(CODEX_KEY))
        .secret(GMGN_KEY, std::env::var(GMGN_KEY).expect(GMGN_KEY))
        .build();
    let turn = Turn::new(&ctx, hoodit::runtime::Lane::Chat);
    let mut misses = 0;
    for token in &tokens {
        let lines = rt.tokio.block_on(audit(&rt, &turn, token));
        println!("== {token}");
        for (ok, line) in lines {
            if !ok {
                misses += 1;
            }
            println!("  {} {line}", if ok { "ok  " } else { "MISS" });
        }
    }
    println!("{misses} misses; gaps: {:?}", turn.gaps());
    if misses > 0 {
        std::process::exit(1);
    }
}

async fn audit(rt: &hoodit::runtime::Runtime, turn: &Turn, token: &str) -> Vec<(bool, String)> {
    let gmgn = Gmgn::new(rt, turn);
    let codex = Codex::new(rt, turn);
    let chain = Chain::new(rt, turn);
    let now = hoodit::view::now();
    let span = BarSpan {
        resolution: "15",
        from: now - 6 * 3600,
        to: now + 900,
        bars: 24,
    };
    let (info, holders, gm_holders, bars, codex_token, launch) = tokio::join!(
        gmgn.token_info(token),
        codex.holders(token, 16),
        gmgn.top_holders(token, None),
        codex.bars(token, &span, None),
        codex.token(token),
        chain.pons(token)
    );
    let mut out = vec![];
    if let Err(e) = &gm_holders {
        out.push((false, format!("gmgn holders unavailable: {}", e.message())));
    }
    let Ok(info) = info else {
        return vec![(
            false,
            format!(
                "gmgn token info unavailable: {}",
                info.err().map(|e| e.message()).unwrap_or_default()
            ),
        )];
    };
    let gm_price = info.price.price.get();
    let ratio =
        |a: Option<f64>, b: Option<f64>| a.zip(b).filter(|(_, b)| *b > 0.0).map(|(a, b)| a / b);
    // Price: Codex card fallback vs GMGN.
    if let Ok(t) = &codex_token {
        let r = ratio(t.price_usd.get(), gm_price);
        out.push((
            r.is_some_and(|r| (r - 1.0).abs() <= PRICE_TOLERANCE),
            format!("price codex/gmgn = {:.3}", r.unwrap_or(f64::NAN)),
        ));
    }
    // Candles: the chart's last close vs GMGN's price now.
    if let Ok((b, _)) = &bars {
        let last = b.c.iter().rev().find_map(|c| c.get());
        let r = ratio(last, gm_price);
        out.push((
            r.is_some_and(|r| (r - 1.0).abs() <= CANDLE_TOLERANCE * 2.5),
            format!("last 15m close / gmgn price = {:.3}", r.unwrap_or(f64::NAN)),
        ));
    }
    // Holders: Codex's top 10 wallets vs GMGN's, contracts excluded on both.
    if let (Ok(c), Ok(g)) = (&holders, &gm_holders) {
        let skip = |a: &str| hoodit::domain::holders::contract_label(a).is_some();
        let ours: Vec<String> = c
            .items
            .iter()
            .map(|h| h.address.to_ascii_lowercase())
            .filter(|a| !skip(a) && Some(a) != c.pool.as_ref())
            .take(10)
            .collect();
        let theirs: HashSet<String> = g
            .iter()
            .filter(|h| h.addr_type.get() != Some(2.0))
            .map(|h| h.address.to_ascii_lowercase())
            .filter(|a| !skip(a))
            .take(12)
            .collect();
        let overlap = ours.iter().filter(|a| theirs.contains(*a)).count();
        out.push((
            overlap >= MIN_HOLDER_OVERLAP.min(ours.len()),
            format!(
                "top-10 holder overlap codex vs gmgn = {overlap}/{}",
                ours.len()
            ),
        ));
    }
    // Pons curve from chain vs GMGN's launchpad progress.
    if let Ok(Some(l)) = &launch
        && l.phase == 0
        && let Some(pct) = pons::progress_pct(&chain, l).await
        && let Some(g) = info.launchpad_progress.get()
    {
        let diff = (pct - g * 100.0).abs();
        out.push((
            diff <= CURVE_TOLERANCE_PTS,
            format!("curve chain {pct:.1}% vs gmgn {:.1}%", g * 100.0),
        ));
    }
    out
}

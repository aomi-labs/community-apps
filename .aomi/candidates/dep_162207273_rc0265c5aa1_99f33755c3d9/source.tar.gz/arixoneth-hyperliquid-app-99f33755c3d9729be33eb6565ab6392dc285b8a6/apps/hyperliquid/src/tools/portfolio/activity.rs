use crate::{
    client::HyperliquidApp,
    domain::{
        account::{account, now_ms},
        market::resolve,
    },
};
use aomi_sdk::DynToolCallCtx;
use schemars::JsonSchema;
use serde::Deserialize;
use serde_json::{Value, json};
#[derive(Deserialize, JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum ActivityKind {
    Fills,
    FundingPayments,
    Ledger,
    Transfers,
    TwapHistory,
}
#[derive(Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct ActivityArgs {
    pub kind: ActivityKind,
    pub address: Option<String>,
    pub market: Option<String>,
    pub start_time: Option<u64>,
    pub end_time: Option<u64>,
    pub limit: Option<u16>,
    pub cursor: Option<u64>,
}
pub fn run(app: &HyperliquidApp, args: ActivityArgs, ctx: DynToolCallCtx) -> Result<Value, String> {
    let user = account(&ctx, args.address.as_deref())?;
    let end = args.end_time.unwrap_or_else(now_ms);
    let start = args
        .cursor
        .or(args.start_time)
        .unwrap_or(end.saturating_sub(86400000));
    if start >= end {
        return Err("start_time/cursor must precede end_time".into());
    }
    let limit = args.limit.unwrap_or(100);
    if !(1..=500).contains(&limit) {
        return Err("limit must be 1–500".into());
    }
    let endpoint = match args.kind {
        ActivityKind::Fills => "userFillsByTime",
        ActivityKind::FundingPayments => "userFunding",
        ActivityKind::Ledger | ActivityKind::Transfers => "userNonFundingLedgerUpdates",
        ActivityKind::TwapHistory => "twapHistory",
    };
    let market = args
        .market
        .as_deref()
        .map(|m| resolve(app, m))
        .transpose()?;
    let mut request = json!({"type":endpoint,"user":user});
    if !matches!(args.kind, ActivityKind::TwapHistory) {
        request["startTime"] = json!(start);
        request["endTime"] = json!(end);
    }
    let response = app.venue.info(request)?;
    let rows = response.as_array().ok_or("Malformed account history")?;
    let mut filtered = rows
        .iter()
        .filter(|row| {
            let item = if row["delta"].is_object() {
                &row["delta"]
            } else if row["state"].is_object() {
                &row["state"]
            } else {
                row
            };
            market
                .as_ref()
                .is_none_or(|m| item["coin"].as_str() == Some(&m.coin))
                && (!matches!(args.kind, ActivityKind::Transfers)
                    || item["type"].as_str().is_some_and(|t| {
                        t.to_lowercase().contains("transfer")
                            || t == "deposit"
                            || t == "withdraw"
                            || t == "send"
                    }))
                && row["time"].as_u64().is_none_or(|t| t >= start && t <= end)
        })
        .cloned()
        .collect::<Vec<_>>();
    filtered.sort_by_key(|row| {
        row["time"]
            .as_u64()
            .or_else(|| row["state"]["timestamp"].as_u64())
            .unwrap_or(0)
    });
    // Keep a whole timestamp bucket so the next cursor never skips events sharing a millisecond.
    let cutoff = filtered
        .get(limit as usize - 1)
        .and_then(|row| row["time"].as_u64());
    let truncated = filtered.len() > limit as usize;
    if let Some(cutoff) = cutoff {
        filtered.retain(|row| row["time"].as_u64().is_none_or(|t| t <= cutoff));
    } else {
        filtered.truncate(limit as usize);
    }
    let next = if truncated || rows.len() >= 500 {
        filtered
            .last()
            .and_then(|row| row["time"].as_u64())
            .map(|t| t + 1)
    } else {
        None
    };
    Ok(
        json!({"account":user,"activity":filtered,"next_cursor":next,"source_rows":rows.len(),"pagination_note":"Venue history is bounded. A complete timestamp bucket may exceed limit; use next_cursor for later events."}),
    )
}
read_tool!(
    AccountActivity,
    ActivityArgs,
    "hl_account_activity",
    "Inspect account fills, funding payments, ledger transfers or TWAP history with a bounded time window and timestamp cursor.",
    run
);

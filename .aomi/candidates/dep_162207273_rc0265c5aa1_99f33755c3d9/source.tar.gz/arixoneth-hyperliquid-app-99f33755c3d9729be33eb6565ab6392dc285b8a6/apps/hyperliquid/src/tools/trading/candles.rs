use crate::{
    client::HyperliquidApp,
    domain::{account::now_ms, market::resolve},
};
use aomi_sdk::DynToolCallCtx;
use schemars::JsonSchema;
use serde::Deserialize;
use serde_json::{Value, json};
#[derive(Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct CandlesArgs {
    pub market: String,
    pub interval: String,
    pub start: Option<u64>,
    pub end: Option<u64>,
    pub limit: Option<u16>,
    pub include_incomplete: Option<bool>,
}
pub fn run(app: &HyperliquidApp, args: CandlesArgs, _ctx: DynToolCallCtx) -> Result<Value, String> {
    let milliseconds: u64 = match args.interval.as_str() {
        "1m" => 60000,
        "3m" => 180000,
        "5m" => 300000,
        "15m" => 900000,
        "30m" => 1800000,
        "1h" => 3600000,
        "2h" => 7200000,
        "4h" => 14400000,
        "8h" => 28800000,
        "12h" => 43200000,
        "1d" => 86400000,
        "3d" => 259200000,
        "1w" => 604800000,
        "1M" => 2678400000,
        _ => return Err("Unsupported candle interval".into()),
    };
    let limit = args.limit.unwrap_or(100);
    if !(1..=5000).contains(&limit) {
        return Err("limit must be 1–5000".into());
    }
    let now = now_ms();
    let end = args.end.unwrap_or(now);
    let start = args
        .start
        .unwrap_or(end.saturating_sub(milliseconds * (u64::from(limit) + 1)));
    if start >= end || end > now {
        return Err("Candle range must satisfy start < end <= now".into());
    }
    let market = resolve(app, &args.market)?;
    let response=app.venue.info(json!({"type":"candleSnapshot","req":{"coin":market.coin,"interval":args.interval,"startTime":start,"endTime":end}}))?;
    let mut rows = response
        .as_array()
        .ok_or("Malformed candle response")?
        .iter()
        .filter(|row| {
            args.include_incomplete.unwrap_or(false) || row["T"].as_u64().is_some_and(|t| t <= now)
        })
        .cloned()
        .collect::<Vec<_>>();
    rows.sort_by_key(|row| row["t"].as_u64());
    if rows.len() > limit as usize {
        rows.drain(..rows.len() - limit as usize);
    }
    Ok(
        json!({"market_ref":market.market_ref,"interval":args.interval,"candles":rows,"history_limit":5000}),
    )
}
read_tool!(
    Candles,
    CandlesArgs,
    "hl_candles",
    "Read bounded OHLCV candles. Defaults to completed candles only; venue retains at most 5000 recent candles per interval.",
    run
);

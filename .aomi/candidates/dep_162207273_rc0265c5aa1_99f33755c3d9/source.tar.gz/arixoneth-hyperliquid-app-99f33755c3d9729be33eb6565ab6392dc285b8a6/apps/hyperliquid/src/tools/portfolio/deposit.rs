use aomi_sdk::{DynAomiTool, DynToolCallCtx, EnforcementPolicy, ToolReturn, host};
use rust_decimal::Decimal;
use schemars::JsonSchema;
use serde::Deserialize;
use serde_json::{Value, json};

use crate::{
    client::HyperliquidApp,
    domain::{
        account,
        funding::{
            FundingQuote, FundingRequest, HYPERCORE_CHAIN_ID, approval_transaction, needs_approval,
            validate_quote,
        },
    },
    tools::continuation::CompleteHyperliquidFunding,
};

pub struct PrepareDeposit;

#[derive(Debug, Deserialize, JsonSchema)]
pub struct PrepareDepositArgs {
    /// Human-readable source-token amount. Scientific notation is rejected.
    pub amount: String,
    /// Human chain name/key or numeric chain ID, for example `base` or `8453`.
    pub source_chain: String,
    /// Source token symbol or address, resolved through LI.FI's live catalog.
    pub source_token: String,
    /// Maximum route slippage in basis points. Defaults to 50 (0.5%).
    #[serde(default)]
    pub slippage_bps: Option<u32>,
}

impl DynAomiTool for PrepareDeposit {
    type App = HyperliquidApp;
    type Args = PrepareDepositArgs;
    const NAME: &'static str = "hl_prepare_deposit";
    const DESCRIPTION: &'static str = "Quote and prepare a LI.FI route that credits USDC directly to the connected wallet's HyperCore perpetual balance. The tool validates the executable quote, checks exact ERC-20 allowance, and routes any required approval plus the deposit through wallet simulation and commit.";

    fn run_with_routes(
        app: &HyperliquidApp,
        args: Self::Args,
        ctx: DynToolCallCtx,
    ) -> Result<ToolReturn, String> {
        if app.network != crate::domain::market::Network::Mainnet {
            return Err("LI.FI HyperCore funding is supported on mainnet only".into());
        }
        let token_raw = app.funding.token(&args.source_chain, &args.source_token)?;
        let source_chain_id = token_raw
            .get("chainId")
            .and_then(Value::as_u64)
            .ok_or("LI.FI token lookup omitted chainId")?;
        if source_chain_id == HYPERCORE_CHAIN_ID {
            return Err("the source is already HyperCore; use an internal transfer instead".into());
        }
        if args.slippage_bps.unwrap_or(50) > 1_000 {
            return Err("slippage_bps must not exceed 1000 (10%)".into());
        }
        let amount = Decimal::from_str_exact(&args.amount)
            .map_err(|_| "amount must be a plain positive decimal string")?;
        let wallet = account::wallet(&ctx)?;
        let (source_token, source_token_decimals, _) =
            crate::domain::funding::resolved_token(&token_raw, source_chain_id)?;
        let request = FundingRequest {
            from_chain: source_chain_id,
            from_token: source_token,
            from_decimals: source_token_decimals,
            amount,
            wallet,
            slippage_bps: args.slippage_bps.unwrap_or(50),
        };
        let raw = app.funding.quote(&request)?;
        let quote = validate_quote(&raw, &request)?;

        let allowance = if quote.skip_approval
            || quote
                .from_token
                .eq_ignore_ascii_case(crate::domain::funding::NATIVE_TOKEN)
        {
            "0".to_owned()
        } else {
            let spender = quote
                .approval_address
                .as_deref()
                .ok_or("ERC-20 LI.FI quote omitted approvalAddress")?;
            app.funding.allowance(
                quote.from_chain,
                &quote.from_token,
                &quote.from_address,
                spender,
            )?
        };
        let approval = needs_approval(&quote, &allowance)?
            .then(|| approval_transaction(&quote))
            .transpose()?;
        let started_at_ms = account::now_ms();
        let preview = json!({
            "status":"awaiting_wallet",
            "kind":"hypercore_perp_deposit",
            "account":quote.to_address,
            "source_chain_id":quote.from_chain,
            "source_token":quote.from_token,
            "source_amount":quote.from_amount,
            "expected_credit":quote.to_amount,
            "minimum_credit":quote.to_amount_min,
            "route_tool":quote.route_tool,
            "fees":quote.fee_costs,
            "gas":quote.gas_costs,
            "estimated_seconds":quote.execution_duration_seconds,
            "needs_approval":approval.is_some(),
            "approval_amount":approval.as_ref().map(|_|quote.from_amount.as_str()),
        });
        deposit_route(preview, quote, approval, started_at_ms)
    }
}

fn stage_args(tx: &crate::domain::funding::EvmTransaction, description: &str, kind: &str) -> Value {
    json!({
        "to":tx.to,
        "chain_id":tx.chain_id,
        "description":description,
        "data":{"raw":tx.data},
        "value":tx.value,
        "gas_limit":tx.gas_limit,
        "kind":kind,
    })
}

pub(crate) fn deposit_route(
    preview: Value,
    quote: FundingQuote,
    approval: Option<crate::domain::funding::EvmTransaction>,
    started_at_ms: u64,
) -> Result<ToolReturn, String> {
    let mut stages = Vec::new();
    if let Some(tx) = approval {
        stages.push(stage_args(
            &tx,
            "Approve the exact quoted amount for the quoted LI.FI spender",
            "erc20_approve",
        ));
    }
    stages.push(stage_args(
        &quote.transaction,
        "Deposit through the exact validated LI.FI route into HyperCore perps",
        "hypercore_deposit",
    ));
    let last = stages.len() - 1;
    ToolReturn::route(preview)
        .next(|next| {
            for (index, stage) in stages.into_iter().enumerate() {
                let step = next.add::<host::StageTx>(stage);
                if index == last {
                    step.note("Stage the exact LI.FI transaction without changing its target, value, or calldata. The host must simulate the full staged batch before committing it.")
                        .enforce(EnforcementPolicy::Stop, |enforce| {
                            enforce.add::<host::SimulateBatch>(json!({}));
                            enforce.add::<host::CommitTxs>(json!({}))
                                .bind_as("transaction_hash");
                        });
                } else {
                    step.note("Stage the exact-amount token approval and wait for it to be included in the simulated batch.");
                }
            }
        })
        .after::<CompleteHyperliquidFunding>(json!({
            "kind":"deposit",
            "quote":quote,
            "started_at_ms":started_at_ms,
            "transaction_hash":null,
        }))
        .awaits("transaction_hash")
        .note("The source transaction was submitted. Check LI.FI progress and independently verify the HyperCore ledger credit; pending settlement is not success.")
        .try_build()
        .map_err(|error| format!("could not build deposit route: {error}"))
}

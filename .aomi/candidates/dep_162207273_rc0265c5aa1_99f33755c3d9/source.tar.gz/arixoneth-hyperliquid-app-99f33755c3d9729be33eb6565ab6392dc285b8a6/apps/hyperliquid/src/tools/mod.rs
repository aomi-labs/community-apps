macro_rules! read_tool {
    ($tool:ident, $args:ty, $name:literal, $description:literal, $run:path) => {
        pub struct $tool;
        impl aomi_sdk::DynAomiTool for $tool {
            type App = crate::client::HyperliquidApp;
            type Args = $args;
            const NAME: &'static str = $name;
            const DESCRIPTION: &'static str = $description;
            fn run(
                app: &Self::App,
                args: Self::Args,
                ctx: aomi_sdk::DynToolCallCtx,
            ) -> Result<serde_json::Value, String> {
                $run(app, args, ctx)
            }
        }
    };
}
pub mod continuation;
pub mod portfolio;
pub mod trading;

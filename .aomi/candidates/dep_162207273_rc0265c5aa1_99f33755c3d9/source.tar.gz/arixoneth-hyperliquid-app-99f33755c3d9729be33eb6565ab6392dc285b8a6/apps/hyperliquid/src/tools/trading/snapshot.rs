use crate::{client::HyperliquidApp, domain::market::resolve};
use aomi_sdk::DynToolCallCtx;
use rust_decimal::Decimal;
use schemars::JsonSchema;
use serde::Deserialize;
use serde_json::{Value, json};
use std::str::FromStr;
#[derive(Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct MarketArgs {
    pub market: String,
}
pub fn run(app: &HyperliquidApp, args: MarketArgs, _ctx: DynToolCallCtx) -> Result<Value, String> {
    let market = resolve(app, &args.market)?;
    let book = app
        .venue
        .info(json!({"type":"l2Book","coin":market.coin}))?;
    let bid = book["levels"][0][0]["px"].as_str();
    let ask = book["levels"][1][0]["px"].as_str();
    let spread = bid.zip(ask).and_then(|(b, a)| {
        Some(
            Decimal::from_str(a)
                .ok()?
                .checked_sub(Decimal::from_str(b).ok()?)?
                .normalize()
                .to_string(),
        )
    });
    Ok(
        json!({"mark":market.context["markPx"],"oracle":market.context["oraclePx"],"mid":market.context["midPx"],"funding":market.context["funding"],"volume_24h":market.context["dayNtlVlm"],"open_interest":market.context["openInterest"],"market":market,"best_bid":bid,"best_ask":ask,"spread":spread,"book_time":book["time"]}),
    )
}
read_tool!(
    MarketSnapshot,
    MarketArgs,
    "hl_market_snapshot",
    "Read fresh mark, oracle, funding, volume, open interest, collateral, leverage and best bid/ask for one resolved market.",
    run
);

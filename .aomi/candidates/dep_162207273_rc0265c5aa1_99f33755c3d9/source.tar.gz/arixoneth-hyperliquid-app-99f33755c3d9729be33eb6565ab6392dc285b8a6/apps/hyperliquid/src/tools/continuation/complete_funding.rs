use aomi_sdk::{DynAomiTool, DynToolCallCtx, EnforcementPolicy, ToolReturn, host};
use rust_decimal::Decimal;
use schemars::JsonSchema;
use serde::Deserialize;
use serde_json::{Value, json};

use crate::{
    client::HyperliquidApp,
    domain::{
        account,
        funding::{self, FundingQuote, FundingRequest},
    },
};

pub struct CompleteHyperliquidFunding;

#[derive(Debug, Deserialize, JsonSchema)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum CompleteHyperliquidFundingArgs {
    Deposit {
        quote: FundingQuote,
        started_at_ms: u64,
        transaction_hash: Value,
    },
    Withdrawal {
        account: String,
        recipient: String,
        amount: String,
        started_at_ms: u64,
        arbitrum_from_block: u64,
        #[serde(default)]
        onward_chain: Option<String>,
        #[serde(default)]
        onward_token: Option<String>,
        #[serde(default)]
        onward_slippage_bps: Option<u32>,
    },
    Onward {
        quote: FundingQuote,
        transaction_hash: Value,
    },
}

impl DynAomiTool for CompleteHyperliquidFunding {
    type App = HyperliquidApp;
    type Args = CompleteHyperliquidFundingArgs;
    const NAME: &'static str = "complete_hyperliquid_funding";
    const DESCRIPTION: &'static str = "Verify funding settlement without assuming submission means success. Deposits require LI.FI identity plus a hash-bound HyperCore ledger credit. Withdrawals require a matching HyperCore ledger entry plus the unique Arbitrum USDC bridge Transfer before an onward LI.FI route is prepared.";
    fn run_with_routes(
        app: &HyperliquidApp,
        args: Self::Args,
        ctx: DynToolCallCtx,
    ) -> Result<ToolReturn, String> {
        match args {
            CompleteHyperliquidFundingArgs::Deposit {
                quote,
                started_at_ms,
                transaction_hash,
            } => Ok(ToolReturn::value(deposit_status(
                app,
                &ctx,
                quote,
                started_at_ms,
                transaction_hash,
            )?)),
            CompleteHyperliquidFundingArgs::Onward {
                quote,
                transaction_hash,
            } => Ok(ToolReturn::value(onward_status(
                app,
                &ctx,
                quote,
                transaction_hash,
            )?)),
            CompleteHyperliquidFundingArgs::Withdrawal {
                account: owner,
                recipient,
                amount,
                started_at_ms,
                arbitrum_from_block,
                onward_chain,
                onward_token,
                onward_slippage_bps,
            } => withdrawal_status(
                app,
                &ctx,
                owner,
                recipient,
                amount,
                started_at_ms,
                arbitrum_from_block,
                onward_chain,
                onward_token,
                onward_slippage_bps,
            ),
        }
    }
}

pub fn complete_withdrawal(
    app: &HyperliquidApp,
    value: Value,
    ctx: DynToolCallCtx,
) -> Result<ToolReturn, String> {
    let args: CompleteHyperliquidFundingArgs = serde_json::from_value(value)
        .map_err(|error| format!("invalid withdrawal completion state: {error}"))?;
    match args {
        CompleteHyperliquidFundingArgs::Withdrawal {
            account: owner,
            recipient,
            amount,
            started_at_ms,
            arbitrum_from_block,
            onward_chain,
            onward_token,
            onward_slippage_bps,
        } => withdrawal_status(
            app,
            &ctx,
            owner,
            recipient,
            amount,
            started_at_ms,
            arbitrum_from_block,
            onward_chain,
            onward_token,
            onward_slippage_bps,
        ),
        _ => Err("accepted funding follow-up must be a withdrawal".into()),
    }
}

fn deposit_status(
    app: &HyperliquidApp,
    ctx: &DynToolCallCtx,
    quote: FundingQuote,
    started: u64,
    source: Value,
) -> Result<Value, String> {
    let wallet = account::wallet(ctx)?;
    if !wallet.eq_ignore_ascii_case(&quote.to_address) {
        return Err("connected wallet changed after funding preparation".into());
    }
    let hash = tx_hash(&source)?;
    let raw = app
        .funding
        .status(&hash, &quote.route_tool, quote.from_chain, quote.to_chain)?;
    let status = funding::parse_status(&raw, &hash, &quote)?;
    if matches!(status.state.as_str(), "FAILED" | "INVALID") {
        return Ok(json!({"status":"failed","lifi":status,"source_transaction_hash":hash}));
    }
    let ledger = app
        .venue
        .info(json!({"type":"userNonFundingLedgerUpdates","user":wallet,"startTime":started}))?;
    let credit = match status.receiving_tx_hash.as_deref() {
        Some(receiving) => {
            funding::credited_deposit(&ledger, started, &quote.to_amount_min, receiving)?
        }
        None => None,
    };
    Ok(if status.state == "DONE" && credit.is_some() {
        json!({"status":"credited","lifi":status,"hypercore_ledger_entry":credit,"source_transaction_hash":hash})
    } else {
        json!({"status":if status.state=="DONE"{"pending_hypercore_credit"}else{"pending_settlement"},"lifi":status,"source_transaction_hash":hash,"message":"Retry this continuation; do not submit another deposit."})
    })
}

#[allow(clippy::too_many_arguments)]
fn withdrawal_status(
    app: &HyperliquidApp,
    ctx: &DynToolCallCtx,
    owner: String,
    recipient: String,
    amount: String,
    started: u64,
    from_block: u64,
    onward_chain: Option<String>,
    onward_token: Option<String>,
    slippage: Option<u32>,
) -> Result<ToolReturn, String> {
    let wallet = account::wallet(ctx)?;
    if wallet != account::address(&owner)? {
        return Err("connected wallet changed after withdrawal preparation".into());
    }
    let recipient = account::address(&recipient)?;
    let amount_decimal =
        Decimal::from_str_exact(&amount).map_err(|_| "invalid withdrawal amount")?;
    let amount_base = funding::decimal_to_base_units(amount_decimal, 6)?;
    let ledger = app
        .venue
        .info(json!({"type":"userNonFundingLedgerUpdates","user":wallet,"startTime":started}))?;
    let core = matching_withdrawal(&ledger, started, &amount)?;
    let logs = app.funding.withdrawal_logs(&recipient, from_block)?;
    let settlement_not_before = core
        .as_ref()
        .and_then(|entry| entry.get("time"))
        .and_then(Value::as_u64)
        .unwrap_or(started);
    let arb = funding::settled_withdrawal(&logs, &amount_base, settlement_not_before)?;
    let (core, arb) = match (core, arb) {
        (Some(core), Some(arb)) => (core, arb),
        (core, arb) => {
            return Ok(ToolReturn::value(
                json!({"status":"pending_withdrawal_settlement","hypercore_withdrawal_seen":core.is_some(),"arbitrum_bridge_transfer_seen":arb.is_some(),"message":"Retry this continuation; do not submit another withdrawal."}),
            ));
        }
    };
    let (Some(chain), Some(token)) = (onward_chain, onward_token) else {
        return Ok(ToolReturn::value(
            json!({"status":"settled_on_arbitrum","hypercore_ledger_entry":core,"arbitrum_transfer":arb,"recipient":recipient}),
        ));
    };
    let token_raw = app.funding.token(&chain, &token)?;
    let chain_id = token_raw["chainId"]
        .as_u64()
        .ok_or("LI.FI token lookup omitted chainId")?;
    let (to_token, _, _) = funding::resolved_token(&token_raw, chain_id)?;
    let onward_amount = amount_decimal
        .checked_sub(Decimal::ONE)
        .ok_or("withdrawal does not cover the 1 USDC fee")?;
    let req = FundingRequest {
        from_chain: funding::ARBITRUM_CHAIN_ID,
        from_token: funding::HYPERCORE_PERP_USDC.to_ascii_lowercase(),
        from_decimals: 6,
        amount: onward_amount,
        wallet: recipient.clone(),
        slippage_bps: slippage.unwrap_or(50),
    };
    let raw = app.funding.quote_to(&req, chain_id, &to_token)?;
    let quote = funding::validate_quote_to(&raw, &req, chain_id, &to_token)?;
    let allowance = if quote.skip_approval {
        "0".into()
    } else {
        app.funding.allowance(
            quote.from_chain,
            &quote.from_token,
            &quote.from_address,
            quote
                .approval_address
                .as_deref()
                .ok_or("onward quote omitted approvalAddress")?,
        )?
    };
    let approval = funding::needs_approval(&quote, &allowance)?
        .then(|| funding::approval_transaction(&quote))
        .transpose()?;
    onward_route(
        json!({"status":"awaiting_wallet","kind":"onward_withdrawal","from_chain":quote.from_chain,"to_chain":quote.to_chain,"from_amount":quote.from_amount,"minimum_received":quote.to_amount_min,"needs_approval":approval.is_some(),"verified_withdrawal":{"hypercore":core,"arbitrum":arb}}),
        quote,
        approval,
    )
}

fn onward_route(
    preview: Value,
    quote: FundingQuote,
    approval: Option<funding::EvmTransaction>,
) -> Result<ToolReturn, String> {
    let mut txs = Vec::new();
    if let Some(tx) = approval {
        txs.push((tx, "erc20_approve"));
    }
    txs.push((quote.transaction.clone(), "onward_bridge"));
    let last = txs.len() - 1;
    ToolReturn::route(preview)
        .next(|next| {
            for (index, (tx, kind)) in txs.into_iter().enumerate() {
                let step = next.add::<host::StageTx>(json!({
                    "to":tx.to,
                    "chain_id":tx.chain_id,
                    "data":{"raw":tx.data},
                    "value":tx.value,
                    "gas_limit":tx.gas_limit,
                    "kind":kind,
                    "description":"Exact validated onward withdrawal route",
                }));
                if index == last {
                    step.enforce(EnforcementPolicy::Stop, |enforce| {
                        enforce.add::<host::SimulateBatch>(json!({}));
                        enforce
                            .add::<host::CommitTxs>(json!({}))
                            .bind_as("transaction_hash");
                    });
                }
            }
        })
        .after::<CompleteHyperliquidFunding>(json!({
            "kind":"onward",
            "quote":quote,
            "transaction_hash":null,
        }))
        .awaits("transaction_hash")
        .try_build()
}

fn onward_status(
    app: &HyperliquidApp,
    ctx: &DynToolCallCtx,
    quote: FundingQuote,
    source: Value,
) -> Result<Value, String> {
    let wallet = account::wallet(ctx)?;
    if wallet != quote.from_address {
        return Err("connected wallet changed after onward route preparation".into());
    }
    let hash = tx_hash(&source)?;
    let raw = app
        .funding
        .status(&hash, &quote.route_tool, quote.from_chain, quote.to_chain)?;
    let status = funding::parse_status(&raw, &hash, &quote)?;
    Ok(
        json!({"status":match status.state.as_str(){"DONE"=>"completed","FAILED"|"INVALID"=>"failed",_=>"pending_settlement"},"lifi":status,"source_transaction_hash":hash}),
    )
}

fn matching_withdrawal(
    ledger: &Value,
    started: u64,
    amount: &str,
) -> Result<Option<Value>, String> {
    let entries = ledger
        .as_array()
        .ok_or("Hyperliquid ledger response is not an array")?;
    let found = entries
        .iter()
        .filter(|e| {
            e["time"].as_u64().unwrap_or(0) >= started
                && e["delta"]["type"] == "withdraw"
                && e["delta"]["usdc"].as_str() == Some(amount)
        })
        .cloned()
        .collect::<Vec<_>>();
    match found.as_slice() {
        [] => Ok(None),
        [one] => Ok(Some(one.clone())),
        _ => Err(
            "multiple indistinguishable HyperCore withdrawals matched; settlement is ambiguous"
                .into(),
        ),
    }
}
fn tx_hash(v: &Value) -> Result<String, String> {
    let h = v
        .as_str()
        .or_else(|| {
            v.as_array()
                .and_then(|hashes| hashes.last())
                .and_then(Value::as_str)
        })
        // `commit_txs` preserves staged order. When approval + route are
        // committed together, the route transaction is the final hash.
        .or_else(|| {
            v.get("tx_hashes")
                .and_then(Value::as_array)
                .and_then(|hashes| hashes.last())
                .and_then(Value::as_str)
        })
        .or_else(|| v.get("transaction_hash").and_then(Value::as_str))
        .or_else(|| v.get("tx_hash").and_then(Value::as_str))
        .or_else(|| v.get("hash").and_then(Value::as_str))
        .ok_or("wallet completion is missing source transaction hash")?;
    if h.len() != 66 || !h.starts_with("0x") || !h[2..].bytes().all(|b| b.is_ascii_hexdigit()) {
        return Err("source transaction hash is malformed".into());
    }
    Ok(h.to_ascii_lowercase())
}

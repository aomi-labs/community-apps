use crate::{
    client::HyperliquidApp,
    domain::{
        account::account,
        market::{MarketType, resolve},
    },
};
use aomi_sdk::DynToolCallCtx;
use schemars::JsonSchema;
use serde::Deserialize;
use serde_json::{Value, json};
#[derive(Deserialize, JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum OrderView {
    Open,
    History,
    Status,
}
#[derive(Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct OrdersArgs {
    pub view: OrderView,
    pub address: Option<String>,
    pub market: Option<String>,
    pub order_ref: Option<crate::domain::order::OrderRef>,
    pub include_triggers: Option<bool>,
}
pub fn run(app: &HyperliquidApp, args: OrdersArgs, ctx: DynToolCallCtx) -> Result<Value, String> {
    let user = account(&ctx, args.address.as_deref())?;
    let market = args
        .market
        .as_deref()
        .map(|m| resolve(app, m))
        .transpose()?;
    if let OrderView::Status = args.view {
        let reference = args.order_ref.ok_or("order_ref is required for status")?;
        let selected = resolve(app, &reference.market)?;
        if market
            .as_ref()
            .is_some_and(|m| m.market_ref != selected.market_ref)
        {
            return Err("Order and market selectors disagree".into());
        }
        let oid = reference.order_id;
        let mut result = app
            .venue
            .info(json!({"type":"orderStatus","user":user,"oid":oid}))?;
        if result["order"]["order"]["coin"]
            .as_str()
            .is_some_and(|c| c != selected.coin)
        {
            return Err("Order belongs to another market".into());
        }
        result["order_ref"] = json!({"market":selected.market_ref,"order_id":oid});
        return Ok(result);
    }
    let mut request = json!({"type":match args.view {OrderView::Open=>"frontendOpenOrders",_=>"historicalOrders"},"user":user});
    if let Some(m) = &market {
        request["dex"] = json!(m.dex.as_deref().unwrap_or(""));
    }
    let mut response = app.venue.info(request)?;
    if market.is_none() && matches!(args.view, OrderView::Open) {
        let rows = response.as_array_mut().ok_or("Malformed open orders")?;
        for dex in crate::domain::account::dexes(app, None)?
            .iter()
            .filter(|d| !d.is_empty())
        {
            let additional = app
                .venue
                .info(json!({"type":"frontendOpenOrders","user":user,"dex":dex}))?;
            rows.extend(
                additional
                    .as_array()
                    .ok_or("Malformed DEX open orders")?
                    .iter()
                    .cloned(),
            );
        }
    }
    let rows=response.as_array().ok_or("Malformed order response")?.iter().filter(|row|{
        let order=if row["order"].is_object(){&row["order"]}else{row};
        market.as_ref().is_none_or(|m|order["coin"].as_str()==Some(&m.coin)) && (args.include_triggers.unwrap_or(true)||!order["isTrigger"].as_bool().unwrap_or(false))
    }).map(|row|{let mut row=row.clone();let order=if row["order"].is_object(){&row["order"]}else{&row};let oid=order["oid"].clone();let coin=order["coin"].as_str().unwrap_or("");let kind=if coin.starts_with('@')||coin.contains('/'){MarketType::Spot}else{MarketType::Perp};let kind=match kind {MarketType::Spot=>"spot",MarketType::Perp=>"perp"};row["order_ref"]=json!({"market":format!("hl:{}:{kind}:{coin}",app.network.as_str()),"order_id":oid});row}).collect::<Vec<_>>();
    Ok(json!({"account":user,"orders":rows}))
}
read_tool!(
    Orders,
    OrdersArgs,
    "hl_orders",
    "Inspect open, historical or exact-order status for a connected wallet or public address. Returns stable order references for cancel and modify.",
    run
);

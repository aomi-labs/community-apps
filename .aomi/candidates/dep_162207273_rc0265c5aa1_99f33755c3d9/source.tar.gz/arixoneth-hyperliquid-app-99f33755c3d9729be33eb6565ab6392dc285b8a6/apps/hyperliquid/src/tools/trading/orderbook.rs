use crate::{client::HyperliquidApp, domain::market::resolve};
use aomi_sdk::DynToolCallCtx;
use schemars::JsonSchema;
use serde::Deserialize;
use serde_json::{Value, json};
#[derive(Deserialize, JsonSchema)]
#[serde(tag = "kind", rename_all = "snake_case", deny_unknown_fields)]
pub enum BookAggregation {
    FullPrecision,
    SignificantFigures { digits: u8, mantissa: Option<u8> },
}
#[derive(Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct OrderBookArgs {
    pub market: String,
    pub depth: Option<u8>,
    pub aggregation: Option<BookAggregation>,
}
pub fn run(
    app: &HyperliquidApp,
    args: OrderBookArgs,
    _ctx: DynToolCallCtx,
) -> Result<Value, String> {
    let depth = args.depth.unwrap_or(10);
    if !(1..=20).contains(&depth) {
        return Err("depth must be 1–20".into());
    }
    let market = resolve(app, &args.market)?;
    let mut request = json!({"type":"l2Book","coin":market.coin});
    if let Some(BookAggregation::SignificantFigures { digits, mantissa }) = args.aggregation {
        if !(2..=5).contains(&digits) {
            return Err("Significant figures must be 2–5".into());
        }
        request["nSigFigs"] = json!(digits);
        if let Some(m) = mantissa {
            if digits != 5 || ![1, 2, 5].contains(&m) {
                return Err("Mantissa 1, 2 or 5 requires five significant figures".into());
            }
            request["mantissa"] = json!(m);
        }
    }
    let mut book = app.venue.info(request)?;
    if let Some(levels) = book["levels"].as_array_mut() {
        for side in levels {
            if let Some(rows) = side.as_array_mut() {
                rows.truncate(depth as usize);
            }
        }
    }
    Ok(json!({"market_ref":market.market_ref,"book":book}))
}
read_tool!(
    OrderBook,
    OrderBookArgs,
    "hl_orderbook",
    "Read up to 20 levels per side with explicit full precision or significant-figure aggregation. Preserves the canonical DEX-qualified market.",
    run
);

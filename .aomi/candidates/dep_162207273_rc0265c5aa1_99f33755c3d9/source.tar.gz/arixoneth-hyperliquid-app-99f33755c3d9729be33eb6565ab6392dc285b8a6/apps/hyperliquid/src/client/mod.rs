pub mod hypersdk;

use crate::domain::market::Network;
use serde_json::Value;
use std::sync::Arc;

/// Venue boundary shared by live adapters and deterministic fixture tests.
pub trait HyperliquidVenue: Send + Sync {
    fn info(&self, request: Value) -> Result<Value, String>;
    fn exchange(&self, request: Value) -> Result<Value, String>;
}

#[derive(Clone)]
pub struct HyperliquidApp {
    pub venue: Arc<dyn HyperliquidVenue>,
    pub network: Network,
    pub funding: Arc<dyn crate::domain::funding::FundingVenue>,
}

impl HyperliquidApp {
    pub fn new(network: Network, venue: Arc<dyn HyperliquidVenue>) -> Self {
        Self {
            venue,
            network,
            funding: Arc::new(crate::domain::funding::LifiFundingVenue::default()),
        }
    }
    pub fn with_funding(mut self, funding: Arc<dyn crate::domain::funding::FundingVenue>) -> Self {
        self.funding = funding;
        self
    }
}

impl Default for HyperliquidApp {
    fn default() -> Self {
        Self::new(
            Network::Mainnet,
            Arc::new(hypersdk::HyperSdkVenue::mainnet()),
        )
    }
}

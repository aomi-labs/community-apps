use aomi_sdk::{DynAomiTool, DynToolCallCtx, ToolReturn};
use rust_decimal::Decimal;
use schemars::JsonSchema;
use serde::Deserialize;
use serde_json::json;

use crate::{
    client::HyperliquidApp,
    domain::{account, signing},
};

pub struct PrepareTransfer;

#[derive(Debug, Deserialize, JsonSchema)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum TransferIntent {
    SpotToPerp {
        amount: String,
        #[serde(default)]
        subaccount: Option<String>,
    },
    PerpToSpot {
        amount: String,
        #[serde(default)]
        subaccount: Option<String>,
    },
    SendUsdc {
        amount: String,
        destination: String,
    },
    SendSpot {
        amount: String,
        token: String,
        destination: String,
    },
    MoveCollateral {
        amount: String,
        token: String,
        source_dex: String,
        destination_dex: String,
        #[serde(default)]
        from_subaccount: Option<String>,
        #[serde(default)]
        destination: Option<String>,
    },
}

#[derive(Debug, Deserialize, JsonSchema)]
pub struct PrepareTransferArgs {
    pub intent: TransferIntent,
}

impl DynAomiTool for PrepareTransfer {
    type App = HyperliquidApp;
    type Args = PrepareTransferArgs;
    const NAME: &'static str = "hl_prepare_transfer";
    const DESCRIPTION: &'static str = "Prepare an exact signed HyperCore balance transfer: spot/perp USDC, USDC or spot sends, owned-subaccount movement, or supported DEX collateral movement. Arbitrary raw actions are not accepted.";

    fn run_with_routes(
        app: &HyperliquidApp,
        args: Self::Args,
        ctx: DynToolCallCtx,
    ) -> Result<ToolReturn, String> {
        let wallet = account::wallet(&ctx)?;
        let (action, summary) = match args.intent {
            TransferIntent::SpotToPerp { amount, subaccount } => {
                validate_owned_subaccount(app, &wallet, subaccount.as_deref())?;
                class_transfer(amount, subaccount, true)?
            }
            TransferIntent::PerpToSpot { amount, subaccount } => {
                validate_owned_subaccount(app, &wallet, subaccount.as_deref())?;
                class_transfer(amount, subaccount, false)?
            }
            TransferIntent::SendUsdc {
                amount,
                destination,
            } => {
                let amount = amount_string(&amount, 6)?;
                let destination = account::address(&destination)?;
                (
                    json!({"type":"usdSend","destination":destination,"amount":amount}),
                    json!({"direction":"send_usdc","destination":destination,"amount":amount}),
                )
            }
            TransferIntent::SendSpot {
                amount,
                token,
                destination,
            } => {
                let amount = amount_string(&amount, 8)?;
                validate_token_id(&token)?;
                let destination = account::address(&destination)?;
                (
                    json!({"type":"spotSend","destination":destination,"token":token,"amount":amount}),
                    json!({"direction":"send_spot","destination":destination,"token":token,"amount":amount}),
                )
            }
            TransferIntent::MoveCollateral {
                amount,
                token,
                source_dex,
                destination_dex,
                from_subaccount,
                destination,
            } => {
                let amount = amount_string(&amount, 8)?;
                validate_supported_dex(app, &source_dex)?;
                validate_supported_dex(app, &destination_dex)?;
                validate_token_id(&token)?;
                if source_dex == destination_dex {
                    return Err("source_dex and destination_dex must differ".into());
                }
                let from_subaccount = from_subaccount
                    .as_deref()
                    .map(account::address)
                    .transpose()?
                    .unwrap_or_default();
                validate_owned_subaccount(
                    app,
                    &wallet,
                    (!from_subaccount.is_empty()).then_some(from_subaccount.as_str()),
                )?;
                let destination = destination
                    .as_deref()
                    .map(account::address)
                    .transpose()?
                    .unwrap_or_else(|| wallet.clone());
                (
                    json!({"type":"sendAsset","destination":destination,"sourceDex":source_dex,"destinationDex":destination_dex,"token":token,"amount":amount,"fromSubAccount":from_subaccount}),
                    json!({"direction":"move_collateral","destination":destination,"source_dex":source_dex,"destination_dex":destination_dex,"token":token,"amount":amount,"from_subaccount":from_subaccount}),
                )
            }
        };
        signing::prepare(
            app,
            &ctx,
            action,
            json!({"kind":"hypercore_transfer","account":wallet,"transfer":summary}),
        )
    }
}

fn validate_owned_subaccount(
    app: &HyperliquidApp,
    wallet: &str,
    subaccount: Option<&str>,
) -> Result<(), String> {
    let Some(subaccount) = subaccount else {
        return Ok(());
    };
    let subaccount = account::address(subaccount)?;
    let response = app
        .venue
        .info(json!({"type":"subAccounts","user":wallet}))?;
    let owned = response.as_array().is_some_and(|entries| {
        entries.iter().any(|entry| {
            entry
                .get("subAccountUser")
                .and_then(serde_json::Value::as_str)
                .is_some_and(|candidate| candidate.eq_ignore_ascii_case(&subaccount))
        })
    });
    if !owned {
        return Err("the requested subaccount is not owned by the connected wallet".into());
    }
    Ok(())
}

fn class_transfer(
    amount: String,
    subaccount: Option<String>,
    to_perp: bool,
) -> Result<(serde_json::Value, serde_json::Value), String> {
    let mut amount = amount_string(&amount, 6)?;
    let subaccount = subaccount.as_deref().map(account::address).transpose()?;
    if let Some(address) = &subaccount {
        amount.push_str(" subaccount:");
        amount.push_str(address);
    }
    Ok((
        json!({"type":"usdClassTransfer","amount":amount,"toPerp":to_perp}),
        json!({"direction":if to_perp{"spot_to_perp"}else{"perp_to_spot"},"amount":amount,"subaccount":subaccount}),
    ))
}

fn amount_string(value: &str, max_scale: u32) -> Result<String, String> {
    let amount = Decimal::from_str_exact(value)
        .map_err(|_| "amount must be a plain positive decimal string")?;
    if amount <= Decimal::ZERO {
        return Err("amount must be greater than zero".into());
    }
    if amount.scale() > max_scale {
        return Err(format!(
            "amount supports at most {max_scale} decimal places"
        ));
    }
    Ok(amount.normalize().to_string())
}

fn validate_token_id(value: &str) -> Result<(), String> {
    let Some((name, id)) = value.split_once(':') else {
        return Err("token must use Hyperliquid name:id form".into());
    };
    if name.is_empty()
        || id.len() != 34
        || !id.starts_with("0x")
        || !id[2..].bytes().all(|b| b.is_ascii_hexdigit())
    {
        return Err("invalid Hyperliquid spot token identifier".into());
    }
    Ok(())
}
fn validate_supported_dex(app: &HyperliquidApp, value: &str) -> Result<(), String> {
    if value == "spot" || value.is_empty() {
        return Ok(());
    }
    if !value
        .bytes()
        .all(|b| b.is_ascii_alphanumeric() || b == b'_' || b == b'-')
    {
        return Err("invalid DEX name".into());
    }
    let dexes = app.venue.info(json!({"type":"perpDexs"}))?;
    if dexes.as_array().is_some_and(|entries| {
        entries.iter().any(|entry| {
            entry
                .get("name")
                .and_then(serde_json::Value::as_str)
                .is_some_and(|name| name == value)
        })
    }) {
        Ok(())
    } else {
        Err(format!("unsupported Hyperliquid DEX: {value}"))
    }
}

use aomi_sdk::DynToolCallCtx;

pub fn address(value: &str) -> Result<String, String> {
    if value.len() != 42
        || !value.starts_with("0x")
        || !value[2..].bytes().all(|b| b.is_ascii_hexdigit())
    {
        return Err("Expected a 20-byte EVM address".into());
    }
    Ok(value.to_ascii_lowercase())
}

pub fn wallet(ctx: &DynToolCallCtx) -> Result<String, String> {
    address(
        &ctx.attribute_string(&["domain", "evm", "address"])
            .ok_or("Connect an EVM wallet before using this tool")?,
    )
}

pub fn account(ctx: &DynToolCallCtx, explicit: Option<&str>) -> Result<String, String> {
    match explicit {
        Some(value) => address(value),
        None => wallet(ctx),
    }
}

pub fn now_ms() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis() as u64
}

/// Enumerate DEX names without dropping the native DEX's null metadata entry.
pub fn dexes(
    app: &crate::client::HyperliquidApp,
    selected: Option<&str>,
) -> Result<Vec<String>, String> {
    if let Some(name) = selected {
        return Ok(vec![name.to_string()]);
    }
    let response = app.venue.info(serde_json::json!({"type":"perpDexs"}))?;
    Ok(response
        .as_array()
        .ok_or("Malformed DEX list")?
        .iter()
        .map(|dex| dex["name"].as_str().unwrap_or("").to_string())
        .collect())
}

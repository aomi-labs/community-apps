use crate::{
    client::HyperliquidApp,
    domain::{
        account::wallet,
        market::resolve,
        order::{OrderRef, decimal, round_price, round_size, wire_decimal},
    },
};
use aomi_sdk::{DynAomiTool, DynToolCallCtx, ToolReturn, schemars::JsonSchema};
use rust_decimal::Decimal;
use serde::Deserialize;
use serde_json::{Value, json};
use std::str::FromStr;
pub struct PrepareModify;
#[derive(Debug, Deserialize, JsonSchema)]
pub struct ModifyOrder {
    pub order_ref: OrderRef,
    pub new_price: Option<String>,
    pub new_remaining_size: Option<String>,
}
#[derive(Debug, Deserialize, JsonSchema)]
pub struct PrepareModifyArgs {
    pub modifications: Vec<ModifyOrder>,
}
impl DynAomiTool for PrepareModify {
    type App = HyperliquidApp;
    type Args = PrepareModifyArgs;
    const NAME: &'static str = "hl_prepare_modify";
    const DESCRIPTION: &'static str = "Modify the price or remaining size of exact currently-open orders; fails if any original order disappeared.";
    fn run_with_routes(
        app: &Self::App,
        args: Self::Args,
        ctx: DynToolCallCtx,
    ) -> Result<ToolReturn, String> {
        if args.modifications.is_empty() || args.modifications.len() > 100 {
            return Err("modifications must contain 1..=100 entries".into());
        }
        let address = wallet(&ctx)?;
        let mut out = Vec::new();
        let mut preview = Vec::new();
        for change in args.modifications {
            if change.new_price.is_none() && change.new_remaining_size.is_none() {
                return Err("each modification needs new_price or new_remaining_size".into());
            }
            let m = resolve(app, &change.order_ref.market)?;
            let open=app.venue.info(json!({"type":"frontendOpenOrders","user":address,"dex":m.dex.as_deref().unwrap_or("")}))?;
            let open = open
                .as_array()
                .ok_or("open orders response must be an array")?;
            let original = open
                .iter()
                .find(|o| {
                    o.get("oid").and_then(Value::as_u64) == Some(change.order_ref.order_id)
                        && (o.get("coin").and_then(Value::as_str) == Some(m.coin.as_str())
                            || o.get("coin").and_then(Value::as_str) == Some(m.symbol.as_str()))
                })
                .ok_or_else(|| {
                    format!(
                        "order {} disappeared or is no longer open",
                        change.order_ref.order_id
                    )
                })?;
            let price = match change.new_price {
                Some(v) => decimal(&v, "new_price")?,
                None => Decimal::from_str(
                    original
                        .get("limitPx")
                        .or_else(|| original.get("px"))
                        .and_then(Value::as_str)
                        .ok_or("original order price missing")?,
                )
                .map_err(|_| "original order price invalid")?,
            };
            let size = match change.new_remaining_size {
                Some(v) => round_size(decimal(&v, "new_remaining_size")?, &m)?,
                None => round_size(
                    Decimal::from_str(
                        original
                            .get("sz")
                            .and_then(Value::as_str)
                            .ok_or("original remaining size missing")?,
                    )
                    .map_err(|_| "original remaining size invalid")?,
                    &m,
                )?,
            };
            let is_buy = original
                .get("side")
                .and_then(Value::as_str)
                .map(|s| s == "B")
                .or_else(|| original.get("isBuy").and_then(Value::as_bool))
                .ok_or("original order side missing")?;
            let reduce = original
                .get("reduceOnly")
                .and_then(Value::as_bool)
                .unwrap_or(false);
            let wire_price = wire_decimal(round_price(price, &m)?);
            let order_type = original
                .get("orderType")
                .and_then(Value::as_str)
                .unwrap_or("");
            let trigger_px = original
                .get("triggerPx")
                .and_then(Value::as_str)
                .filter(|value| Decimal::from_str(value).is_ok_and(|value| !value.is_zero()));
            let wire_type = if let Some(trigger_px) = trigger_px {
                let purpose = if order_type.to_ascii_lowercase().contains("take profit") {
                    "tp"
                } else if order_type.to_ascii_lowercase().contains("stop") {
                    "sl"
                } else {
                    return Err("original trigger purpose is unavailable; refusing to change order semantics".into());
                };
                json!({"trigger":{"isMarket":order_type.to_ascii_lowercase().contains("market"),"triggerPx":wire_decimal(round_price(decimal(trigger_px,"original trigger price")?,&m)?),"tpsl":purpose}})
            } else {
                let tif = original.get("tif").and_then(Value::as_str).unwrap_or("Gtc");
                if !matches!(tif, "Gtc" | "Ioc" | "Alo") {
                    return Err("original order has an unsupported time in force".into());
                }
                json!({"limit":{"tif":tif}})
            };
            let order = json!({"a":m.asset_id,"b":is_buy,"p":wire_price.clone(),"s":wire_decimal(size),"r":reduce,"t":wire_type});
            out.push(json!({"oid":change.order_ref.order_id,"order":order}));
            preview.push(json!({"market_ref":m.market_ref,"order_id":change.order_ref.order_id,"new_price":wire_price,"new_remaining_size":wire_decimal(size)}));
        }
        let action = if out.len() == 1 {
            let one = out.remove(0);
            json!({"type":"modify","oid":one["oid"],"order":one["order"]})
        } else {
            json!({"type":"batchModify","modifies":out})
        };
        crate::domain::signing::prepare(
            app,
            &ctx,
            action,
            json!({"kind":"modify","account":address,"modifications":preview}),
        )
    }
}

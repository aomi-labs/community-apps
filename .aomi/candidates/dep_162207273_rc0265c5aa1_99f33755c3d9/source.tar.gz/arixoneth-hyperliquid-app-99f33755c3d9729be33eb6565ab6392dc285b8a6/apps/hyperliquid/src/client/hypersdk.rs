use serde_json::Value;
use std::{thread, time::Duration};

use super::HyperliquidVenue;

/// Blocking HTTP venue used by the dynamic app boundary.
///
/// Signing is deliberately kept out of this type. The wallet signs through the
/// host and the continuation passes an already verified exchange envelope here.
#[derive(Clone)]
pub struct HyperSdkVenue {
    base_url: String,
    client: reqwest::blocking::Client,
}

impl HyperSdkVenue {
    pub fn mainnet() -> Self {
        Self::with_base_url("https://api.hyperliquid.xyz")
    }

    pub fn testnet() -> Self {
        Self::with_base_url("https://api.hyperliquid-testnet.xyz")
    }

    pub fn with_base_url(base_url: impl Into<String>) -> Self {
        Self {
            base_url: base_url.into().trim_end_matches('/').to_owned(),
            client: reqwest::blocking::Client::new(),
        }
    }

    fn post(&self, path: &str, request: Value, retry_rate_limits: bool) -> Result<Value, String> {
        let mut attempt = 0u8;
        let response = loop {
            let response = self
                .client
                .post(format!("{}{path}", self.base_url))
                .timeout(Duration::from_secs(20))
                .json(&request)
                .send()
                .map_err(|error| {
                    format!("hyperliquid request failed before a response: {error}")
                })?;
            if !(retry_rate_limits && response.status().as_u16() == 429 && attempt < 2) {
                break response;
            }
            attempt += 1;
            thread::sleep(Duration::from_millis(250 * u64::from(attempt)));
        };
        let status = response.status();
        let body = response
            .text()
            .map_err(|error| format!("hyperliquid response body could not be read: {error}"))?;
        if !status.is_success() {
            let mut safe_body = body;
            if safe_body.len() > 2048 {
                safe_body.truncate(2048);
                safe_body.push('…');
            }
            if safe_body.to_ascii_lowercase().contains("signature") {
                safe_body = "[redacted venue response containing signature metadata]".to_owned();
            }
            return Err(format!("hyperliquid HTTP {status}: {safe_body}"));
        }
        serde_json::from_str(&body)
            .map_err(|error| format!("hyperliquid returned invalid JSON: {error}; body={body}"))
    }
}

impl HyperliquidVenue for HyperSdkVenue {
    fn info(&self, request: Value) -> Result<Value, String> {
        self.post("/info", request, true)
    }

    fn exchange(&self, request: Value) -> Result<Value, String> {
        // Exchange writes are never retried: a lost response is ambiguous.
        self.post("/exchange", request, false)
    }
}

use std::{collections::HashMap, str::FromStr};

use aomi_sdk::{DynAomiTool, DynToolCallCtx, ToolReturn, schemars::JsonSchema};
use rust_decimal::Decimal;
use serde::Deserialize;
use serde_json::{Value, json};

use crate::{
    client::HyperliquidApp,
    domain::{
        account::wallet,
        market::{Market, resolve},
        order::*,
    },
};

pub struct PrepareOrder;

#[derive(Debug, Deserialize, JsonSchema)]
pub struct PrepareOrderArgs {
    pub intent: OrderIntent,
}

pub(crate) fn mids(value: Value) -> Result<HashMap<String, Decimal>, String> {
    let object = value
        .as_object()
        .ok_or("allMids response must be an object")?;
    object
        .iter()
        .map(|(key, value)| {
            let raw = value
                .as_str()
                .ok_or_else(|| format!("mid for {key} is not a decimal string"))?;
            Decimal::from_str(raw)
                .map(|v| (key.clone(), v))
                .map_err(|_| format!("invalid mid for {key}"))
        })
        .collect()
}

pub(crate) fn mid_for(all: &HashMap<String, Decimal>, market: &Market) -> Result<Decimal, String> {
    all.get(&market.coin)
        .or_else(|| all.get(&market.symbol))
        .copied()
        .ok_or_else(|| format!("no live mid for {}", market.market_ref))
}

fn compile_spec(
    app: &HyperliquidApp,
    spec: &OrderSpec,
    all_mids: &mut HashMap<String, HashMap<String, Decimal>>,
) -> Result<(Market, Value), String> {
    let market = resolve(app, &spec.market)?;
    if !market.active {
        return Err(format!("market {} is inactive", market.market_ref));
    }
    let dex_key = market.dex.clone().unwrap_or_default();
    let mut live_mid = || -> Result<Decimal, String> {
        if !all_mids.contains_key(&dex_key) {
            let response = app
                .venue
                .info(json!({"type":"allMids","dex":market.dex.as_deref().unwrap_or("")}))?;
            all_mids.insert(dex_key.clone(), mids(response)?);
        }
        mid_for(all_mids.get(&dex_key).expect("inserted"), &market)
    };
    let reference_price = match &spec.order_type {
        OrderType::Limit { price, .. } => decimal(price, "price")?,
        OrderType::Market { .. } => live_mid()?,
        OrderType::Trigger {
            trigger_price,
            execution,
            ..
        } => match execution {
            TriggerExecution::Market => decimal(trigger_price, "trigger_price")?,
            TriggerExecution::Limit { price } => decimal(price, "execution.price")?,
        },
    };
    let size = round_size(spec.size.base_at(reference_price)?, &market)?;
    let value = match &spec.order_type {
        OrderType::Limit {
            price,
            time_in_force,
        } => limit_order(
            &market,
            spec.side,
            size,
            decimal(price, "price")?,
            *time_in_force,
            spec.reduce_only,
        )?,
        OrderType::Market { max_slippage_bps } => {
            let px = market_price(live_mid()?, spec.side, *max_slippage_bps)?;
            let px = ioc_bound_price(px, &market, spec.side)?;
            limit_order(
                &market,
                spec.side,
                size,
                px,
                TimeInForce::Ioc,
                spec.reduce_only,
            )?
        }
        OrderType::Trigger {
            purpose,
            trigger_price,
            execution,
        } => trigger_order(
            &market,
            spec.side,
            size,
            decimal(trigger_price, "trigger_price")?,
            execution,
            *purpose,
            spec.reduce_only,
        )?,
    };
    let compiled_price = value
        .get("p")
        .and_then(Value::as_str)
        .ok_or_else(|| "compiled order omitted price".to_string())
        .and_then(|price| decimal(price, "compiled price"))?;
    validate_min_notional(size, compiled_price, spec.reduce_only)?;
    Ok((market, value))
}

pub(crate) fn position(
    app: &HyperliquidApp,
    address: &str,
    market: &Market,
) -> Result<(Decimal, Side), String> {
    let response = app
        .venue
        .info(json!({"type":"clearinghouseState","user":address,"dex":market.dex.as_deref().unwrap_or("")}))?;
    let positions = response
        .get("assetPositions")
        .and_then(Value::as_array)
        .ok_or("clearinghouseState omitted assetPositions")?;
    for item in positions {
        let p = item.get("position").unwrap_or(item);
        if p.get("coin").and_then(Value::as_str) == Some(market.coin.as_str()) {
            let szi = Decimal::from_str(
                p.get("szi")
                    .and_then(Value::as_str)
                    .ok_or("position szi missing")?,
            )
            .map_err(|_| "position szi invalid")?;
            if szi == Decimal::ZERO {
                return Err("position has zero size".into());
            }
            return Ok((
                szi.abs(),
                if szi > Decimal::ZERO {
                    Side::Sell
                } else {
                    Side::Buy
                },
            ));
        }
    }
    Err(format!("no open position for {}", market.market_ref))
}

pub(crate) fn fraction_size(total: Decimal, size: &ProtectionSize) -> Result<Decimal, String> {
    match size {
        ProtectionSize::FullPosition => Ok(total),
        ProtectionSize::Base { quantity } => {
            let q = decimal(quantity, "size.quantity")?;
            if q > total {
                Err("protection size exceeds position".into())
            } else {
                Ok(q)
            }
        }
        ProtectionSize::PositionFractionBps { bps } => {
            if *bps == 0 || *bps > 10_000 {
                return Err("position fraction bps must be 1..=10000".into());
            }
            total
                .checked_mul(Decimal::from(*bps))
                .and_then(|value| value.checked_div(Decimal::from(10_000u32)))
                .ok_or_else(|| "position fraction overflowed decimal range".into())
        }
    }
}

#[derive(Debug, serde::Serialize, Deserialize)]
pub struct PrepareProtectionAfterCancelArgs {
    pub market_ref: String,
    pub size: ProtectionSize,
    pub take_profit: Option<ProtectionLeg>,
    pub stop_loss: Option<ProtectionLeg>,
    pub canceled_order_ids: Vec<u64>,
    pub account: String,
}

pub fn prepare_protection_after_cancel(
    app: &HyperliquidApp,
    args: PrepareProtectionAfterCancelArgs,
    ctx: DynToolCallCtx,
) -> Result<ToolReturn, String> {
    let account = wallet(&ctx)?;
    if account != args.account {
        return Err("connected wallet changed during protection replacement".into());
    }
    let market = resolve(app, &args.market_ref)?;
    let open = app
        .venue
        .info(json!({"type":"frontendOpenOrders","user":account,"dex":market.dex.as_deref().unwrap_or("")}))?;
    let open = open
        .as_array()
        .ok_or("open orders response must be an array")?;
    if let Some(still_open) = args.canceled_order_ids.iter().find(|oid| {
        open.iter()
            .any(|order| order.get("oid").and_then(Value::as_u64) == Some(**oid))
    }) {
        return Err(format!(
            "protection order {still_open} is still open; replacement halted"
        ));
    }
    let (total, side) = position(app, &account, &market)?;
    let size = round_size(fraction_size(total, &args.size)?, &market)?;
    let mut orders = Vec::new();
    if let Some(leg) = args.take_profit {
        orders.push(trigger_order(
            &market,
            side,
            size,
            decimal(&leg.trigger_price, "take_profit.trigger_price")?,
            &leg.execution,
            TriggerPurpose::TakeProfit,
            true,
        )?);
    }
    if let Some(leg) = args.stop_loss {
        orders.push(trigger_order(
            &market,
            side,
            size,
            decimal(&leg.trigger_price, "stop_loss.trigger_price")?,
            &leg.execution,
            TriggerPurpose::StopLoss,
            true,
        )?);
    }
    if orders.is_empty() {
        return Err("replacement protection has no legs".into());
    }
    let action = order_action(orders.clone(), "positionTpsl");
    crate::domain::signing::prepare(
        app,
        &ctx,
        action,
        json!({"kind":"replace_position_protection","account":account,"market_ref":market.market_ref,"gap_disclosure":"Old protection was canceled before this fresh position check and replacement signature.","orders":orders}),
    )
}

impl DynAomiTool for PrepareOrder {
    type App = HyperliquidApp;
    type Args = PrepareOrderArgs;
    const NAME: &'static str = "hl_prepare_order";
    const DESCRIPTION: &'static str = "Prepare exact Hyperliquid limit, market, batch, bracket, position protection, or ladder orders and route wallet signing.";
    fn run_with_routes(
        app: &Self::App,
        args: Self::Args,
        ctx: DynToolCallCtx,
    ) -> Result<ToolReturn, String> {
        let address = wallet(&ctx)?;
        let mut all_mids = HashMap::new();
        let mut orders = Vec::new();
        let mut refs = Vec::new();
        let mut grouping = "na";
        match args.intent {
            OrderIntent::Orders { orders: specs } => {
                if specs.is_empty() || specs.len() > 100 {
                    return Err("orders must contain 1..=100 entries".into());
                }
                for s in specs {
                    let (m, o) = compile_spec(app, &s, &mut all_mids)?;
                    refs.push(m.market_ref);
                    orders.push(o);
                }
            }
            OrderIntent::Bracket {
                entry,
                take_profit,
                stop_loss,
            } => {
                if take_profit.is_none() && stop_loss.is_none() {
                    return Err("bracket requires take_profit or stop_loss".into());
                }
                let (m, e) = compile_spec(app, &entry, &mut all_mids)?;
                let size = e
                    .get("s")
                    .and_then(Value::as_str)
                    .ok_or_else(|| "compiled entry size missing".to_string())
                    .and_then(|size| decimal(size, "compiled entry size"))?;
                let protective_side = if entry.side.is_buy() {
                    Side::Sell
                } else {
                    Side::Buy
                };
                orders.push(e);
                refs.push(m.market_ref.clone());
                if let Some(leg) = take_profit {
                    orders.push(trigger_order(
                        &m,
                        protective_side,
                        size,
                        decimal(&leg.trigger_price, "take_profit.trigger_price")?,
                        &leg.execution,
                        TriggerPurpose::TakeProfit,
                        true,
                    )?);
                }
                if let Some(leg) = stop_loss {
                    orders.push(trigger_order(
                        &m,
                        protective_side,
                        size,
                        decimal(&leg.trigger_price, "stop_loss.trigger_price")?,
                        &leg.execution,
                        TriggerPurpose::StopLoss,
                        true,
                    )?);
                }
                grouping = "normalTpsl";
            }
            OrderIntent::ProtectPosition {
                market,
                size,
                take_profit,
                stop_loss,
                replace_existing,
            } => {
                if take_profit.is_none() && stop_loss.is_none() {
                    return Err("position protection requires take_profit or stop_loss".into());
                }
                let m = resolve(app, &market)?;
                if replace_existing {
                    let open = app
                        .venue
                        .info(json!({"type":"frontendOpenOrders","user":address,"dex":m.dex.as_deref().unwrap_or("")}))?;
                    let mut canceled = Vec::new();
                    for order in open
                        .as_array()
                        .ok_or("open orders response must be an array")?
                    {
                        let same_market = order
                            .get("coin")
                            .and_then(Value::as_str)
                            .is_some_and(|coin| coin == m.coin || coin == m.symbol);
                        let protection = order
                            .get("isPositionTpsl")
                            .and_then(Value::as_bool)
                            .unwrap_or(false)
                            || (order
                                .get("isTrigger")
                                .and_then(Value::as_bool)
                                .unwrap_or(false)
                                && order
                                    .get("reduceOnly")
                                    .and_then(Value::as_bool)
                                    .unwrap_or(false));
                        if same_market && protection {
                            canceled.push(
                                order
                                    .get("oid")
                                    .and_then(Value::as_u64)
                                    .ok_or("protection order missing oid")?,
                            );
                        }
                    }
                    if !canceled.is_empty() {
                        let cancels = canceled
                            .iter()
                            .map(|oid| json!({"a":m.asset_id,"o":oid}))
                            .collect::<Vec<_>>();
                        let followup = PrepareProtectionAfterCancelArgs {
                            market_ref: m.market_ref.clone(),
                            size,
                            take_profit,
                            stop_loss,
                            canceled_order_ids: canceled.clone(),
                            account: address.clone(),
                        };
                        let state = serde_json::to_value(followup).map_err(|e| e.to_string())?;
                        return crate::domain::signing::prepare_with_followup(
                            app,
                            &ctx,
                            json!({"type":"cancel","cancels":cancels}),
                            json!({"kind":"replace_position_protection_cancel","account":address,"market_ref":m.market_ref,"frozen_order_ids":canceled,"gap_disclosure":"If this cancellation succeeds, old protection is removed before a fresh position check and a second replacement signature. The sequence halts on rejection or ambiguity."}),
                            crate::domain::signing::OnAccept::ProtectionAfterCancel(state),
                        );
                    }
                }
                let (total, side) = position(app, &address, &m)?;
                let qty = round_size(fraction_size(total, &size)?, &m)?;
                refs.push(m.market_ref.clone());
                if let Some(leg) = take_profit {
                    orders.push(trigger_order(
                        &m,
                        side,
                        qty,
                        decimal(&leg.trigger_price, "take_profit.trigger_price")?,
                        &leg.execution,
                        TriggerPurpose::TakeProfit,
                        true,
                    )?);
                }
                if let Some(leg) = stop_loss {
                    orders.push(trigger_order(
                        &m,
                        side,
                        qty,
                        decimal(&leg.trigger_price, "stop_loss.trigger_price")?,
                        &leg.execution,
                        TriggerPurpose::StopLoss,
                        true,
                    )?);
                }
                grouping = "positionTpsl";
            }
            OrderIntent::Ladder {
                market,
                side,
                total_size,
                start_price,
                end_price,
                levels,
                allocation,
                reduce_only,
            } => {
                let m = resolve(app, &market)?;
                let prices = ladder_prices(
                    decimal(&start_price, "start_price")?,
                    decimal(&end_price, "end_price")?,
                    levels,
                )?;
                let sizes = match (allocation, total_size) {
                    (LadderAllocation::EqualSize, SizeSpec::Base { quantity }) => {
                        vec![
                            decimal(&quantity, "total_size.quantity")?
                                .checked_div(Decimal::from(levels))
                                .ok_or("ladder allocation overflowed decimal range")?;
                            levels as usize
                        ]
                    }
                    (LadderAllocation::EqualNotional, SizeSpec::Base { quantity }) => {
                        let total = decimal(&quantity, "total_size.quantity")?;
                        let reciprocal_sum = prices.iter().try_fold(Decimal::ZERO, |sum, p| {
                            Decimal::ONE
                                .checked_div(*p)
                                .and_then(|v| sum.checked_add(v))
                                .ok_or("ladder allocation overflowed decimal range")
                        })?;
                        let unit = total
                            .checked_div(reciprocal_sum)
                            .ok_or("ladder allocation overflowed decimal range")?;
                        prices
                            .iter()
                            .map(|p| {
                                unit.checked_div(*p)
                                    .ok_or("ladder allocation overflowed decimal range")
                            })
                            .collect::<Result<Vec<_>, _>>()?
                    }
                    (LadderAllocation::EqualSize, SizeSpec::QuoteNotional { amount }) => {
                        let notional = decimal(&amount, "total_size.amount")?;
                        let price_sum = prices.iter().try_fold(Decimal::ZERO, |sum, p| {
                            sum.checked_add(*p)
                                .ok_or("ladder allocation overflowed decimal range")
                        })?;
                        let each_size = notional
                            .checked_div(price_sum)
                            .ok_or("ladder allocation overflowed decimal range")?;
                        vec![each_size; levels as usize]
                    }
                    (LadderAllocation::EqualNotional, SizeSpec::QuoteNotional { amount }) => {
                        let each = decimal(&amount, "total_size.amount")?
                            .checked_div(Decimal::from(levels))
                            .ok_or("ladder allocation overflowed decimal range")?;
                        prices
                            .iter()
                            .map(|price| {
                                each.checked_div(*price)
                                    .ok_or("ladder allocation overflowed decimal range")
                            })
                            .collect::<Result<Vec<_>, _>>()?
                    }
                };
                refs.push(m.market_ref.clone());
                for (px, sz) in prices.into_iter().zip(sizes) {
                    let rounded_size = round_size(sz, &m)?;
                    let compiled_price = exact_price(px, &m)?;
                    validate_min_notional(rounded_size, compiled_price, reduce_only)?;
                    orders.push(limit_order(
                        &m,
                        side,
                        rounded_size,
                        compiled_price,
                        TimeInForce::Gtc,
                        reduce_only,
                    )?);
                }
            }
        }
        let action = order_action(orders.clone(), grouping);
        let preview = json!({"kind":"orders","account":address,"markets":refs,"grouping":grouping,"orders":orders});
        crate::domain::signing::prepare(app, &ctx, action, preview)
    }
}

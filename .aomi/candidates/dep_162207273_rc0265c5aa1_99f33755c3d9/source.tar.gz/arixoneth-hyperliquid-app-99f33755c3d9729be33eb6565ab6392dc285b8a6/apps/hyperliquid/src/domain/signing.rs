use std::{
    collections::HashMap,
    str::FromStr,
    sync::{LazyLock, Mutex},
    time::{SystemTime, UNIX_EPOCH},
};

use alloy::dyn_abi::TypedData;
use alloy::signers::k256::ecdsa::RecoveryId;
use aomi_sdk::{DynToolCallCtx, ToolReturn, host};
use chrono::{DateTime, Utc};
use hypersdk::hypercore::{Chain, Signature, types::Action};
use serde::{Deserialize, Serialize};
use serde_json::{Map, Value, json};

use crate::{
    client::HyperliquidApp, domain::market::Network, tools::continuation::SubmitHyperliquidAction,
};

const VERSION: u8 = 1;
const L1_EXPIRY_MS: u64 = 120_000;
static LAST_NONCE: LazyLock<Mutex<HashMap<(String, String), u64>>> =
    LazyLock::new(|| Mutex::new(HashMap::new()));

#[derive(Debug, Clone, Serialize, Deserialize, schemars::JsonSchema)]
pub struct PreparedHyperliquidAction {
    pub version: u8,
    pub network: Network,
    pub expected_signer: String,
    pub action: Value,
    pub nonce: u64,
    pub vault_address: Option<String>,
    pub expires_after: Option<u64>,
    pub prehash: String,
    pub created_at_ms: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize, schemars::JsonSchema)]
#[serde(tag = "kind", content = "args", rename_all = "snake_case")]
pub enum OnAccept {
    CompleteFunding(Value),
    ProtectionAfterCancel(Value),
    TwapCancels(Value),
}

pub fn connected_signer(ctx: &DynToolCallCtx) -> Result<String, String> {
    let signer = ctx
        .attribute_string(&["domain", "evm", "address"])
        .ok_or("a connected EVM wallet is required")?;
    let address = alloy::primitives::Address::from_str(&signer)
        .map_err(|_| "connected EVM wallet address is invalid".to_string())?;
    Ok(address.to_string().to_lowercase())
}

fn now_ms() -> Result<u64, String> {
    Ok(SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_err(|_| "system clock is before the Unix epoch".to_string())?
        .as_millis() as u64)
}

fn next_nonce(network: Network, signer: &str, now: u64) -> Result<u64, String> {
    let mut nonces = LAST_NONCE
        .lock()
        .map_err(|_| "nonce allocator lock poisoned".to_string())?;
    let key = (network.as_str().to_owned(), signer.to_owned());
    let nonce = now.max(
        nonces
            .get(&key)
            .copied()
            .unwrap_or_default()
            .saturating_add(1),
    );
    nonces.insert(key, nonce);
    Ok(nonce)
}

pub fn chain(network: Network) -> Chain {
    match network {
        Network::Mainnet => Chain::Mainnet,
        Network::Testnet => Chain::Testnet,
    }
}

fn is_user_signed(kind: &str) -> bool {
    matches!(
        kind,
        "usdSend"
            | "spotSend"
            | "sendAsset"
            | "sendToEvmWithData"
            | "approveAgent"
            | "approveBuilderFee"
            | "convertToMultiSigUser"
            | "userDexAbstraction"
            | "userSetAbstraction"
            | "userPortfolioMargin"
            | "linkStakingUser"
            | "stakingLinkDisableTradingUser"
            | "withdraw3"
            | "usdClassTransfer"
            | "tokenDelegate"
    )
}

fn prepare_user_fields(action: &mut Value, network: Network, nonce: u64) -> Result<(), String> {
    let object = action
        .as_object_mut()
        .ok_or("action must be a JSON object")?;
    object.insert(
        "hyperliquidChain".into(),
        json!(match network {
            Network::Mainnet => "Mainnet",
            Network::Testnet => "Testnet",
        }),
    );
    object.insert(
        "signatureChainId".into(),
        json!(match network {
            // Match the official Python SDK. This is a signing-domain selector,
            // not a request to switch the connected wallet's active network.
            Network::Mainnet | Network::Testnet => "0x66eee",
        }),
    );
    let kind = object
        .get("type")
        .and_then(Value::as_str)
        .unwrap_or_default();
    if matches!(kind, "usdSend" | "spotSend" | "withdraw3") {
        object.insert("time".into(), json!(nonce));
    } else {
        object.insert("nonce".into(), json!(nonce));
    }
    lowercase_addresses(object);
    Ok(())
}

fn lowercase_addresses(object: &mut Map<String, Value>) {
    const FIELDS: &[&str] = &[
        "destination",
        "fromSubAccount",
        "agentAddress",
        "builder",
        "user",
        "validator",
        "tradingUser",
        "destinationRecipient",
    ];
    for field in FIELDS {
        if let Some(Value::String(value)) = object.get_mut(*field)
            && value.starts_with("0x")
        {
            *value = value.to_lowercase();
        }
    }
}

fn user_schema(kind: &str) -> Option<(&'static str, &'static [(&'static str, &'static str)])> {
    const USD: &[(&str, &str)] = &[
        ("hyperliquidChain", "string"),
        ("destination", "string"),
        ("amount", "string"),
        ("time", "uint64"),
    ];
    const SPOT: &[(&str, &str)] = &[
        ("hyperliquidChain", "string"),
        ("destination", "string"),
        ("token", "string"),
        ("amount", "string"),
        ("time", "uint64"),
    ];
    const SEND: &[(&str, &str)] = &[
        ("hyperliquidChain", "string"),
        ("destination", "string"),
        ("sourceDex", "string"),
        ("destinationDex", "string"),
        ("token", "string"),
        ("amount", "string"),
        ("fromSubAccount", "string"),
        ("nonce", "uint64"),
    ];
    const CLASS: &[(&str, &str)] = &[
        ("hyperliquidChain", "string"),
        ("amount", "string"),
        ("toPerp", "bool"),
        ("nonce", "uint64"),
    ];
    const AGENT: &[(&str, &str)] = &[
        ("hyperliquidChain", "string"),
        ("agentAddress", "address"),
        ("agentName", "string"),
        ("nonce", "uint64"),
    ];
    const BUILDER: &[(&str, &str)] = &[
        ("hyperliquidChain", "string"),
        ("maxFeeRate", "string"),
        ("builder", "address"),
        ("nonce", "uint64"),
    ];
    const DEX: &[(&str, &str)] = &[
        ("hyperliquidChain", "string"),
        ("user", "address"),
        ("enabled", "bool"),
        ("nonce", "uint64"),
    ];
    const SET: &[(&str, &str)] = &[
        ("hyperliquidChain", "string"),
        ("user", "address"),
        ("abstraction", "string"),
        ("nonce", "uint64"),
    ];
    const CONVERT: &[(&str, &str)] = &[
        ("hyperliquidChain", "string"),
        ("signers", "string"),
        ("nonce", "uint64"),
    ];
    const TOKEN_DELEGATE: &[(&str, &str)] = &[
        ("hyperliquidChain", "string"),
        ("validator", "address"),
        ("wei", "uint64"),
        ("isUndelegate", "bool"),
        ("nonce", "uint64"),
    ];
    match kind {
        "usdSend" => Some(("UsdSend", USD)),
        // The exchange action is named withdraw3, but the official EIP-712
        // primary type is HyperliquidTransaction:Withdraw (without the 3).
        "withdraw3" => Some(("Withdraw", USD)),
        "spotSend" => Some(("SpotSend", SPOT)),
        "sendAsset" => Some(("SendAsset", SEND)),
        "usdClassTransfer" => Some(("UsdClassTransfer", CLASS)),
        "approveAgent" => Some(("ApproveAgent", AGENT)),
        "approveBuilderFee" => Some(("ApproveBuilderFee", BUILDER)),
        "userDexAbstraction" => Some(("UserDexAbstraction", DEX)),
        "userPortfolioMargin" => Some(("UserPortfolioMargin", DEX)),
        "userSetAbstraction" => Some(("UserSetAbstraction", SET)),
        "convertToMultiSigUser" => Some(("ConvertToMultiSigUser", CONVERT)),
        "tokenDelegate" => Some(("TokenDelegate", TOKEN_DELEGATE)),
        _ => None,
    }
}

pub fn typed_data(
    action: &Action,
    action_json: &Value,
    nonce: u64,
    vault: Option<alloy::primitives::Address>,
    expires: Option<u64>,
    network: Network,
) -> Result<Value, String> {
    let kind = action_json
        .get("type")
        .and_then(Value::as_str)
        .ok_or("action.type is required")?;
    let data = if let Some((name, fields)) = user_schema(kind) {
        let message = action_json
            .as_object()
            .ok_or("action must be an object")?
            .iter()
            .filter(|(key, _)| key.as_str() != "type" && key.as_str() != "signatureChainId")
            .map(|(key, value)| (key.clone(), value.clone()))
            .collect::<Map<_, _>>();
        let primary = format!("HyperliquidTransaction:{name}");
        json!({
            "domain":{"name":"HyperliquidSignTransaction","version":"1","chainId":action_json["signatureChainId"].as_str().and_then(|id|u64::from_str_radix(id.trim_start_matches("0x"),16).ok()).ok_or("invalid signatureChainId")?,"verifyingContract":"0x0000000000000000000000000000000000000000"},
            "types":{"EIP712Domain":[{"name":"name","type":"string"},{"name":"version","type":"string"},{"name":"chainId","type":"uint256"},{"name":"verifyingContract","type":"address"}], (primary.clone()): fields.iter().map(|(name,kind)|json!({"name":name,"type":kind})).collect::<Vec<_>>()},
            "primaryType":primary,"message":message
        })
    } else if is_user_signed(kind) {
        return Err(format!(
            "external typed-data signing for `{kind}` is not implemented"
        ));
    } else {
        let connection_id = action
            .hash(nonce, vault, expires)
            .map_err(|e| format!("could not hash action: {e}"))?;
        json!({
            "domain":{"name":"Exchange","version":"1","chainId":1337,"verifyingContract":"0x0000000000000000000000000000000000000000"},
            "types":{"EIP712Domain":[{"name":"name","type":"string"},{"name":"version","type":"string"},{"name":"chainId","type":"uint256"},{"name":"verifyingContract","type":"address"}],"Agent":[{"name":"source","type":"string"},{"name":"connectionId","type":"bytes32"}]},
            "primaryType":"Agent","message":{"source":match network {Network::Mainnet=>"a",Network::Testnet=>"b"},"connectionId":connection_id.to_string()}
        })
    };
    let parsed: TypedData = serde_json::from_value(data.clone())
        .map_err(|e| format!("invalid generated typed data: {e}"))?;
    let actual = parsed
        .eip712_signing_hash()
        .map_err(|e| format!("could not hash typed data: {e}"))?;
    // L1 actions are checked against hypersdk's msgpack/Agent implementation.
    // Direct user actions are intentionally independent because hypersdk 0.2.15
    // calls withdraw3's primary type `Withdraw3`, while the official SDK and
    // exchange use `Withdraw`.
    if !is_user_signed(kind) {
        let expected = action
            .prehash(
                nonce,
                vault,
                expires.and_then(|ms| DateTime::<Utc>::from_timestamp_millis(ms as i64)),
                chain(network),
            )
            .map_err(|e| format!("could not derive SDK prehash: {e}"))?;
        if actual != expected {
            return Err("generated typed data does not match hypersdk prehash".into());
        }
    }
    Ok(data)
}

pub fn action_prehash(
    action: &Action,
    action_json: &Value,
    nonce: u64,
    vault: Option<alloy::primitives::Address>,
    expires: Option<u64>,
    network: Network,
) -> Result<alloy::primitives::B256, String> {
    let kind = action_json
        .get("type")
        .and_then(Value::as_str)
        .ok_or("action.type is required")?;
    if is_user_signed(kind) {
        let value = typed_data(action, action_json, nonce, vault, None, network)?;
        let data: TypedData = serde_json::from_value(value)
            .map_err(|e| format!("invalid generated typed data: {e}"))?;
        data.eip712_signing_hash()
            .map_err(|e| format!("could not hash typed data: {e}"))
    } else {
        action
            .prehash(
                nonce,
                vault,
                expires.and_then(|ms| DateTime::<Utc>::from_timestamp_millis(ms as i64)),
                chain(network),
            )
            .map_err(|e| format!("could not derive SDK prehash: {e}"))
    }
}

pub fn recover_signer(
    signature: &Signature,
    prehash: alloy::primitives::B256,
) -> Result<String, String> {
    let recovery = u8::try_from(signature.v)
        .ok()
        .and_then(|v| v.checked_sub(27))
        .and_then(RecoveryId::from_byte)
        .ok_or_else(|| format!("invalid signature recovery id {}", signature.v))?;
    let signature = alloy::signers::Signature::new(signature.r, signature.s, recovery.is_y_odd());
    signature
        .recover_address_from_prehash(&prehash)
        .map(|address| address.to_string().to_lowercase())
        .map_err(|e| format!("could not recover Hyperliquid signer: {e}"))
}

pub fn prepare(
    app: &HyperliquidApp,
    ctx: &DynToolCallCtx,
    action_json: Value,
    preview: Value,
) -> Result<ToolReturn, String> {
    prepare_inner(app, ctx, action_json, preview, None)
}

pub fn prepare_with_followup(
    app: &HyperliquidApp,
    ctx: &DynToolCallCtx,
    action_json: Value,
    preview: Value,
    followup: OnAccept,
) -> Result<ToolReturn, String> {
    prepare_inner(app, ctx, action_json, preview, Some(followup))
}

fn prepare_inner(
    app: &HyperliquidApp,
    ctx: &DynToolCallCtx,
    mut action_json: Value,
    preview: Value,
    followup: Option<OnAccept>,
) -> Result<ToolReturn, String> {
    let signer = connected_signer(ctx)?;
    let created = now_ms()?;
    let nonce = next_nonce(app.network, &signer, created)?;
    let kind = action_json
        .get("type")
        .and_then(Value::as_str)
        .ok_or("action.type is required")?
        .to_owned();
    if is_user_signed(&kind) {
        prepare_user_fields(&mut action_json, app.network, nonce)?;
    }
    let action: Action = serde_json::from_value(action_json.clone())
        .map_err(|e| format!("invalid Hyperliquid action: {e}"))?;
    let expires = (!is_user_signed(&kind)).then_some(created + L1_EXPIRY_MS);
    let prehash = action_prehash(&action, &action_json, nonce, None, expires, app.network)?;
    let wallet_request = json!({"typed_data":typed_data(&action,&action_json,nonce,None,expires,app.network)?,"description":format!("Authorize the reviewed Hyperliquid {kind} action")});
    let prepared = PreparedHyperliquidAction {
        version: VERSION,
        network: app.network,
        expected_signer: signer,
        action: action_json,
        nonce,
        vault_address: None,
        expires_after: expires,
        prehash: prehash.to_string(),
        created_at_ms: created,
    };
    Ok(ToolReturn::route(
        json!({"status":"awaiting_wallet_signature","preview":preview,"reviewed_action":&prepared.action,"nonce":prepared.nonce,"expires_after":prepared.expires_after,"prepared":&prepared}),
    )
    .next(|next| {
        next.add::<host::EvmCommitMessage>(wallet_request)
            .bind_as("hyperliquid_signature")
            .note("Sign the exact reviewed Hyperliquid action.");
    })
    .after::<SubmitHyperliquidAction>(json!({"prepared":prepared,"hyperliquid_signature":null,"followup":followup}))
    .awaits("hyperliquid_signature")
    .note("Signature received; verify and submit the exact prepared action.")
    .build())
}

pub fn parse_signature(value: Value) -> Result<Signature, String> {
    let raw = match value {
        Value::String(value) => value,
        Value::Object(mut object) => object
            .remove("signature")
            .and_then(|v| v.as_str().map(ToOwned::to_owned))
            .ok_or("wallet callback is missing signature")?,
        _ => return Err("wallet callback has an unsupported signature shape".into()),
    };
    let bytes = hex::decode(raw.strip_prefix("0x").unwrap_or(&raw))
        .map_err(|_| "wallet signature is not valid hex")?;
    if bytes.len() != 65 {
        return Err("wallet signature must be exactly 65 bytes".into());
    }
    let mut normalized = bytes;
    normalized[64] = match normalized[64] {
        0 | 1 => normalized[64] + 27,
        27 | 28 => normalized[64],
        _ => return Err("wallet signature recovery id must be 0, 1, 27, or 28".into()),
    };
    Signature::from_str(&format!("0x{}", hex::encode(normalized)))
        .map_err(|e| format!("invalid wallet signature: {e}"))
}

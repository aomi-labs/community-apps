use aomi_sdk::{DynAomiTool, DynToolCallCtx, ToolReturn};
use rust_decimal::Decimal;
use schemars::JsonSchema;
use serde::Deserialize;
use serde_json::json;

use crate::{
    client::HyperliquidApp,
    domain::{account, signing},
};

pub struct PrepareWithdraw;

#[derive(Debug, Deserialize, JsonSchema)]
pub struct PrepareWithdrawArgs {
    /// Human-readable USDC amount to withdraw from HyperCore perps.
    pub amount: String,
    /// Arbitrum recipient. Omit to use the connected wallet.
    #[serde(default)]
    pub recipient: Option<String>,
    /// Optional final EVM chain after Arbitrum settlement. This is informational
    /// until the withdrawal is credited; a fresh LI.FI quote is required then.
    #[serde(default)]
    pub onward_chain_id: Option<u64>,
    /// Optional final-chain token address paired with onward_chain_id.
    #[serde(default)]
    pub onward_token: Option<String>,
}

impl DynAomiTool for PrepareWithdraw {
    type App = HyperliquidApp;
    type Args = PrepareWithdrawArgs;
    const NAME: &'static str = "hl_prepare_withdraw";
    const DESCRIPTION: &'static str = "Prepare a gasless Hyperliquid withdraw3 action from the connected wallet's perpetual balance to Arbitrum. HyperCore cannot currently be quoted as a LI.FI source, so onward bridging is only prepared after Arbitrum settlement and is never reported as complete early.";

    fn run_with_routes(
        app: &HyperliquidApp,
        args: Self::Args,
        ctx: DynToolCallCtx,
    ) -> Result<ToolReturn, String> {
        let amount = Decimal::from_str_exact(&args.amount)
            .map_err(|_| "amount must be a plain positive decimal string")?;
        if amount <= Decimal::ZERO {
            return Err("amount must be greater than zero".into());
        }
        if amount.scale() > 6 {
            return Err("USDC withdrawal supports at most 6 decimal places".into());
        }
        if args.onward_chain_id.is_some() != args.onward_token.is_some() {
            return Err("onward_chain_id and onward_token must be supplied together".into());
        }
        let wallet = account::wallet(&ctx)?;
        let recipient = args
            .recipient
            .as_deref()
            .map(account::address)
            .transpose()?
            .unwrap_or_else(|| wallet.clone());
        let started_at_ms = account::now_ms();
        let arbitrum_from_block = app
            .funding
            .block_number(crate::domain::funding::ARBITRUM_CHAIN_ID)?;
        let action = json!({
            "type":"withdraw3",
            "destination":recipient,
            "amount":amount.normalize().to_string(),
        });
        let preview = json!({
            "kind":"hypercore_withdrawal",
            "account":wallet,
            "amount":amount.normalize().to_string(),
            "recipient":recipient,
            "settlement_chain_id":42161,
            "withdrawal_fee_usdc":"1",
            "estimated_settlement_seconds":300,
            "started_at_ms":started_at_ms,
            "arbitrum_from_block":arbitrum_from_block,
            "onward":args.onward_chain_id.map(|chain_id|json!({
                "status":"awaiting_arbitrum_settlement",
                "chain_id":chain_id,
                "token":args.onward_token,
                "message":"After withdraw3 is accepted, call complete_hyperliquid_funding with the reviewed withdrawal metadata. It must observe the withdrawal ledger entry and the Arbitrum USDC balance increase before preparing a fresh LI.FI route."
            })),
        });
        signing::prepare_with_followup(
            app,
            &ctx,
            action,
            preview,
            signing::OnAccept::CompleteFunding(json!({
                "kind":"withdrawal","account":wallet,"recipient":recipient,
                "amount":amount.normalize().to_string(),"started_at_ms":started_at_ms,
                "arbitrum_from_block":arbitrum_from_block,
                "onward_chain":args.onward_chain_id.map(|value|value.to_string()),
                "onward_token":args.onward_token,"onward_slippage_bps":50
            })),
        )
    }
}

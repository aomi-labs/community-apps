use aomi_sdk::*;
pub mod client;
pub mod domain;
pub mod tools;

dyn_aomi_app!(
    app = client::HyperliquidApp, name = "hyperliquid", version = "0.2.0",
    preamble = include_str!("preamble.md"),
    tools = [tools::continuation::SubmitHyperliquidAction, tools::continuation::CompleteHyperliquidFunding],
    namespaces = ["evm-core"],
    skills = [
        { id: "hyperliquid/portfolio", description: "Inspect and manage accounts, balances, positions, funding and transfers", tags: ["portfolio", "balance", "position", "margin", "deposit", "withdraw", "transfer", "history"], tools: [tools::portfolio::Portfolio, tools::portfolio::AccountActivity, tools::portfolio::PrepareDeposit, tools::portfolio::PrepareWithdraw, tools::portfolio::PrepareTransfer], sections: { instructions: "skills/portfolio/instructions.md", workflows: "skills/portfolio/workflows.md", safety: "skills/portfolio/safety.md" }, },
        { id: "hyperliquid/trading", description: "Research markets and trade spot, native perpetuals and HIP-3 markets", tags: ["trade", "order", "perp", "spot", "market", "orderbook", "candles", "funding", "twap"], tools: [tools::trading::Markets, tools::trading::MarketSnapshot, tools::trading::OrderBook, tools::trading::Candles, tools::trading::Funding, tools::trading::Orders, tools::trading::PrepareOrder, tools::trading::PrepareCancel, tools::trading::PrepareModify, tools::trading::PrepareClose, tools::trading::PrepareTwap, tools::trading::PrepareRisk], sections: { instructions: "skills/trading/instructions.md", execution: "skills/trading/execution.md", safety: "skills/trading/safety.md" }, },
        { id: "hyperliquid/hip3", description: "Apply DEX identity, collateral and execution rules to HIP-3 markets", tags: ["hip3", "hip-3", "dex", "xyz"], tools: [], sections: { instructions: "skills/hip3.md" }, },
        { id: "hyperliquid/rwa", description: "Understand reference prices, sessions and derivative exposure for stock, index and commodity markets", tags: ["rwa", "stocks", "equities", "commodities"], tools: [], sections: { instructions: "skills/rwa.md" }, },
        { id: "hyperliquid/order-strategies", description: "Use brackets, TP/SL, ladders and native TWAP", tags: ["tp", "sl", "stop", "bracket", "twap", "ladder"], tools: [], sections: { instructions: "skills/order-strategies.md" }, },
        { id: "hyperliquid/risk", description: "Reason about leverage, margin, liquidation and exposure", tags: ["risk", "leverage", "margin", "liquidation", "funding"], tools: [], sections: { instructions: "skills/risk.md" }, },
    ],
);

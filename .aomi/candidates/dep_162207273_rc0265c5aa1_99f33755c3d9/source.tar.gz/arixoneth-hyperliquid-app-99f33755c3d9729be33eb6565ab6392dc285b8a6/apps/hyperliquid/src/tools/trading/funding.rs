use crate::{
    client::HyperliquidApp,
    domain::{
        account::now_ms,
        market::{MarketType, resolve},
    },
};
use aomi_sdk::DynToolCallCtx;
use schemars::JsonSchema;
use serde::Deserialize;
use serde_json::{Value, json};
#[derive(Deserialize, JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum FundingView {
    Current,
    History,
    Predicted,
}
#[derive(Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct FundingArgs {
    pub market: String,
    pub view: FundingView,
    pub start_time: Option<u64>,
    pub end_time: Option<u64>,
}
pub fn run(app: &HyperliquidApp, args: FundingArgs, _ctx: DynToolCallCtx) -> Result<Value, String> {
    let market = resolve(app, &args.market)?;
    if market.market_type != MarketType::Perp {
        return Err("Spot markets do not pay perpetual funding".into());
    }
    let data = match args.view {
        FundingView::Current => {
            json!({"funding":market.context["funding"],"premium":market.context["premium"],"mark_price":market.context["markPx"],"oracle_price":market.context["oraclePx"]})
        }
        FundingView::History => {
            let end = args.end_time.unwrap_or_else(now_ms);
            let start = args.start_time.unwrap_or(end.saturating_sub(86400000));
            if start >= end {
                return Err("start_time must precede end_time".into());
            }
            app.venue.info(
                json!({"type":"fundingHistory","coin":market.coin,"startTime":start,"endTime":end}),
            )?
        }
        FundingView::Predicted => {
            let data = app.venue.info(json!({"type":"predictedFundings"}))?;
            json!(
                data.as_array()
                    .ok_or("Malformed predicted funding")?
                    .iter()
                    .filter(|v| v[0].as_str() == Some(&market.coin))
                    .collect::<Vec<_>>()
            )
        }
    };
    Ok(
        json!({"market_ref":market.market_ref,"funding":data,"units":"venue decimal funding rate; not an annualized percentage"}),
    )
}
read_tool!(
    Funding,
    FundingArgs,
    "hl_funding",
    "Read current, historical or predicted market funding. Personal funding payments belong to hl_account_activity.",
    run
);

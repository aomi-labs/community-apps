use crate::{
    client::HyperliquidApp,
    domain::{
        account::wallet,
        market::resolve,
        order::{OrderRef, Side},
    },
};
use aomi_sdk::{DynAomiTool, DynToolCallCtx, ToolReturn, schemars::JsonSchema};
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};

pub struct PrepareCancel;
#[derive(Debug, Clone, Serialize, Deserialize, JsonSchema)]
pub struct TwapRef {
    pub market: String,
    pub twap_id: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct TwapCancelState {
    account: String,
    pending: Vec<TwapRef>,
}
#[derive(Debug, Deserialize, JsonSchema)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum CancelIntent {
    Exact {
        orders: Vec<OrderRef>,
    },
    Scope {
        market: Option<String>,
        side: Option<Side>,
        #[serde(default)]
        include_triggers: bool,
        #[serde(default)]
        include_protection: bool,
        #[serde(default)]
        include_twap: bool,
        /// Exact TWAP ids to cancel. Required because Hyperliquid has no REST
        /// endpoint that safely enumerates currently active master TWAPs.
        #[serde(default)]
        twap_ids: Vec<TwapRef>,
    },
}
#[derive(Debug, Deserialize, JsonSchema)]
pub struct PrepareCancelArgs {
    pub intent: CancelIntent,
}

impl DynAomiTool for PrepareCancel {
    type App = HyperliquidApp;
    type Args = PrepareCancelArgs;
    const NAME: &'static str = "hl_prepare_cancel";
    const DESCRIPTION: &'static str =
        "Freeze and review an exact set of Hyperliquid orders before cancelling them.";
    fn run_with_routes(
        app: &Self::App,
        args: Self::Args,
        ctx: DynToolCallCtx,
    ) -> Result<ToolReturn, String> {
        let address = wallet(&ctx)?;
        let mut frozen = Vec::new();
        let mut frozen_twaps = Vec::new();
        match args.intent {
            CancelIntent::Exact { orders } => {
                if orders.is_empty() {
                    return Err("orders cannot be empty".into());
                }
                for r in orders {
                    let m = resolve(app, &r.market)?;
                    frozen.push(json!({"a":m.asset_id,"o":r.order_id,"market_ref":m.market_ref}));
                }
            }
            CancelIntent::Scope {
                market,
                side,
                include_triggers,
                include_protection,
                include_twap,
                twap_ids,
            } => {
                if include_twap && twap_ids.is_empty() {
                    return Err("include_twap requires exact twap_ids because active master TWAPs cannot be safely enumerated over REST".into());
                }
                if !include_twap && !twap_ids.is_empty() {
                    return Err("twap_ids require include_twap=true".into());
                }
                frozen_twaps = twap_ids;
                let selected = match market {
                    Some(s) => Some(resolve(app, &s)?),
                    None => None,
                };
                let selected_dex = selected.as_ref().map(|m| m.dex.as_deref().unwrap_or(""));
                for dex in crate::domain::account::dexes(app, selected_dex)? {
                    let response = app
                        .venue
                        .info(json!({"type":"frontendOpenOrders","user":address,"dex":dex}))?;
                    for o in response
                        .as_array()
                        .ok_or("open orders response must be an array")?
                    {
                        let coin = o
                            .get("coin")
                            .and_then(Value::as_str)
                            .ok_or("open order missing coin")?;
                        if let Some(m) = &selected
                            && coin != m.coin
                            && coin != m.symbol
                        {
                            continue;
                        }
                        let is_buy = o
                            .get("side")
                            .and_then(Value::as_str)
                            .map(|s| s == "B")
                            .or_else(|| o.get("isBuy").and_then(Value::as_bool))
                            .ok_or("open order missing side")?;
                        if side.is_some_and(|s| s.is_buy() != is_buy) {
                            continue;
                        }
                        let is_trigger = o
                            .get("isTrigger")
                            .and_then(Value::as_bool)
                            .unwrap_or_else(|| o.get("triggerPx").is_some());
                        let is_protection = o
                            .get("reduceOnly")
                            .and_then(Value::as_bool)
                            .unwrap_or(false)
                            && is_trigger;
                        if is_trigger && !include_triggers && !is_protection {
                            continue;
                        }
                        if is_protection && !include_protection {
                            continue;
                        }
                        let m = if let Some(m) = &selected {
                            m.clone()
                        } else {
                            resolve(
                                app,
                                &if dex.is_empty() {
                                    coin.to_string()
                                } else {
                                    format!("{dex}:{coin}")
                                },
                            )?
                        };
                        let oid = o
                            .get("oid")
                            .and_then(Value::as_u64)
                            .ok_or("open order missing oid")?;
                        frozen.push(json!({"a":m.asset_id,"o":oid,"market_ref":m.market_ref,"side":if is_buy{"buy"}else{"sell"},"trigger":is_trigger,"protection":is_protection}));
                    }
                }
            }
        }
        if frozen.is_empty() && frozen_twaps.is_empty() {
            return Err("no matching open orders to cancel".into());
        }
        if frozen.len() > 100 {
            return Err("cancel scope matched more than 100 orders; narrow the scope".into());
        }
        if frozen.is_empty() {
            return prepare_twap_sequence(
                app,
                &ctx,
                TwapCancelState {
                    account: address,
                    pending: frozen_twaps,
                },
            );
        }
        let cancels = frozen
            .iter()
            .map(|v| json!({"a":v["a"],"o":v["o"]}))
            .collect::<Vec<_>>();
        let action = json!({"type":"cancel","cancels":cancels});
        let preview = json!({"kind":"cancel","account":address,"frozen_orders":frozen,"sequential_twap_ids":frozen_twaps,"gap_disclosure":"TWAP cancellations are submitted one by one and halt on the first rejected or ambiguous result."});
        if frozen_twaps.is_empty() {
            crate::domain::signing::prepare(app, &ctx, action, preview)
        } else {
            let state = serde_json::to_value(TwapCancelState {
                account: address,
                pending: frozen_twaps,
            })
            .map_err(|e| e.to_string())?;
            crate::domain::signing::prepare_with_followup(
                app,
                &ctx,
                action,
                preview,
                crate::domain::signing::OnAccept::TwapCancels(state),
            )
        }
    }
}

fn prepare_twap_sequence(
    app: &HyperliquidApp,
    ctx: &DynToolCallCtx,
    mut state: TwapCancelState,
) -> Result<ToolReturn, String> {
    if wallet(ctx)? != state.account {
        return Err("connected wallet changed during TWAP cancellation sequence".into());
    }
    let next = state.pending.remove(0);
    let market = resolve(app, &next.market)?;
    let action = json!({"type":"twapCancel","a":market.asset_id,"t":next.twap_id});
    let preview = json!({"kind":"twap_cancel","account":state.account,"market_ref":market.market_ref,"twap_id":next.twap_id,"remaining_after_this":state.pending.len(),"gap_disclosure":"TWAP cancellations are sequential and stop on rejection or ambiguity."});
    if state.pending.is_empty() {
        crate::domain::signing::prepare(app, ctx, action, preview)
    } else {
        let value = serde_json::to_value(state).map_err(|e| e.to_string())?;
        crate::domain::signing::prepare_with_followup(
            app,
            ctx,
            action,
            preview,
            crate::domain::signing::OnAccept::TwapCancels(value),
        )
    }
}

pub fn continue_twap_cancels(
    app: &HyperliquidApp,
    value: Value,
    ctx: DynToolCallCtx,
) -> Result<ToolReturn, String> {
    let state: TwapCancelState = serde_json::from_value(value)
        .map_err(|e| format!("invalid TWAP cancel continuation: {e}"))?;
    if state.pending.is_empty() {
        return Err("TWAP cancel continuation has no remaining ids".into());
    }
    prepare_twap_sequence(app, &ctx, state)
}

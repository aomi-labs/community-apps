use std::str::FromStr;

use aomi_sdk::schemars::JsonSchema;
use rust_decimal::{Decimal, RoundingStrategy};
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};

use crate::domain::market::Market;

#[derive(Debug, Clone, Copy, Deserialize, Serialize, JsonSchema, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum Side {
    Buy,
    Sell,
}

impl Side {
    pub fn is_buy(self) -> bool {
        matches!(self, Self::Buy)
    }
}

#[derive(Debug, Clone, Deserialize, Serialize, JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum SizeSpec {
    Base { quantity: String },
    QuoteNotional { amount: String },
}

impl SizeSpec {
    pub fn base_at(&self, price: Decimal) -> Result<Decimal, String> {
        match self {
            Self::Base { quantity } => decimal(quantity, "size.quantity"),
            Self::QuoteNotional { amount } => {
                let notional = decimal(amount, "size.amount")?;
                if price <= Decimal::ZERO {
                    return Err("reference price must be positive".into());
                }
                notional
                    .checked_div(price)
                    .ok_or_else(|| "size conversion overflowed decimal range".into())
            }
        }
    }
}

#[derive(Debug, Clone, Copy, Deserialize, Serialize, JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum TimeInForce {
    Gtc,
    Ioc,
    Alo,
}

impl TimeInForce {
    pub fn wire(self) -> &'static str {
        match self {
            Self::Gtc => "Gtc",
            Self::Ioc => "Ioc",
            Self::Alo => "Alo",
        }
    }
}

#[derive(Debug, Clone, Copy, Deserialize, Serialize, JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum TriggerPurpose {
    TakeProfit,
    StopLoss,
}

impl TriggerPurpose {
    pub fn wire(self) -> &'static str {
        match self {
            Self::TakeProfit => "tp",
            Self::StopLoss => "sl",
        }
    }
}

#[derive(Debug, Clone, Deserialize, Serialize, JsonSchema)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum TriggerExecution {
    Market,
    Limit { price: String },
}

#[derive(Debug, Clone, Deserialize, Serialize, JsonSchema)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum OrderType {
    Limit {
        price: String,
        time_in_force: TimeInForce,
    },
    Market {
        max_slippage_bps: u16,
    },
    Trigger {
        purpose: TriggerPurpose,
        trigger_price: String,
        execution: TriggerExecution,
    },
}

#[derive(Debug, Clone, Deserialize, Serialize, JsonSchema)]
pub struct OrderSpec {
    pub market: String,
    pub side: Side,
    pub size: SizeSpec,
    pub order_type: OrderType,
    #[serde(default)]
    pub reduce_only: bool,
}

#[derive(Debug, Clone, Deserialize, Serialize, JsonSchema)]
pub struct ProtectionLeg {
    pub trigger_price: String,
    pub execution: TriggerExecution,
}

#[derive(Debug, Clone, Deserialize, Serialize, JsonSchema)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum ProtectionSize {
    FullPosition,
    Base { quantity: String },
    PositionFractionBps { bps: u16 },
}

#[derive(Debug, Clone, Deserialize, Serialize, JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum LadderAllocation {
    EqualSize,
    EqualNotional,
}

#[derive(Debug, Clone, Deserialize, Serialize, JsonSchema)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum OrderIntent {
    Orders {
        orders: Vec<OrderSpec>,
    },
    Bracket {
        entry: OrderSpec,
        take_profit: Option<ProtectionLeg>,
        stop_loss: Option<ProtectionLeg>,
    },
    ProtectPosition {
        market: String,
        size: ProtectionSize,
        take_profit: Option<ProtectionLeg>,
        stop_loss: Option<ProtectionLeg>,
        #[serde(default)]
        replace_existing: bool,
    },
    Ladder {
        market: String,
        side: Side,
        total_size: SizeSpec,
        start_price: String,
        end_price: String,
        levels: u16,
        allocation: LadderAllocation,
        #[serde(default)]
        reduce_only: bool,
    },
}

#[derive(Debug, Clone, Deserialize, Serialize, JsonSchema)]
pub struct OrderRef {
    pub market: String,
    pub order_id: u64,
}

pub fn decimal(input: &str, field: &str) -> Result<Decimal, String> {
    let value = Decimal::from_str(input)
        .map_err(|_| format!("{field} must be a base-10 decimal string"))?;
    if value <= Decimal::ZERO {
        return Err(format!("{field} must be greater than zero"));
    }
    Ok(value)
}

pub fn decimal_nonnegative(input: &str, field: &str) -> Result<Decimal, String> {
    let value = Decimal::from_str(input)
        .map_err(|_| format!("{field} must be a base-10 decimal string"))?;
    if value < Decimal::ZERO {
        return Err(format!("{field} must not be negative"));
    }
    Ok(value)
}

pub fn wire_decimal(value: Decimal) -> String {
    value.normalize().to_string()
}

pub fn round_size(value: Decimal, market: &Market) -> Result<Decimal, String> {
    let rounded = value.round_dp_with_strategy(market.sz_decimals, RoundingStrategy::ToZero);
    if rounded <= Decimal::ZERO {
        return Err(format!("size is below {} precision", market.sz_decimals));
    }
    Ok(rounded)
}

pub fn round_price(value: Decimal, market: &Market) -> Result<Decimal, String> {
    if value <= Decimal::ZERO {
        return Err("price must be greater than zero".into());
    }
    let max_decimals = match market.market_type {
        crate::domain::market::MarketType::Perp => 6u32.saturating_sub(market.sz_decimals),
        crate::domain::market::MarketType::Spot => 8u32.saturating_sub(market.sz_decimals),
    };
    let abs = value.abs();
    let integer_digits = if abs >= Decimal::ONE {
        abs.trunc().to_string().trim_start_matches('-').len() as i32
    } else {
        0
    };
    let significant_dp = if integer_digits >= 5 {
        0
    } else if integer_digits > 0 {
        (5 - integer_digits) as u32
    } else {
        let leading_zeros = abs
            .normalize()
            .to_string()
            .split_once('.')
            .map(|(_, fraction)| fraction.chars().take_while(|c| *c == '0').count() as u32)
            .unwrap_or(0);
        leading_zeros + 5
    };
    Ok(value.round_dp_with_strategy(
        max_decimals.min(significant_dp),
        RoundingStrategy::MidpointAwayFromZero,
    ))
}

pub fn exact_price(value: Decimal, market: &Market) -> Result<Decimal, String> {
    let normalized = round_price(value, market)?;
    if normalized != value {
        return Err(format!(
            "price {} exceeds Hyperliquid precision for {}",
            wire_decimal(value),
            market.market_ref
        ));
    }
    Ok(value)
}

pub fn ioc_bound_price(value: Decimal, market: &Market, side: Side) -> Result<Decimal, String> {
    let nearest = round_price(value, market)?;
    let scale = nearest.scale();
    Ok(value.round_dp_with_strategy(
        scale,
        if side.is_buy() {
            RoundingStrategy::ToNegativeInfinity
        } else {
            RoundingStrategy::ToPositiveInfinity
        },
    ))
}

pub fn limit_order(
    market: &Market,
    side: Side,
    size: Decimal,
    price: Decimal,
    tif: TimeInForce,
    reduce_only: bool,
) -> Result<Value, String> {
    Ok(
        json!({"a":market.asset_id,"b":side.is_buy(),"p":wire_decimal(exact_price(price,market)?),"s":wire_decimal(size),"r":reduce_only,"t":{"limit":{"tif":tif.wire()}}}),
    )
}

pub fn trigger_order(
    market: &Market,
    side: Side,
    size: Decimal,
    trigger: Decimal,
    execution: &TriggerExecution,
    purpose: TriggerPurpose,
    reduce_only: bool,
) -> Result<Value, String> {
    let (is_market, px) = match execution {
        TriggerExecution::Market => (true, trigger),
        TriggerExecution::Limit { price } => (false, decimal(price, "execution.price")?),
    };
    Ok(
        json!({"a":market.asset_id,"b":side.is_buy(),"p":wire_decimal(exact_price(px,market)?),"s":wire_decimal(size),"r":reduce_only,"t":{"trigger":{"isMarket":is_market,"triggerPx":wire_decimal(exact_price(trigger,market)?),"tpsl":purpose.wire()}}}),
    )
}

pub fn order_action(orders: Vec<Value>, grouping: &str) -> Value {
    json!({"type":"order","orders":orders,"grouping":grouping})
}

pub fn market_price(mid: Decimal, side: Side, bps: u16) -> Result<Decimal, String> {
    if bps == 0 || bps > 5_000 {
        return Err("max_slippage_bps must be between 1 and 5000".into());
    }
    let shift = Decimal::from(bps)
        .checked_div(Decimal::from(10_000u32))
        .ok_or("slippage calculation overflowed decimal range")?;
    let factor = if side.is_buy() {
        Decimal::ONE.checked_add(shift)
    } else {
        Decimal::ONE.checked_sub(shift)
    }
    .ok_or("slippage calculation overflowed decimal range")?;
    mid.checked_mul(factor)
        .ok_or_else(|| "market price overflowed decimal range".into())
}

pub fn ladder_prices(start: Decimal, end: Decimal, levels: u16) -> Result<Vec<Decimal>, String> {
    if !(2..=100).contains(&levels) {
        return Err("levels must be between 2 and 100".into());
    }
    let step = end
        .checked_sub(start)
        .and_then(|delta| delta.checked_div(Decimal::from(levels - 1)))
        .ok_or("ladder price calculation overflowed decimal range")?;
    (0..levels)
        .map(|i| {
            step.checked_mul(Decimal::from(i))
                .and_then(|offset| start.checked_add(offset))
                .ok_or_else(|| "ladder price calculation overflowed decimal range".into())
        })
        .collect()
}

pub fn validate_min_notional(
    size: Decimal,
    price: Decimal,
    reduce_only: bool,
) -> Result<(), String> {
    if reduce_only {
        return Ok(());
    }
    let notional = size
        .checked_mul(price)
        .ok_or("order notional overflowed decimal range")?;
    if notional < Decimal::TEN {
        return Err(format!(
            "order notional {} is below Hyperliquid's minimum of 10 quote units",
            wire_decimal(notional)
        ));
    }
    Ok(())
}

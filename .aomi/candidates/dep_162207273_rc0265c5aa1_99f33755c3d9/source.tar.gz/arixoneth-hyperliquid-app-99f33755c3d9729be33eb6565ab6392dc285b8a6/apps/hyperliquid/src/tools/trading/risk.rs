use crate::{
    client::HyperliquidApp,
    domain::{
        account::wallet,
        market::{MarketType, resolve},
        order::decimal,
    },
};
use aomi_sdk::{DynAomiTool, DynToolCallCtx, ToolReturn, schemars::JsonSchema};
use rust_decimal::Decimal;
use serde::Deserialize;
use serde_json::{Value, json};
use std::str::FromStr;
pub struct PrepareRisk;
#[derive(Debug, Clone, Copy, Deserialize, JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum MarginMode {
    Cross,
    Isolated,
}
#[derive(Debug, Clone, Copy, Deserialize, JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum AccountMode {
    Standard,
    Unified,
    PortfolioMargin,
}
#[derive(Debug, Deserialize, JsonSchema)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum RiskIntent {
    SetLeverage {
        market: String,
        leverage: u32,
        margin_mode: MarginMode,
    },
    AddIsolatedMargin {
        market: String,
        amount: String,
    },
    RemoveIsolatedMargin {
        market: String,
        amount: String,
    },
    SetAccountMode {
        mode: AccountMode,
    },
}
#[derive(Debug, Deserialize, JsonSchema)]
pub struct PrepareRiskArgs {
    pub intent: RiskIntent,
}
fn micros(amount: &str, negative: bool) -> Result<i64, String> {
    let d = decimal(amount, "amount")?
        .checked_mul(Decimal::from(1_000_000u32))
        .ok_or("amount is too large")?;
    if d.fract() != Decimal::ZERO {
        return Err("amount supports at most 6 decimal places".into());
    }
    let n = d.to_i64().ok_or("amount is too large")?;
    if negative {
        n.checked_neg().ok_or_else(|| "amount is too large".into())
    } else {
        Ok(n)
    }
}
use rust_decimal::prelude::ToPrimitive;
fn position_is_buy(
    app: &HyperliquidApp,
    address: &str,
    coin: &str,
    dex: Option<&str>,
) -> Result<bool, String> {
    let v = app
        .venue
        .info(json!({"type":"clearinghouseState","user":address,"dex":dex.unwrap_or("")}))?;
    for x in v
        .get("assetPositions")
        .and_then(Value::as_array)
        .ok_or("clearinghouseState omitted assetPositions")?
    {
        let p = x.get("position").unwrap_or(x);
        if p.get("coin").and_then(Value::as_str) == Some(coin) {
            let s = Decimal::from_str(
                p.get("szi")
                    .and_then(Value::as_str)
                    .ok_or("position szi missing")?,
            )
            .map_err(|_| "position szi invalid")?;
            if s != Decimal::ZERO {
                return Ok(s > Decimal::ZERO);
            }
        }
    }
    Err("isolated margin requires an open position".into())
}
impl DynAomiTool for PrepareRisk {
    type App = HyperliquidApp;
    type Args = PrepareRiskArgs;
    const NAME: &'static str = "hl_prepare_risk";
    const DESCRIPTION: &'static str = "Prepare an explicit leverage, isolated-margin, or account-mode change without silently altering risk settings.";
    fn run_with_routes(
        app: &Self::App,
        args: Self::Args,
        ctx: DynToolCallCtx,
    ) -> Result<ToolReturn, String> {
        let account = wallet(&ctx)?;
        let (action, preview) = match args.intent {
            RiskIntent::SetLeverage {
                market,
                leverage,
                margin_mode,
            } => {
                let m = resolve(app, &market)?;
                if !matches!(m.market_type, MarketType::Perp) {
                    return Err("leverage applies only to perp markets".into());
                }
                if m.only_isolated && matches!(margin_mode, MarginMode::Cross) {
                    return Err("this market supports isolated margin only".into());
                }
                let max = m
                    .max_leverage
                    .ok_or("market does not publish max leverage")?;
                if leverage == 0 || leverage > max {
                    return Err(format!("leverage must be between 1 and {max}"));
                }
                let cross = matches!(margin_mode, MarginMode::Cross);
                (
                    json!({"type":"updateLeverage","asset":m.asset_id,"isCross":cross,"leverage":leverage}),
                    json!({"kind":"set_leverage","account":account,"market_ref":m.market_ref,"leverage":leverage,"margin_mode":if cross{"cross"}else{"isolated"}}),
                )
            }
            RiskIntent::AddIsolatedMargin { market, amount } => {
                let m = resolve(app, &market)?;
                if !matches!(m.market_type, MarketType::Perp) {
                    return Err("isolated margin applies only to perp markets".into());
                }
                let is_buy = position_is_buy(app, &account, &m.coin, m.dex.as_deref())?;
                let ntli = micros(&amount, false)?;
                (
                    json!({"type":"updateIsolatedMargin","asset":m.asset_id,"isBuy":is_buy,"ntli":ntli}),
                    json!({"kind":"add_isolated_margin","account":account,"market_ref":m.market_ref,"amount":amount,"position_side":if is_buy{"long"}else{"short"}}),
                )
            }
            RiskIntent::RemoveIsolatedMargin { market, amount } => {
                let m = resolve(app, &market)?;
                if !matches!(m.market_type, MarketType::Perp) {
                    return Err("isolated margin applies only to perp markets".into());
                }
                let is_buy = position_is_buy(app, &account, &m.coin, m.dex.as_deref())?;
                let ntli = micros(&amount, true)?;
                (
                    json!({"type":"updateIsolatedMargin","asset":m.asset_id,"isBuy":is_buy,"ntli":ntli}),
                    json!({"kind":"remove_isolated_margin","account":account,"market_ref":m.market_ref,"amount":amount,"position_side":if is_buy{"long"}else{"short"}}),
                )
            }
            RiskIntent::SetAccountMode { mode } => {
                let abstraction = match mode {
                    AccountMode::Standard => "disabled",
                    AccountMode::Unified => "unifiedAccount",
                    AccountMode::PortfolioMargin => "portfolioMargin",
                };
                (
                    json!({"type":"userSetAbstraction","user":account,"abstraction":abstraction}),
                    json!({"kind":"set_account_mode","account":account,"mode":abstraction}),
                )
            }
        };
        crate::domain::signing::prepare(app, &ctx, action, preview)
    }
}

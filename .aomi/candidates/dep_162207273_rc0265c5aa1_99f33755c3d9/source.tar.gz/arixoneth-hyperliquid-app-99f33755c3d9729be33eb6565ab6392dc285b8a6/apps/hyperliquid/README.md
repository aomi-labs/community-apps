# Hyperliquid Aomi app

The app uses Hyperliquid's millisecond nonces for wallet-signed actions. Its
current allocator is monotonic per `(network, signer)` inside one app process.
Run a single write-capable instance in staging. Multiple replicas require a
shared durable nonce allocator before writes are enabled; process-local state
cannot prevent two replicas from allocating the same nonce. Read-only replicas
do not share this restriction.

An ambiguous `/exchange` response is never retried automatically. Reconcile it
through order status, open orders, fills, or account activity before preparing
another action.

//! Explicitly invoked disposable-wallet testing. This binary cannot target mainnet.
use alloy::{
    dyn_abi::TypedData,
    signers::{SignerSync, local::PrivateKeySigner},
};
use aomi_sdk::{DynAomiTool, DynToolCallCtx, ToolReturn};
use hyperliquid::{
    client::{HyperliquidApp, HyperliquidVenue, hypersdk::HyperSdkVenue},
    domain::market::Network,
    tools::{
        continuation::{SubmitHyperliquidAction, submit_action::SubmitHyperliquidActionArgs},
        trading::PrepareCancel,
    },
};
use serde_json::{Value, json};
use std::{collections::HashMap, sync::Arc};

fn submit_signed(
    app: &HyperliquidApp,
    ctx: &DynToolCallCtx,
    prepared: ToolReturn,
    signer: &PrivateKeySigner,
) -> Result<Value, String> {
    let envelope = serde_json::to_value(prepared).map_err(|e| e.to_string())?;
    submit_envelope(app, ctx, envelope, signer)
}

fn submit_envelope(
    app: &HyperliquidApp,
    ctx: &DynToolCallCtx,
    envelope: Value,
    signer: &PrivateKeySigner,
) -> Result<Value, String> {
    let routes = envelope["__aomi_tool_routes"]
        .as_array()
        .ok_or("No wallet routes")?;
    let signing = routes
        .iter()
        .find(|r| r["tool"] == "evm_commit_message" || r["tool_name"] == "evm_commit_message")
        .or_else(|| routes.first())
        .ok_or("No signing route")?;
    let data: TypedData = serde_json::from_value(signing["args"]["typed_data"].clone())
        .map_err(|e| format!("Invalid wallet typed-data route: {e}"))?;
    let signature = signer
        .sign_dynamic_typed_data_sync(&data)
        .map_err(|e| e.to_string())?;
    let continuation = routes
        .iter()
        .find(|r| {
            r["tool"] == "submit_hyperliquid_action"
                || r["tool_name"] == "submit_hyperliquid_action"
        })
        .or_else(|| routes.get(1))
        .ok_or("No continuation")?;
    let mut args: SubmitHyperliquidActionArgs =
        serde_json::from_value(continuation["args"].clone()).map_err(|e| e.to_string())?;
    args.hyperliquid_signature = Some(json!(signature.to_string()));
    let result = SubmitHyperliquidAction::run_with_routes(app, args, ctx.clone())?;
    serde_json::to_value(result).map_err(|e| e.to_string())
}

fn run() -> Result<(), String> {
    let args = std::env::args().skip(1).collect::<Vec<_>>();
    if args.len() != 2
        || !["account", "signed-probe", "roundtrip", "strategies", "twap"]
            .contains(&args[0].as_str())
    {
        return Err(
            "Usage: testnet <account|signed-probe|roundtrip|strategies|twap> <private-key-file>; always testnet"
                .into(),
        );
    }
    let path = std::path::Path::new(&args[1]);
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        if std::fs::metadata(path)
            .map_err(|_| "Cannot inspect key file")?
            .permissions()
            .mode()
            & 0o077
            != 0
        {
            return Err("Key file must not be accessible to group/other (use mode 0600)".into());
        }
    }
    let raw = std::fs::read_to_string(path).map_err(|_| "Cannot read testnet key file")?;
    let signer: PrivateKeySigner = raw.trim().parse().map_err(|_| "Invalid testnet key file")?;
    let address = signer.address().to_string().to_lowercase();
    let venue = Arc::new(HyperSdkVenue::testnet());
    let app = HyperliquidApp::new(Network::Testnet, venue.clone());
    let state = venue.info(json!({"type":"clearinghouseState","user":address}))?;
    println!(
        "{}",
        json!({"network":"testnet","address":address,"account":state})
    );
    if args[0] == "account" {
        return Ok(());
    }
    let ctx = DynToolCallCtx {
        session_id: "disposable-testnet-probe".into(),
        tool_name: PrepareCancel::NAME.into(),
        call_id: "cancel-probe".into(),
        state_attributes: serde_json::from_value(json!({"domain":{"evm":{"address":address}}}))
            .unwrap(),
        secrets: HashMap::new(),
    };
    if args[0] == "roundtrip" {
        return roundtrip(&app, &ctx, &signer);
    }
    if args[0] == "strategies" {
        return strategies(&app, &ctx, &signer);
    }
    if args[0] == "twap" {
        return twap_roundtrip(&app, &ctx, &signer);
    }
    // A nonexistent order ID exercises authorization without risking an execution.
    let prepared=PrepareCancel::run_with_routes(&app,serde_json::from_value(json!({"intent":{"kind":"exact","orders":[{"market":"hl:testnet:perp:BTC","order_id":0}]}})).map_err(|e|e.to_string())?,ctx.clone())?;
    let result = submit_signed(&app, &ctx, prepared, &signer)?;
    println!(
        "{}",
        json!({"probe":"signed_cancel_nonexistent_order","result":result})
    );
    Ok(())
}

fn strategies(
    app: &HyperliquidApp,
    ctx: &DynToolCallCtx,
    signer: &PrivateKeySigner,
) -> Result<(), String> {
    use hyperliquid::tools::trading::{PrepareClose, PrepareOrder};
    use rust_decimal::Decimal;
    use std::str::FromStr;
    let market = "hl:testnet:perp:BTC";
    let metadata = hyperliquid::domain::market::resolve(app, market)?;
    let mid = app.venue.info(json!({"type":"allMids"}))?;
    let mid =
        Decimal::from_str(mid["BTC"].as_str().ok_or("No BTC mid")?).map_err(|e| e.to_string())?;
    let price = |factor: u32| -> Result<String, String> {
        Ok(hyperliquid::domain::order::round_price(
            mid * Decimal::from(factor) / Decimal::from(100),
            &metadata,
        )?
        .normalize()
        .to_string())
    };
    execute::<PrepareOrder>(
        app,
        ctx,
        signer,
        "ladder",
        json!({"intent":{"kind":"ladder","market":market,"side":"buy","total_size":{"quote_notional":{"amount":"40"}},"start_price":price(48)?,"end_price":price(50)?,"levels":2,"allocation":"equal_notional"}}),
    )?;
    execute::<PrepareCancel>(
        app,
        ctx,
        signer,
        "cancel_ladder_scope",
        json!({"intent":{"kind":"scope","market":market,"include_triggers":true,"include_protection":true}}),
    )?;
    execute::<PrepareOrder>(
        app,
        ctx,
        signer,
        "bracket",
        json!({"intent":{"kind":"bracket","entry":{"market":market,"side":"buy","size":{"quote_notional":{"amount":"20"}},"order_type":{"kind":"market","max_slippage_bps":100}},"take_profit":{"trigger_price":price(150)?,"execution":{"kind":"market"}},"stop_loss":{"trigger_price":price(50)?,"execution":{"kind":"market"}}}}),
    )?;
    let args = json!({"intent":{"kind":"protect_position","market":market,"size":{"kind":"full_position"},"take_profit":{"trigger_price":price(140)?,"execution":{"kind":"market"}},"stop_loss":{"trigger_price":price(60)?,"execution":{"kind":"market"}},"replace_existing":true}});
    let prepared = PrepareOrder::run_with_routes(
        app,
        serde_json::from_value(args).map_err(|e| e.to_string())?,
        ctx.clone(),
    )?;
    let replacement = submit_signed(app, ctx, prepared, signer)?;
    if replacement.get("__aomi_tool_routes").is_none() {
        return Err(format!(
            "Protection replacement did not request its second signature: {replacement}"
        ));
    }
    let result = submit_envelope(app, ctx, replacement, signer)?;
    println!(
        "{}",
        json!({"test":"replace_protection_two_signatures","result":result})
    );
    if result["status"] != "accepted" {
        return Err("Replacement protection was not accepted".into());
    }
    execute::<PrepareCancel>(
        app,
        ctx,
        signer,
        "cancel_protection",
        json!({"intent":{"kind":"scope","market":market,"include_triggers":true,"include_protection":true}}),
    )?;
    execute::<PrepareClose>(
        app,
        ctx,
        signer,
        "close_bracket_position",
        json!({"market":market,"size":{"kind":"full"},"max_slippage_bps":100}),
    )?;
    twap_roundtrip(app, ctx, signer)
}

fn twap_roundtrip(
    app: &HyperliquidApp,
    ctx: &DynToolCallCtx,
    signer: &PrivateKeySigner,
) -> Result<(), String> {
    use hyperliquid::tools::trading::{PrepareClose, PrepareTwap};
    let market = "hl:testnet:perp:BTC";
    let twap = execute::<PrepareTwap>(
        app,
        ctx,
        signer,
        "twap_place",
        json!({"intent":{"kind":"place","market":market,"side":"buy","size":{"quote_notional":{"amount":"120"}},"duration_minutes":5,"randomize":false}}),
    )?;
    let twap_id = twap
        .pointer("/response/response/data/status/running/twapId")
        .and_then(Value::as_u64)
        .ok_or("TWAP id missing")?;
    execute::<PrepareTwap>(
        app,
        ctx,
        signer,
        "twap_cancel",
        json!({"intent":{"kind":"cancel","market":market,"twap_id":twap_id}}),
    )?;
    let state = app
        .venue
        .info(json!({"type":"clearinghouseState","user":signer.address().to_string()}))?;
    if state["assetPositions"]
        .as_array()
        .is_some_and(|rows| !rows.is_empty())
    {
        execute::<PrepareClose>(
            app,
            ctx,
            signer,
            "close_twap_fill",
            json!({"market":market,"size":{"kind":"full"},"max_slippage_bps":100}),
        )?;
    }
    let state = app
        .venue
        .info(json!({"type":"clearinghouseState","user":signer.address().to_string()}))?;
    let orders = app
        .venue
        .info(json!({"type":"frontendOpenOrders","user":signer.address().to_string()}))?;
    println!(
        "{}",
        json!({"final_positions":state["assetPositions"],"final_open_orders":orders})
    );
    if state["assetPositions"]
        .as_array()
        .is_none_or(|rows| !rows.is_empty())
        || orders.as_array().is_none_or(|rows| !rows.is_empty())
    {
        return Err("Strategy test cleanup incomplete".into());
    }
    Ok(())
}
fn main() {
    if let Err(error) = run() {
        eprintln!("{error}");
        std::process::exit(1);
    }
}

fn execute<T: DynAomiTool<App = HyperliquidApp>>(
    app: &HyperliquidApp,
    ctx: &DynToolCallCtx,
    signer: &PrivateKeySigner,
    label: &str,
    args: Value,
) -> Result<Value, String> {
    let prepared = T::run_with_routes(
        app,
        serde_json::from_value(args).map_err(|e| e.to_string())?,
        ctx.clone(),
    )?;
    let result = submit_signed(app, ctx, prepared, signer)?;
    println!("{}", json!({"test":label,"result":result}));
    if result["status"] != "accepted" {
        return Err(format!("{label} did not receive venue acceptance"));
    }
    Ok(result)
}

fn order_id(result: &Value) -> Result<u64, String> {
    result
        .pointer("/response/response/data/statuses/0/resting/oid")
        .and_then(Value::as_u64)
        .ok_or_else(|| "Venue did not return a resting order ID".into())
}

fn roundtrip(
    app: &HyperliquidApp,
    ctx: &DynToolCallCtx,
    signer: &PrivateKeySigner,
) -> Result<(), String> {
    use hyperliquid::tools::{
        portfolio::PrepareTransfer,
        trading::{PrepareClose, PrepareModify, PrepareOrder, PrepareRisk},
    };
    use rust_decimal::Decimal;
    use std::str::FromStr;
    let market = "hl:testnet:perp:BTC";
    let existing = app
        .venue
        .info(json!({"type":"frontendOpenOrders","user":signer.address().to_string()}))?;
    let orders = existing
        .as_array()
        .ok_or("Invalid open orders")?
        .iter()
        .filter(|order| order["coin"] == "BTC")
        .map(|order| json!({"market":market,"order_id":order["oid"]}))
        .collect::<Vec<_>>();
    if !orders.is_empty() {
        execute::<PrepareCancel>(
            app,
            ctx,
            signer,
            "cleanup_previous_orders",
            json!({"intent":{"kind":"exact","orders":orders}}),
        )?;
    }
    let previous = app
        .venue
        .info(json!({"type":"clearinghouseState","user":signer.address().to_string()}))?;
    if previous["assetPositions"]
        .as_array()
        .is_some_and(|rows| !rows.is_empty())
    {
        execute::<PrepareClose>(
            app,
            ctx,
            signer,
            "cleanup_previous_position",
            json!({"market":market,"size":{"kind":"full"},"max_slippage_bps":100}),
        )?;
    }
    let metadata = hyperliquid::domain::market::resolve(app, market)?;
    let mid = app.venue.info(json!({"type":"allMids"}))?;
    let mid =
        Decimal::from_str(mid["BTC"].as_str().ok_or("No BTC mid")?).map_err(|e| e.to_string())?;
    let half = hyperliquid::domain::order::round_price(mid / Decimal::from(2), &metadata)?
        .normalize()
        .to_string();
    let balance = app
        .venue
        .info(json!({"type":"clearinghouseState","user":signer.address().to_string()}))?;
    let available = Decimal::from_str(
        balance["withdrawable"]
            .as_str()
            .ok_or("Missing withdrawable balance")?,
    )
    .map_err(|e| e.to_string())?;
    if available < Decimal::from(50) {
        execute::<PrepareTransfer>(
            app,
            ctx,
            signer,
            "fund_perpetual_balance",
            json!({"intent":{"kind":"spot_to_perp","amount":"100"}}),
        )?;
    }
    execute::<PrepareRisk>(
        app,
        ctx,
        signer,
        "set_isolated_leverage",
        json!({"intent":{"kind":"set_leverage","market":market,"leverage":2,"margin_mode":"isolated"}}),
    )?;
    let placed = execute::<PrepareOrder>(
        app,
        ctx,
        signer,
        "resting_limit",
        json!({"intent":{"kind":"orders","orders":[{"market":market,"side":"buy","size":{"quote_notional":{"amount":"20"}},"order_type":{"kind":"limit","price":half,"time_in_force":"alo"}}]}}),
    )?;
    let oid = order_id(&placed)?;
    let changed_price = hyperliquid::domain::order::round_price(
        mid * Decimal::from_str("0.49").unwrap(),
        &metadata,
    )?
    .normalize()
    .to_string();
    execute::<PrepareModify>(
        app,
        ctx,
        signer,
        "modify_remaining",
        json!({"modifications":[{"order_ref":{"market":market,"order_id":oid},"new_price":changed_price}]}),
    )?;
    let open = app
        .venue
        .info(json!({"type":"frontendOpenOrders","user":signer.address().to_string()}))?;
    let oid = open
        .as_array()
        .and_then(|orders| orders.iter().find(|order| order["coin"] == "BTC"))
        .and_then(|order| order["oid"].as_u64())
        .ok_or("Modified resting order missing")?;
    execute::<PrepareCancel>(
        app,
        ctx,
        signer,
        "cancel_exact",
        json!({"intent":{"kind":"exact","orders":[{"market":market,"order_id":oid}]}}),
    )?;
    execute::<PrepareTransfer>(
        app,
        ctx,
        signer,
        "perp_to_spot",
        json!({"intent":{"kind":"perp_to_spot","amount":"1"}}),
    )?;
    execute::<PrepareTransfer>(
        app,
        ctx,
        signer,
        "spot_to_perp",
        json!({"intent":{"kind":"spot_to_perp","amount":"1"}}),
    )?;
    execute::<PrepareOrder>(
        app,
        ctx,
        signer,
        "market_open",
        json!({"intent":{"kind":"orders","orders":[{"market":market,"side":"buy","size":{"quote_notional":{"amount":"20"}},"order_type":{"kind":"market","max_slippage_bps":100}}]}}),
    )?;
    execute::<PrepareRisk>(
        app,
        ctx,
        signer,
        "add_isolated_margin",
        json!({"intent":{"kind":"add_isolated_margin","market":market,"amount":"1"}}),
    )?;
    execute::<PrepareRisk>(
        app,
        ctx,
        signer,
        "remove_isolated_margin",
        json!({"intent":{"kind":"remove_isolated_margin","market":market,"amount":"0.5"}}),
    )?;
    execute::<PrepareClose>(
        app,
        ctx,
        signer,
        "reduce_only_close",
        json!({"market":market,"size":{"kind":"full"},"max_slippage_bps":100}),
    )?;
    let state = app
        .venue
        .info(json!({"type":"clearinghouseState","user":signer.address().to_string()}))?;
    let open = app
        .venue
        .info(json!({"type":"frontendOpenOrders","user":signer.address().to_string()}))?;
    println!(
        "{}",
        json!({"final_positions":state["assetPositions"],"final_open_orders":open})
    );
    if !state["assetPositions"]
        .as_array()
        .is_some_and(Vec::is_empty)
        || !open.as_array().is_some_and(Vec::is_empty)
    {
        return Err("Testnet cleanup must finish: position/order remains".into());
    }
    Ok(())
}

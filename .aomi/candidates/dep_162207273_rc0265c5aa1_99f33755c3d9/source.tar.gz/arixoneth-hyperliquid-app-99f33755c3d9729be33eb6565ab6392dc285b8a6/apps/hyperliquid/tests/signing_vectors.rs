use alloy::{
    dyn_abi::TypedData,
    signers::{SignerSync, local::PrivateKeySigner},
};
use aomi_sdk::{DynAomiTool, DynToolCallCtx};
use chrono::{DateTime, Utc};
use hyperliquid::domain::{
    market::Network,
    signing::{action_prehash, chain, parse_signature, recover_signer, typed_data},
};
use hyperliquid::{
    client::{HyperliquidApp, HyperliquidVenue},
    tools::continuation::{SubmitHyperliquidAction, submit_action::SubmitHyperliquidActionArgs},
};
use hypersdk::hypercore::{Signature, types::Action};
use serde_json::json;
use serde_json::{Map, Value};
use std::{collections::HashMap, sync::Arc};

fn signer() -> PrivateKeySigner {
    "0x59c6995e998f97a5a0044976f7d5f80a52246f4d6f5d81d64f80a5d7f6f8b6c1"
        .parse()
        .expect("fixed test key")
}

#[test]
fn l1_agent_typed_data_matches_hypersdk_and_recovers_signer() {
    let action_json = json!({"type":"cancel","cancels":[{"a":0,"o":12345}]});
    let action: Action = serde_json::from_value(action_json.clone()).unwrap();
    let nonce = 1_762_000_000_000;
    let expires_ms = nonce + 120_000;
    let expires = DateTime::<Utc>::from_timestamp_millis(expires_ms as i64);
    let value = typed_data(
        &action,
        &action_json,
        nonce,
        None,
        Some(expires_ms),
        Network::Mainnet,
    )
    .unwrap();
    assert_eq!(value["domain"]["chainId"], 1337);
    assert_eq!(value["primaryType"], "Agent");
    assert_eq!(value["message"]["source"], "a");
    let data: TypedData = serde_json::from_value(value).unwrap();
    let alloy_signature = signer().sign_dynamic_typed_data_sync(&data).unwrap();
    let signature: Signature = alloy_signature.into();
    let recovered = action
        .recover(&signature, nonce, None, expires, chain(Network::Mainnet))
        .unwrap();
    assert_eq!(recovered, signer().address());
}

#[test]
fn testnet_agent_changes_source_but_keeps_exchange_domain() {
    let action_json = json!({"type":"cancel","cancels":[{"a":110000,"o":7}]});
    let action: Action = serde_json::from_value(action_json.clone()).unwrap();
    let value = typed_data(
        &action,
        &action_json,
        1_762_000_000_001,
        None,
        None,
        Network::Testnet,
    )
    .unwrap();
    assert_eq!(value["domain"]["chainId"], 1337);
    assert_eq!(value["message"]["source"], "b");
}

#[test]
fn official_python_l1_order_vector_matches_action_hash_and_signer() {
    // Generated with hyperliquid-python-sdk master's sign_l1_action.
    let action_json = json!({"type":"order","orders":[{"a":0,"b":true,"p":"60000","s":"0.001","r":false,"t":{"limit":{"tif":"Gtc"}},"c":"0x00000000000000000000000000000001"}],"grouping":"na"});
    let action: Action = serde_json::from_value(action_json.clone()).unwrap();
    let nonce = 1_762_000_000_030u64;
    let data = typed_data(&action, &action_json, nonce, None, None, Network::Mainnet).unwrap();
    assert_eq!(
        data["message"]["connectionId"],
        "0x518539a9950abe28ca96620ea4eba4cdbbfd3a8aa504dff3a615fa46c68a09f2"
    );
    let signature=parse_signature(json!("0x035b9ce92af0038046c840c223238686b89b8369b4b34e57135ad11a6791dac4210ebf07574496015c561a20138783894d30dd3317c4688db25c29af92eb191b1b")).unwrap();
    let prehash =
        action_prehash(&action, &action_json, nonce, None, None, Network::Mainnet).unwrap();
    assert_eq!(
        recover_signer(&signature, prehash).unwrap(),
        "0x4d25c2ebd62130db1c2538dd7df386f375f800b9"
    );
}

#[test]
fn typed_data_commits_to_every_order_field() {
    let first_json = json!({"type":"cancel","cancels":[{"a":0,"o":11}]});
    let second_json = json!({"type":"cancel","cancels":[{"a":0,"o":12}]});
    let first: Action = serde_json::from_value(first_json.clone()).unwrap();
    let second: Action = serde_json::from_value(second_json.clone()).unwrap();
    let first_data = typed_data(
        &first,
        &first_json,
        1_762_000_000_002,
        None,
        None,
        Network::Mainnet,
    )
    .unwrap();
    let second_data = typed_data(
        &second,
        &second_json,
        1_762_000_000_002,
        None,
        None,
        Network::Mainnet,
    )
    .unwrap();
    assert_ne!(
        first_data["message"]["connectionId"],
        second_data["message"]["connectionId"]
    );
}

#[test]
fn user_signed_transfer_uses_human_readable_domain() {
    let action_json = json!({
        "type":"usdClassTransfer",
        "signatureChainId":"0x66eee",
        "hyperliquidChain":"Mainnet",
        "amount":"12.5",
        "toPerp":true,
        "nonce":1_762_000_000_003u64
    });
    let action: Action = serde_json::from_value(action_json.clone()).unwrap();
    let data = typed_data(
        &action,
        &action_json,
        1_762_000_000_003,
        None,
        None,
        Network::Mainnet,
    )
    .unwrap();
    assert_eq!(data["domain"]["name"], "HyperliquidSignTransaction");
    assert_eq!(data["domain"]["chainId"], 421614);
    assert_eq!(
        data["primaryType"],
        "HyperliquidTransaction:UsdClassTransfer"
    );
    assert!(data["message"].get("signatureChainId").is_none());
}

#[test]
fn official_python_withdraw_vector_uses_withdraw_primary_type_and_recovers() {
    // Generated with hyperliquid-python-sdk master and eth-account 0.13.7.
    let action_json = json!({
        "type":"withdraw3", "signatureChainId":"0x66eee", "hyperliquidChain":"Mainnet",
        "destination":"0x1111111111111111111111111111111111111111", "amount":"12.5",
        "time":1_762_000_000_004u64
    });
    let action: Action = serde_json::from_value(action_json.clone()).unwrap();
    let data = typed_data(
        &action,
        &action_json,
        1_762_000_000_004,
        None,
        None,
        Network::Mainnet,
    )
    .unwrap();
    assert_eq!(data["primaryType"], "HyperliquidTransaction:Withdraw");
    let prehash = action_prehash(
        &action,
        &action_json,
        1_762_000_000_004,
        None,
        None,
        Network::Mainnet,
    )
    .unwrap();
    let signature = parse_signature(json!("0xfd6336bd7574a26471748dac52211c8c013542c1ce88e158000244588a3f7b4a61c89e82e3e70235a8ae411708a89fd5f5db2f15cbb8c6c0248a4a2b7cf4cd661c")).unwrap();
    assert_eq!(
        recover_signer(&signature, prehash).unwrap(),
        "0x4d25c2ebd62130db1c2538dd7df386f375f800b9"
    );
}

#[test]
fn direct_action_nonce_is_part_of_the_signature() {
    let first_json = json!({"type":"usdClassTransfer","signatureChainId":"0x66eee","hyperliquidChain":"Mainnet","amount":"1","toPerp":true,"nonce":1762000000010u64});
    let second_json = json!({"type":"usdClassTransfer","signatureChainId":"0x66eee","hyperliquidChain":"Mainnet","amount":"1","toPerp":true,"nonce":1762000000011u64});
    let first: Action = serde_json::from_value(first_json.clone()).unwrap();
    let second: Action = serde_json::from_value(second_json.clone()).unwrap();
    assert_ne!(
        action_prehash(
            &first,
            &first_json,
            1762000000010,
            None,
            None,
            Network::Mainnet
        )
        .unwrap(),
        action_prehash(
            &second,
            &second_json,
            1762000000011,
            None,
            None,
            Network::Mainnet
        )
        .unwrap()
    );
}

#[derive(Clone)]
struct AcceptVenue;
impl HyperliquidVenue for AcceptVenue {
    fn info(&self, _: Value) -> Result<Value, String> {
        unreachable!()
    }
    fn exchange(&self, _: Value) -> Result<Value, String> {
        Ok(json!({"status":"ok","response":{"type":"default"}}))
    }
}
fn ctx(address: &str) -> DynToolCallCtx {
    let mut evm = Map::new();
    evm.insert("address".into(), json!(address));
    let mut domain = Map::new();
    domain.insert("evm".into(), Value::Object(evm));
    let mut attrs = Map::new();
    attrs.insert("domain".into(), Value::Object(domain));
    DynToolCallCtx {
        session_id: "s".into(),
        tool_name: "submit_hyperliquid_action".into(),
        call_id: "c".into(),
        state_attributes: attrs,
        secrets: HashMap::new(),
    }
}

#[test]
fn continuation_rejects_tampering_changed_wallet_and_expiration() {
    let action_json = json!({"type":"cancel","cancels":[{"a":0,"o":9}]});
    let action: Action = serde_json::from_value(action_json.clone()).unwrap();
    let nonce = 1762000000020u64;
    let typed = typed_data(&action, &action_json, nonce, None, None, Network::Mainnet).unwrap();
    let typed: TypedData = serde_json::from_value(typed).unwrap();
    let alloy_sig = signer().sign_dynamic_typed_data_sync(&typed).unwrap();
    let sig: Signature = alloy_sig.into();
    let prepared = hyperliquid::domain::signing::PreparedHyperliquidAction {
        version: 1,
        network: Network::Mainnet,
        expected_signer: signer().address().to_string().to_lowercase(),
        action: action_json,
        nonce,
        vault_address: None,
        expires_after: None,
        prehash: action_prehash(
            &action,
            &serde_json::to_value(&action).unwrap(),
            nonce,
            None,
            None,
            Network::Mainnet,
        )
        .unwrap()
        .to_string(),
        created_at_ms: nonce,
    };
    let app = HyperliquidApp::new(Network::Mainnet, Arc::new(AcceptVenue));
    let mut tampered = prepared.clone();
    tampered.action["cancels"][0]["o"] = json!(10);
    assert!(
        SubmitHyperliquidAction::run_with_routes(
            &app,
            SubmitHyperliquidActionArgs {
                prepared: tampered,
                hyperliquid_signature: Some(json!(sig.to_string())),
                followup: None,
            },
            ctx(&prepared.expected_signer)
        )
        .is_err()
    );
    assert!(
        SubmitHyperliquidAction::run_with_routes(
            &app,
            SubmitHyperliquidActionArgs {
                prepared: prepared.clone(),
                hyperliquid_signature: Some(json!(sig.to_string())),
                followup: None,
            },
            ctx("0x1111111111111111111111111111111111111111")
        )
        .is_err()
    );
    let mut expired = prepared;
    expired.expires_after = Some(1);
    assert!(
        SubmitHyperliquidAction::run_with_routes(
            &app,
            SubmitHyperliquidActionArgs {
                prepared: expired,
                hyperliquid_signature: Some(json!(sig.to_string())),
                followup: None,
            },
            ctx(&signer().address().to_string())
        )
        .is_err()
    );
}

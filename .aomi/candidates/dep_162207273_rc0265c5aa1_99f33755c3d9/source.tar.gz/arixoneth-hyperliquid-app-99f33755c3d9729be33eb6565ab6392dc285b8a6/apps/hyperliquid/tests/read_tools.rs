use aomi_sdk::{DynAomiTool, DynToolCallCtx};
use hyperliquid::{
    client::{HyperliquidApp, HyperliquidVenue},
    domain::{account::now_ms, market::Network},
    tools::{
        portfolio::{AccountActivity, Portfolio},
        trading::{Candles, Funding, MarketSnapshot, Markets, OrderBook, Orders},
    },
};
use serde_json::{Value, json};
use std::{collections::HashMap, sync::Arc};
struct Fixture;
impl HyperliquidVenue for Fixture {
    fn exchange(&self, _: Value) -> Result<Value, String> {
        panic!("read tools must never submit")
    }
    fn info(&self, r: Value) -> Result<Value, String> {
        Ok(match r["type"].as_str().unwrap() {
            "spotMetaAndAssetCtxs" => {
                json!([{"tokens":[{"index":0,"name":"USDC","szDecimals":6}],"universe":[]},[]])
            }
            "perpDexs" => json!([null]),
            "metaAndAssetCtxs" => {
                json!([{"collateralToken":0,"universe":[{"name":"BTC","szDecimals":5,"maxLeverage":40}]},[{"markPx":"100","oraclePx":"99","funding":"0.00001","openInterest":"50","dayNtlVlm":"1000"}]])
            }
            "l2Book" => {
                json!({"coin":"BTC","time":now_ms(),"levels":[[{"px":"99.5","sz":"1","n":1}],[{"px":"100.5","sz":"2","n":2}]]})
            }
            "candleSnapshot" => {
                json!([{"t":now_ms()-120000,"T":now_ms()-60000,"o":"99","h":"101","l":"98","c":"100","v":"12"},{"t":now_ms(),"T":now_ms()+60000,"o":"100","c":"101"}])
            }
            "fundingHistory" => {
                json!([{"coin":"BTC","fundingRate":"0.00001","time":now_ms()-1000}])
            }
            "predictedFundings" => {
                json!([["BTC",[["HlPerp",{"fundingRate":"0.00001"}]]],["ETH",[]]])
            }
            "clearinghouseState" => {
                json!({"marginSummary":{"accountValue":"100","totalMarginUsed":"20"},"crossMarginSummary":{},"withdrawable":"80","assetPositions":[{"position":{"coin":"BTC","szi":"1"}}]})
            }
            "spotClearinghouseState" => {
                json!({"balances":[{"coin":"USDC","total":"5","hold":"1"}]})
            }
            "frontendOpenOrders" => {
                json!([{"coin":"BTC","oid":42,"isTrigger":false},{"coin":"BTC","oid":43,"isTrigger":true}])
            }
            "historicalOrders" => json!([{"order":{"coin":"BTC","oid":41},"status":"filled"}]),
            "orderStatus" => {
                json!({"status":"order","order":{"order":{"coin":"BTC","oid":42},"status":"open"}})
            }
            "userAbstraction" => json!("unifiedAccount"),
            "subAccounts" | "userVaultEquities" => json!([]),
            "userFees" | "userRateLimit" => json!({}),
            "userFillsByTime" => json!([{"coin":"BTC","time":now_ms()-100,"sz":"1"}]),
            "userFunding" => json!([{"time":now_ms()-100,"delta":{"coin":"BTC","usdc":"-0.1"}}]),
            "userNonFundingLedgerUpdates" => {
                json!([{"time":now_ms()-100,"delta":{"type":"deposit","usdc":"10"}}])
            }
            "twapHistory" => json!([]),
            other => return Err(format!("unexpected request {other}")),
        })
    }
}
fn call<T: DynAomiTool<App = HyperliquidApp>>(args: Value) -> Result<Value, String> {
    let app = HyperliquidApp::new(Network::Mainnet, Arc::new(Fixture));
    let ctx = DynToolCallCtx {
        session_id: "read-test".into(),
        tool_name: T::NAME.into(),
        call_id: "1".into(),
        state_attributes: serde_json::from_value(
            json!({"domain":{"evm":{"address":"0x1111111111111111111111111111111111111111"}}}),
        )
        .unwrap(),
        secrets: HashMap::new(),
    };
    T::run(&app, serde_json::from_value(args).unwrap(), ctx)
}
#[test]
fn research_tools_return_domain_results() {
    assert_eq!(call::<Markets>(json!({"query":"BTC"})).unwrap()["total"], 1);
    assert_eq!(
        call::<MarketSnapshot>(json!({"market":"BTC"})).unwrap()["spread"],
        "1"
    );
    assert_eq!(call::<OrderBook>(json!({"market":"BTC","aggregation":{"kind":"significant_figures","digits":5,"mantissa":2}})).unwrap()["book"]["levels"][0].as_array().unwrap().len(),1);
    assert_eq!(
        call::<Candles>(json!({"market":"BTC","interval":"1m"})).unwrap()["candles"]
            .as_array()
            .unwrap()
            .len(),
        1
    );
    for view in ["current", "history", "predicted"] {
        assert!(call::<Funding>(json!({"market":"BTC","view":view})).is_ok());
    }
}
#[test]
fn every_portfolio_section_and_activity_kind_is_executable() {
    let p=call::<Portfolio>(json!({"sections":["overview","balances","positions","margin","open_orders","account_mode","subaccounts","vaults","fees","rate_limits"]})).unwrap();
    assert_eq!(p["summary"]["withdrawable"], "80");
    assert_eq!(p["account_mode"], "unifiedAccount");
    for kind in [
        "fills",
        "funding_payments",
        "ledger",
        "transfers",
        "twap_history",
    ] {
        assert!(
            call::<AccountActivity>(json!({"kind":kind})).is_ok(),
            "{kind}"
        );
    }
}
#[test]
fn order_views_and_input_guards_work() {
    assert_eq!(call::<Orders>(json!({"view":"open","market":"BTC","include_triggers":false})).unwrap()["orders"].as_array().unwrap().len(),1);
    assert!(call::<Orders>(json!({"view":"history"})).is_ok());
    assert!(
        call::<Orders>(
            json!({"view":"status","order_ref":{"market":"hl:mainnet:perp:BTC","order_id":42}})
        )
        .is_ok()
    );
    assert!(call::<OrderBook>(json!({"market":"BTC","aggregation":{"kind":"significant_figures","digits":4,"mantissa":2}})).is_err());
    assert!(call::<Candles>(json!({"market":"BTC","interval":"nonsense"})).is_err());
    assert!(call::<Portfolio>(json!({"address":"not-an-address"})).is_err());
}

use aomi_sdk::DynAomiApp;
use hyperliquid::client::HyperliquidApp;
use serde_json::Value;
use std::collections::HashSet;

fn validate_objects(value: &Value, path: &str) {
    match value {
        Value::Object(object) => {
            if object.get("type").and_then(Value::as_str) == Some("object") {
                assert!(
                    object.get("properties").is_some_and(Value::is_object),
                    "Missing properties: {path}"
                );
            }
            for (key, value) in object {
                validate_objects(value, &format!("{path}/{key}"));
            }
        }
        Value::Array(values) => {
            for (index, value) in values.iter().enumerate() {
                validate_objects(value, &format!("{path}/{index}"));
            }
        }
        _ => {}
    }
}

#[test]
fn all_nineteen_tools_have_unique_valid_provider_schemas_and_six_skills() {
    let manifest = HyperliquidApp::default().manifest();
    assert_eq!(manifest.tools.len(), 19);
    assert_eq!(manifest.skills.len(), 6);
    let names = manifest
        .tools
        .iter()
        .map(|t| t.name.as_str())
        .collect::<HashSet<_>>();
    assert_eq!(names.len(), 19);
    for tool in &manifest.tools {
        validate_objects(&tool.parameters_schema, &tool.name);
    }
    assert_eq!(manifest.name, "hyperliquid");
    assert!(manifest.preamble.len() < 1500);
}

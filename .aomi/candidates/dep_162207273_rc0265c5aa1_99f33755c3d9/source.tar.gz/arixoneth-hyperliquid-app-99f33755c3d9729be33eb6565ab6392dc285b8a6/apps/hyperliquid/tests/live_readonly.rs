//! Explicit opt-in smoke coverage for the public Hyperliquid API.
//! No exchange action is prepared, signed, or submitted in this file.

use std::{collections::HashMap, sync::Arc};

use aomi_sdk::{DynAomiTool, DynToolCallCtx};
use hyperliquid::{
    client::{HyperliquidApp, HyperliquidVenue, hypersdk::HyperSdkVenue},
    domain::market::Network,
    tools::{
        portfolio::{
            AccountActivity, Portfolio,
            account_view::{PortfolioArgs, PortfolioSection},
            activity::{ActivityArgs, ActivityKind},
        },
        trading::{
            Candles, Funding, MarketSnapshot, Markets, OrderBook, Orders,
            candles::CandlesArgs,
            funding::{FundingArgs, FundingView},
            markets::MarketsArgs,
            orderbook::{BookAggregation, OrderBookArgs},
            orders::{OrderView, OrdersArgs},
            snapshot::MarketArgs,
        },
    },
};
use serde_json::{Map, Value, json};

const ZERO: &str = "0x0000000000000000000000000000000000000000";

fn context(tool_name: &str) -> DynToolCallCtx {
    DynToolCallCtx {
        session_id: "hyperliquid-live-readonly".into(),
        tool_name: tool_name.into(),
        call_id: format!("{tool_name}-call"),
        state_attributes: Map::new(),
        secrets: HashMap::new(),
    }
}

fn assert_object(value: &Value, label: &str) {
    assert!(
        value.is_object(),
        "{label} should return an object: {value}"
    );
}

#[test]
#[ignore = "calls the live mainnet API; run explicitly with --ignored"]
fn every_read_tool_smokes_against_mainnet() {
    let app = HyperliquidApp::new(Network::Mainnet, Arc::new(HyperSdkVenue::mainnet()));

    let markets = Markets::run(
        &app,
        MarketsArgs {
            query: Some("BTC".into()),
            market_type: None,
            dex: Some(String::new()),
            include_context: Some(true),
            include_inactive: Some(false),
            limit: Some(5),
        },
        context("hl_markets"),
    )
    .expect("markets");
    assert_object(&markets, "markets");
    assert!(
        markets["markets"]
            .as_array()
            .is_some_and(|rows| !rows.is_empty())
    );

    let snapshot = MarketSnapshot::run(
        &app,
        MarketArgs {
            market: "hl:mainnet:perp:BTC".into(),
        },
        context("hl_market_snapshot"),
    )
    .expect("snapshot");
    assert_object(&snapshot, "snapshot");

    let book = OrderBook::run(
        &app,
        OrderBookArgs {
            market: "hl:mainnet:perp:BTC".into(),
            depth: Some(2),
            aggregation: Some(BookAggregation::FullPrecision),
        },
        context("hl_orderbook"),
    )
    .expect("orderbook");
    assert_object(&book, "orderbook");

    let candles = Candles::run(
        &app,
        CandlesArgs {
            market: "hl:mainnet:perp:BTC".into(),
            interval: "1h".into(),
            start: None,
            end: None,
            limit: Some(2),
            include_incomplete: Some(false),
        },
        context("hl_candles"),
    )
    .expect("candles");
    assert_object(&candles, "candles");

    let funding = Funding::run(
        &app,
        FundingArgs {
            market: "hl:mainnet:perp:BTC".into(),
            view: FundingView::Current,
            start_time: None,
            end_time: None,
        },
        context("hl_funding"),
    )
    .expect("funding");
    assert_object(&funding, "funding");

    let orders = Orders::run(
        &app,
        OrdersArgs {
            view: OrderView::Open,
            address: Some(ZERO.into()),
            market: None,
            order_ref: None,
            include_triggers: Some(true),
        },
        context("hl_orders"),
    )
    .expect("orders");
    assert_object(&orders, "orders");

    let portfolio = Portfolio::run(
        &app,
        PortfolioArgs {
            address: Some(ZERO.into()),
            sections: Some(vec![
                PortfolioSection::Overview,
                PortfolioSection::Balances,
                PortfolioSection::Positions,
                PortfolioSection::OpenOrders,
            ]),
            dex: None,
            market: None,
        },
        context("hl_portfolio"),
    )
    .expect("portfolio");
    assert_object(&portfolio, "portfolio");

    let activity = AccountActivity::run(
        &app,
        ActivityArgs {
            kind: ActivityKind::Fills,
            address: Some(ZERO.into()),
            market: None,
            start_time: None,
            end_time: None,
            limit: Some(2),
            cursor: None,
        },
        context("hl_account_activity"),
    )
    .expect("account activity");
    assert_object(&activity, "account activity");
}

#[test]
#[ignore = "calls live mainnet and testnet APIs; run explicitly with --ignored"]
fn mainnet_and_testnet_info_endpoints_respond() {
    for (name, venue) in [
        ("mainnet", HyperSdkVenue::mainnet()),
        ("testnet", HyperSdkVenue::testnet()),
    ] {
        let mids = venue
            .info(json!({"type":"allMids"}))
            .unwrap_or_else(|error| panic!("{name} allMids request failed: {error}"));
        assert!(mids.is_object(), "{name} allMids response: {mids}");

        let dexes = venue
            .info(json!({"type":"perpDexs"}))
            .unwrap_or_else(|error| panic!("{name} perpDexs request failed: {error}"));
        assert!(dexes.is_array(), "{name} perpDexs response: {dexes}");
    }
}

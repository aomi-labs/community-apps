use aomi_sdk::testing::{TestCtxBuilder, run_tool};
use hyperliquid::domain::funding::{
    EvmTransaction, FundingQuote, FundingRequest, FundingVenue, HYPERCORE_CHAIN_ID,
    HYPERCORE_PERP_USDC, approval_transaction, credited_deposit, decimal_to_base_units,
    needs_approval, parse_status, validate_quote,
};
use hyperliquid::{
    client::{HyperliquidApp, HyperliquidVenue},
    domain::market::Network,
    tools::portfolio::{PrepareDeposit, PrepareTransfer, PrepareWithdraw},
};
use rust_decimal::Decimal;
use serde_json::{Value, json};
use std::str::FromStr;
use std::sync::Arc;

const WALLET: &str = "0x1111111111111111111111111111111111111111";
const BASE_USDC: &str = "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913";
const SOURCE_HASH: &str = "0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";

fn request() -> FundingRequest {
    FundingRequest {
        from_chain: 8453,
        from_token: BASE_USDC.into(),
        from_decimals: 6,
        amount: Decimal::from_str("10.25").unwrap(),
        wallet: WALLET.into(),
        slippage_bps: 50,
    }
}

fn raw_quote() -> Value {
    json!({
        "id":"fixture:0",
        "tool":"polymerStandard",
        "action":{
            "fromChainId":8453,
            "toChainId":1337,
            "fromAddress":WALLET,
            "toAddress":WALLET,
            "fromAmount":"10250000",
            "fromToken":{"address":BASE_USDC},
            "toToken":{"address":HYPERCORE_PERP_USDC}
        },
        "estimate":{
            "fromAmount":"10250000",
            "toAmount":"10224375",
            "toAmountMin":"10220000",
            "approvalAddress":"0x1231DEB6f5749EF6cE6943a275A1D3E7486F4EaE",
            "feeCosts":[],"gasCosts":[],"executionDuration":1080
        },
        "transactionRequest":{
            "chainId":8453,"from":WALLET,
            "to":"0x1231DEB6f5749EF6cE6943a275A1D3E7486F4EaE",
            "data":"0x1234567890abcdef","value":"0x0","gasLimit":"0x10000"
        }
    })
}

fn quote() -> FundingQuote {
    validate_quote(&raw_quote(), &request()).unwrap()
}

#[test]
fn decimal_conversion_is_exact_and_rejects_hidden_rounding() {
    assert_eq!(
        decimal_to_base_units(Decimal::from_str("10.25").unwrap(), 6).unwrap(),
        "10250000"
    );
    assert!(decimal_to_base_units(Decimal::from_str("0.0000001").unwrap(), 6).is_err());
    assert!(decimal_to_base_units(Decimal::ZERO, 6).is_err());
    assert!(decimal_to_base_units(Decimal::ONE, 29).is_err());
}

#[test]
fn validates_bound_quote_and_rejects_recipient_or_chain_tampering() {
    let valid = quote();
    assert_eq!(valid.to_chain, HYPERCORE_CHAIN_ID);
    assert_eq!(valid.from_amount, "10250000");

    let mut tampered = raw_quote();
    tampered["action"]["toAddress"] = json!("0x2222222222222222222222222222222222222222");
    assert!(
        validate_quote(&tampered, &request())
            .unwrap_err()
            .contains("toAddress")
    );
    let mut tampered = raw_quote();
    tampered["transactionRequest"]["chainId"] = json!(1);
    assert!(
        validate_quote(&tampered, &request())
            .unwrap_err()
            .contains("chainId")
    );
    let mut tampered = raw_quote();
    tampered["action"]["fromAmount"] = json!("10250001");
    assert!(
        validate_quote(&tampered, &request())
            .unwrap_err()
            .contains("fromAmount")
    );
}

#[test]
fn approval_is_exact_and_skipped_only_when_proven_unnecessary() {
    let quoted = quote();
    assert!(needs_approval(&quoted, "10249999").unwrap());
    assert!(!needs_approval(&quoted, "10250000").unwrap());
    let tx = approval_transaction(&quoted).unwrap();
    assert_eq!(tx.to.to_ascii_lowercase(), BASE_USDC.to_ascii_lowercase());
    assert!(tx.data.starts_with("0x095ea7b3"));
    assert!(
        tx.data
            .ends_with("00000000000000000000000000000000000000000000000000000000009c6710")
    );

    let mut native = quoted.clone();
    native.skip_approval = true;
    assert!(!needs_approval(&native, "0").unwrap());
}

#[test]
fn status_must_belong_to_the_committed_route() {
    let expected = quote();
    let valid = json!({
        "transactionId":SOURCE_HASH,"status":"DONE","substatus":"COMPLETED",
        "sending":{"txHash":SOURCE_HASH,"chainId":8453},
        "receiving":{"txHash":"0xbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","chainId":1337,"token":{"address":HYPERCORE_PERP_USDC},"amount":"10224375"},
        "toAddress":WALLET
    });
    assert_eq!(
        parse_status(&valid, SOURCE_HASH, &expected).unwrap().state,
        "DONE"
    );
    let mut wrong = valid.clone();
    wrong["sending"]["txHash"] =
        json!("0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc");
    assert!(
        parse_status(&wrong, SOURCE_HASH, &expected)
            .unwrap_err()
            .contains("different source")
    );
    let mut wrong = valid;
    wrong["toAddress"] = json!("0x2222222222222222222222222222222222222222");
    assert!(
        parse_status(&wrong, SOURCE_HASH, &expected)
            .unwrap_err()
            .contains("recipient")
    );
}

#[test]
fn completion_requires_a_new_matching_deposit_ledger_entry() {
    let ledger = json!([
        {"time":999,"hash":"old","delta":{"type":"deposit","usdc":"99"}},
        {"time":1001,"hash":"transfer","delta":{"type":"internalTransfer","usdc":"20"}},
        {"time":1002,"hash":"small","delta":{"type":"deposit","usdc":"10.21"}},
        {"time":1003,"hash":"credit","delta":{"type":"deposit","usdc":"10.22"}}
    ]);
    let credit = credited_deposit(&ledger, 1000, "10220000", "credit")
        .unwrap()
        .unwrap();
    assert_eq!(credit["hash"], "credit");
    assert!(
        credited_deposit(&ledger, 1004, "10220000", "credit")
            .unwrap()
            .is_none()
    );
}

#[test]
fn funding_quote_round_trips_for_continuation_without_raw_payload() {
    let quoted = quote();
    let encoded = serde_json::to_value(&quoted).unwrap();
    let decoded: FundingQuote = serde_json::from_value(encoded).unwrap();
    assert_eq!(quoted, decoded);
    let _tx: EvmTransaction = decoded.transaction;
}

#[derive(Default)]
struct FixtureVenue;
impl HyperliquidVenue for FixtureVenue {
    fn info(&self, request: Value) -> Result<Value, String> {
        match request["type"].as_str() {
            Some("subAccounts") => {
                Ok(json!([{"subAccountUser":"0x2222222222222222222222222222222222222222"}]))
            }
            Some("perpDexs") => Ok(json!([{"name":""},{"name":"xyz"}])),
            Some("userNonFundingLedgerUpdates") => Ok(json!([])),
            _ => Err(format!("unexpected info request: {request}")),
        }
    }
    fn exchange(&self, _: Value) -> Result<Value, String> {
        Ok(json!({"status":"ok"}))
    }
}

struct FixtureFunding;
impl FundingVenue for FixtureFunding {
    fn token(&self, chain: &str, token: &str) -> Result<Value, String> {
        assert_eq!(chain, "base");
        assert_eq!(token, "USDC");
        Ok(json!({"chainId":8453,"address":BASE_USDC,"symbol":"USDC","decimals":6}))
    }
    fn quote(&self, _: &FundingRequest) -> Result<Value, String> {
        Ok(raw_quote())
    }
    fn quote_to(&self, _: &FundingRequest, _: u64, _: &str) -> Result<Value, String> {
        Ok(raw_quote())
    }
    fn status(&self, _: &str, _: &str, _: u64, _: u64) -> Result<Value, String> {
        Err("not called".into())
    }
    fn allowance(&self, _: u64, _: &str, _: &str, _: &str) -> Result<String, String> {
        Ok("0".into())
    }
    fn block_number(&self, _: u64) -> Result<u64, String> {
        Ok(123)
    }
    fn withdrawal_logs(&self, _: &str, _: u64) -> Result<Value, String> {
        Ok(json!([]))
    }
}

fn fixture_app() -> HyperliquidApp {
    HyperliquidApp::new(Network::Mainnet, Arc::new(FixtureVenue))
        .with_funding(Arc::new(FixtureFunding))
}
fn ctx(tool: &str) -> aomi_sdk::DynToolCallCtx {
    TestCtxBuilder::new(tool)
        .attribute("domain", json!({"evm":{"address":WALLET}}))
        .build()
}

#[test]
fn deposit_tool_resolves_catalog_and_routes_approval_simulation_commit_and_completion() {
    let result = run_tool::<PrepareDeposit>(
        &fixture_app(),
        json!({"amount":"10.25","source_chain":"base","source_token":"USDC","slippage_bps":50}),
        ctx("hl_prepare_deposit"),
    )
    .unwrap();
    assert_eq!(result.value["needs_approval"], true);
    assert_eq!(result.value["minimum_credit"], "10220000");
    assert_eq!(result.routes.len(), 3);
    assert_eq!(result.routes[0].tool, "stage_tx");
    assert_eq!(result.routes[1].tool, "stage_tx");
    assert!(result.routes[0].args.get("from").is_none());
    assert_eq!(result.routes[0].args["chain_id"], 8453);
    assert!(
        result.routes[0].args["data"]["raw"]
            .as_str()
            .is_some_and(|data| data.starts_with("0x095ea7b3"))
    );
    assert_eq!(result.routes[2].tool, "complete_hyperliquid_funding");
    let enforcement = result.routes[1].enforcement.as_ref().unwrap();
    assert_eq!(enforcement.steps[0].tool, "simulate_batch");
    assert_eq!(enforcement.steps[1].tool, "commit_txs");
    assert_eq!(enforcement.steps[1].args, json!({}));
    assert_eq!(
        enforcement.steps[1].bind_as.as_deref(),
        Some("transaction_hash")
    );
    assert!(result.routes[2].args.get("transaction_hash").is_some());
}

#[test]
fn transfer_rejects_unowned_subaccount_before_signing() {
    let result = run_tool::<PrepareTransfer>(
        &fixture_app(),
        json!({"intent":{"kind":"spot_to_perp","amount":"1","subaccount":"0x3333333333333333333333333333333333333333"}}),
        ctx("hl_prepare_transfer"),
    );
    assert!(result.unwrap_err().contains("not owned"));
}

#[test]
fn withdrawal_rejects_incomplete_onward_request() {
    let result = run_tool::<PrepareWithdraw>(
        &fixture_app(),
        json!({"amount":"2","onward_chain_id":8453}),
        ctx("hl_prepare_withdraw"),
    );
    assert!(result.unwrap_err().contains("must be supplied together"));
}

#[test]
fn withdrawal_prepares_signed_action_with_accepted_only_settlement_followup() {
    let result = run_tool::<PrepareWithdraw>(
        &fixture_app(),
        json!({"amount":"2","recipient":WALLET,"onward_chain_id":8453,"onward_token":BASE_USDC}),
        ctx("hl_prepare_withdraw"),
    )
    .unwrap();
    assert_eq!(result.value["status"], "awaiting_wallet_signature");
    assert_eq!(result.value["preview"]["arbitrum_from_block"], 123);
    assert_eq!(result.routes[0].tool, "evm_commit_message");
    assert_eq!(result.routes[1].tool, "submit_hyperliquid_action");
    assert_eq!(
        result.routes[1].args["followup"]["kind"],
        "complete_funding"
    );
    assert_eq!(
        result.routes[1].args["followup"]["args"]["kind"],
        "withdrawal"
    );
}

#[test]
fn withdrawal_settlement_requires_unique_exact_bridge_transfer() {
    let data = format!("0x{:064x}", 1_000_000u128);
    let one = json!([{"removed":false,"data":data,"transactionHash":SOURCE_HASH,"blockTimestampMs":1_001}]);
    assert!(
        hyperliquid::domain::funding::settled_withdrawal(&one, "2000000", 1_000)
            .unwrap()
            .is_some()
    );
    let same_second = json!([{"removed":false,"data":format!("0x{:064x}",1_000_000u128),"transactionHash":SOURCE_HASH,"blockTimestampMs":1_000}]);
    assert!(
        hyperliquid::domain::funding::settled_withdrawal(&same_second, "2000000", 1_999)
            .unwrap()
            .is_some()
    );
    let duplicate = json!([one[0].clone(), one[0].clone()]);
    assert!(
        hyperliquid::domain::funding::settled_withdrawal(&duplicate, "2000000", 1_000)
            .unwrap_err()
            .contains("ambiguous")
    );
    assert!(
        hyperliquid::domain::funding::settled_withdrawal(&json!([]), "2000000", 1_000)
            .unwrap()
            .is_none()
    );
    let old = json!([{"removed":false,"data":format!("0x{:064x}",1_000_000u128),"transactionHash":SOURCE_HASH,"blockTimestampMs":999}]);
    assert!(
        hyperliquid::domain::funding::settled_withdrawal(&old, "2000000", 1_000)
            .unwrap()
            .is_none()
    );
    let missing_timestamp = json!([{"removed":false,"data":format!("0x{:064x}",1_000_000u128),"transactionHash":SOURCE_HASH}]);
    assert!(
        hyperliquid::domain::funding::settled_withdrawal(&missing_timestamp, "2000000", 1_000)
            .unwrap()
            .is_none()
    );
}

#[test]
#[ignore = "opt-in public mainnet LI.FI quote probe; no transaction is submitted"]
fn live_lifi_quote_proves_direct_base_to_hypercore_perps_route() {
    let venue = hyperliquid::domain::funding::LifiFundingVenue::default();
    let token = venue.token("base", "USDC").unwrap();
    let (address, decimals, _) =
        hyperliquid::domain::funding::resolved_token(&token, 8453).unwrap();
    let request = FundingRequest {
        from_chain: 8453,
        from_token: address,
        from_decimals: decimals,
        amount: Decimal::ONE,
        wallet: WALLET.into(),
        slippage_bps: 50,
    };
    let raw = venue.quote(&request).unwrap();
    let quote = validate_quote(&raw, &request).unwrap();
    assert_eq!(quote.to_chain, HYPERCORE_CHAIN_ID);
    assert_eq!(quote.to_address, WALLET);
    assert!(!quote.transaction.data.is_empty());
}

# Verification evidence

This matrix separates deterministic contract tests, public read-only API probes, and signed execution. A prepared action or accepted exchange response is not counted as settlement. Unless explicitly marked **live**, evidence uses fixtures and submits no transaction.

## Tool matrix

| Tool | Deterministic evidence | Public/live evidence | Current status |
|---|---|---|---|
| `hl_markets` | `tests/read_tools.rs`, `tests/market_resolution.rs` cover catalog filtering, canonical IDs, native spot/perp and HIP-3 resolution | `tests/live_readonly.rs::every_read_tool_smokes_against_mainnet` passed on mainnet | Verified read-only |
| `hl_market_snapshot` | Snapshot shape, exact spread and canonical market resolution in `tests/read_tools.rs` | Mainnet smoke passed | Verified read-only |
| `hl_orderbook` | Levels, aggregation and invalid precision guards in `tests/read_tools.rs` | Mainnet smoke passed | Verified read-only |
| `hl_candles` | Completed-candle filtering and interval validation in `tests/read_tools.rs` | Mainnet smoke passed | Verified read-only |
| `hl_funding` | Current, historical and predicted views in `tests/read_tools.rs` | Mainnet smoke passed | Verified read-only |
| `hl_orders` | Open/history/status views, trigger filtering and exact order references in `tests/read_tools.rs` | Mainnet smoke passed with a read-only address | Verified read-only |
| `hl_portfolio` | All ten sections, account mode, balances, positions, margin, subaccounts, vaults, fees and rate limits in `tests/read_tools.rs` | Mainnet smoke passed with a read-only address | Verified read-only |
| `hl_account_activity` | Fills, funding, ledger, transfers and TWAP history in `tests/read_tools.rs` | Mainnet smoke passed with a read-only address | Verified read-only |
| `hl_prepare_order` | IOC market, exact quote-to-base conversion, limit, trigger, bracket, ladder and batch actions in `tests/trading_writes.rs`; signing vectors in `tests/signing_vectors.rs` | Signed testnet limit and market entries, two-leg ladder, market bracket TP/SL, and cancel-then-protection replacement accepted | Fixture and signed-live verified |
| `hl_prepare_cancel` | Exact cancel, scoped cancel and frozen order identity in `tests/trading_writes.rs` | Signed exact cancel, scoped ladder cancel, two-signature cancel-before-replace, and protection cancel accepted | Fixture and signed-live verified |
| `hl_prepare_modify` | Missing-original rejection and preservation of limit/trigger semantics in `tests/trading_writes.rs` | Signed testnet limit modify accepted; discovered trigger-price `0.0` and default modify-shape bugs were fixed | Fixture and signed-live verified |
| `hl_prepare_close` | Every size mode is reduce-only; minimum-size and decimal guards in `tests/trading_writes.rs` | Signed reduce-only full close and protection-cancel close completed; final positions and orders were empty | Fixture and signed-live verified |
| `hl_prepare_twap` | Place/cancel encoding, exact IDs, duration-derived notional and reduce-only dust behavior in `tests/trading_writes.rs` | Signed TWAP `120 / 5 min` accepted as ID `17874`, first `0.00015 BTC` slice filled and closed, then cancellation accepted; a 60-second request correctly failed the native 100-second minimum | Fixture and signed-live verified |
| `hl_prepare_risk` | Every leverage and margin intent parses and exact decimal error paths fail closed in `tests/trading_writes.rs` | Signed isolated leverage `2`, margin add `1`, and margin removal `0.5` accepted; removal `1` correctly rejected for insufficient collateral | Fixture and signed-live verified |
| `hl_prepare_deposit` | `tests/funding.rs` covers catalog resolution, exact base units, strict quote identity, allowance, approval, host StageTx/SimulateBatch/CommitTxs route, and hash-bound ledger credit | Public LI.FI quote probe exists as an opt-in ignored test; no paid mainnet wallet route executed | Fixture verified; paid live pending |
| `hl_prepare_withdraw` | `tests/funding.rs` covers signed `withdraw3` preparation, accepted-only continuation, block baseline, unique bridge log, timestamp replay defense, ambiguity and onward-route validation | No paid mainnet withdrawal executed | Fixture verified; paid live pending |
| `hl_prepare_transfer` | `tests/funding.rs` covers owned subaccounts, spot/perp movement, USDC/spot sends and supported DEX collateral movement | Signed testnet spot-to-perp and perp-to-spot transfers accepted | Fixture and signed-live verified for both directions |
| `submit_hyperliquid_action` | Unit tests in `src/tools/continuation/submit_action.rs` cover signature envelope validation, accepted/rejected normalization, replay behavior and accepted-only funding follow-up; signing vectors cover action hashing | Exercised across the accepted signed testnet roundtrip and strategy suite | Fixture and signed-live verified for Hyperliquid actions |
| `complete_hyperliquid_funding` | `tests/funding.rs` covers LI.FI status identity, exact route hash selection, ledger-hash binding, withdrawal ledger plus canonical Arbitrum block timestamp, duplicate rejection and pending states | No paid bridge settlement has been observed end to end | Fixture verified; paid live pending |

## Network and protocol evidence

- The opt-in public checks in `tests/live_readonly.rs` exercised all eight user-facing read tools against mainnet. The same suite separately confirmed that `allMids` and `perpDexs` respond on both mainnet and testnet.
- Market resolution fixtures cover native perpetuals, spot markets and named HIP-3 DEX markets. Network-qualified canonical IDs prevent accidental mainnet/testnet or DEX substitution.
- `tests/tool_contracts.rs` checks the exported tool contract. Schema tests in `tests/trading_writes.rs` require object schemas with declared properties for every write tool.
- `tests/signing_vectors.rs` verifies deterministic action hashing and signing payloads for orders, cancels, modifications, leverage, margin, transfers, TWAP and withdrawals without exposing or requiring a private key.
- The signed testnet roundtrip completed spot-to-perp and perp-to-spot transfers, isolated leverage `2`, limit place/modify/exact cancel, market entry, margin add `1`, margin removal `0.5`, and a reduce-only full close. Advanced coverage completed a two-leg ladder plus scoped cancel, market bracket TP/SL, two-signature cancel-before-protection replacement, protection-cancel close, and TWAP place/fill/cancel. Final open orders and positions were empty.
- The signed run used the app locally with Alloy signing and direct Hyperliquid submission. It validates EIP-712 payloads and exchange acceptance, but it does **not** validate the deployed host/browser wallet ceremony or its callback transport.

## Funding evidence boundaries

LI.FI fixture tests deliberately mutate recipient, chain, token, amount, spender and status identity to prove the validator rejects quote substitution. Token decimals come from the LI.FI catalog rather than caller input. ERC-20 allowance is checked against the quote's exact spender and amount. Wallet routes use the host contract `{to, description, data, chain_id, value?, gas_limit?, kind?}`, simulate the staged batch, and commit host-injected transaction IDs. The browser EOA completion binds the final batch transaction hash, which is the LI.FI leg when approval precedes it.

The ignored public LI.FI test requests a Base USDC to HyperCore-perps quote and validates it without signing or sending. It is network-dependent and is not equivalent to a paid end-to-end deposit. Deposit completion additionally requires LI.FI receiving-transaction identity and a matching HyperCore deposit ledger hash. Withdrawal completion requires a matching HyperCore withdrawal, a unique USDC `Transfer` from the documented Hyperliquid Arbitrum bridge, and a canonical block timestamp at or after the ledger event. Pending or ambiguous evidence never becomes success.

Mainnet deposit, withdrawal, approval, bridge settlement and onward bridging remain unexecuted because they move real funds. They require the final private-key-assisted test and explicit balance/fee budget. Testnet cannot establish equivalence for LI.FI's HyperCore mainnet route.

## Remaining gates and limitations

- **Final automated suite:** the full final managed test run is in progress; record its command and result when complete.
- **Paid funding:** no mainnet deposit/withdraw/onward transaction has been sent. The host route and settlement observers are verified with fixtures plus public quote/API data only.
- **Nonce scope:** nonce/replay coordination is process-local. Concurrent signers in separate app processes can race unless the deployment provides a shared nonce coordinator or serializes writes per account.
- **Wallet mode:** the app declares no sponsored or account-abstraction policy. Funding relies on the connected EOA wallet/default broadcaster; the current host API has no per-route AA override.
- **Host/browser signing:** local Alloy signing passed, but the real host/browser EIP-712 request, callback binding, and user-wallet confirmation path remain untested.
- **Deployment:** build-staging deployment and deployed smoke evidence are pending. Add the deployment identifier, version, and smoke result after the single planned rollout.

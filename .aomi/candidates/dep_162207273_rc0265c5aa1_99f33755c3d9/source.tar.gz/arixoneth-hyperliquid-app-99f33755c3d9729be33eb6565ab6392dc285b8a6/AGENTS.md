# Hyperliquid app

This repository is separate from Hoodit. Keep venue logic inside the app.
Use exact decimal strings and resolve fresh market metadata before writes.
Derive write identities from the host context. Never accept a model-selected signer.
Preserve wallet routes and verify the signed action before submission.
Never log or commit credentials, private keys, or signatures.
Run resource-managed builds with the Aomi workflow skill, workspace `hyperliquid-app`.
Keep tools grouped by portfolio/trading and put protocol code in the adapter.

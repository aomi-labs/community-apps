# Daiko pilot acceptance

## Verified 2026-11-06

- Community Project 1675 belongs to aomi-labs/daiko-bot under Cecilia's builder account.
- App 2937821 activated, artifact-ready and runtime-loaded on staging. Source checks and automatic activation passed through commit fcab967.
- SDK 7.0.0 and Dottie's exact managed Solana wallet manifest accepted by manager preflight.
- Hosted no-tool and exact-mint token checks completed; DEX Screener, Jupiter and RugCheck results included source timestamps.
- TwitterAPI.io, ScrapeCreators and Solana Tracker credentials are in 1Password and the app vault. Hosted X and compact TikTok reads succeeded; a local token-specific KOL read succeeded.
- TikTok output is capped at 10 unique video links and about 7 KB in the real sample, rather than the multi-megabyte raw response. Meme matches do not establish token affiliation.
- Telegram @daiko_aomi_bot is registered with the shared Aomi host, active, mapped only to Daiko app 2937821, with group privacy enabled. Its webhook is configured on api-staging.aomi.dev with no pending updates or errors.
- A real /start provisioned Daiko's managed Solana wallet using the same Instant suggestion as Dottie. A subsequent Telegram exact-mint query returned a concise wSOL identity, pool-specific market evidence and risk limitations. No funds or trades were used.
- Existing Chrome profile is signed into fomo. The narrow DOM reader extracted 20 real public thesis rows and source links without position/PnL fields.
- Seven Rust tests, three Playwright relay tests and seven new bridge tests cover schemas, identity, cost/cache guards, TikTok bounds, authenticated pairing, offline semantics and rejection of unsolicited browser results.

## Still required before group launch

- Install the prepared fomo-only extension into the existing Chrome profile after action-time browser permission approval. Verify a real extension thesis read, persistence/reconnect and a hosted Daiko thesis call. The deployed bridge and manual DOM extraction alone do not prove the full path.
- One hosted token-specific Solana Tracker KOL read and source-labelled trending result.
- A real group mention/reply test and concise Japanese/English responses; no unsolicited group trading or research.
- Pilot group validation of practical reply length and usefulness.

No trade, signature, broadcast or funding was performed during research acceptance. Optional credentials never justify fabricated evidence. Vendor quotas/prepaid balances and the bridge-wide browser cap bound their respective sources; app per-process guards are not a fleetwide dollar cap.

use crate::client::*;
use aomi_sdk::{DynAomiTool, DynToolCallCtx, schemars::JsonSchema};
use serde::Deserialize;
use serde_json::{Value, json};
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Empty {}
impl JsonSchema for Empty {
    fn schema_name() -> std::borrow::Cow<'static, str> {
        "Empty".into()
    }
    fn json_schema(_: &mut schemars::SchemaGenerator) -> schemars::Schema {
        schemars::json_schema!({"type":"object","properties":{},"required":[],"additionalProperties":false})
    }
}
#[derive(Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct Mint {
    /// Exact Solana mint; never a ticker or wallet URL.
    pub mint: String,
}
#[derive(Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct Meme {
    /// Specific meme/project name resolved from a token or supplied by the user. Not proof of token affiliation.
    pub query: String,
}
macro_rules! tool {
    ($t:ident,$args:ty,$name:literal,$desc:literal,$f:expr) => {
        pub struct $t;
        impl DynAomiTool for $t {
            type App = DaikoApp;
            type Args = $args;
            const NAME: &'static str = $name;
            const DESCRIPTION: &'static str = $desc;
            fn run(_: &DaikoApp, args: Self::Args, ctx: DynToolCallCtx) -> Result<Value, String> {
                ($f)(args, ctx)
            }
        }
    };
}
tool!(
    About,
    Empty,
    "daiko_about",
    "Report app build, SDK, supported sources and credential configuration. Configuration is not a live connectivity test.",
    |_: Empty, ctx: DynToolCallCtx| {
        Ok(
            json!({"status":"ok","app":"daiko","build":env!("CARGO_PKG_VERSION"),"sdk":aomi_sdk::AOMI_SDK_VERSION,"research_only_tools":true,"sources":["dexscreener","jupiter","rugcheck","twitterapi.io","scrapecreators","fomo","solana_tracker"],"configured":{"x":key(&ctx,"TWITTERAPI_IO_KEY").is_some(),"tiktok":key(&ctx,"SCRAPECREATORS_KEY").is_some(),"wallets":key(&ctx,"SOLANA_TRACKER_KEY").is_some(),"fomo":key(&ctx,"FOMO_RELAY_URL").is_some()&&key(&ctx,"FOMO_RELAY_KEY").is_some()},"limits":"Single page, cached; daily request guards are per process, not a fleetwide spending guarantee"}),
        )
    }
);
tool!(
    Token,
    Mint,
    "daiko_token",
    "Resolve an exact Solana CA using DEX Screener, Jupiter and RugCheck. Returns market context and risk findings; verification labels never guarantee safety. Free/public reads only.",
    |args: Mint, ctx: DynToolCallCtx| {
        let m = mint(&args.mint)?;
        let mut dex = get(
            "dexscreener",
            &format!("https://api.dexscreener.com/token-pairs/v1/solana/{m}"),
            &[],
            None,
            30,
            10000,
        );
        if let Some(a) = dex["data"].as_array_mut() {
            a.retain(|p| p["chainId"] == "solana" && p["baseToken"]["address"] == m);
            a.sort_by(|a, b| {
                b["liquidity"]["usd"]
                    .as_f64()
                    .unwrap_or(0.)
                    .total_cmp(&a["liquidity"]["usd"].as_f64().unwrap_or(0.))
            });
            a.truncate(3);
            for p in a {
                *p = select(
                    p,
                    &[
                        "chainId",
                        "dexId",
                        "url",
                        "pairAddress",
                        "baseToken",
                        "quoteToken",
                        "priceUsd",
                        "txns",
                        "volume",
                        "priceChange",
                        "liquidity",
                        "fdv",
                        "marketCap",
                        "pairCreatedAt",
                        "info",
                        "boosts",
                    ],
                );
            }
        }
        let jk = key(&ctx, "JUPITER_API_KEY");
        let mut jup = get(
            "jupiter",
            "https://api.jup.ag/tokens/v2/search",
            &[("query", m)],
            jk.as_deref().map(|k| ("x-api-key", k)),
            120,
            10000,
        );
        if let Some(a) = jup["data"].as_array_mut() {
            a.retain(|t| t["id"] == m);
            a.truncate(1);
        }
        let mut risk = get(
            "rugcheck",
            &format!("https://api.rugcheck.xyz/v1/tokens/{m}/report/summary"),
            &[],
            None,
            120,
            10000,
        );
        if risk["status"] == "ok" {
            risk["data"] = select(
                &risk["data"],
                &[
                    "tokenProgram",
                    "risks",
                    "score",
                    "score_normalised",
                    "rugged",
                    "tokenType",
                ],
            );
        }
        Ok(
            json!({"status":"ok","chain":"solana","mint":m,"sources":[dex,jup,risk],"links":{"chart":format!("https://dexscreener.com/solana/{m}"),"risk":format!("https://rugcheck.xyz/tokens/{m}")},"warning":"No report or vendor verification label proves safety. Social affiliation requires separate evidence."}),
        )
    }
);
tool!(
    XPulse,
    Mint,
    "daiko_x_pulse",
    "On-demand X research: one recent search page mentioning the exact CA. A sample, not total mentions, sentiment, or proof of earliest origin. Cached for ten minutes.",
    |args: Mint, ctx: DynToolCallCtx| {
        let m = mint(&args.mint)?;
        let Some(k) = key(&ctx, "TWITTERAPI_IO_KEY") else {
            return Ok(unavailable("twitterapi.io", "not_configured"));
        };
        let q = format!("\"{m}\" -filter:retweets");
        let mut v = get(
            "twitterapi.io",
            "https://api.twitterapi.io/twitter/tweet/advanced_search",
            &[("query", &q), ("queryType", "Latest")],
            Some(("X-API-Key", &k)),
            600,
            500,
        );
        limit(&mut v, "/data/tweets", 20);
        if let Some(a) = v.pointer_mut("/data/tweets").and_then(Value::as_array_mut) {
            for p in a {
                let author = select(&p["author"], &["userName", "name", "url"]);
                *p = select(
                    p,
                    &[
                        "id",
                        "url",
                        "text",
                        "createdAt",
                        "likeCount",
                        "retweetCount",
                        "replyCount",
                        "viewCount",
                    ],
                );
                p["author"] = author;
            }
        }
        v["coverage"] = json!(
            "One search page, up to 20 returned posts; no pagination. Not a complete census."
        );
        Ok(v)
    }
);
tool!(
    TikTok,
    Meme,
    "daiko_tiktok",
    "Search TikTok for a specific meme/project name, one page on demand. Results describe a meme; token affiliation remains unverified unless explicitly evidenced.",
    |args: Meme, ctx: DynToolCallCtx| {
        let q = args.query.trim();
        if q.is_empty() || q.len() > 100 || q.chars().any(char::is_control) {
            return Err("Use a specific meme name of 1-100 characters".into());
        }
        let Some(k) = key(&ctx, "SCRAPECREATORS_KEY") else {
            return Ok(unavailable("scrapecreators", "not_configured"));
        };
        let mut v = get(
            "scrapecreators",
            "https://api.scrapecreators.com/v1/tiktok/search/keyword",
            &[("query", q)],
            Some(("x-api-key", &k)),
            900,
            100,
        );
        v["query"] = json!(q);
        v["token_affiliation"] = json!(
            "unverified; matching a meme or ticker alone does not link its creator to a token"
        );
        Ok(v)
    }
);
tool!(
    Thesis,
    Mint,
    "daiko_thesis",
    "Read cached public fomo thesis comments via the authenticated browser relay. Missing login or offline browser returns unavailable; never invent comments.",
    |args: Mint, ctx: DynToolCallCtx| {
        let m = mint(&args.mint)?;
        let (Some(url), Some(k)) = (key(&ctx, "FOMO_RELAY_URL"), key(&ctx, "FOMO_RELAY_KEY"))
        else {
            return Ok(unavailable("fomo", "not_configured"));
        };
        let Ok(parsed) = reqwest::Url::parse(&url) else {
            return Ok(unavailable("fomo", "invalid_configuration"));
        };
        if parsed.scheme() != "https"
            || parsed.host_str().is_none()
            || !parsed.username().is_empty()
            || parsed.password().is_some()
        {
            return Ok(unavailable("fomo", "invalid_configuration"));
        }
        let bearer = format!("Bearer {k}");
        let v = get(
            "fomo",
            &format!("{}/thesis/{m}", url.trim_end_matches('/')),
            &[],
            Some(("authorization", &bearer)),
            // The relay owns the five-minute success cache. Brief local caching lets pending reads recover.
            5,
            1000,
        );
        // Preserve relay status/fetched_at rather than stamping stale nested data as fresh.
        if v["status"] == "ok" {
            return Ok(v["data"].clone());
        }
        Ok(v)
    }
);
tool!(
    Wallets,
    Mint,
    "daiko_wallets",
    "Read token-specific labelled KOL trades from Solana Tracker, one page. Historical trades do not prove current holdings or a label's identity. On demand only.",
    |args: Mint, ctx: DynToolCallCtx| {
        let m = mint(&args.mint)?;
        let Some(k) = key(&ctx, "SOLANA_TRACKER_KEY") else {
            return Ok(unavailable("solana_tracker", "not_configured"));
        };
        let mut v = get(
            "solana_tracker",
            &format!("https://data.solanatracker.io/trades/kols/{m}"),
            &[("limit", "20"), ("hideArb", "true")],
            Some(("x-api-key", &k)),
            120,
            1000,
        );
        limit(&mut v, "/data/trades", 20);
        v["coverage"] = json!(
            "Provider-labelled KOL trades, one page. A past buy is not proof of a current holding."
        );
        Ok(v)
    }
);
tool!(
    Trending,
    Empty,
    "daiko_trending",
    "Get Solana Tracker trending tokens; falls back to DEX Screener paid boosts explicitly labelled as promotion, never organic trends.",
    |_: Empty, ctx: DynToolCallCtx| {
        if let Some(k) = key(&ctx, "SOLANA_TRACKER_KEY") {
            let mut v = get(
                "solana_tracker",
                "https://data.solanatracker.io/tokens/trending",
                &[],
                Some(("x-api-key", &k)),
                120,
                1000,
            );
            limit(&mut v, "/data", 10);
            if v["status"] == "ok" {
                return Ok(v);
            }
        }
        let mut v = get(
            "dexscreener",
            "https://api.dexscreener.com/token-boosts/top/v1",
            &[],
            None,
            120,
            10000,
        );
        if let Some(a) = v["data"].as_array_mut() {
            a.retain(|p| p["chainId"] == "solana");
            a.truncate(10);
        }
        v["ranking_kind"] = json!("paid_boosts");
        v["warning"] = json!("Paid promotion, not an organic popularity or quality ranking");
        Ok(v)
    }
);

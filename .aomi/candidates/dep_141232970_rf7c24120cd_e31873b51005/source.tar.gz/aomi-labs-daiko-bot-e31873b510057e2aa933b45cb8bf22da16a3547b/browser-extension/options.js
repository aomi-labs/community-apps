const url=document.querySelector('#url'),key=document.querySelector('#key'),status=document.querySelector('#status');
chrome.storage.local.get(['bridgeUrl','browserKey']).then(x=>{url.value=x.bridgeUrl??'';key.value=x.browserKey??'';});
document.querySelector('form').addEventListener('submit',async event=>{event.preventDefault();
  try{const u=new URL(url.value);if(u.protocol!=='https:' || !/^daiko-fomo-bridge\.[a-z0-9-]+\.workers\.dev$/.test(u.hostname))throw Error();
    await chrome.storage.local.set({bridgeUrl:u.origin,browserKey:key.value});status.textContent='Saved. Connection will resume while Chrome is running.';
  }catch{status.textContent='Enter the deployed Daiko HTTPS workers.dev URL.';}
});

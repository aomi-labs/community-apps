// This function runs in the isolated content-script world. Only rendered thesis rows leave the page.
export function readThesis(mint) {
  if (location.origin !== 'https://fomo.family' || location.pathname !== `/tokens/solana/${mint}`) return {status:'page_mismatch'};
  const comments=[];
  for (const control of document.querySelectorAll('[aria-label="Like comment"]')) {
    const row=control.closest('button');
    const content=Array.from(control.parentElement?.children ?? []).find(x=>x!==control);
    const text=content?.innerText?.trim();
    const author=row?.firstElementChild?.innerText?.split('\n')[0]?.trim();
    if(!text || !author || comments.some(x=>x.author===author && x.text===text.slice(0,1600)))continue;
    const links=Array.from(content.querySelectorAll('a[href]')).map(a=>a.href).filter(h=>/^https:\/\//.test(h)).slice(0,3).map(h=>h.slice(0,300));
    comments.push({author:author.slice(0,80),text:text.slice(0,1600),likes:control.innerText?.trim().slice(0,20) ?? null,links});
    if(comments.length===20)break;
  }
  if(!comments.length) return {status:'no_visible_theses'};
  return {status:'ok',mint,source_url:`https://fomo.family/tokens/solana/${mint}`,comments,
    coverage:'Up to 20 rendered thesis comments in the page\'s current holder/default order. Not all comments, not a vote ranking. Comments may be truncated by the site; community opinions are unverified.'};
}

import {test} from 'node:test';
import assert from 'node:assert/strict';
import {sameSecret,validMint,cleanResult} from './contract.mjs';
import worker,{BrowserBridge} from './worker.mjs';
const mint='So11111111111111111111111111111111111111112',key='a'.repeat(40);
class Store{
 constructor(){this.values=new Map();}
 async get(k){return this.values.get(k);}
 async put(k,v){this.values.set(k,v);}
 async delete(k){this.values.delete(k);}
 async transaction(fn){return fn(this);}
 async list({prefix,limit}){return new Map(Array.from(this.values).filter(([k])=>k.startsWith(prefix)).slice(0,limit));}
}
function setup(){const sockets=[];const ctx={storage:new Store(),getWebSockets:()=>sockets,waitUntil:()=>{}};const bridge=new BrowserBridge(ctx,{FOMO_BROWSER_KEY:key});return {ctx,bridge,sockets};}
function socket(attachment={authenticated:true}){return {attachment,deserializeAttachment(){return this.attachment;},serializeAttachment(a){this.attachment=a;},sent:[],send(x){this.sent.push(JSON.parse(x));},close(){this.closed=true;}};}
test('exact bearer and exact 32-byte mint are required',async()=>{
 assert(await sameSecret(`Bearer ${key}`,`Bearer ${key}`));assert(!await sameSecret('Bearer wrong',`Bearer ${key}`));assert(!await sameSecret(undefined,key));
 assert(validMint(mint));for(const bad of ['SOL','1'.repeat(31),'1'.repeat(33),'0'.repeat(32),'../x'])assert(!validMint(bad));
});
test('worker cannot reach browser without app authentication',async()=>{
 let forwarded=false;const env={FOMO_RELAY_KEY:key,BROWSER:{idFromName(){},get(){return {fetch(){forwarded=true;}};}}};
 const r=await worker.fetch(new Request('https://relay/thesis/'+mint),env);assert.equal(r.status,401);assert(!forwarded);
});
test('browser must pair before accepting result data',async()=>{
 const {bridge}=setup(),ws=socket({authenticated:false});await bridge.webSocketMessage(ws,JSON.stringify({type:'result',value:{}}));assert(ws.closed);assert(!ws.attachment.authenticated);
});
test('offline browser and exhausted quota do not fabricate successful empty data',async()=>{
 const {bridge,sockets,ctx}=setup();let value=await (await bridge.fetch(new Request('https://relay/thesis/'+mint))).json();assert.equal(value.status,'browser_offline');assert.equal(value.data,null);
 sockets.push(socket());await ctx.storage.put('quota',{day:new Date().toISOString().slice(0,10),count:100});value=await (await bridge.fetch(new Request('https://relay/thesis/'+mint))).json();assert.equal(value.status,'daily_cap');assert.equal(sockets[0].sent.length,0);
});
test('matching replies resolve, bound output and cache with original timestamp',async()=>{
 const {bridge,sockets,ctx}=setup(),ws=socket();sockets.push(ws);
 const pending=bridge.fetch(new Request('https://relay/thesis/'+mint));
 await new Promise(r=>setImmediate(r));const req=ws.sent[0];assert.equal(req.type,'read');
 await bridge.webSocketMessage(ws,JSON.stringify({type:'result',id:req.id,mint,value:{status:'ok',mint,comments:Array.from({length:25},()=>({author:'alice',text:'a'.repeat(1800),links:['javascript:alert(1)','https://x.com/test']}))}}));
 const result=await(await pending).json();assert.equal(result.status,'ok');assert.equal(result.data.comments.length,20);assert.equal(result.data.comments[0].text.length,1600);assert.deepEqual(result.data.comments[0].links,['https://x.com/test']);
 const hit=await(await bridge.fetch(new Request('https://relay/thesis/'+mint))).json();assert(hit.cached);assert.equal(hit.fetched_at,result.fetched_at);assert.equal(ws.sent.length,1);assert.equal((await ctx.storage.get('quota')).count,1);
});
test('unsolicited and wrong-mint browser results cannot poison cache',async()=>{
 const {bridge,ctx}=setup(),ws=socket({authenticated:true,request:{id:'expected',mint,at:Date.now()}});
 await bridge.webSocketMessage(ws,JSON.stringify({type:'result',id:'unexpected',mint,value:{status:'ok',mint,comments:[{author:'a',text:'b'}]}}));assert.equal(await ctx.storage.get('cache:'+mint),undefined);
 assert.equal(cleanResult({status:'ok',mint:'wrong',comments:[{author:'a',text:'b'}]},mint).status,'invalid_browser_response');
});
test('an unauthenticated socket closing does not interrupt a valid read',()=>{
 const {bridge}=setup(),good=socket(),bad=socket({authenticated:false});let resolved=false;
 bridge.pending.set('a',{socket:good,resolve(){resolved=true;},timer:setTimeout(()=>{},50)});bridge.webSocketClose(bad);assert(!resolved);clearTimeout(bridge.pending.get('a').timer);
});

"use client";

import { ExternalLink, KeyRound, Loader2 } from "lucide-react";
import { useActionState } from "react";

import { connect } from "@/app/actions";

export function ConnectForm({ authorizeUrl, expired = false }: { authorizeUrl: string; expired?: boolean }) {
  const [state, action, pending] = useActionState(connect, undefined);

  return (
    <form action={action} className="w-full max-w-md space-y-5">
      <div>
        {expired && (
          <p className="mb-3 rounded-md border border-danger/35 bg-danger/8 px-3 py-2 text-xs text-danger">
            Arc Studio no longer accepts the saved token. Connect again.
          </p>
        )}
        <h1 className="font-display text-2xl tracking-tight text-ink">Connect your Arc Studio account</h1>
        <p className="mt-2 text-sm leading-6 text-ink-muted">
          Aomi reads your app&apos;s contracts and compiled artifacts, attacks them on a held Arc
          fork, and can send verified findings back to Arc Studio for a fix. Nothing is signed,
          deployed, or broadcast.
        </p>
      </div>

      <ol className="space-y-3 text-sm text-ink">
        <li className="flex gap-3">
          <span className="grid size-6 shrink-0 place-items-center rounded-pill bg-accent-subtle text-xs font-medium text-accent-strong">
            1
          </span>
          <span>
            Open{" "}
            <a
              href={authorizeUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1 text-accent-strong underline underline-offset-2"
            >
              Arc Studio&apos;s token page <ExternalLink className="size-3" />
            </a>{" "}
            and click <strong>Authorize</strong>.
          </span>
        </li>
        <li className="flex gap-3">
          <span className="grid size-6 shrink-0 place-items-center rounded-pill bg-accent-subtle text-xs font-medium text-accent-strong">
            2
          </span>
          <span>Paste the token it shows (starts with <code className="font-mono">origin_pat_</code>).</span>
        </li>
      </ol>

      <label className="block">
        <span className="sr-only">Arc Studio token</span>
        <div className="flex items-center gap-2 rounded-pill border border-border bg-surface px-4 transition focus-within:border-ink">
          <KeyRound className="size-4 text-ink-muted" />
          <input
            name="token"
            type="password"
            autoComplete="off"
            spellCheck={false}
            required
            placeholder="origin_pat_…"
            className="h-11 w-full bg-transparent font-mono text-sm text-ink outline-none placeholder:text-ink-muted/70"
          />
        </div>
      </label>

      {state?.error && <p className="text-sm text-danger">{state.error}</p>}

      <button
        type="submit"
        disabled={pending}
        className="flex h-11 w-full items-center justify-center gap-2 rounded-pill bg-ink text-sm font-medium text-bg transition hover:bg-ink/85 disabled:opacity-70"
      >
        {pending && <Loader2 className="size-4 animate-spin" />} Connect
      </button>

      <p className="text-xs leading-5 text-ink-muted">
        The token is verified with Arc Studio, then kept only in an encrypted, httpOnly cookie on
        this site for 7 days. Revoke it anytime with <code className="font-mono">arc-studio tokens revoke</code> or from
        Arc Studio.
      </p>
    </form>
  );
}

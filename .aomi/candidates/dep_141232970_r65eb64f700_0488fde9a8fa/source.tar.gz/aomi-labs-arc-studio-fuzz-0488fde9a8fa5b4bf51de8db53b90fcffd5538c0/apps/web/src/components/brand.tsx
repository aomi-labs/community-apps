/**
 * Header lockup: the Aomi mark and the company signature "aomi labs" (aomi-design
 * `assets/logo/aomi-mark.svg`, wordmark in Source Serif 4 SemiBold), then the product
 * name in body sans.
 * Inlined rather than imported from the widget so the connect page does not
 * pull in the chat bundle for a logo. Everything renders in currentColor.
 */
export function Brand() {
  return (
    <div className="flex shrink-0 items-center gap-3 whitespace-nowrap text-ink">
      <span className="inline-flex items-center gap-[0.34em] text-[20px]" role="img" aria-label="Aomi Labs">
        <svg viewBox="0 0 362 362" fill="currentColor" aria-hidden className="size-[1em] shrink-0">
          <path d="M321.778 94.2349C321.778 64.4045 297.595 40.2222 267.765 40.2222C237.935 40.2222 213.752 64.4045 213.752 94.2349C213.752 124.065 237.935 148.248 267.765 148.248C297.595 148.248 321.778 124.065 321.778 94.2349ZM362 94.2349C362 146.279 319.81 188.47 267.765 188.47C215.721 188.47 173.53 146.279 173.53 94.2349C173.53 42.1904 215.721 1.33271e-06 267.765 0C319.81 0 362 42.1904 362 94.2349Z" />
          <path d="M181 0C184.792 0 188.556 0.116399 192.289 0.346221C189.506 2.74481 186.833 5.26892 184.28 7.90977C170.997 20.759 160.669 36.6452 154.42 54.4509C95.7682 66.7078 51.7143 118.709 51.7143 181C51.7143 252.403 109.597 310.286 181 310.286C243.292 310.286 295.291 266.231 307.547 207.58C325.364 201.327 341.259 190.99 354.113 177.695C356.745 175.149 359.261 172.486 361.653 169.71C361.883 173.444 362 177.208 362 181C362 280.964 280.964 362 181 362C81.0365 362 0 280.964 0 181C0 81.0365 81.0365 0 181 0Z" />
        </svg>
        <span
          aria-hidden
          className="font-semibold leading-none tracking-[-0.025em]"
          style={{ fontFamily: 'var(--font-source-serif-4, "Source Serif 4"), ui-serif, Georgia, serif' }}
        >
          aomi labs
        </span>
      </span>
      <span className="h-4 w-px bg-border" />
      <span className="text-[14px] font-medium tracking-tight">
        Fuzz <span className="font-normal text-ink-muted">for Arc Studio</span>
      </span>
    </div>
  );
}

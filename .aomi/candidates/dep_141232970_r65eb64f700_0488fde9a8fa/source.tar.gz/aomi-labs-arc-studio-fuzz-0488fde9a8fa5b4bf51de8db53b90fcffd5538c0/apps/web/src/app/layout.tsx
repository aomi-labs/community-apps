import type { Metadata } from "next";
import { Geist, Geist_Mono, PT_Serif, Source_Serif_4 } from "next/font/google";
import type { ReactNode } from "react";

import "@aomi-labs/widget-lib/styles.css";
import "./globals.css";

// Brand faces (aomi-design): Geist for UI, Geist Mono for code and addresses,
// PT Serif for display headings, Source Serif 4 for the "aomi" wordmark only.
// The variable names are the ones the Aomi widget stylesheet reads, so the
// embedded chat picks up the same loaded fonts.
const sans = Geist({ subsets: ["latin"], variable: "--font-geist-sans", display: "swap" });
const mono = Geist_Mono({ subsets: ["latin"], variable: "--font-geist-mono", display: "swap" });
const display = PT_Serif({ subsets: ["latin"], weight: ["400", "700"], variable: "--font-pt-serif", display: "swap" });
const wordmark = Source_Serif_4({ subsets: ["latin"], variable: "--font-source-serif-4", display: "swap" });

// Light-first like aomi.dev; follows the OS appearance. The widget stylesheet
// keys its dark token set off `.dark`, so that class is set before first paint.
const THEME_SCRIPT = `(()=>{try{var m=matchMedia("(prefers-color-scheme: dark)"),s=function(){document.documentElement.classList.toggle("dark",m.matches)};s();m.addEventListener("change",s)}catch(e){}})()`;

export const metadata: Metadata = {
  title: "Aomi Fuzz for Arc Studio",
  description:
    "Stateful fuzzing of your Arc Studio contracts on a held Arc fork, with verified reproductions sent back to Arc Studio for a fix.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: THEME_SCRIPT }} />
      </head>
      <body className={`${sans.variable} ${mono.variable} ${display.variable} ${wordmark.variable} font-sans antialiased`}>
        {children}
      </body>
    </html>
  );
}

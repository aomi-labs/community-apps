import { ChevronRight, LogOut } from "lucide-react";
import Link from "next/link";

import { disconnect } from "@/app/actions";
import { Brand } from "@/components/brand";
import { ConnectForm } from "@/components/connect-form";
import { StudioSession } from "@/server/studio-session";

export const dynamic = "force-dynamic";

export default async function Home() {
  const session = await StudioSession.current();
  // A stored token Arc Studio no longer accepts (revoked, expired, other host) sends the user back to connect.
  const apps = await session
    ?.client()
    .listApps()
    .then((list) => list.sort((a, b) => b.timestamp.localeCompare(a.timestamp)))
    .catch(() => null);

  if (!session || !apps) {
    return (
      <main className="flex min-h-screen flex-col">
        <header className="flex h-14 items-center border-b border-border px-5">
          <Brand />
        </header>
        <div className="flex flex-1 items-center justify-center px-4 py-12">
          <ConnectForm authorizeUrl={`${StudioSession.apiUrl}/cli-auth`} expired={Boolean(session)} />
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen">
      <header className="flex h-14 items-center justify-between border-b border-border px-5">
        <Brand />
        <form action={disconnect}>
          <button className="flex items-center gap-1.5 rounded-pill px-3 py-1.5 text-xs text-ink-muted transition hover:bg-hover hover:text-ink">
            <LogOut className="size-3.5" /> Disconnect
          </button>
        </form>
      </header>
      <section className="mx-auto max-w-3xl px-4 py-10">
        <h1 className="font-display text-2xl tracking-tight text-ink">Pick an Arc Studio app to fuzz</h1>
        <p className="mt-1.5 text-sm text-ink-muted">
          {apps.length} app{apps.length === 1 ? "" : "s"} in your Arc Studio account.
        </p>
        <ul className="mt-6 divide-y divide-border overflow-hidden rounded-lg border border-border bg-surface">
          {apps.map((app) => (
            <li key={app.id}>
              <Link
                href={`/apps/${app.id}`}
                className="flex items-center gap-4 px-4 py-3.5 transition hover:bg-hover"
              >
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm text-ink">
                    {app.description || "Untitled app"}
                  </p>
                  <p className="mt-0.5 font-mono text-[11px] text-ink-muted">
                    {app.id}
                    {app.timestamp && ` · ${new Date(app.timestamp).toLocaleString()}`}
                  </p>
                </div>
                <ChevronRight className="size-4 text-ink-muted" />
              </Link>
            </li>
          ))}
          {apps.length === 0 && (
            <li className="px-4 py-8 text-center text-sm text-ink-muted">
              No apps yet. Build one in Arc Studio, then come back.
            </li>
          )}
        </ul>
      </section>
    </main>
  );
}

"use client";

import { ArcStudioApp, CampaignTrace, FuzzTarget, INSTALL_ADDRESS } from "@aomi-labs/arc-studio-fuzz-core";
import { useAomiRuntime, usePerThreadControl } from "@aomi-labs/react";
import { AomiFrame } from "@aomi-labs/widget-lib";
import {
  AlertTriangle,
  BrainCircuit,
  Check,
  ChevronRight,
  CircleDot,
  ExternalLink,
  Play,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  Wrench,
  X,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState, useTransition } from "react";

import { requestFix, type TargetData } from "@/app/actions";
import type { AomiAccount } from "@/lib/aomi-account";

const MAX_RESUMES = 6;
const FALLBACK_MODELS = [
  "GPT-6 Sol",
  "Gemini 3 Flash",
  "Claude Sonnet 5",
  "Claude Opus 5",
  "Claude Haiku 4.5",
  "GPT-6 Luna",
];

function CampaignModelSelect({ backendUrl, disabled }: { backendUrl: string; disabled: boolean }) {
  const { currentThreadId } = useAomiRuntime();
  const {
    actions: { getCurrentThreadControl, onModelSelect },
  } = usePerThreadControl();
  const [models, setModels] = useState(FALLBACK_MODELS);
  const control = getCurrentThreadControl();
  const auto = control.modelMode === "auto" || !control.model;
  const value = auto ? "auto" : (control.model ?? "auto");

  useEffect(() => {
    const controller = new AbortController();
    const url = new URL("/api/thread/models", backendUrl);
    void fetch(url, {
      headers: { "X-Session-Id": currentThreadId, "X-Thread-Id": currentThreadId },
      signal: controller.signal,
    })
      .then(async (response) => {
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const available = (await response.json()) as unknown;
        if (Array.isArray(available) && available.every((model) => typeof model === "string") && available.length > 0) {
          setModels(available);
        }
      })
      .catch((error: unknown) => {
        if (!(error instanceof DOMException && error.name === "AbortError")) {
          console.warn("Could not refresh the Aomi model catalog; using the bundled list.", error);
        }
      });
    return () => controller.abort();
  }, [backendUrl, currentThreadId]);

  return (
    <select
      aria-label="Campaign model"
      disabled={disabled}
      value={value}
      onChange={(event) => {
        const model = event.target.value;
        if (model === "auto") {
          void onModelSelect(models[0] ?? "GPT-6 Sol", { mode: "auto" });
        } else {
          void onModelSelect(model, { mode: "manual" });
        }
      }}
      className="h-8 max-w-40 rounded-pill border border-border bg-bg px-2.5 text-[11px] text-ink outline-none hover:bg-hover disabled:cursor-not-allowed disabled:opacity-50"
    >
      <option value="auto">Balanced</option>
      {models.map((model) => (
        <option key={model} value={model}>
          {model}
        </option>
      ))}
    </select>
  );
}

function short(value: string, head = 8, tail = 6): string {
  return value.length <= head + tail + 1 ? value : `${value.slice(0, head)}…${value.slice(-tail)}`;
}

function pretty(value: unknown): string {
  if (value === undefined) return "";
  const output = typeof value === "string" ? value : JSON.stringify(value, null, 2);
  return output.length > 1_200 ? `${output.slice(0, 1_200)}\n…` : output;
}

function messageText(content: unknown): string {
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    return content
      .map((item) => (item && typeof item === "object" ? (item as { text?: unknown }).text : undefined))
      .filter((item): item is string => typeof item === "string")
      .join("\n");
  }
  return pretty(content);
}

export function FuzzPanel({
  appId,
  backendUrl,
  account,
  target: data,
  onRefresh,
}: {
  appId: string;
  backendUrl: string;
  /** Signed-in runs seed the world first; guests hit the per-call input cap partway through. */
  account: AomiAccount | null;
  target: TargetData;
  onRefresh: () => void;
}) {
  const {
    createThread,
    currentThreadId,
    events,
    getMessages,
    isRunning,
    isSubmitting,
    sendMessage,
    setUser,
    turnState,
  } = useAomiRuntime();
  const signedIn = Boolean(account);
  const {
    actions: { getCurrentThreadControl, onModelSelect },
  } = usePerThreadControl();
  const target = useMemo(
    () =>
      new FuzzTarget(
        data.name,
        data.sourcePath,
        data.source,
        data.abi,
        data.deployedBytecode,
        data.chainId,
        data.deployment,
      ),
    [data],
  );
  const [runs, setRuns] = useState(0);
  /** Automatic "continue" messages sent after execution-limit stops in this run. */
  const [resumes, setResumes] = useState(0);
  /** Tool calls, every runtime event, or the canonical Aomi conversation. */
  const [view, setView] = useState<"tools" | "ledger" | "chat">("tools");
  const [failure, setFailure] = useState<string | null>(null);
  /** This run's world was seeded by the harness rather than set up in the chat. */
  const [seeded, setSeeded] = useState(false);
  const [fix, setFix] = useState<{ webUrl?: string; error?: string } | null>(null);
  const [fixing, startFix] = useTransition();
  const traceEnd = useRef<HTMLDivElement>(null);

  const trace = useMemo(() => new CampaignTrace(events), [events]);
  const { report, finding } = trace;
  const started = runs > 0;
  const busy = started && (isSubmitting || isRunning || turnState === "processing");
  const finished = started && !busy && turnState === "complete";
  /** The backend ended the turn without a campaign result. */
  const turnFailed = started && !busy && (turnState === "failed" || turnState === "interrupted");
  const turnError = turnFailed
    ? (trace.errors.at(-1) ??
      trace.notice ??
      (signedIn
        ? `The agent's turn ended (${turnState}) before the campaign finished.`
        : "The guest session hit Aomi's per-call input cap. Sign in to Aomi (top right) and run again for a complete campaign."))
    : null;
  const finalMessage = [...getMessages()].reverse().find((message) => message.role === "assistant");

  useEffect(() => {
    setUser(target.userState(appId, "Arc Studio app"));
  }, [appId, setUser, target]);

  // The runtime caps model calls per turn; the campaign and sim world persist,
  // so resume automatically when a turn stops at that limit.
  useEffect(() => {
    if (!started || busy || !trace.resumable || trace.finding || resumes >= MAX_RESUMES) return;
    setResumes((count) => count + 1);
    void sendMessage(CampaignTrace.CONTINUE_PROMPT).catch((error: unknown) =>
      setFailure(error instanceof Error ? error.message : String(error)),
    );
  }, [started, busy, trace.resumable, trace.finding, resumes, sendMessage]);

  useEffect(() => {
    traceEnd.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }, [trace.rows.length, turnState]);

  async function run(): Promise<void> {
    setFailure(null);
    setFix(null);
    try {
      const threadControl = getCurrentThreadControl();
      const selectedModel = threadControl.model ?? process.env.NEXT_PUBLIC_AOMI_MODEL ?? "Claude Sonnet 5";
      const selectedModelMode = threadControl.model ? (threadControl.modelMode ?? "manual") : "manual";
      // Each campaign gets a fresh session so the trace and report are its own.
      const threadId = runs > 0 ? await createThread() : currentThreadId;
      setRuns((count) => count + 1);
      setResumes(0);
      // Carry the user's picker choice into the fresh campaign thread.
      await onModelSelect(selectedModel, { mode: selectedModelMode });
      // Signed in, the harness seeds the thread's world first so the chat only
      // carries references. Any refusal (e.g. a backend without the route)
      // falls back to the agent opening the world itself.
      const link = data.deployment ? data.artifactUrl : data.installedArtifactUrl;
      let seededLink: string | undefined;
      const bearer = account && link ? await account.session().catch(() => null) : null;
      if (bearer && link) {
        const url = new URL("/api/thread/sim/world", backendUrl);
        url.searchParams.set("user_state", JSON.stringify(target.userState(appId, "Arc Studio app")));
        const response = await fetch(url, {
          method: "POST",
          headers: {
            authorization: `Bearer ${bearer}`,
            "content-type": "application/json",
            "X-Session-Id": threadId,
            "X-Thread-Id": threadId,
          },
          body: JSON.stringify(target.seedWorld()),
        }).catch((error: unknown) => error as Error);
        if (response instanceof Response && response.ok) {
          seededLink = link;
        } else {
          const reason = response instanceof Response ? `HTTP ${response.status} ${await response.text()}` : response;
          console.warn("Seeding the simulation world failed; the agent will open it.", reason);
        }
      }
      setSeeded(Boolean(seededLink));
      await sendMessage(seededLink ? target.seededPrompt(seededLink) : target.prompt(data.artifactUrl));
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      setFailure(
        message === "Failed to fetch"
          ? `Could not reach the Aomi backend at ${backendUrl}. Is it running with the arc-studio-fuzzer app loaded?`
          : message,
      );
    }
  }

  return (
    <>
      <div className="flex h-14 items-center justify-between border-b border-border px-5">
        <div className="flex items-center gap-2.5">
          <div className="grid size-7 place-items-center rounded-pill bg-ink">
            <BrainCircuit className="size-4 text-bg" />
          </div>
          <div>
            <h1 className="text-[15px] font-semibold text-ink">Aomi Security Agent</h1>
            <p className="text-[12px] text-ink-muted">
              {target.name} · {target.writableFunctions.length} writable function
              {target.writableFunctions.length === 1 ? "" : "s"}
            </p>
          </div>
        </div>
        <div className="flex min-w-0 items-center gap-2">
          <CampaignModelSelect backendUrl={backendUrl} disabled={busy} />
          <span className="shrink-0 rounded-pill border border-accent/45 bg-accent/10 px-2 py-0.5 font-mono text-[11px] text-accent-strong">
            LIVE
          </span>
        </div>
      </div>

      <div className={`min-h-0 flex-1 ${view === "chat" && started ? "overflow-hidden" : "overflow-auto p-4"}`}>
        {!started && (
          <div>
            <div className="rounded-lg border border-border bg-bg p-4">
              <div className="mb-3 flex items-center gap-2 text-[13px] font-medium text-ink">
                <Sparkles className="size-4 text-accent" /> Compiled artifact loaded from Arc Studio
              </div>
              <p className="text-[13px] leading-5 text-ink-muted">
                Source, ABI, and runtime bytecode for <code>{target.name}</code> ({ArcStudioApp.workspacePath(target.sourcePath)}) go to the
                Aomi fuzzer. Every row below comes from the agent&apos;s live event stream.
              </p>
              <p className="mt-2 font-mono text-[12px] text-ink-muted">
                writes: {target.writableFunctions.join(", ") || "none"}
              </p>
              {target.deployment ? (
                <p className="mt-3 rounded-md border border-success/30 bg-success/8 px-3 py-2 text-[12px] leading-5 text-ink">
                  Fuzzing your live deployment at{" "}
                  <span className="font-mono">
                    {target.deployment.address.slice(0, 8)}…{target.deployment.address.slice(-6)}
                  </span>{" "}
                  on Arc {target.deployment.chainId === 5042 ? "mainnet" : "testnet"}, with its real owner, tokens and
                  state. Nothing is sent to the chain.
                </p>
              ) : (
                <p className="mt-3 rounded-md border border-warning/40 bg-warning/10 px-3 py-2 text-[12px] leading-5 text-ink">
                  No Arc deployment found for this contract, so the fuzzer installs its compiled code on a fresh
                  address. The constructor does not run, so owner and token setup will be empty. Deploy it to Arc in
                  Arc Studio to fuzz the real thing.
                </p>
              )}
            </div>
            {!signedIn && (
              <div className="mt-4 rounded-lg border border-warning/40 bg-warning/10 p-3 text-[12px] leading-5 text-ink">
                You&apos;re running as an Aomi guest. Guest sessions stop after about 15 tool calls (a per-call
                input cap), before a full campaign can minimize and reproduce a finding.{" "}
                <strong>Sign in to Aomi</strong> (top right) for complete campaigns.
              </div>
            )}
            <div className="mt-4 space-y-2">
              {[
                "Agent authors the threat model, actors, and properties",
                "Runtime holds one Arc fork; nothing is broadcast",
                "A finding needs two clean reproductions",
              ].map((label) => (
                <div
                  key={label}
                  className="flex items-center gap-3 rounded-md border border-border bg-bg px-3 py-3 text-[12px] text-ink-muted"
                >
                  <ShieldCheck className="size-4 text-accent" /> {label}
                </div>
              ))}
            </div>
          </div>
        )}

        {started && (
          <div className={view === "chat" ? "flex h-full min-h-0 flex-col p-4" : undefined}>
            <div
              className={`mb-4 flex items-start gap-3 rounded-lg border p-3 ${
                failure || turnError || finding ? "border-danger/35 bg-danger/8" : "border-border bg-bg"
              }`}
            >
              <div className="mt-0.5 grid size-8 shrink-0 place-items-center rounded-pill bg-surface-2">
                {busy ? (
                  <RefreshCw className="size-4 animate-spin text-accent" />
                ) : failure || turnError || finding ? (
                  <AlertTriangle className="size-4 text-danger" />
                ) : (
                  <Check className="size-4 text-success" />
                )}
              </div>
              <div className="min-w-0">
                <h2 className="text-[13px] font-semibold text-ink">
                  {failure || turnError
                    ? "Campaign failed"
                    : busy
                      ? "Agent is exploring the fork"
                      : finding
                        ? "Reproduced invariant violation"
                        : finished
                          ? "Campaign complete"
                          : "Connecting to agent"}
                </h2>
                <p className="mt-1 font-mono text-[11px] text-ink-muted">
                  {turnState ?? "submitting"} · {trace.rows.length} tool events · {events.length} ledger events
                  {resumes > 0 && ` · continued ${resumes}×`}
                </p>
              </div>
            </div>

            <div className="mb-2 flex items-center justify-between">
              <h3 className="text-[11px] font-semibold uppercase tracking-[0.12em] text-ink-muted">
                Live agent trace
              </h3>
              <div className="flex rounded-pill border border-border bg-surface-2 p-0.5 text-[11px]" role="tablist">
                {(
                  [
                    ["tools", `Tools ${trace.rows.length}`],
                    ["ledger", `All events ${trace.ledger.length}`],
                    ["chat", "Chat"],
                  ] as const
                ).map(([key, label]) => (
                  <button
                    key={key}
                    role="tab"
                    aria-selected={view === key}
                    onClick={() => setView(key)}
                    className={`rounded-pill px-2.5 py-0.5 transition ${view === key ? "bg-bg text-ink" : "text-ink-muted hover:text-ink"}`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>

            {view === "tools" ? (
              <div data-testid="agent-trace" className="space-y-2">
                {seeded && (
                  <div
                    data-testid="seeded-world"
                    className="flex items-center gap-2 rounded-md border border-success/30 bg-success/8 px-3 py-2 text-[12px] text-success"
                  >
                    <ShieldCheck className="size-3.5 shrink-0" />
                    World seeded by the harness on chain {target.chainId}:{" "}
                    {target.deployment ? "live deployment" : "runtime installed"} at{" "}
                    <code className="font-mono">{short(target.deployment?.address ?? INSTALL_ADDRESS)}</code>
                  </div>
                )}
                {trace.rows.length === 0 && (
                  <div className="rounded-md border border-border bg-bg px-3 py-4 text-center text-[12px] text-ink-muted">
                    Waiting for the first tool call…
                  </div>
                )}
                {trace.rows.map((row) => {
                  const result = row.result as { error?: { message?: string } | string } | string | undefined;
                  const errorText =
                    row.state !== "failed"
                      ? null
                      : typeof result === "string"
                        ? result
                        : typeof result?.error === "string"
                          ? result.error
                          : (result?.error?.message ?? pretty(result));
                  return (
                    <details
                      key={row.key}
                      data-tool-name={row.name}
                      className="group rounded-md border border-border bg-bg px-3 py-2.5"
                    >
                      <summary className="flex cursor-pointer list-none items-center gap-2">
                        {row.state === "calling" ? (
                          <CircleDot className="size-3.5 shrink-0 animate-pulse text-accent" />
                        ) : row.state === "failed" ? (
                          <X className="size-3.5 shrink-0 text-danger" />
                        ) : (
                          <Check className="size-3.5 shrink-0 text-success" />
                        )}
                        <span className="min-w-0 flex-1 truncate font-mono text-[12px] text-ink">{row.name}</span>
                        <span className="text-[11px] text-ink-muted/70">#{row.sequence}</span>
                        <ChevronRight className="size-3 text-ink-muted/70 transition group-open:rotate-90" />
                      </summary>
                      {errorText && (
                        <p className="mt-1.5 line-clamp-3 font-mono text-[11px] leading-[1.5] text-danger group-open:line-clamp-none">
                          {errorText}
                        </p>
                      )}
                      {row.result !== undefined && !errorText && (
                        <pre className="mt-2 max-h-72 overflow-auto whitespace-pre-wrap border-t border-border pt-2 font-mono text-[11px] leading-[1.5] text-ink-muted">
                          {`result\n${pretty(row.result)}`}
                        </pre>
                      )}
                      {row.arguments !== undefined && (
                        <details className="mt-2 border-t border-border pt-2">
                          <summary className="cursor-pointer text-[11px] text-ink-muted">args</summary>
                          <pre className="mt-1 max-h-72 overflow-auto whitespace-pre-wrap font-mono text-[11px] leading-[1.5] text-ink-muted">
                            {pretty(row.arguments)}
                          </pre>
                        </details>
                      )}
                    </details>
                  );
                })}
              </div>
            ) : view === "ledger" ? (
              <div data-testid="ledger" className="space-y-1">
                {trace.ledger.length === 0 && (
                  <div className="rounded-md border border-border bg-bg px-3 py-4 text-center text-[12px] text-ink-muted">
                    No events yet.
                  </div>
                )}
                {trace.ledger.map((entry) => (
                  <details key={entry.key} className="group rounded-md border border-border bg-bg px-3 py-2">
                    <summary className="flex cursor-pointer list-none items-center gap-2">
                      <span className="w-9 shrink-0 text-[11px] text-ink-muted/70">#{entry.sequence}</span>
                      <span
                        className={`shrink-0 rounded-pill px-1.5 py-0.5 font-mono text-[10.5px] ${
                          entry.type === "error"
                            ? "bg-danger/10 text-danger"
                            : entry.type === "message"
                              ? "bg-accent/10 text-accent-strong"
                              : "bg-surface-2 text-ink-muted"
                        }`}
                      >
                        {entry.type}
                      </span>
                      <span className="min-w-0 flex-1 truncate text-[12px] text-ink">{entry.label}</span>
                      <ChevronRight className="size-3 shrink-0 text-ink-muted/70 transition group-open:rotate-90" />
                    </summary>
                    <pre className="mt-2 max-h-80 overflow-auto whitespace-pre-wrap border-t border-border pt-2 font-mono text-[11px] leading-[1.5] text-ink-muted">
                      {JSON.stringify(entry.event, null, 2)}
                    </pre>
                  </details>
                ))}
              </div>
            ) : (
              <div
                data-testid="aomi-chat"
                className="min-h-0 flex-1 overflow-hidden rounded-lg border border-border bg-bg"
              >
                <AomiFrame.Composer className="h-full" welcomeTitle="Ask Aomi about this campaign" />
              </div>
            )}

            {view !== "chat" && finding && report && (
              <div
                data-testid="verified-finding"
                className="mt-4 rounded-lg border border-danger/35 bg-danger/8 p-3"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[12px] font-bold uppercase tracking-wider text-danger">
                    Verified finding
                  </span>
                  <span className="rounded-pill bg-success/10 px-2 py-1 font-mono text-[11px] text-success">
                    REPLAYED 2×
                  </span>
                </div>
                <p className="mt-2 text-[13px] leading-5 text-ink">{finding.property}</p>
                <div className="mt-3 space-y-1.5">
                  {finding.minimized_trace.map((call, index) => (
                    <div
                      key={`${call.label}-${index}`}
                      className="flex items-center gap-2 rounded-sm border border-border bg-bg px-2.5 py-2"
                    >
                      <span className="grid size-5 place-items-center rounded-pill bg-accent-subtle font-mono text-[11px] text-accent-strong">
                        {index + 1}
                      </span>
                      <span className="font-mono text-[12px] text-ink">
                        {call.actor} → {call.function}
                      </span>
                    </div>
                  ))}
                </div>
                <div className="mt-3 grid grid-cols-3 gap-2">
                  {(
                    [
                      ["round", report.round],
                      ["executions", report.executions],
                      ["corpus", report.corpus_size],
                    ] as const
                  ).map(([label, value]) => (
                    <div key={label} className="rounded-sm border border-border bg-bg p-2">
                      <div className="text-[11px] uppercase text-ink-muted">{label}</div>
                      <div className="mt-1 font-mono text-[13px] text-ink">{value}</div>
                    </div>
                  ))}
                </div>
                <p className="mt-3 text-center font-mono text-[11px] text-ink-muted/70">
                  {short(report.campaign_id)} · Arc fork · no signing
                </p>
              </div>
            )}

            {view !== "chat" && finalMessage?.content && finished && (
              <div className="mt-4 rounded-lg border border-border bg-bg p-3">
                <div className="mb-2 text-[12px] font-semibold uppercase tracking-wider text-accent-strong">
                  Agent conclusion
                </div>
                <div className="max-h-80 overflow-auto whitespace-pre-wrap text-[13px] leading-6 text-ink">
                  {messageText(finalMessage.content)}
                </div>
              </div>
            )}
            {view !== "chat" && (failure ?? turnError) && (
              <p className="mt-3 text-[12px] leading-5 text-danger">{failure ?? turnError}</p>
            )}
            <div ref={traceEnd} />
          </div>
        )}
      </div>

      <div className="space-y-2 border-t border-border p-4">
        {finding && report && finished && (
          <>
            {fix?.webUrl ? (
              <div className="rounded-md border border-success/30 bg-success/8 p-3 text-[13px] text-ink">
                Fix request sent to Arc Studio.{" "}
                <a href={fix.webUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 underline">
                  Follow it there <ExternalLink className="size-3" />
                </a>
                <button onClick={onRefresh} className="mt-2 block text-ink-muted underline">
                  Arc Studio finished? Reload the contract, then fuzz again
                </button>
              </div>
            ) : (
              <button
                data-testid="send-fix"
                disabled={fixing}
                onClick={() =>
                  startFix(async () => {
                    const result = await requestFix(appId, target.sourcePath, target.name, report);
                    setFix(result.ok ? { webUrl: result.value.webUrl } : { error: result.error });
                  })
                }
                className="flex h-10 w-full items-center justify-center gap-2 rounded-pill bg-danger-strong text-[13px] font-medium text-on-danger transition hover:brightness-110 disabled:opacity-70"
              >
                {fixing ? <RefreshCw className="size-3.5 animate-spin" /> : <Wrench className="size-3.5" />}
                Send finding to Arc Studio for a fix
              </button>
            )}
            {fix?.error && <p className="text-[12px] text-danger">{fix.error}</p>}
          </>
        )}
        <button
          data-testid="run-aomi-fuzz"
          onClick={() => void run()}
          disabled={busy}
          className="flex h-10 w-full items-center justify-center gap-2 rounded-pill bg-ink text-[13px] font-medium text-bg transition hover:bg-ink/85 disabled:cursor-wait disabled:opacity-70"
        >
          {busy ? (
            <>
              <RefreshCw className="size-3.5 animate-spin" /> Running campaign…
            </>
          ) : started ? (
            <>
              <RefreshCw className="size-3.5" /> Run a new campaign
            </>
          ) : (
            <>
              <Play className="size-3.5 fill-current" /> Fuzz {target.name} on an Arc fork
            </>
          )}
        </button>
        <p className="text-center text-[12px] text-ink-muted/70">Real model · held Arc fork · no signing or broadcast</p>
      </div>
    </>
  );
}

use std::collections::{BTreeSet, HashMap};
use std::sync::{Arc, Mutex, MutexGuard};
use std::time::Instant;

use aomi_sdk::schemars::JsonSchema;
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};

use crate::abi::ContractAbi;
use crate::campaign::FuzzCampaign;
use crate::plan::{FuzzContract, FuzzDeployment, ProtocolContract};

#[derive(Clone, Default)]
pub(crate) struct ArcStudioFuzzerApp {
    sessions: Arc<Mutex<Sessions>>,
}

impl ArcStudioFuzzerApp {
    pub(crate) fn sessions(&self) -> MutexGuard<'_, Sessions> {
        self.sessions
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
    }
}

pub(crate) struct Session {
    pub contract: FuzzContract,
    /// Kept so `arc_source` can serve slices without another download.
    pub source_code: String,
    pub campaign: Option<FuzzCampaign>,
    touched: Instant,
}

impl Session {
    const MAX_SOURCE_SLICE: usize = 200;

    /// Numbered source lines `from_line..=to_line`, capped per call.
    pub fn source(&self, args: SourceArgs) -> Result<Value, String> {
        if args.from_line == 0 || args.to_line < args.from_line {
            return Err("from_line must be at least 1 and no greater than to_line".into());
        }
        let total = self.source_code.lines().count();
        let to = args
            .to_line
            .min(args.from_line + Self::MAX_SOURCE_SLICE - 1)
            .min(total);
        let source = self
            .source_code
            .lines()
            .enumerate()
            .skip(args.from_line - 1)
            .take((to + 1).saturating_sub(args.from_line))
            .map(|(index, line)| format!("{:>5}  {line}", index + 1))
            .collect::<Vec<_>>()
            .join("\n");
        Ok(json!({
            "from_line": args.from_line,
            "to_line": to,
            "total_lines": total,
            "source": source,
        }))
    }
}

/// Per-chat-session state. Bounded: a session the model never closes is
/// evicted once newer sessions need the room.
#[derive(Default)]
pub(crate) struct Sessions(HashMap<String, Session>);

impl Sessions {
    const MAX: usize = 64;

    /// Start (or restart) a session with a new compiler artifact.
    pub fn open(&mut self, id: String, artifact: CompilerArtifact) {
        if !self.0.contains_key(&id) && self.0.len() >= Self::MAX {
            let oldest = self
                .0
                .iter()
                .min_by_key(|(_, session)| session.touched)
                .map(|(id, _)| id.clone());
            if let Some(oldest) = oldest {
                self.0.remove(&oldest);
            }
        }
        self.0.insert(
            id,
            Session {
                contract: artifact.contract,
                source_code: artifact.source_code,
                campaign: None,
                touched: Instant::now(),
            },
        );
    }

    pub fn get_mut(&mut self, id: &str) -> Result<&mut Session, String> {
        let session = self.0.get_mut(id).ok_or_else(|| {
            "no compiler artifact for this session; call arc_map_attack_surface first".to_string()
        })?;
        session.touched = Instant::now();
        Ok(session)
    }

    pub fn close(&mut self, id: &str) -> bool {
        self.0.remove(id).is_some()
    }
}

#[derive(Debug, Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub(crate) struct MapAttackSurfaceArgs {
    /// HTTPS link to the compiled artifact, issued by the Arc Studio fuzz site.
    /// Preferred: the app downloads the source, ABI, and runtime bytecode itself,
    /// so they never pass through the conversation. When set, leave
    /// `source_code` and `contract` null.
    pub artifact_url: Option<String>,
    /// Complete Solidity source, only when no `artifact_url` was given.
    pub source_code: Option<String>,
    /// The compiler artifact, only when no `artifact_url` was given.
    pub contract: Option<FuzzContract>,
}

#[derive(Debug, Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub(crate) struct SourceArgs {
    /// First line to read, 1-based.
    pub from_line: usize,
    /// Last line to read, inclusive. At most 200 lines come back per call.
    pub to_line: usize,
}

/// Source plus compiler artifact for one fuzz session.
pub(crate) struct CompilerArtifact {
    pub source_code: String,
    pub contract: FuzzContract,
    /// Downloaded rather than inlined, so the model has not seen the source yet.
    pub downloaded: bool,
}

impl MapAttackSurfaceArgs {
    /// The only origin allowed to serve artifacts: the fuzz site's production
    /// domain, matched exactly, because anyone can claim a
    /// `<project>.vercel.app` name, so no pattern over that domain is safe.
    /// A local build may set `ARC_FUZZ_ARTIFACT_ORIGIN` at compile time to
    /// test against a local site; release builds never do.
    const ARTIFACT_ORIGIN: &'static str = match option_env!("ARC_FUZZ_ARTIFACT_ORIGIN") {
        Some(origin) => origin,
        None => "https://arc-studio-fuzz.vercel.app",
    };
    const MAX_ARTIFACT_BYTES: u64 = 4 * 1024 * 1024;

    pub fn artifact(self) -> Result<CompilerArtifact, String> {
        let Some(url) = self.artifact_url else {
            return Ok(CompilerArtifact {
                source_code: self
                    .source_code
                    .ok_or("source_code is required without artifact_url")?,
                contract: self
                    .contract
                    .ok_or("contract is required without artifact_url")?,
                downloaded: false,
            });
        };
        let url = reqwest::Url::parse(&url).map_err(|_| "artifact_url is not a valid URL")?;
        let allowed = reqwest::Url::parse(Self::ARTIFACT_ORIGIN).expect("valid artifact origin");
        if url.origin() != allowed.origin()
            || !url.username().is_empty()
            || url.password().is_some()
        {
            return Err(format!(
                "artifact_url must be {}/... with no credentials",
                Self::ARTIFACT_ORIGIN
            ));
        }

        #[derive(Deserialize)]
        struct Download {
            name: String,
            source_code: String,
            abi: String,
            deployed_bytecode: String,
            /// Set when the builder already deployed the contract on Arc.
            #[serde(default)]
            deployment: Option<FuzzDeployment>,
            /// The rest of the protocol, already in the world.
            #[serde(default)]
            protocol: Vec<ProtocolContract>,
        }
        let response = reqwest::blocking::Client::builder()
            .timeout(std::time::Duration::from_secs(20))
            .redirect(reqwest::redirect::Policy::none())
            .build()
            .map_err(|e| format!("artifact client: {e}"))?
            .get(url)
            .send()
            .map_err(|e| format!("artifact download failed: {e}"))?;
        if !response.status().is_success() {
            let status = response.status();
            let detail = response.text().unwrap_or_default();
            return Err(format!(
                "artifact download returned {status}: {}",
                detail.chars().take(300).collect::<String>()
            ));
        }
        if response
            .content_length()
            .is_some_and(|length| length > Self::MAX_ARTIFACT_BYTES)
        {
            return Err("artifact exceeds 4 MB".into());
        }
        // Bounded read: an oversized or unannounced body is never buffered past the cap.
        let mut body = Vec::new();
        std::io::Read::read_to_end(
            &mut std::io::Read::take(response, Self::MAX_ARTIFACT_BYTES + 1),
            &mut body,
        )
        .map_err(|e| format!("artifact download failed: {e}"))?;
        if body.len() as u64 > Self::MAX_ARTIFACT_BYTES {
            return Err("artifact exceeds 4 MB".into());
        }
        let download: Download = serde_json::from_slice(&body)
            .map_err(|e| format!("artifact is not valid JSON: {e}"))?;
        Ok(CompilerArtifact {
            source_code: download.source_code,
            contract: FuzzContract {
                name: download.name,
                abi: download.abi,
                deployed_bytecode: download.deployed_bytecode,
                deployment: download.deployment,
                protocol: download.protocol,
            },
            downloaded: true,
        })
    }
}

#[derive(Debug, Serialize)]
struct EntryPoint {
    signature: String,
    mutability: alloy_json_abi::StateMutability,
    outputs: Vec<String>,
}

#[derive(Debug, Serialize)]
struct ProtocolSurface {
    name: String,
    address: String,
    writable: BTreeSet<String>,
    observers: Vec<String>,
}

#[derive(Debug, Serialize)]
pub(crate) struct AttackSurface {
    contract: String,
    /// The downloaded source, when it is short; read longer source in slices
    /// with `arc_source`.
    #[serde(skip_serializing_if = "Option::is_none")]
    source_code: Option<String>,
    source_lines: usize,
    /// The rest of the protocol: each contract's address and callable
    /// surface. Target one with a call's `contract` field.
    #[serde(skip_serializing_if = "Vec::is_empty")]
    protocol: Vec<ProtocolSurface>,
    /// Where the code already sits: a live deployment, or a harness install.
    #[serde(skip_serializing_if = "Option::is_none")]
    deployment: Option<FuzzDeployment>,
    entry_points: Vec<EntryPoint>,
    state_observers: Vec<String>,
    events: Vec<String>,
    custom_errors: Vec<String>,
    attack_hypothesis_seeds: BTreeSet<&'static str>,
    agent_next_action: &'static str,
}

impl AttackSurface {
    /// Function-name fragments and the attack family they suggest.
    const NAME_SEEDS: [(&'static [&'static str], &'static str); 4] = [
        (
            &["withdraw", "redeem", "claim", "transfer", "sweep", "drain"],
            "Unauthorized or over-sized value extraction across user roles",
        ),
        (
            &["deposit", "mint", "stake", "borrow", "repay"],
            "Cross-call accounting and ordering around asset/share creation",
        ),
        (
            &[
                "owner",
                "admin",
                "role",
                "pause",
                "upgrade",
                "initialize",
                "set",
            ],
            "Privilege escalation, unsafe initialization, or role confusion",
        ),
        (
            &["execute", "call", "hook", "callback", "flash"],
            "Arbitrary call, callback ordering, or reentrancy reachability",
        ),
    ];

    /// Source fragments and the attack family they suggest.
    const SOURCE_SEEDS: [(&'static str, &'static str); 9] = [
        (
            "delegatecall",
            "Delegatecall target/control and storage-context takeover",
        ),
        (
            "selfdestruct",
            "Destruction reachability and forced value movement",
        ),
        (
            "tx.origin",
            "tx.origin authorization confusion through an intermediary",
        ),
        (
            "ecrecover",
            "Signature replay, malleability, nonce, and domain separation",
        ),
        (
            "block.timestamp",
            "Timestamp-dependent state transitions at boundary values",
        ),
        (
            ".call{",
            "External callback/reentrancy before state finalization",
        ),
        (
            "assembly",
            "Assembly memory/storage assumptions and arbitrary slot access",
        ),
        (
            "initializer",
            "Initialization ordering and uninitialized takeover",
        ),
        (
            "upgrade",
            "Upgrade authorization and implementation-slot takeover",
        ),
    ];

    /// Downloaded source up to this many lines comes back whole.
    const INLINE_SOURCE_LINES: usize = 300;

    const PAYABLE_SEED: &'static str =
        "Native-USDC accounting: vary msg.value across callers and ordering";

    pub fn map(artifact: &CompilerArtifact) -> Result<Self, String> {
        if artifact.contract.name.trim().is_empty() {
            return Err("contract name is required".into());
        }
        if artifact.source_code.trim().is_empty() {
            return Err("complete source_code is required for agentic analysis".into());
        }
        artifact.contract.runtime()?;
        let abi = ContractAbi::parse(&artifact.contract.abi)?;

        let mut seeds = BTreeSet::new();
        let mut entry_points = Vec::new();
        let mut observers = Vec::new();
        for function in abi.functions() {
            let signature = function.signature();
            if ContractAbi::read_only(function) {
                observers.push(signature.clone());
            } else {
                let name = function.name.to_ascii_lowercase();
                seeds.extend(
                    Self::NAME_SEEDS
                        .iter()
                        .filter(|(parts, _)| parts.iter().any(|part| name.contains(part)))
                        .map(|(_, seed)| *seed),
                );
            }
            if function.state_mutability == alloy_json_abi::StateMutability::Payable {
                seeds.insert(Self::PAYABLE_SEED);
            }
            entry_points.push(EntryPoint {
                signature,
                mutability: function.state_mutability,
                outputs: function
                    .outputs
                    .iter()
                    .map(|output| output.selector_type().into_owned())
                    .collect(),
            });
        }
        let source = artifact.source_code.to_ascii_lowercase();
        seeds.extend(
            Self::SOURCE_SEEDS
                .iter()
                .filter(|(needle, _)| source.contains(needle))
                .map(|(_, seed)| *seed),
        );

        Ok(Self {
            contract: artifact.contract.name.clone(),
            source_code: (artifact.downloaded
                && artifact.source_code.lines().count() <= Self::INLINE_SOURCE_LINES)
                .then(|| artifact.source_code.clone()),
            source_lines: artifact.source_code.lines().count(),
            protocol: artifact
                .contract
                .protocol
                .iter()
                .map(|contract| {
                    let abi = ContractAbi::parse(&contract.abi)
                        .map_err(|e| format!("protocol contract `{}`: {e}", contract.name))?;
                    Ok(ProtocolSurface {
                        name: contract.name.clone(),
                        address: contract.address.clone(),
                        writable: abi.writable(),
                        observers: abi
                            .functions()
                            .filter(|function| ContractAbi::read_only(function))
                            .map(|function| function.signature())
                            .collect(),
                    })
                })
                .collect::<Result<_, String>>()?,
            deployment: artifact.contract.deployment.clone(),
            entry_points,
            state_observers: observers,
            events: abi
                .inner()
                .events()
                .map(|event| event.name.clone())
                .collect(),
            custom_errors: abi
                .inner()
                .errors()
                .map(|error| error.name.clone())
                .collect(),
            attack_hypothesis_seeds: seeds,
            agent_next_action: "Read the source (arc_source for slices when source_code is absent), turn the threat model into executable properties and ABI-level action templates, then run arc_fuzz_start and arc_fuzz_round until the campaign completes. These seeds are prompts, not findings.",
        })
    }
}

import type { ChatBody, StudioClient, StudioDeployment } from "@aomi-labs/arc-studio-cli/client";
import { describe, expect, it } from "vitest";

import { ArcStudioApp, MissingBuildError } from "./arc-studio-app.ts";
import { INSTALL_ADDRESS, MAX_MESSAGE_CHARS } from "./fuzz-target.ts";
import type { FuzzCampaignReport } from "./report.ts";

const VAULT = `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.30;
import {Owned} from "./base/Owned.sol";
import "forge-std/console.sol";

contract UnsafeVault is Owned {
    mapping(address => uint256) public deposits;
    function deposit() external payable { deposits[msg.sender] += msg.value; }
    function withdraw(uint256 amount) external { payable(msg.sender).transfer(amount); }
}`;
const OWNED = `pragma solidity ^0.8.30;
abstract contract Owned { address public owner; }`;
const ARTIFACT = {
  abi: [
    { type: "function", name: "deposit", inputs: [], outputs: [], stateMutability: "payable" },
    { type: "function", name: "deposits", inputs: [], outputs: [], stateMutability: "view" },
    { type: "function", name: "withdraw", inputs: [], outputs: [], stateMutability: "nonpayable" },
  ],
  deployedBytecode: { object: "0x6080604052" },
};

function fakeClient(
  workspace: Record<string, string>,
  chats: ChatBody[] = [],
  deployments: StudioDeployment[] = [],
) {
  return {
    webUrl: (appId: string) => `https://studio.arc.io/app/${appId}`,
    listDeployments: async () => deployments,
    getSandbox: async () => ({ sandboxId: "sbx_1" }),
    listSandboxFiles: async () => Object.keys(workspace).map((path) => ({ path, hash: "h" })),
    batchReadFiles: async (_: string, paths: string[]) =>
      paths.map((path) => ({ path, content: workspace[path], error: workspace[path] ? undefined : "missing" })),
    chatDetached: async (body: ChatBody) => {
      chats.push(body);
      return { appId: "app_1", threadId: "thr_9" };
    },
  } as unknown as StudioClient;
}

const WORKSPACE = {
  "foundry.toml": `[profile.default]\nsrc = "contracts"\nout = "out"\n`,
  "contracts/UnsafeVault.sol": VAULT,
  "contracts/base/Owned.sol": OWNED,
  "contracts/UnsafeVault.t.sol": "contract VaultTest {}",
  "out/UnsafeVault.sol/UnsafeVault.json": JSON.stringify(ARTIFACT),
  "src/App.tsx": "export {}",
};

describe("ArcStudioApp", () => {
  it("lists concrete contracts under the Foundry src dir with build status", async () => {
    const app = await ArcStudioApp.open(fakeClient(WORKSPACE), "app_1");
    expect(await app.contracts()).toEqual([
      { path: "contracts/UnsafeVault.sol", source: VAULT, contracts: ["UnsafeVault"], built: true },
      { path: "contracts/base/Owned.sol", source: OWNED, contracts: [], built: false },
    ]);
  });

  it("builds a target from the Foundry artifact and inlines workspace imports only", async () => {
    const app = await ArcStudioApp.open(fakeClient(WORKSPACE), "app_1");
    const target = await app.target("contracts/UnsafeVault.sol", "UnsafeVault");
    expect(target.deployedBytecode).toBe("0x6080604052");
    expect(target.writableFunctions).toEqual(["deposit", "withdraw"]);
    expect(target.source).toContain("// ==== contracts/base/Owned.sol ====");
    expect(target.source).not.toContain("forge-std/console.sol ====");
    expect(target.prompt()).toContain('"deployed_bytecode":"0x6080604052"');
  });

  it("finds contracts in a nested Foundry project and skips libraries", async () => {
    const nested = {
      "onchain/foundry.toml": "[profile.default]\n",
      "onchain/src/UnsafeVault.sol": VAULT,
      "onchain/src/base/Owned.sol": OWNED,
      "onchain/lib/forge-std/src/Test.sol": "contract Test {}",
      "onchain/out/UnsafeVault.sol/UnsafeVault.json": JSON.stringify(ARTIFACT),
      "node_modules/x/Token.sol": "contract Token {}",
    };
    const app = await ArcStudioApp.open(fakeClient(nested), "app_1");
    expect((await app.contracts()).map(({ path, contracts, built }) => ({ path, contracts, built }))).toEqual([
      { path: "onchain/src/UnsafeVault.sol", contracts: ["UnsafeVault"], built: true },
      { path: "onchain/src/base/Owned.sol", contracts: [], built: false },
    ]);
    const target = await app.target("onchain/src/UnsafeVault.sol", "UnsafeVault");
    expect(target.source).toContain("// ==== onchain/src/base/Owned.sol ====");
  });

  it("handles the absolute sandbox paths Arc Studio returns", async () => {
    const absolute = Object.fromEntries(
      Object.entries(WORKSPACE).map(([path, text]) => [`/home/user/app/${path}`, text]),
    );
    const app = await ArcStudioApp.open(fakeClient(absolute), "app_1");
    const [vault] = await app.contracts();
    expect(vault?.path).toBe("/home/user/app/contracts/UnsafeVault.sol");
    expect(vault?.built).toBe(true);
    const target = await app.target("/home/user/app/contracts/UnsafeVault.sol", "UnsafeVault");
    expect(target.source).toContain("// ==== /home/user/app/contracts/base/Owned.sol ====");
  });

  it("reads listed files but never credential files or unlisted paths", async () => {
    const app = await ArcStudioApp.open(fakeClient({ ...WORKSPACE, ".env": "PRIVATE_KEY=0x1" }), "app_1");
    expect(await app.readFile("src/App.tsx")).toBe("export {}");
    await expect(app.readFile(".env")).rejects.toThrow("may hold secrets");
    await expect(app.readFile("../etc/passwd")).rejects.toThrow("not in this app's workspace");
    expect(ArcStudioApp.isSensitive("keys/deployer.PEM")).toBe(true);
  });

  it("reports a missing build instead of guessing", async () => {
    const { ["out/UnsafeVault.sol/UnsafeVault.json"]: _, ...unbuilt } = WORKSPACE;
    const app = await ArcStudioApp.open(fakeClient(unbuilt), "app_1");
    await expect(app.target("contracts/UnsafeVault.sol", "UnsafeVault")).rejects.toBeInstanceOf(
      MissingBuildError,
    );
  });

  it("sends only confirmed findings back to Arc Studio as a fix request", async () => {
    const chats: ChatBody[] = [];
    const app = await ArcStudioApp.open(fakeClient(WORKSPACE, chats), "app_1");
    const target = await app.target("contracts/UnsafeVault.sol", "UnsafeVault");
    const call = (actor: string, fn: string, args: string[], value = "0") => ({
      label: fn, actor, function: fn, arguments: args, value,
    });
    const report = {
      campaign_id: "0xabc",
      round: 4,
      executions: 10,
      findings: [
        {
          property: "unauthorized_withdraw_must_revert",
          minimized_trace: [call("alice", "deposit()", [], "5"), call("bob", "withdraw(uint256)", ["5"])],
          reproductions: 2,
        },
      ],
      unconfirmed: [{ property: "unconfirmed", trace: [], reason: "violation did not reproduce" }],
    } as unknown as FuzzCampaignReport;

    const result = await app.requestFix(target, report);
    expect(result).toEqual({ threadId: "thr_9", webUrl: "https://studio.arc.io/app/app_1" });
    const content = chats[0]?.messages[0]?.content ?? "";
    expect(chats[0]?.appId).toBe("app_1");
    expect(content).toContain("2. bob calls withdraw(uint256) with (5)");
    expect(content).not.toContain("unconfirmed");
  });
});

describe("FuzzTarget.prompt", () => {
  it("hands large contracts over by link and refuses to inline past the message limit", async () => {
    const big = { ...ARTIFACT, deployedBytecode: { object: `0x${"60".repeat(20_000)}` } };
    const app = await ArcStudioApp.open(
      fakeClient({ ...WORKSPACE, "out/UnsafeVault.sol/UnsafeVault.json": JSON.stringify(big) }),
      "app_1",
    );
    const target = await app.target("contracts/UnsafeVault.sol", "UnsafeVault");
    const linked = target.prompt("https://arc-studio-fuzz.vercel.app/api/artifacts/t");
    expect(linked.length).toBeLessThanOrEqual(MAX_MESSAGE_CHARS);
    expect(linked).toContain("artifact_url set to https://arc-studio-fuzz.vercel.app/api/artifacts/t");
    expect(linked).not.toContain("6060606060");
    expect(linked).toContain("withdraw() nonpayable");
    // Source comes back from arc_map_attack_surface, not the prompt.
    expect(linked).not.toContain("contract Owned");
    expect(() => target.prompt()).toThrow(/too large to send inline/);
  });
});

describe("FuzzTarget seeded runs", () => {
  it("installs the runtime for the harness and sends only references", async () => {
    const app = await ArcStudioApp.open(fakeClient(WORKSPACE), "app_1");
    const target = await app.target("contracts/UnsafeVault.sol", "UnsafeVault");
    expect(target.seedWorld()).toEqual({
      forks: [
        { chain_id: target.chainId, overrides: [{ address: INSTALL_ADDRESS, code: target.deployedBytecode }] },
      ],
    });
    const prompt = target.seededPrompt("https://arc-studio-fuzz.vercel.app/api/artifacts/t");
    expect(prompt.length).toBeLessThan(1_000);
    expect(prompt).toContain("do not call sim_open or sim_set_code");
    expect(prompt).toContain(`installed at ${INSTALL_ADDRESS}`);
    expect(prompt).toContain("artifact_url https://arc-studio-fuzz.vercel.app/api/artifacts/t");
    expect(prompt).not.toContain(target.deployedBytecode);
  });

  it("seeds only the chain for a live deployment", async () => {
    const address = "0x00000000000000000000000000000000000000De";
    const app = await ArcStudioApp.open(
      fakeClient(WORKSPACE, [], [{ contract: "UnsafeVault", address, network: "Arc Testnet", deployedAt: "2026-10-05" }]),
      "app_1",
    );
    const target = await app.target("contracts/UnsafeVault.sol", "UnsafeVault");
    expect(target.seedWorld()).toEqual({ forks: [{ chain_id: 5_042_002, overrides: [] }] });
    expect(target.seededPrompt("https://x/y")).toContain(`the live deployment at ${address}`);
  });
});

describe("Arc Studio deployments", () => {
  it("maps Arc Studio network labels to Arc chains and ignores other chains", () => {
    expect(ArcStudioApp.arcChainId("Arc Testnet")).toBe(5_042_002);
    expect(ArcStudioApp.arcChainId("arc-testnet")).toBe(5_042_002);
    expect(ArcStudioApp.arcChainId("Arc", "https://arcscan.app/address/0x1")).toBe(5042);
    expect(ArcStudioApp.arcChainId("unknown", "https://testnet.arcscan.app/tx/0x1")).toBe(5_042_002);
    expect(ArcStudioApp.arcChainId("Base Sepolia")).toBeUndefined();
  });

  it("fuzzes the latest Arc deployment of the contract in place", async () => {
    const address = "0x00000000000000000000000000000000000000De";
    const app = await ArcStudioApp.open(
      fakeClient(WORKSPACE, [], [
        { contract: "UnsafeVault", address: "0x0000000000000000000000000000000000000001", network: "Arc Testnet", deployedAt: "2026-10-01" },
        { contract: "UnsafeVault", address, network: "Arc Testnet", deployedAt: "2026-10-05" },
        { contract: "UnsafeVault", address: "0x0000000000000000000000000000000000000002", network: "Base", deployedAt: "2026-10-09" },
        { contract: "Other", address: "0x0000000000000000000000000000000000000003", network: "Arc", deployedAt: "2026-10-09" },
      ]),
      "app_1",
    );
    const target = await app.target("contracts/UnsafeVault.sol", "UnsafeVault");
    expect(target.deployment).toEqual({ address, chainId: 5_042_002 });
    expect(target.chainId).toBe(5_042_002);
    expect(target.prompt()).toContain(`already deployed at ${address} on Arc chain 5042002`);
    expect(target.prompt()).toContain(`"deployment":{"address":"${address}","chain_id":5042002}`);
  });

  it("installs the bytecode when the contract has no Arc deployment", async () => {
    const app = await ArcStudioApp.open(fakeClient(WORKSPACE), "app_1");
    const target = await app.target("contracts/UnsafeVault.sol", "UnsafeVault");
    expect(target.deployment).toBeUndefined();
    expect(target.prompt()).not.toContain("already deployed");
  });
});

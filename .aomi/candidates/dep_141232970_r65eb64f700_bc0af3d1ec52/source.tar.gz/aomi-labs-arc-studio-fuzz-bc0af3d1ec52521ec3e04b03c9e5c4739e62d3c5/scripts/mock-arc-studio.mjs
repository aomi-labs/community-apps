#!/usr/bin/env node
// Local stand-in for the Arc Studio API (studio.arc.io) for development and
// tests. Serves one app whose Foundry workspace contains the known-vulnerable
// UnsafeVault with its real compiled artifact. Accepts only MOCK_TOKEN.
//
//   node scripts/mock-arc-studio.mjs            # listens on :4100
//   MOCK_LATENCY_MS=400 node scripts/...        # add a per-request delay
//   ARC_STUDIO_API_URL=http://localhost:4100 pnpm dev
import http from "node:http";

const PORT = Number(process.env.PORT ?? 4100);
// Simulated network round trip per request, to reproduce real-world loading.
const LATENCY_MS = Number(process.env.MOCK_LATENCY_MS ?? 0);
export const MOCK_TOKEN = "origin_pat_mock_local_dev";
const APP_ID = "00000000-0000-4000-8000-00000000a11c";
const SCAFFOLD_APP_ID = "00000000-0000-4000-8000-0000000005ca";

const VAULT = `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.30;

/// A simple native-USDC vault for Arc.
contract UnsafeVault {
    mapping(address => uint256) public deposits;

    function deposit() external payable {
        deposits[msg.sender] += msg.value;
    }

    function withdraw(uint256 amount) external {
        payable(msg.sender).transfer(amount);
    }
}
`;
const ARTIFACT = {"abi": [{"type": "function", "name": "deposit", "inputs": [], "outputs": [], "stateMutability": "payable"}, {"type": "function", "name": "deposits", "inputs": [{"name": "", "type": "address", "internalType": "address"}], "outputs": [{"name": "", "type": "uint256", "internalType": "uint256"}], "stateMutability": "view"}, {"type": "function", "name": "withdraw", "inputs": [{"name": "amount", "type": "uint256", "internalType": "uint256"}], "outputs": [], "stateMutability": "nonpayable"}], "deployedBytecode": {"object": "0x608060405260043610610033575f3560e01c80632e1a7d4d14610037578063d0e30db014610058578063fc7e286d14610060575b5f5ffd5b348015610042575f5ffd5b506100566100513660046100f0565b61009d565b005b6100566100cb565b34801561006b575f5ffd5b5061008b61007a366004610107565b5f6020819052908152604090205481565b60405190815260200160405180910390f35b604051339082156108fc029083905f818181858888f193505050501580156100c7573d5f5f3e3d5ffd5b5050565b335f90815260208190526040812080543492906100e9908490610134565b9091555050565b5f60208284031215610100575f5ffd5b5035919050565b5f60208284031215610117575f5ffd5b81356001600160a01b038116811461012d575f5ffd5b9392505050565b8082018082111561015357634e487b7160e01b5f52601160045260245ffd5b9291505056fea26469706673582212201a21847b2140e02638d24f6cc519af55c7105be2737921391b8b239857586ae964736f6c634300081e0033"}};
// Shaped like a real Arc Studio sandbox: absolute paths under /home/user/app,
// a Foundry project under contracts/, forge-std in lib/, and a Vite frontend.
const ROOT = "/home/user/app/";
const SCAFFOLD = {
  ".env": "VITE_RPC_URL=https://rpc.testnet.arc.network\n",
  "AGENTS.md": "# Agent notes\n",
  "foundry.toml": '[profile.default]\nsrc = "contracts/src"\nout = "contracts/out"\nlibs = ["lib"]\n',
  "remappings.txt": "forge-std/=lib/forge-std/src/\n",
  "package.json": '{ "name": "app", "private": true }\n',
  "index.html": "<!doctype html><div id=root></div>\n",
  "src/App.tsx": "export default function App() {\n  return null;\n}\n",
  "src/main.tsx": "import App from './App';\n",
  "src/onchain-money.ts": "export const USDC = '0x3600000000000000000000000000000000000000';\n",
  "contracts/script/Deploy.s.sol": "// SPDX-License-Identifier: MIT\npragma solidity ^0.8.30;\nimport {Script} from 'forge-std/Script.sol';\ncontract Deploy is Script { function run() external {} }\n",
  "contracts/test/.gitkeep": "",
  "contracts/out/Script.sol/Script.json": "{}",
  "contracts/out/Vm.sol/Vm.json": "{}",
  "lib/forge-std/README.md": "# Forge Standard Library\n",
  "lib/forge-std/src/Script.sol": "// SPDX-License-Identifier: MIT\npragma solidity >=0.6.2;\nabstract contract Script {}\n",
};
const absolute = (entries) => Object.fromEntries(Object.entries(entries).map(([path, text]) => [ROOT + path, text]));
const APPS = {
  [APP_ID]: {
    description: "Native-USDC vault (mock)",
    timestamp: "2026-10-05T08:00:00.000Z",
    files: absolute({
      ...SCAFFOLD,
      "contracts/src/UnsafeVault.sol": VAULT,
      "contracts/out/UnsafeVault.sol/UnsafeVault.json": JSON.stringify(ARTIFACT),
    }),
  },
  [SCAFFOLD_APP_ID]: {
    description: "USDC payments, no custom contract (mock)",
    timestamp: "2026-10-04T08:00:00.000Z",
    files: absolute(SCAFFOLD),
  },
};
const chats = [];

function send(res, status, body) {
  res.writeHead(status, { "content-type": "application/json" });
  res.end(JSON.stringify(body));
}

http
  .createServer(async (req, res) => {
    const url = new URL(req.url ?? "/", `http://localhost:${PORT}`);
    if (LATENCY_MS) await new Promise((resolve) => setTimeout(resolve, LATENCY_MS));
    if (url.pathname === "/__chats") return send(res, 200, chats);
    if (req.headers.authorization !== `Bearer ${MOCK_TOKEN}`) return send(res, 401, { error: "unauthorized" });
    let body = "";
    for await (const chunk of req) body += chunk;
    const json = body ? JSON.parse(body) : {};

    switch (`${req.method} ${url.pathname}`) {
      case "GET /api/apps":
        return send(res, 200, {
          data: Object.entries(APPS).map(([id, app]) => ({ id, description: app.description, timestamp: app.timestamp })),
        });
      case "GET /api/sandbox": {
        const appId = url.searchParams.get("appId");
        return send(res, 200, { data: { sandboxId: appId in APPS ? `sbx_${appId}` : null } });
      }
      case "GET /api/sandbox-file-list": {
        const files = APPS[url.searchParams.get("sandboxId")?.replace(/^sbx_/, "")]?.files ?? {};
        return send(res, 200, { data: { files: Object.keys(files).map((path) => ({ path, hash: "mock" })) } });
      }
      case "POST /api/sandbox-file-batch-read": {
        const files = APPS[json.sandboxId?.replace(/^sbx_/, "")]?.files ?? {};
        return send(res, 200, {
          data: {
            files: json.paths.map((path) =>
              path in files ? { path, content: files[path] } : { path, error: "not_found" },
            ),
          },
        });
      }
      case "POST /api/chat":
        chats.push(json);
        process.stdout.write(`[mock-arc-studio] chat for ${json.appId}: ${json.messages?.[0]?.content?.slice(0, 120)}…\n`);
        return send(res, 202, { data: { appId: json.appId ?? APP_ID, threadId: `thr_${chats.length}` } });
      default:
        return send(res, 404, { error: `no mock for ${req.method} ${url.pathname}` });
    }
  })
  .listen(PORT, "127.0.0.1", () => process.stdout.write(`[mock-arc-studio] http://localhost:${PORT}\n`));

# arc-studio-fuzz

Stateful smart-contract fuzzing for [Arc Studio](https://studio.arc.io) apps, powered by Aomi.

Aomi reads an Arc Studio app's contracts and Foundry artifacts, runs a bounded
breadth-first fuzz campaign on a held Arc fork (multi-actor, ordered
transactions), minimizes any violation, and only reports it after two clean
reproductions. A verified finding can be sent straight back to the app as an
Arc Studio fix request. Simulation only: nothing is signed, deployed, or broadcast.

| Path | What |
|---|---|
| `apps/arc-studio-fuzzer` | The Aomi app (Rust, `aomi-sdk` 5.1.1) that runs the campaign: owns the breadth-first search, minimization and two-reproduction rule, and drives the host's `evm-sim` tools. Listed in `.aomi/config.json`; deployed from the Aomi build platform. |
| `apps/web` | Next.js app (Vercel). Connect an Arc Studio token, pick an app, fuzz a contract with a live agent trace, send the finding back for a fix. |
| `packages/arc-studio-cli` | Fork of Circle's MIT `@circle-fin/arc-studio-cli` 1.1.3. Adds `arc-studio fuzz` and exposes `StudioClient` as a library. See its `NOTICE`. |
| `packages/fuzz-core` | Shared logic: `ArcStudioApp` (workspace → `FuzzTarget`, fix requests), `FuzzTarget` (artifact + campaign prompt), `CampaignTrace` (Aomi events → trace + report). |
| `scripts/mock-arc-studio.mjs` | Local stand-in for the Arc Studio API with a known-vulnerable `UnsafeVault`, for development without an Arc Studio account. |

The fuzzing itself runs in the `arc-studio-fuzzer` Aomi app (`apps/arc-studio-fuzzer`)
on the backend's `evm-sim` runtime (`sim_set_code`, `sim_set_balance`, `sim_snapshot`,
`sim_replay_traces`).

## How Arc Studio access works

The Arc Studio web app is closed source; its CLI is MIT and talks to the same
HTTP API (`/api/apps`, `/api/sandbox`, `/api/sandbox-file-list`,
`/api/sandbox-file-batch-read`, `/api/chat`) with a personal access token
(`origin_pat_…`). Both surfaces here use the forked CLI's `StudioClient`:

- **CLI**: `arc-studio login` (Circle's loopback device-link flow, unchanged), then `arc-studio fuzz`.
- **Web**: Arc Studio only redirects tokens to `127.0.0.1`, so the web app uses the paste flow — the user authorizes at `studio.arc.io/cli-auth` and pastes the token. It is verified, then held server-side in an AES-256-GCM encrypted httpOnly cookie.

## Develop

```bash
pnpm install
cp apps/web/.env.example apps/web/.env.local   # set SESSION_SECRET
node scripts/mock-arc-studio.mjs               # optional: mock Arc Studio on :4100
pnpm dev                                       # web on :3100
```

With the mock, set `ARC_STUDIO_API_URL=http://localhost:4100` and connect with
the token in `scripts/mock-arc-studio.mjs`. Campaigns need an Aomi backend with
the `arc-studio-fuzzer` app at `NEXT_PUBLIC_AOMI_BACKEND_URL`.

## Aomi app

```bash
cargo test                                         # campaign, plan, ABI and strict-schema tests
aomi-build sdk check --required-version 5.1.1      # SDK pin the build platform requires
aomi-build compile --app arc-studio-fuzzer         # plugin -> plugins/
```

The repository is an Aomi Project: `.aomi/config.json` lists
`apps/arc-studio-fuzzer/aomi.toml`, and the build platform deploys it from an
immutable commit.

## CLI

```bash
pnpm --filter @aomi-labs/arc-studio-cli exec arc-studio login
pnpm --filter @aomi-labs/arc-studio-cli exec arc-studio fuzz --app <appId>                # only compiled contract
pnpm --filter @aomi-labs/arc-studio-cli exec arc-studio fuzz Vault --app <appId> --fix    # send finding back
pnpm --filter @aomi-labs/arc-studio-cli exec arc-studio fuzz contracts/V.sol:Vault -o json
```

Exit codes: `0` no violation within budget, `2` verified finding, `1` error, `64` ambiguous/unknown contract.
`--aomi-url` / `ARC_STUDIO_FUZZ_AOMI_URL` select the Aomi portal (default staging: `https://chat-staging.aomi.dev`, app 2937813).

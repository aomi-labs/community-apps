import type { NextConfig } from "next";

const config: NextConfig = {
  // Lets a second local dev server (e.g. against the mock Arc Studio) run beside the first.
  distDir: process.env.NEXT_DIST_DIR ?? ".next",
  // fuzz-core ships TypeScript source.
  transpilePackages: ["@aomi-labs/arc-studio-fuzz-core"],
  // The forked CLI client uses Node APIs (keychain fallback); keep it out of bundling.
  serverExternalPackages: ["@aomi-labs/arc-studio-cli"],
};

export default config;

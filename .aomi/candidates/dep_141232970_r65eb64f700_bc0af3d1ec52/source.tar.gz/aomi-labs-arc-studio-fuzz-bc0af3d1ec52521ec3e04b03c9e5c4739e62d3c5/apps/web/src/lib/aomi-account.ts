"use client";

import {
  type AccountSessionProvider,
  createAccountSessionProvider,
  createSiweAccountAuthAdapter,
} from "@aomi-labs/client";

/** Minimal EIP-1193 surface of an injected browser wallet. */
interface InjectedWallet {
  request(args: { method: string; params?: unknown[] }): Promise<unknown>;
}

const ADDRESS_KEY = "arc-studio-fuzz:aomi-account";

function injected(): InjectedWallet | undefined {
  return (globalThis as { ethereum?: InjectedWallet }).ethereum;
}

function storage(): Storage | undefined {
  try {
    return sessionStorage;
  } catch {
    return undefined;
  }
}

/**
 * An Aomi account signed in with the visitor's browser wallet (Sign-In with
 * Ethereum through the portal's widget session). Signed-in sessions run with
 * an account budget instead of the guest per-call input cap, which full fuzz
 * campaigns exceed. The wallet only signs the login message; it never signs
 * or sends transactions here.
 */
export class AomiAccount {
  private constructor(
    readonly address: string,
    readonly session: AccountSessionProvider,
  ) {}

  static get walletAvailable(): boolean {
    return Boolean(injected());
  }

  /** Prompts the wallet for an account, then signs in (one signature). */
  static async signIn(baseUrl: string): Promise<AomiAccount> {
    const wallet = injected();
    if (!wallet) throw new Error("No browser wallet found. Install MetaMask or another Ethereum wallet.");
    const [address] = (await wallet.request({ method: "eth_requestAccounts" })) as string[];
    if (!address) throw new Error("The wallet did not share an account.");
    const account = AomiAccount.#create(baseUrl, wallet, address);
    try {
      // Mints the account session now, so a rejected signature fails here, not mid-campaign.
      await account.session();
    } catch (error) {
      account.session.dispose();
      throw error;
    }
    storage()?.setItem(ADDRESS_KEY, address);
    return account;
  }

  /** Re-attaches to this tab's signed-in account, if any, without prompting. */
  static async resume(baseUrl: string): Promise<AomiAccount | null> {
    const wallet = injected();
    const address = storage()?.getItem(ADDRESS_KEY);
    if (!wallet || !address) return null;
    const accounts = ((await wallet.request({ method: "eth_accounts" }).catch(() => [])) as string[]) ?? [];
    if (!accounts.some((a) => a.toLowerCase() === address.toLowerCase())) return null;
    return AomiAccount.#create(baseUrl, wallet, address);
  }

  static #create(baseUrl: string, wallet: InjectedWallet, address: string): AomiAccount {
    const adapter = createSiweAccountAuthAdapter({
      async getSigner() {
        const chainId = Number.parseInt(String(await wallet.request({ method: "eth_chainId" })), 16);
        return {
          address,
          chainId,
          signMessage: (message: string) =>
            wallet.request({ method: "personal_sign", params: [message, address] }) as Promise<string>,
        };
      },
    });
    const session = createAccountSessionProvider({ baseUrl, adapter, storage: storage() });
    return new AomiAccount(address, session);
  }

  async signOut(): Promise<void> {
    storage()?.removeItem(ADDRESS_KEY);
    await this.session.signOut().catch(() => undefined);
    this.session.dispose();
  }
}

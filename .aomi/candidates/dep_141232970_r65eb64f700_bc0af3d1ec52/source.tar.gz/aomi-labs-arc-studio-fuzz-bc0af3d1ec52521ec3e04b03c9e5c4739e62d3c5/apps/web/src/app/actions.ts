"use server";

import type { FuzzCampaignReport } from "@aomi-labs/arc-studio-fuzz-core";
import { MissingBuildError } from "@aomi-labs/arc-studio-fuzz-core";
import { headers } from "next/headers";
import { redirect } from "next/navigation";

import { StudioSession } from "@/server/studio-session";

/** Plain-data form of a FuzzTarget, safe to cross the server-action boundary. */
export interface TargetData {
  name: string;
  sourcePath: string;
  source: string;
  abi: Array<{ type?: string; name?: string; stateMutability?: string }>;
  deployedBytecode: string;
  chainId: number;
  /**
   * Short-lived link the Aomi fuzzer app downloads the artifact from, so large
   * contracts never pass through the chat. Only minted on the production host,
   * the one the app accepts; elsewhere the prompt inlines the artifact.
   */
  artifactUrl?: string;
}

type Result<T> = { ok: true; value: T } | { ok: false; error: string; missingBuild?: boolean };

/** The one host the arc-studio-fuzzer app accepts artifact links from. */
const ARTIFACT_HOST = "arc-studio-fuzz.vercel.app";

/** Public https URL of the artifact route, or undefined off the production host. */
async function artifactUrl(
  current: StudioSession,
  appId: string,
  sourcePath: string,
  contract: string,
): Promise<string | undefined> {
  const request = await headers();
  const host = request.get("x-forwarded-host") ?? request.get("host");
  // The fuzzer app downloads only from this exact host (squatting-safe).
  if (host !== ARTIFACT_HOST) return undefined;
  return `https://${host}/api/artifacts/${current.artifactTicket(appId, sourcePath, contract)}`;
}

async function session(): Promise<StudioSession> {
  const current = await StudioSession.current();
  if (!current) redirect("/");
  return current;
}

function failure(error: unknown): { ok: false; error: string; missingBuild?: boolean } {
  return {
    ok: false,
    error: error instanceof Error ? error.message : String(error),
    missingBuild: error instanceof MissingBuildError || undefined,
  };
}

export async function connect(_: unknown, form: FormData): Promise<{ error: string } | undefined> {
  try {
    await StudioSession.start(String(form.get("token") ?? ""));
  } catch (error) {
    return { error: error instanceof Error ? error.message : String(error) };
  }
  redirect("/");
}

export async function disconnect(): Promise<void> {
  await StudioSession.end();
  redirect("/");
}

export async function loadTarget(
  appId: string,
  sourcePath: string,
  contract: string,
): Promise<Result<TargetData>> {
  try {
    const current = await session();
    const target = await StudioSession.timed(`target ${contract}`, async () =>
      (await current.app(appId)).target(sourcePath, contract),
    );
    return {
      ok: true,
      value: {
        name: target.name,
        sourcePath: target.sourcePath,
        source: target.source,
        abi: target.abi,
        deployedBytecode: target.deployedBytecode,
        chainId: target.chainId,
        artifactUrl: await artifactUrl(current, appId, sourcePath, contract),
      },
    };
  } catch (error) {
    return failure(error);
  }
}

/** Drops the cached sandbox view so the next read sees Arc Studio's latest files. */
export async function refreshApp(appId: string): Promise<void> {
  await (await session()).app(appId, { fresh: true });
}

export async function requestBuild(appId: string): Promise<Result<{ webUrl: string }>> {
  try {
    const { webUrl } = await (await (await session()).app(appId)).requestBuild();
    return { ok: true, value: { webUrl } };
  } catch (error) {
    return failure(error);
  }
}

export async function requestFix(
  appId: string,
  sourcePath: string,
  contract: string,
  report: FuzzCampaignReport,
): Promise<Result<{ webUrl: string }>> {
  try {
    const app = await (await session()).app(appId);
    const { webUrl } = await app.requestFix(await app.target(sourcePath, contract), report);
    return { ok: true, value: { webUrl } };
  } catch (error) {
    return failure(error);
  }
}

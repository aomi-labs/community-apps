"use client";

import { ExternalLink, KeyRound, Loader2 } from "lucide-react";
import { useActionState } from "react";

import { connect } from "@/app/actions";

export function ConnectForm({ authorizeUrl, expired = false }: { authorizeUrl: string; expired?: boolean }) {
  const [state, action, pending] = useActionState(connect, undefined);

  return (
    <form action={action} className="w-full max-w-md space-y-5">
      <div>
        {expired && (
          <p className="mb-3 rounded-md border border-[#ff4d6d]/30 bg-[#ff4d6d]/7 px-3 py-2 text-xs text-[#ffc2cd]">
            Arc Studio no longer accepts the saved token. Connect again.
          </p>
        )}
        <h1 className="text-xl font-semibold">Connect your Arc Studio account</h1>
        <p className="mt-2 text-sm leading-6 text-[#a7b0c0]">
          Aomi reads your app&apos;s contracts and compiled artifacts, attacks them on a held Arc
          fork, and can send verified findings back to Arc Studio for a fix. Nothing is signed,
          deployed, or broadcast.
        </p>
      </div>

      <ol className="space-y-3 text-sm text-[#c7cfdb]">
        <li className="flex gap-3">
          <span className="grid size-6 shrink-0 place-items-center rounded-full bg-[#6e59ff]/15 text-xs text-[#b9afff]">
            1
          </span>
          <span>
            Open{" "}
            <a
              href={authorizeUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1 text-[#b9afff] underline underline-offset-2"
            >
              Arc Studio&apos;s token page <ExternalLink className="size-3" />
            </a>{" "}
            and click <strong>Authorize</strong>.
          </span>
        </li>
        <li className="flex gap-3">
          <span className="grid size-6 shrink-0 place-items-center rounded-full bg-[#6e59ff]/15 text-xs text-[#b9afff]">
            2
          </span>
          <span>Paste the token it shows (starts with <code>origin_pat_</code>).</span>
        </li>
      </ol>

      <label className="block">
        <span className="sr-only">Arc Studio token</span>
        <div className="flex items-center gap-2 rounded-md border border-white/10 bg-[#0d1119] px-3 focus-within:border-[#6e59ff]/60">
          <KeyRound className="size-4 text-[#68758a]" />
          <input
            name="token"
            type="password"
            autoComplete="off"
            spellCheck={false}
            required
            placeholder="origin_pat_…"
            className="h-11 w-full bg-transparent font-mono text-sm outline-none placeholder:text-[#4b566a]"
          />
        </div>
      </label>

      {state?.error && <p className="text-sm text-[#ff8ca1]">{state.error}</p>}

      <button
        type="submit"
        disabled={pending}
        className="flex h-11 w-full items-center justify-center gap-2 rounded-md bg-[#6e59ff] text-sm font-semibold text-white transition hover:bg-[#7d6aff] disabled:opacity-70"
      >
        {pending && <Loader2 className="size-4 animate-spin" />} Connect
      </button>

      <p className="text-xs leading-5 text-[#68758a]">
        The token is verified with Arc Studio, then kept only in an encrypted, httpOnly cookie on
        this site for 7 days. Revoke it anytime with <code>arc-studio tokens revoke</code> or from
        Arc Studio.
      </p>
    </form>
  );
}

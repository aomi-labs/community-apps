"use client";

import { ArcStudioApp, type ContractSource } from "@aomi-labs/arc-studio-fuzz-core";
import { AomiRuntimeProvider } from "@aomi-labs/react";
import {
  BrainCircuit,
  Check,
  ChevronLeft,
  CircleDashed,
  ExternalLink,
  File as FileIcon,
  FileCode2,
  Hammer,
  Loader2,
  LogOut,
  UserCheck,
  Wallet,
} from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { type ReactNode, useEffect, useRef, useState, useTransition } from "react";

import { loadTarget, refreshApp, requestBuild, type TargetData } from "@/app/actions";
import { Brand } from "@/components/brand";
import { AomiAccount } from "@/lib/aomi-account";
import { COLLAPSED, FileTree } from "@/components/file-tree";
import { FuzzPanel } from "@/components/fuzz-panel";

// The Aomi portal (auth + proxy to the backend). Staging hosts arc-studio-fuzzer today.
const backendUrl = process.env.NEXT_PUBLIC_AOMI_BACKEND_URL ?? "https://chat-staging.aomi.dev";
const configuredApplicationId = Number(process.env.NEXT_PUBLIC_AOMI_APPLICATION_ID);
const applicationId =
  Number.isSafeInteger(configuredApplicationId) && configuredApplicationId > 0
    ? configuredApplicationId
    : undefined;

const KEYWORDS =
  /\b(?:contract|interface|library|abstract|is|mapping|address|bool|string|bytes\d*|u?int\d*|public|private|internal|external|view|pure|payable|function|modifier|event|error|emit|returns?|require|revert|if|else|for|while|memory|storage|calldata|constructor|pragma|solidity|import|using|struct|enum|override|virtual|immutable|constant)\b/;

function highlight(line: string): ReactNode {
  if (line.trim().startsWith("//")) return <span className="text-[#70809a]">{line}</span>;
  return line.split(new RegExp(`(${KEYWORDS.source})`, "g")).map((token, index) =>
    KEYWORDS.test(token) ? (
      <span key={index} className="text-[#c995ff]">
        {token}
      </span>
    ) : (
      token
    ),
  );
}

type TargetState =
  | { status: "idle" }
  | { status: "loading" }
  | { status: "ready"; target: TargetData }
  | { status: "missing-build"; error: string; buildUrl?: string }
  | { status: "error"; error: string };

export interface FuzzWorkspaceProps {
  appId: string;
  appName: string;
  studioUrl: string;
  contracts: ContractSource[];
  /** Paths Arc Studio listed in the sandbox; empty usually means it was still waking up. */
  files: string[];
}

export function FuzzWorkspace(props: FuzzWorkspaceProps) {
  const [account, setAccount] = useState<AomiAccount | null>(null);

  useEffect(() => {
    void AomiAccount.resume(backendUrl).then(setAccount);
  }, []);

  return (
    <AomiRuntimeProvider
      // A new runtime per identity, so a sign-in never mixes guest and account threads.
      key={account?.address ?? "guest"}
      backendUrl={backendUrl}
      applicationId={applicationId}
      clientOptions={account ? { getAccountBearer: account.session } : undefined}
      accountSessionAvailable={Boolean(account)}
      agentTarget={
        applicationId
          ? { mode: "direct", applicationId, app: "arc-studio-fuzzer" }
          : { mode: "direct", app: "arc-studio-fuzzer" }
      }
      persistThread={false}
      threadPersistenceScope={`arc-studio-fuzz:${props.appId}`}
    >
      <Workspace {...props} account={account} onAccount={setAccount} />
    </AomiRuntimeProvider>
  );
}

/** Header control for the Aomi account the campaigns run as. */
function AccountControl({
  account,
  onAccount,
}: {
  account: AomiAccount | null;
  onAccount: (account: AomiAccount | null) => void;
}) {
  const [pending, startPending] = useTransition();
  const [error, setError] = useState<string | null>(null);

  if (account) {
    return (
      <div className="flex items-center gap-2 rounded-md border border-[#7fe3aa]/25 bg-[#7fe3aa]/5 px-3 py-1.5 text-[12px] text-[#bfeccf]">
        <UserCheck className="size-3.5" />
        Aomi · {account.address.slice(0, 6)}…{account.address.slice(-4)}
        <button
          onClick={() => startPending(async () => {
            await account.signOut();
            onAccount(null);
          })}
          className="ml-1 text-[#8996ab] hover:text-white"
          aria-label="Sign out of Aomi"
          title="Sign out of Aomi"
        >
          <LogOut className="size-3.5" />
        </button>
      </div>
    );
  }
  return (
    <div className="flex items-center gap-2">
      {error && <span className="max-w-64 truncate text-[12px] text-[#ff8ca1]" title={error}>{error}</span>}
      <button
        disabled={pending}
        onClick={() =>
          startPending(async () => {
            setError(null);
            try {
              onAccount(await AomiAccount.signIn(backendUrl));
            } catch (cause) {
              setError(cause instanceof Error ? cause.message : String(cause));
            }
          })
        }
        title="Sign in with your Ethereum wallet (one signature, no transaction). Signed-in campaigns are not limited by the guest input cap."
        className="flex items-center gap-1.5 rounded-md bg-[#6e59ff] px-3 py-1.5 text-[12px] font-semibold text-white hover:bg-[#7d6aff] disabled:opacity-70"
      >
        {pending ? <Loader2 className="size-3.5 animate-spin" /> : <Wallet className="size-3.5" />}
        Sign in to Aomi
      </button>
    </div>
  );
}

const LAYOUT_KEY = "arc-studio-fuzz:layout";
const LIMITS = { explorer: [180, 520], agent: [340, 760] } as const;
const DEFAULT_LAYOUT = { explorer: 280, agent: 460 };
const MAX_VIEW_BYTES = 300_000;

type Layout = typeof DEFAULT_LAYOUT;
type OpenFile = { path: string; content?: string; error?: string };

/** Drag handle between two panels. `side` says which panel the drag resizes. */
function Divider({ onDrag, onReset }: { onDrag: (dx: number) => void; onReset: () => void }) {
  return (
    <div
      role="separator"
      aria-orientation="vertical"
      title="Drag to resize · double-click to reset"
      onDoubleClick={onReset}
      onPointerDown={(event) => {
        const handle = event.currentTarget;
        handle.setPointerCapture(event.pointerId);
        let last = event.clientX;
        const move = (e: PointerEvent) => {
          onDrag(e.clientX - last);
          last = e.clientX;
        };
        const up = () => {
          handle.removeEventListener("pointermove", move);
          handle.removeEventListener("pointerup", up);
          document.body.style.removeProperty("cursor");
          document.body.style.removeProperty("user-select");
        };
        document.body.style.cursor = "col-resize";
        document.body.style.userSelect = "none";
        handle.addEventListener("pointermove", move);
        handle.addEventListener("pointerup", up);
      }}
      className="group relative z-10 -mx-1 w-2 shrink-0 cursor-col-resize"
    >
      <div className="mx-auto h-full w-px bg-white/10 transition group-hover:w-0.5 group-hover:bg-[#8b7cff] group-active:bg-[#8b7cff]" />
    </div>
  );
}

function Workspace({
  appId,
  appName,
  studioUrl,
  contracts,
  files,
  account,
  onAccount,
}: FuzzWorkspaceProps & { account: AomiAccount | null; onAccount: (account: AomiAccount | null) => void }) {
  const router = useRouter();
  const firstBuilt =
    contracts.find((file) => file.built && file.contracts.length > 0) ??
    contracts.find((file) => file.contracts.length > 0);
  const [selected, setSelected] = useState<{ path: string; contract: string } | null>(
    firstBuilt ? { path: firstBuilt.path, contract: firstBuilt.contracts[0] as string } : null,
  );
  const [opened, setOpened] = useState<OpenFile | null>(
    firstBuilt ? { path: firstBuilt.path, content: firstBuilt.source } : null,
  );
  const [target, setTarget] = useState<TargetState>({ status: "idle" });
  const [reloads, setReloads] = useState(0);
  const [building, startBuild] = useTransition();
  const [layout, setLayout] = useState<Layout>(DEFAULT_LAYOUT);
  /** File reads by path, shared by hover-prefetch and clicks; cleared on refresh. */
  const reads = useRef(new Map<string, Promise<OpenFile>>());
  const fuzzable = contracts.filter((file) => file.contracts.length > 0);
  const scaffoldOnly = files.some((path) => /(^|\/)contracts\/(out|script)\//.test(path));

  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(LAYOUT_KEY) ?? "null") as Partial<Layout> | null;
      if (saved) setLayout((current) => ({ ...current, ...saved }));
    } catch {
      /* per-viewer convenience only */
    }
  }, []);

  function resize(panel: keyof Layout, delta: number) {
    setLayout((current) => {
      const [min, max] = LIMITS[panel];
      const next = { ...current, [panel]: Math.min(max, Math.max(min, current[panel] + delta)) };
      try {
        localStorage.setItem(LAYOUT_KEY, JSON.stringify(next));
      } catch {
        /* ignore */
      }
      return next;
    });
  }

  useEffect(() => {
    if (!selected) return;
    let cancelled = false;
    setTarget({ status: "loading" });
    void loadTarget(appId, selected.path, selected.contract).then((result) => {
      if (cancelled) return;
      if (result.ok) setTarget({ status: "ready", target: result.value });
      else if (result.missingBuild) setTarget({ status: "missing-build", error: result.error });
      else setTarget({ status: "error", error: result.error });
    });
    return () => {
      cancelled = true;
    };
  }, [appId, selected, reloads]);

  function read(path: string): Promise<OpenFile> {
    let pending = reads.current.get(path);
    if (!pending) {
      pending = fetch(`/api/apps/${appId}/file?path=${encodeURIComponent(path)}`).then(async (response) =>
        response.ok ? { path, content: await response.text() } : { path, error: await response.text() },
      );
      // Failed reads are retried on the next click.
      void pending.then((file) => file.error && reads.current.delete(path));
      reads.current.set(path, pending);
    }
    return pending;
  }

  // Warm the viewer: fetch the app's own files (not deps, build output, lockfiles
  // or secrets) in one batch, so most clicks never wait on Arc Studio.
  useEffect(() => {
    const known = new Set(contracts.map((file) => file.path));
    const project = files.filter(
      (path) =>
        !known.has(path) &&
        !reads.current.has(path) &&
        !ArcStudioApp.isSensitive(path) &&
        !ArcStudioApp.workspacePath(path).split("/").some((part) => COLLAPSED.has(part)) &&
        !/\.(lock|jsonl|png|jpe?g|gif|ico|woff2?|ttf)$/i.test(path),
    );
    if (project.length === 0) return;
    const batch = fetch(`/api/apps/${appId}/files`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ paths: project }),
    })
      .then((response): Promise<Record<string, string>> | Record<string, string> =>
        response.ok ? response.json() : {},
      )
      .catch((): Record<string, string> => ({}));
    for (const path of project.slice(0, 80)) {
      reads.current.set(
        path,
        batch.then((contents) => {
          if (path in contents) return { path, content: contents[path] as string };
          reads.current.delete(path);
          return read(path);
        }),
      );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- once per workspace load
  }, [appId, files]);

  function open(path: string) {
    const known = contracts.find((file) => file.path === path);
    if (known) {
      setOpened({ path, content: known.source });
      return;
    }
    setOpened({ path });
    void read(path).then((file) => setOpened((current) => (current?.path === path ? file : current)));
  }

  function choose(path: string, contract: string) {
    setSelected({ path, contract });
    open(path);
  }

  /** Re-read the workspace from Arc Studio (after a build or fix landed there). */
  function refresh() {
    reads.current.clear();
    void refreshApp(appId).then(() => {
      router.refresh();
      setReloads((count) => count + 1);
    });
  }

  const content = opened?.content ?? "";
  const truncated = content.length > MAX_VIEW_BYTES;
  const lines = (truncated ? content.slice(0, MAX_VIEW_BYTES) : content).split("\n");
  const solidity = opened?.path.endsWith(".sol") ?? false;

  return (
    <main className="flex h-screen flex-col overflow-hidden text-[13px]">
      <header className="flex h-14 shrink-0 items-center justify-between gap-4 border-b border-white/10 bg-[#0c1018] px-4">
        <div className="flex min-w-0 items-center gap-4">
          <Link href="/" className="rounded p-1 text-[#8996ab] hover:bg-white/5 hover:text-white" aria-label="Back to apps">
            <ChevronLeft className="size-5" />
          </Link>
          <Brand />
          <div className="h-5 w-px bg-white/10" />
          <span className="truncate text-[14px] font-medium text-[#eef2f8]">{appName}</span>
        </div>
        <div className="flex shrink-0 items-center gap-3">
          <AccountControl account={account} onAccount={onAccount} />
          <div className="flex items-center gap-2 rounded-full border border-[#6e59ff]/35 bg-[#6e59ff]/10 px-3 py-1.5 text-[12px] text-[#c5baff]">
            <span className="size-1.5 rounded-full bg-[#8b7cff] shadow-[0_0_8px_#8b7cff]" />
            Arc fork · {target.status === "ready" ? target.target.chainId : 5042}
          </div>
          <a
            href={studioUrl}
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1.5 rounded-md border border-white/10 bg-white/5 px-3 py-1.5 text-[12px] font-medium text-[#cbd3e1] hover:bg-white/10"
          >
            Open in Arc Studio <ExternalLink className="size-3.5" />
          </a>
        </div>
      </header>

      <div className="flex min-h-0 flex-1">
        <aside style={{ width: layout.explorer }} className="flex shrink-0 flex-col overflow-hidden bg-[#0d1119]">
          <div className="min-h-0 flex-1 overflow-auto">
            <h2 className="px-3 pb-2 pt-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-[#78859a]">
              Fuzz targets
            </h2>
            {fuzzable.length === 0 ? (
              <div className="mx-3 mb-4 space-y-2 rounded-md border border-white/8 bg-white/[.02] p-3 text-[12px] leading-5 text-[#a7b0c0]">
                <p>
                  {files.length === 0
                    ? "Arc Studio returned an empty workspace. The app's sandbox may still be waking up."
                    : scaffoldOnly
                      ? "This app has Foundry scaffolding (forge-std, deploy scripts) but no contract of its own. It likely uses existing contracts such as USDC."
                      : "No Solidity contracts in this app yet."}
                </p>
                <p className="text-[#8996ab]">Ask Arc Studio to write a contract, then check again.</p>
                <button onClick={refresh} className="font-medium text-[#b9afff] hover:underline">
                  Check again
                </button>
              </div>
            ) : (
              <ul className="space-y-0.5 px-2 pb-4">
                {fuzzable.flatMap((file) =>
                  file.contracts.map((name) => {
                    const active = selected?.path === file.path && selected.contract === name;
                    return (
                      <li key={`${file.path}:${name}`}>
                        <button
                          onClick={() => choose(file.path, name)}
                          className={`flex w-full items-center gap-2 rounded-md px-2 py-2 text-left ${
                            active ? "bg-[#6e59ff]/18 text-[#e2ddff]" : "text-[#d5dbe6] hover:bg-white/5"
                          }`}
                        >
                          <FileCode2 className="size-4 shrink-0 text-[#6ed7ff]" />
                          <span className="min-w-0 flex-1">
                            <span className="block truncate font-medium">{name}</span>
                            <span className="block truncate text-[11px] text-[#68758a]">
                              {ArcStudioApp.workspacePath(file.path)}
                            </span>
                          </span>
                          {file.built ? (
                            <span className="flex shrink-0 items-center gap-1 text-[11px] text-[#7fe3aa]">
                              <Check className="size-3.5" /> built
                            </span>
                          ) : (
                            <span className="flex shrink-0 items-center gap-1 text-[11px] text-[#8996ab]">
                              <CircleDashed className="size-3.5" /> not built
                            </span>
                          )}
                        </button>
                      </li>
                    );
                  }),
                )}
              </ul>
            )}

            <h2 className="flex items-center justify-between border-t border-white/8 px-3 pb-2 pt-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-[#78859a]">
              Files <span className="font-normal normal-case tracking-normal text-[#5f6a7d]">{files.length}</span>
            </h2>
            <FileTree files={files} openPath={opened?.path} onOpen={open} onPrefetch={(path) => void read(path)} />
          </div>
        </aside>

        <Divider onDrag={(dx) => resize("explorer", dx)} onReset={() => resize("explorer", DEFAULT_LAYOUT.explorer - layout.explorer)} />

        <section className="flex min-w-0 flex-1 flex-col bg-[#0b0f16]">
          <div className="flex h-11 shrink-0 items-center gap-2 border-b border-white/10 bg-[#0d1119] px-4 text-[13px] text-[#dfe4ec]">
            {opened ? (
              <>
                {solidity ? <FileCode2 className="size-4 text-[#6ed7ff]" /> : <FileIcon className="size-4 text-[#68758a]" />}
                <span className="truncate">{ArcStudioApp.workspacePath(opened.path)}</span>
              </>
            ) : (
              <span className="text-[#8996ab]">Select a file to view it</span>
            )}
          </div>
          <div className="min-h-0 flex-1 overflow-auto py-4 font-mono text-[13px] leading-[1.75]">
            {opened && opened.content === undefined && !opened.error && (
              <p className="flex items-center gap-2 px-6 text-[#8996ab]">
                <Loader2 className="size-4 animate-spin" /> Reading from Arc Studio…
              </p>
            )}
            {opened?.error && <p className="px-6 text-[#ff8ca1]">{opened.error}</p>}
            {opened?.content !== undefined &&
              lines.map((line, index) => (
                <div key={index} className="flex min-h-[23px]">
                  <span className="w-14 shrink-0 select-none pr-4 text-right text-[#465165]">{index + 1}</span>
                  <span className="whitespace-pre pr-6 text-[#d5dbe6]">{solidity ? highlight(line) : line}</span>
                </div>
              ))}
            {truncated && (
              <p className="px-6 pt-2 text-[#8996ab]">
                Showing the first {MAX_VIEW_BYTES.toLocaleString()} characters of a large file.
              </p>
            )}
          </div>
        </section>

        <Divider onDrag={(dx) => resize("agent", -dx)} onReset={() => resize("agent", DEFAULT_LAYOUT.agent - layout.agent)} />

        <aside style={{ width: layout.agent }} className="flex min-h-0 shrink-0 flex-col bg-[#10151f]">
          {target.status === "ready" ? (
            <FuzzPanel
              key={`${target.target.sourcePath}:${target.target.name}`}
              appId={appId}
              backendUrl={backendUrl}
              signedIn={Boolean(account)}
              target={target.target}
              onRefresh={refresh}
            />
          ) : (
            <div className="flex flex-1 flex-col items-center justify-center gap-3 p-8 text-center text-[14px] leading-6 text-[#a7b0c0]">
              <BrainCircuit className="size-8 text-[#6e59ff]" />
              {target.status === "idle" &&
                (fuzzable.length === 0 ? (
                  <p>Nothing to fuzz yet. Pick an app with a Solidity contract, or ask Arc Studio to write one.</p>
                ) : (
                  <p>Pick a fuzz target on the left.</p>
                ))}
              {target.status === "loading" && (
                <p className="flex items-center gap-2">
                  <Loader2 className="size-4 animate-spin" /> Loading compiled artifact from Arc Studio…
                </p>
              )}
              {target.status === "error" && <p className="text-[#ff8ca1]">{target.error}</p>}
              {target.status === "missing-build" && (
                <>
                  <p>{target.error}</p>
                  {target.buildUrl ? (
                    <>
                      <a href={target.buildUrl} target="_blank" rel="noreferrer" className="text-[#b9afff] underline">
                        Follow the build in Arc Studio
                      </a>
                      <button onClick={refresh} className="text-[#8996ab] underline">
                        Check again
                      </button>
                    </>
                  ) : (
                    <button
                      disabled={building}
                      onClick={() =>
                        startBuild(async () => {
                          const result = await requestBuild(appId);
                          setTarget(
                            result.ok
                              ? { status: "missing-build", error: "Arc Studio is building the app.", buildUrl: result.value.webUrl }
                              : { status: "error", error: result.error },
                          );
                        })
                      }
                      className="flex items-center gap-2 rounded-md bg-[#6e59ff] px-4 py-2 font-semibold text-white disabled:opacity-70"
                    >
                      {building ? <Loader2 className="size-4 animate-spin" /> : <Hammer className="size-4" />}
                      Ask Arc Studio to build
                    </button>
                  )}
                </>
              )}
            </div>
          )}
        </aside>
      </div>
    </main>
  );
}

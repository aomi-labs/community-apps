import { ChevronRight, LogOut } from "lucide-react";
import Link from "next/link";

import { disconnect } from "@/app/actions";
import { Brand } from "@/components/brand";
import { ConnectForm } from "@/components/connect-form";
import { StudioSession } from "@/server/studio-session";

export const dynamic = "force-dynamic";

export default async function Home() {
  const session = await StudioSession.current();
  // A stored token Arc Studio no longer accepts (revoked, expired, other host) sends the user back to connect.
  const apps = await session
    ?.client()
    .listApps()
    .then((list) => list.sort((a, b) => b.timestamp.localeCompare(a.timestamp)))
    .catch(() => null);

  if (!session || !apps) {
    return (
      <main className="flex min-h-screen flex-col">
        <header className="flex h-14 items-center border-b border-white/10 px-5">
          <Brand />
        </header>
        <div className="flex flex-1 items-center justify-center px-4 py-12">
          <ConnectForm authorizeUrl={`${StudioSession.apiUrl}/cli-auth`} expired={Boolean(session)} />
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen">
      <header className="flex h-14 items-center justify-between border-b border-white/10 px-5">
        <Brand />
        <form action={disconnect}>
          <button className="flex items-center gap-1.5 text-xs text-[#8996ab] hover:text-white">
            <LogOut className="size-3.5" /> Disconnect
          </button>
        </form>
      </header>
      <section className="mx-auto max-w-3xl px-4 py-10">
        <h1 className="text-lg font-semibold">Pick an Arc Studio app to fuzz</h1>
        <p className="mt-1 text-sm text-[#8996ab]">
          {apps.length} app{apps.length === 1 ? "" : "s"} in your Arc Studio account.
        </p>
        <ul className="mt-6 divide-y divide-white/5 overflow-hidden rounded-lg border border-white/10">
          {apps.map((app) => (
            <li key={app.id}>
              <Link
                href={`/apps/${app.id}`}
                className="flex items-center gap-4 bg-[#0d1119] px-4 py-3.5 transition hover:bg-[#121827]"
              >
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm text-[#e2e7ef]">
                    {app.description || "Untitled app"}
                  </p>
                  <p className="mt-0.5 font-mono text-[11px] text-[#5f6a7d]">
                    {app.id}
                    {app.timestamp && ` · ${new Date(app.timestamp).toLocaleString()}`}
                  </p>
                </div>
                <ChevronRight className="size-4 text-[#5f6a7d]" />
              </Link>
            </li>
          ))}
          {apps.length === 0 && (
            <li className="bg-[#0d1119] px-4 py-8 text-center text-sm text-[#8996ab]">
              No apps yet. Build one in Arc Studio, then come back.
            </li>
          )}
        </ul>
      </section>
    </main>
  );
}

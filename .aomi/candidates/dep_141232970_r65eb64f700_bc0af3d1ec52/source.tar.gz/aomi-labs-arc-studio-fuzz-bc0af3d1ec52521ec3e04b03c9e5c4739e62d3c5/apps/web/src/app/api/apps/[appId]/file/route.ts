import { StudioSession } from "@/server/studio-session";

/**
 * One workspace file as text. A route (not a server action) so the browser can
 * fetch files in parallel instead of queueing behind other actions.
 */
export async function GET(request: Request, { params }: { params: Promise<{ appId: string }> }) {
  const { appId } = await params;
  const path = new URL(request.url).searchParams.get("path");
  const session = await StudioSession.current();
  if (!session) return new Response("Not connected to Arc Studio.", { status: 401 });
  if (!path) return new Response("Missing ?path=", { status: 400 });
  try {
    const content = await StudioSession.timed(`file ${path.split("/").at(-1)}`, async () =>
      (await session.app(appId)).readFile(path),
    );
    return new Response(content, {
      headers: { "content-type": "text/plain; charset=utf-8", "cache-control": "private, no-store" },
    });
  } catch (error) {
    return new Response(error instanceof Error ? error.message : String(error), { status: 422 });
  }
}

import { StudioSession } from "@/server/studio-session";

/**
 * Serves one contract's compiled artifact to the Aomi arc-studio-fuzzer app.
 * The ticket is a sealed, 30-minute capability for exactly this artifact.
 */
export async function GET(_: Request, { params }: { params: Promise<{ ticket: string }> }) {
  const { ticket } = await params;
  const redeemed = StudioSession.fromArtifactTicket(ticket);
  if (!redeemed) return new Response("Artifact link is invalid or expired.", { status: 403 });
  try {
    const target = await StudioSession.timed(`artifact ${redeemed.contract}`, async () =>
      (await redeemed.session.app(redeemed.appId)).target(redeemed.sourcePath, redeemed.contract),
    );
    return Response.json(
      {
        name: target.name,
        source_code: target.source,
        abi: JSON.stringify(target.abi),
        deployed_bytecode: target.deployedBytecode,
        chain_id: target.chainId,
      },
      { headers: { "cache-control": "private, no-store" } },
    );
  } catch (error) {
    return new Response(error instanceof Error ? error.message : String(error), { status: 422 });
  }
}

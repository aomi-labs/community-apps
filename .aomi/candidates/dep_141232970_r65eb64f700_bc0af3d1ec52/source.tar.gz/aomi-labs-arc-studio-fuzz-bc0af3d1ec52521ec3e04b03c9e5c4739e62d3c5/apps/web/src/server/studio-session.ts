import "server-only";

import { createCipheriv, createDecipheriv, createHash, randomBytes } from "node:crypto";

import { ArcStudioApp } from "@aomi-labs/arc-studio-fuzz-core";
import { StudioClient } from "@aomi-labs/arc-studio-cli/client";
import { cookies } from "next/headers";

const COOKIE = "arc_studio_session";
/** How long an opened app (sandbox id + file listing) is reused across requests. */
const APP_TTL_MS = 60_000;
const MAX_AGE_SECONDS = 60 * 60 * 24 * 7;
/** Lifetime of an artifact link handed to the Aomi fuzzer app. */
const ARTIFACT_TICKET_MS = 30 * 60_000;
const ALLOWED_API_URLS = new Set(["https://studio.arc.io", "https://studio-staging.arc.io"]);

/**
 * The visitor's Arc Studio personal access token, held only server-side in an
 * AES-256-GCM encrypted, httpOnly cookie. Every Arc Studio call goes through
 * the forked CLI's StudioClient with that token injected.
 */
export class StudioSession {
  /**
   * Opened apps keyed by token hash + app id, so a file click costs one Arc Studio
   * call. On globalThis because Next bundles pages and route handlers separately.
   */
  static get #apps(): Map<string, { app: Promise<ArcStudioApp>; expires: number }> {
    const store = globalThis as { __arcStudioApps?: Map<string, { app: Promise<ArcStudioApp>; expires: number }> };
    store.__arcStudioApps ??= new Map();
    return store.__arcStudioApps;
  }

  private constructor(readonly token: string) {}

  static get apiUrl(): string {
    const url = (process.env.ARC_STUDIO_API_URL ?? "https://studio.arc.io").replace(/\/+$/, "");
    if (!ALLOWED_API_URLS.has(url) && !/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(url)) {
      throw new Error(`ARC_STUDIO_API_URL must be an Arc Studio host, got ${url}`);
    }
    return url;
  }

  /** Per-purpose key, so a cookie can never be replayed as an artifact ticket or vice versa. */
  static #key(purpose: "cookie" | "artifact"): Buffer {
    const secret = process.env.SESSION_SECRET;
    if (!secret || secret.length < 32) {
      throw new Error("SESSION_SECRET must be set (at least 32 characters).");
    }
    // The cookie key predates artifact tickets; keep it so existing sessions stay valid.
    return createHash("sha256").update(purpose === "cookie" ? secret : `artifact:${secret}`).digest();
  }

  static #seal(purpose: "cookie" | "artifact", text: string): string {
    const iv = randomBytes(12);
    const cipher = createCipheriv("aes-256-gcm", StudioSession.#key(purpose), iv);
    const body = Buffer.concat([cipher.update(text, "utf8"), cipher.final()]);
    return Buffer.concat([iv, body, cipher.getAuthTag()]).toString("base64url");
  }

  static #open(purpose: "cookie" | "artifact", sealed: string): string | null {
    try {
      const raw = Buffer.from(sealed, "base64url");
      const decipher = createDecipheriv("aes-256-gcm", StudioSession.#key(purpose), raw.subarray(0, 12));
      decipher.setAuthTag(raw.subarray(raw.length - 16));
      return Buffer.concat([decipher.update(raw.subarray(12, raw.length - 16)), decipher.final()]).toString("utf8");
    } catch {
      return null;
    }
  }

  static async current(): Promise<StudioSession | null> {
    const sealed = (await cookies()).get(COOKIE)?.value;
    const token = sealed ? StudioSession.#open("cookie", sealed) : null;
    return token ? new StudioSession(token) : null;
  }

  /**
   * An opaque, 30-minute link capability for one contract's artifact, so the Aomi
   * fuzzer app can download it instead of the bytecode passing through the chat.
   * The token inside is encrypted with a key only this server holds.
   */
  artifactTicket(appId: string, sourcePath: string, contract: string): string {
    return StudioSession.#seal(
      "artifact",
      JSON.stringify({ token: this.token, appId, sourcePath, contract, expires: Date.now() + ARTIFACT_TICKET_MS }),
    );
  }

  /** Redeems an artifact ticket; null when forged, tampered with, or expired. */
  static fromArtifactTicket(
    ticket: string,
  ): { session: StudioSession; appId: string; sourcePath: string; contract: string } | null {
    const opened = StudioSession.#open("artifact", ticket);
    if (!opened) return null;
    const claims = JSON.parse(opened) as {
      token: string;
      appId: string;
      sourcePath: string;
      contract: string;
      expires: number;
    };
    if (claims.expires < Date.now()) return null;
    return { session: new StudioSession(claims.token), ...claims };
  }

  /** Verifies the token against Arc Studio before storing it. */
  static async start(token: string): Promise<StudioSession> {
    const trimmed = token.trim();
    if (!/^origin_pat_[A-Za-z0-9_-]+$/.test(trimmed)) {
      throw new Error("That does not look like an Arc Studio token (expected origin_pat_…).");
    }
    const session = new StudioSession(trimmed);
    try {
      await session.client().listApps();
    } catch {
      throw new Error("Arc Studio rejected that token. Authorize again and paste the new token.");
    }
    (await cookies()).set(COOKIE, StudioSession.#seal("cookie", trimmed), {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: MAX_AGE_SECONDS,
    });
    return session;
  }

  static async end(): Promise<void> {
    (await cookies()).delete(COOKIE);
  }

  client(): StudioClient {
    return new StudioClient(StudioSession.apiUrl, {
      headers: { authorization: `Bearer ${this.token}` },
      source: "injected-token",
    });
  }

  /** The app's sandbox view, reused for APP_TTL_MS; `fresh` re-reads it from Arc Studio. */
  app(appId: string, { fresh = false } = {}): Promise<ArcStudioApp> {
    const key = `${createHash("sha256").update(this.token).digest("base64url")}:${appId}`;
    const now = Date.now();
    const cached = StudioSession.#apps.get(key);
    if (cached && !fresh && cached.expires > now) return cached.app;
    for (const [k, entry] of StudioSession.#apps) if (entry.expires <= now) StudioSession.#apps.delete(k);
    const app = ArcStudioApp.open(this.client(), appId);
    StudioSession.#apps.set(key, { app, expires: now + APP_TTL_MS });
    app.catch(() => StudioSession.#apps.delete(key));
    return app;
  }

  /** Logs how long an Arc Studio-backed step took (never the token or file contents). */
  static async timed<T>(label: string, work: () => Promise<T>): Promise<T> {
    const start = performance.now();
    try {
      return await work();
    } finally {
      console.info(`[arc-studio] ${label} ${Math.round(performance.now() - start)}ms`);
    }
  }
}

import type { SandboxFile, StudioClient } from "@aomi-labs/arc-studio-cli/client";

import { FuzzTarget } from "./fuzz-target.ts";
import type { FuzzCampaignReport } from "./report.ts";

export interface ContractSource {
  /** Workspace path, e.g. `contracts/Vault.sol`. */
  path: string;
  source: string;
  /** Concrete (non-abstract) contracts declared in the file. */
  contracts: string[];
  /** Whether a Foundry artifact exists for every declared contract. */
  built: boolean;
}

/** Raised when a contract has no compiled artifact in the app workspace yet. */
export class MissingBuildError extends Error {
  constructor(readonly sourcePath: string, readonly contract: string) {
    super(
      `No compiled artifact for ${contract} (${sourcePath}). Build the app in Arc Studio, or ask it to run \`forge build\`.`,
    );
    this.name = "MissingBuildError";
  }
}

/**
 * One of the user's Arc Studio apps, seen through its live sandbox workspace
 * (a Vite + Foundry project; Solidity may sit at the root or in a subfolder).
 */
export class ArcStudioApp {
  #files: SandboxFile[] | undefined;
  #contracts: Promise<ContractSource[]> | undefined;

  private constructor(
    readonly client: StudioClient,
    readonly appId: string,
    readonly sandboxId: string,
  ) {}

  static async open(client: StudioClient, appId: string): Promise<ArcStudioApp> {
    const { sandboxId } = await client.getSandbox(appId);
    if (!sandboxId) {
      throw new Error(
        `App ${appId} has no live sandbox. Open it in Arc Studio (or run one turn) to wake it, then retry.`,
      );
    }
    return new ArcStudioApp(client, appId, sandboxId);
  }

  /** A sandbox path as the builder knows it: `/home/user/app/contracts/V.sol` → `contracts/V.sol`. */
  static workspacePath(path: string): string {
    return path.replace(/^\/home\/user\/app\//, "");
  }

  /** Credential-shaped files (same policy as the CLI's --file guard); never read or shown. */
  static isSensitive(path: string): boolean {
    const name = path.split("/").at(-1)?.toLowerCase() ?? "";
    return /^\.env/.test(name) || name === ".npmrc" || /\.(pem|key|p12|pfx|keystore)$/.test(name) || name.startsWith("id_rsa");
  }

  /** Reads one workspace file the sandbox listed, refusing credential-shaped files. */
  async readFile(path: string): Promise<string> {
    if (ArcStudioApp.isSensitive(path)) throw new Error(`${ArcStudioApp.workspacePath(path)} may hold secrets and is not shown.`);
    if (!(await this.files()).some((f) => f.path === path)) throw new Error(`${path} is not in this app's workspace.`);
    return (await this.read([path])).get(path) ?? "";
  }

  /** Reads many listed files in one batch, silently skipping credential files and unlisted paths. */
  async readFiles(paths: string[]): Promise<Map<string, string>> {
    const listed = new Set((await this.files()).map((f) => f.path));
    const wanted = paths.filter((p) => listed.has(p) && !ArcStudioApp.isSensitive(p));
    return wanted.length ? this.read(wanted) : new Map();
  }

  get webUrl(): string {
    return this.client.webUrl(this.appId);
  }

  async files(): Promise<SandboxFile[]> {
    this.#files ??= await this.client.listSandboxFiles(this.sandboxId);
    return this.#files;
  }

  /** Reads workspace files as text; throws on the first file the sandbox could not return. */
  async read(paths: string[]): Promise<Map<string, string>> {
    const out = new Map<string, string>();
    for (const file of await this.client.batchReadFiles(this.sandboxId, paths)) {
      if (file.content === undefined) {
        throw new Error(`Could not read ${file.path}: ${file.error ?? "no content"}`);
      }
      out.set(file.path, file.content);
    }
    return out;
  }

  /**
   * Path of the Foundry artifact for `contract` declared in `sourcePath`, wherever
   * the Foundry project sits (root or a subfolder like `onchain/`).
   */
  async artifactPath(sourcePath: string, contract: string): Promise<string | undefined> {
    const suffix = `/${sourcePath.split("/").at(-1)}/${contract}.json`;
    const matches = (await this.files())
      .map((f) => f.path)
      .filter((p) => p.endsWith(suffix) && !p.includes("node_modules/"));
    return matches.find((p) => /(^|\/)out\//.test(p)) ?? matches[0];
  }

  /** The app's own Solidity files and their contracts; read once per ArcStudioApp. */
  contracts(): Promise<ContractSource[]> {
    this.#contracts ??= this.#scanContracts();
    return this.#contracts;
  }

  async #scanContracts(): Promise<ContractSource[]> {
    const solidity = (await this.files())
      .map((f) => f.path)
      .filter(
        (p) =>
          p.endsWith(".sol") &&
          !/\.(t|s)\.sol$/.test(p) &&
          !/(^|\/)(lib|node_modules|test|tests|script|out|cache|broadcast|context)\//.test(p),
      )
      .sort();
    if (solidity.length === 0) return [];
    const sources = await this.read(solidity);
    const contracts = solidity.map((path) => {
      const source = sources.get(path) ?? "";
      const declared = [
        ...source.matchAll(/^\s*(abstract\s+)?contract\s+(\w+)/gm),
      ]
        .filter((m) => !m[1])
        .map((m) => m[2] as string);
      return { path, source, contracts: declared };
    });
    return Promise.all(
      contracts.map(async (file) => ({
        ...file,
        built:
          file.contracts.length > 0 &&
          (await Promise.all(file.contracts.map((name) => this.artifactPath(file.path, name)))).every(Boolean),
      })),
    );
  }

  /**
   * Loads a contract's Foundry artifact plus its source. Relative imports inside
   * the workspace are inlined (with path headers) so the agent sees the code it
   * is attacking; library dependencies under `lib/` or `node_modules/` are not.
   */
  async target(sourcePath: string, contract: string, chainId?: number): Promise<FuzzTarget> {
    const artifactPath = await this.artifactPath(sourcePath, contract);
    if (!artifactPath) {
      throw new MissingBuildError(sourcePath, contract);
    }
    const artifact = JSON.parse((await this.read([artifactPath])).get(artifactPath) ?? "null");

    const known = new Set((await this.files()).map((f) => f.path));
    const seen = new Map<string, string>();
    let frontier = [sourcePath];
    while (frontier.length > 0) {
      const batch = await this.read(frontier);
      frontier = [];
      for (const [path, text] of batch) {
        seen.set(path, text);
        for (const match of text.matchAll(/^\s*import\s+(?:[^"']*from\s+)?["'](\.{1,2}\/[^"']+)["']/gm)) {
          // Arc Studio lists absolute sandbox paths (/home/user/app/...); keep the caller's form.
          const absolute = path.startsWith("/");
          const pathname = new URL(match[1] as string, `file://${absolute ? "" : "/"}${path}`).pathname;
          const resolved = absolute ? pathname : pathname.slice(1);
          if (known.has(resolved) && !seen.has(resolved) && !frontier.includes(resolved)) {
            frontier.push(resolved);
          }
        }
      }
    }
    const source =
      seen.size === 1
        ? (seen.get(sourcePath) as string)
        : [...seen].map(([path, text]) => `// ==== ${path} ====\n${text}`).join("\n\n");

    return FuzzTarget.fromFoundryArtifact(contract, sourcePath, source, artifact, chainId);
  }

  /** Asks the Arc Studio agent to compile the app so `out/` artifacts exist. */
  async requestBuild(): Promise<{ threadId: string; webUrl: string }> {
    const { threadId } = await this.client.chatDetached({
      appId: this.appId,
      messages: [
        {
          role: "user",
          content:
            "Run `forge build` for this app's contracts and fix any compile errors. Do not change contract behavior or deploy anything.",
        },
      ],
    });
    return { threadId, webUrl: this.webUrl };
  }

  /**
   * Hands verified findings back to the Arc Studio agent as a fix request on a
   * new thread in the same app. Only confirmed findings are sent;
   * unconfirmed violations stay in the report.
   */
  async requestFix(
    target: FuzzTarget,
    report: FuzzCampaignReport,
  ): Promise<{ threadId: string; webUrl: string }> {
    const findings = report.findings;
    if (findings.length === 0) {
      throw new Error("The campaign has no reproduced findings to fix.");
    }
    const described = findings
      .map((finding, index) => {
        const steps = finding.minimized_trace
          .map(
            (call, step) =>
              `   ${step + 1}. ${call.actor} calls ${call.function}` +
              (call.arguments.length ? ` with (${call.arguments.join(", ")})` : "") +
              (call.value !== "0" ? `, sending ${call.value} wei of native USDC` : ""),
          )
          .join("\n");
        return `${index + 1}. Property violated: ${finding.property}\n   Minimized reproduction (replayed twice on a held Arc fork):\n${steps}`;
      })
      .join("\n\n");
    const { threadId } = await this.client.chatDetached({
      appId: this.appId,
      messages: [
        {
          role: "user",
          content: `Aomi's stateful fuzzer found ${findings.length === 1 ? "a verified vulnerability" : `${findings.length} verified vulnerabilities`} in ${target.name} (${target.sourcePath}).

${described}

Fix ${target.sourcePath} so each sequence above can no longer violate its property. Keep the public ABI unless a signature change is required for the fix, and explain any such change. Then run \`forge build\` so the artifacts are current. Do not deploy.

Campaign ${report.campaign_id}: ${report.executions} executions over ${report.round} rounds.`,
        },
      ],
    });
    return { threadId, webUrl: this.webUrl };
  }
}

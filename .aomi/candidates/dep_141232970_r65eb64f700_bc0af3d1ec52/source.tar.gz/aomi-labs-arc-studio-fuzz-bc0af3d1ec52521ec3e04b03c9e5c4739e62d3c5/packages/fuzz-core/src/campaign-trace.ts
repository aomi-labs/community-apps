import type { Event } from "@aomi-labs/client";

import type { FuzzCampaignReport } from "./report.ts";

/** One raw ledger event with a one-line description, for an "all events" view. */
export interface LedgerEntry {
  key: string;
  sequence: number;
  type: string;
  label: string;
  event: Event;
}

export interface TraceRow {
  key: string;
  sequence: number;
  /** Tool name without namespace, e.g. `arc_fuzz_round`, `sim_replay_traces`. */
  name: string;
  state: "calling" | "complete" | "failed";
  arguments?: unknown;
  result?: unknown;
}

type RecordValue = Record<string, unknown>;

function record(value: unknown): RecordValue | undefined {
  if (!value || typeof value !== "object" || Array.isArray(value)) return;
  return value as RecordValue;
}

/** Tool results arrive as JSON text, possibly wrapped in MCP `content` blocks. */
function decode(value: unknown): unknown {
  if (typeof value === "string") {
    try {
      return decode(JSON.parse(value));
    } catch {
      return value;
    }
  }
  const object = record(value);
  const content = object?.content;
  if (Array.isArray(content)) {
    const text = content
      .map((item) => record(item)?.text)
      .find((item): item is string => typeof item === "string");
    if (text) return decode(text);
  }
  return object ?? value;
}

/**
 * The fuzz campaign as seen through an Aomi session's event ledger: the
 * `arc_*` / `sim_*` tool calls in order, and the latest campaign report.
 */
export class CampaignTrace {
  readonly rows: TraceRow[];
  /** Every event in order, tool calls or not. */
  readonly ledger: LedgerEntry[];
  readonly report: FuzzCampaignReport | null;
  /** Turn-level errors the backend reported (why a turn ended "failed"). */
  readonly errors: string[];
  /**
   * The latest turn stopped at the runtime's per-turn model-call limit
   * (execution_limit_reached). Campaign state and the sim world persist, so
   * sending another message resumes the campaign.
   */
  readonly resumable: boolean;

  /** Message that resumes a campaign after an execution-limit stop. */
  static readonly CONTINUE_PROMPT =
    "Continue the fuzz campaign exactly where it stopped: keep feeding each sim_replay_traces result to arc_fuzz_round, then finish minimization, the two reproductions, and the report.";

  constructor(events: readonly Event[]) {
    const ordered = [...events].sort((a, b) => a.sequence - b.sequence);
    const rows = new Map<string, TraceRow>();
    let report: FuzzCampaignReport | null = null;
    const errors: string[] = [];
    let lastNotice = "";
    const ledger: LedgerEntry[] = [];

    for (const event of ordered) {
      const raw = event as unknown as Record<string, unknown>;
      const text = (value: unknown) => String(value ?? "").replace(/\s+/g, " ").slice(0, 140);
      ledger.push({
        key: `${ledger.length}:${event.sequence}:${event.type}`,
        sequence: event.sequence,
        type: event.type,
        label:
          event.type === "message"
            ? event.tool_name
              ? `${event.tool_name.split("::").at(-1)} ${event.tool_result ? "result" : "call"}`
              : `${event.sender}: ${text(event.content)}`
            : event.type === "error"
              ? text(event.message)
              : event.type === "tool_update" || event.type === "tool_complete"
                ? event.tool_name.split("::").at(-1) ?? ""
                : text(raw.state ?? raw.title ?? raw.phase ?? raw.status ?? ""),
        event,
      });
      if (event.type === "error") {
        errors.push(event.message);
        lastNotice = event.message;
        continue;
      }
      if (event.type === "message" && !event.tool_name && event.sender !== "user") {
        lastNotice = event.content;
      } else if (event.type === "message" && event.sender === "user") {
        lastNotice = "";
      }
      let name: string | undefined;
      let result: unknown;
      if (event.type === "tool_update" || event.type === "tool_complete") {
        name = event.tool_name.split("::").at(-1);
        result = decode(event.result);
      } else if (event.type === "message" && event.tool_name) {
        name = event.tool_name.split("::").at(-1);
        result = event.tool_result ? decode(event.tool_result[1]) : undefined;
      }
      if (!name || (!name.startsWith("arc_") && !name.startsWith("sim_"))) continue;

      const callId =
        event.type === "tool_update" || event.type === "tool_complete"
          ? (event.call_id ?? event.id)
          : event.type === "message"
            ? (event.tool_call_id ?? `${event.turn_id}:${name}:${event.sequence}`)
            : `${event.sequence}`;
      const key = `${event.turn_id ?? "turn"}:${callId}`;
      const previous = rows.get(key);
      const object = record(result);
      rows.set(key, {
        key,
        sequence: event.sequence,
        name,
        state:
          object?.is_error === true || object?.error
            ? "failed"
            : result !== undefined
              ? "complete"
              : "calling",
        arguments: event.type === "message" ? event.tool_arguments : previous?.arguments,
        result: result ?? previous?.result,
      });

      if (name.startsWith("arc_fuzz_")) {
        const candidate = record(object?.report) ?? object;
        if (typeof candidate?.campaign_id === "string" && Array.isArray(candidate.findings)) {
          report = candidate as unknown as FuzzCampaignReport;
        }
      }
    }

    this.rows = [...rows.values()].sort((a, b) => a.sequence - b.sequence);
    this.report = report;
    this.errors = errors;
    this.ledger = ledger;
    this.resumable = /execution_limit_reached|reached its execution limit/i.test(lastNotice);
  }

  /** The first finding; every finding was reproduced twice. */
  get finding() {
    return this.report?.findings[0];
  }
}

//! Confirmed receipts and wallet-local ERC-20 deltas. Pool events are not
//! wallet settlement. Native input needs a complete execution trace because
//! an event's declared fromAmount does not account for ETH refunds.
use super::Chain;
use crate::runtime::{Cost, Fail, Request, Source};
use num_bigint::{BigInt, BigUint};
use num_traits::{Signed, ToPrimitive, Zero};
use serde::Deserialize;
use serde_json::{Value, json};
use std::collections::BTreeMap;
use std::time::Duration;

const TRANSFER: &str = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef";
const APPROVAL: &str = "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925";
const LIFI_COMPLETED: &str = "0x38eee76fd911eabac79da7af16053e809be0e12c8637f156e77e1af309b99537";
const LIFI: &str = "0xb477751b76cf82d00a686a1232f5fcd772414af3";
const TTL: Duration = Duration::from_secs(24 * 3600);

#[derive(Clone, Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Receipt {
    pub transaction_hash: String,
    pub block_number: String,
    pub transaction_index: String,
    pub status: String,
    pub from: String,
    pub to: Option<String>,
    pub gas_used: String,
    pub effective_gas_price: String,
    pub logs: Vec<Log>,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Log {
    pub address: String,
    pub topics: Vec<String>,
    pub data: String,
    #[serde(default)]
    pub transaction_hash: String,
    #[serde(default)]
    pub block_number: String,
    #[serde(default)]
    pub transaction_index: String,
    #[serde(default)]
    pub removed: bool,
}

#[derive(Debug, Deserialize)]
pub struct Transaction {
    pub hash: String,
    pub from: String,
    pub to: Option<String>,
    pub value: String,
    pub nonce: String,
    pub input: String,
}

impl Chain<'_> {
    pub async fn receipt(self, tx: &str) -> Result<Receipt, Fail> {
        let value = self
            .read("receipt", tx, "eth_getTransactionReceipt", json!([tx]))
            .await?;
        let receipt: Receipt = crate::providers::parse(Source::Chain, value)?;
        if !receipt.transaction_hash.eq_ignore_ascii_case(tx) || receipt.status != "0x1" {
            return Err(Fail::NoData(
                "trade receipt is not a successful confirmed transaction".into(),
            ));
        }
        Ok(receipt)
    }

    pub async fn transaction(self, tx: &str) -> Result<Transaction, Fail> {
        let value = self
            .read("transaction", tx, "eth_getTransactionByHash", json!([tx]))
            .await?;
        let transaction: Transaction = crate::providers::parse(Source::Chain, value)?;
        if !transaction.hash.eq_ignore_ascii_case(tx) {
            return Err(bad("transaction hash mismatch"));
        }
        Ok(transaction)
    }

    async fn read(self, kind: &str, tx: &str, method: &str, params: Value) -> Result<Value, Fail> {
        let request =
            Request::new(Source::Chain, format!("chain:{kind}:{tx}"), Cost::Free, TTL).live_only();
        self.rt
            .fetch(self.turn, request, || self.rpc(method, params))
            .await
    }

    /// Only a distinct approve transaction immediately preceding this swap
    /// in the sender's nonce sequence can be charged to this trade. Older or
    /// unrelated approvals are not silently attributed to the round.
    pub async fn approval(
        self,
        swap: &Receipt,
        tx: &Transaction,
        token: &str,
    ) -> Result<Option<Receipt>, Fail> {
        let Some(spender) = &tx.to else {
            return Ok(None);
        };
        let block = hex_u64(&swap.block_number)?;
        let owner_topic = format!("0x{:0>64}", tx.from.trim_start_matches("0x"));
        let spender_topic = format!("0x{:0>64}", spender.trim_start_matches("0x"));
        let params = json!([{"address":token,"fromBlock":format!("0x{:x}", block.saturating_sub(1200)),"toBlock":swap.block_number,"topics":[APPROVAL,owner_topic,spender_topic]}]);
        let value = self
            .read(
                "approvals",
                &format!("{}:{token}", swap.transaction_hash),
                "eth_getLogs",
                params,
            )
            .await?;
        let logs: Vec<Log> = crate::providers::parse(Source::Chain, value)?;
        let mut candidates: Vec<_> = logs
            .iter()
            .filter(|log| {
                !log.removed
                    && log.address.eq_ignore_ascii_case(token)
                    && log.topics.first().is_some_and(|t| t == APPROVAL)
                    && log.topics.get(1) == Some(&owner_topic)
                    && log.topics.get(2) == Some(&spender_topic)
                    && log.transaction_hash != swap.transaction_hash
                    && position(log)
                        .is_some_and(|p| p < (block, hex_u64(&swap.transaction_index).unwrap_or(0)))
            })
            .collect();
        candidates.sort_by_key(|log| position(log));
        let Some(log) = candidates.last() else {
            return Ok(None);
        };
        let previous = self.transaction(&log.transaction_hash).await?;
        if !previous.from.eq_ignore_ascii_case(&tx.from)
            || !previous
                .to
                .as_ref()
                .is_some_and(|to| to.eq_ignore_ascii_case(token))
            || hex_u64(&previous.nonce)?.checked_add(1) != Some(hex_u64(&tx.nonce)?)
            || !previous.input.starts_with("0x095ea7b3")
            || previous.input.len() != 138
            || !previous.input[2..].bytes().all(|b| b.is_ascii_hexdigit())
            || !previous.input[34..74].eq_ignore_ascii_case(spender.trim_start_matches("0x"))
            || !raw(&previous.value)?.is_zero()
        {
            return Ok(None);
        }
        let receipt = self.receipt(&previous.hash).await?;
        if !receipt.deltas(&tx.from)?.is_empty() {
            return Ok(None);
        }
        Ok(Some(receipt))
    }
}

fn position(log: &Log) -> Option<(u64, u64)> {
    Some((
        hex_u64(&log.block_number).ok()?,
        hex_u64(&log.transaction_index).ok()?,
    ))
}

impl Receipt {
    pub fn gas_eth(&self, wallet: &str) -> Result<f64, Fail> {
        if !self.from.eq_ignore_ascii_case(wallet) {
            return Ok(0.0);
        }
        scaled(
            &(raw(&self.gas_used)? * raw(&self.effective_gas_price)?),
            18,
        )
    }

    pub fn position(&self) -> Result<(u64, u64), Fail> {
        Ok((
            hex_u64(&self.block_number)?,
            hex_u64(&self.transaction_index)?,
        ))
    }

    pub fn deltas(&self, wallet: &str) -> Result<BTreeMap<String, BigInt>, Fail> {
        let mut deltas: BTreeMap<String, BigInt> = BTreeMap::new();
        for log in self.logs.iter().filter(|log| !log.removed) {
            if let Some((asset, amount)) = transfer(log, wallet)? {
                *deltas.entry(asset).or_default() += amount;
            }
        }
        deltas.retain(|_, amount| !amount.is_zero());
        Ok(deltas)
    }

    /// The wallet's trades of `token`, in log order. Each official LI.FI
    /// completion event closes one swap: the wallet transfers since the
    /// previous one must be exactly its from/to assets, and its receiver
    /// the wallet, or the swap is rejected as ambiguous. Amounts come from
    /// the transfers; the event only draws the boundary, except a native
    /// payout, which has no transfer log. Without completion events the
    /// whole transaction is one trade.
    pub fn trades(&self, wallet: &str, token: &str) -> Result<Vec<Trade>, Fail> {
        let swaps = self.logs.iter().filter(|log| completed(log)).count();
        let mut trades = vec![];
        let mut window: BTreeMap<String, BigInt> = BTreeMap::new();
        for log in self.logs.iter().filter(|log| !log.removed) {
            if let Some((asset, amount)) = transfer(log, wallet)? {
                *window.entry(asset).or_default() += amount;
                continue;
            }
            if !completed(log) {
                continue;
            }
            let swap = Completed::parse(log)?;
            let mut legs = std::mem::take(&mut window);
            legs.retain(|_, amount| !amount.is_zero());
            if !legs.contains_key(token) && swap.from != token && swap.to != token {
                continue;
            }
            if !swap.receiver.eq_ignore_ascii_case(wallet)
                || legs
                    .keys()
                    .any(|asset| *asset != swap.from && *asset != swap.to)
            {
                return Err(bad(
                    "a swap's wallet transfers do not match its LI.FI event",
                ));
            }
            if swap.to == crate::providers::NATIVE {
                legs.insert(swap.to.clone(), BigInt::from(swap.to_amount));
            }
            let quantity = legs.remove(token).unwrap_or_default();
            if quantity.is_zero() || quantity.is_positive() != (swap.to == token) {
                return Err(bad(
                    "a swap's wallet transfers do not match its LI.FI event",
                ));
            }
            trades.push(Trade {
                quantity,
                against: legs,
                native_input: swap.from == crate::providers::NATIVE,
                lifi: true,
                shared: swaps > 1,
            });
        }
        window.retain(|_, amount| !amount.is_zero());
        if let Some(quantity) = window.remove(token) {
            if swaps > 0 {
                return Err(bad(
                    "wallet transfers of this coin fall outside its LI.FI swaps",
                ));
            }
            trades.push(Trade {
                quantity,
                against: window,
                native_input: false,
                lifi: false,
                shared: false,
            });
        }
        Ok(trades)
    }
}

/// One trade of a coin inside a receipt.
#[derive(Debug)]
pub struct Trade {
    /// Signed wallet change of the coin: positive is a buy.
    pub quantity: BigInt,
    /// Signed wallet change of each asset it settled against. Native ETH
    /// appears only as a LI.FI payout.
    pub against: BTreeMap<String, BigInt>,
    /// Paid in native ETH; the spend needs an execution trace.
    pub native_input: bool,
    /// Bounded by a LI.FI completion event.
    pub lifi: bool,
    /// Other swaps share this transaction.
    pub shared: bool,
}

/// `LiFiGenericSwapCompleted(bytes32 indexed transactionId, string
/// integrator, string referrer, address receiver, address fromAssetId,
/// address toAssetId, uint256 fromAmount, uint256 toAmount)`. The declared
/// fromAmount is ignored: it can be caller-declared and refunded.
struct Completed {
    receiver: String,
    from: String,
    to: String,
    to_amount: BigUint,
}

impl Completed {
    fn parse(log: &Log) -> Result<Self, Fail> {
        let words: Vec<_> = log
            .data
            .strip_prefix("0x")
            .ok_or_else(|| bad("malformed swap event"))?
            .as_bytes()
            .chunks(64)
            .collect();
        if words.len() < 7 {
            return Err(bad("malformed swap event"));
        }
        let word =
            |i: usize| std::str::from_utf8(words[i]).map_err(|_| bad("malformed swap event"));
        Ok(Self {
            receiver: address_word(word(2)?)?,
            from: address_word(word(3)?)?,
            to: address_word(word(4)?)?,
            to_amount: raw(word(6)?)?,
        })
    }
}

fn completed(log: &Log) -> bool {
    !log.removed
        && log.address.eq_ignore_ascii_case(LIFI)
        && log.topics.first().is_some_and(|t| t == LIFI_COMPLETED)
}

/// The wallet's signed change from one ERC-20 Transfer log, if it is one.
fn transfer(log: &Log, wallet: &str) -> Result<Option<(String, BigInt)>, Fail> {
    if log.topics.len() != 3 || log.topics[0] != TRANSFER {
        return Ok(None);
    }
    let from = address_word(&log.topics[1])?;
    let to = address_word(&log.topics[2])?;
    if !from.eq_ignore_ascii_case(wallet) && !to.eq_ignore_ascii_case(wallet) {
        return Ok(None);
    }
    if log.data.len() != 66 {
        return Err(bad("malformed wallet transfer"));
    }
    let amount = BigInt::from(raw(&log.data)?);
    let mut delta = BigInt::zero();
    if from.eq_ignore_ascii_case(wallet) {
        delta -= &amount;
    }
    if to.eq_ignore_ascii_case(wallet) {
        delta += amount;
    }
    Ok(Some((log.address.to_lowercase(), delta)))
}

pub fn raw(hex: &str) -> Result<BigUint, Fail> {
    let value = hex.strip_prefix("0x").unwrap_or(hex);
    if value.is_empty() || value.len() > 64 {
        return Err(bad("invalid EVM quantity"));
    }
    BigUint::parse_bytes(value.as_bytes(), 16).ok_or_else(|| bad("invalid EVM quantity"))
}

pub fn scaled(amount: &BigUint, decimals: u8) -> Result<f64, Fail> {
    let value = amount
        .to_f64()
        .ok_or_else(|| bad("amount exceeds numeric range"))?
        / 10f64.powi(i32::from(decimals));
    if value.is_finite() {
        Ok(value)
    } else {
        Err(bad("amount exceeds numeric range"))
    }
}

fn hex_u64(value: &str) -> Result<u64, Fail> {
    raw(value)?
        .to_u64()
        .ok_or_else(|| bad("EVM index exceeds numeric range"))
}

fn address_word(value: &str) -> Result<String, Fail> {
    let word = value.strip_prefix("0x").unwrap_or(value);
    if word.len() != 64
        || !word.bytes().all(|b| b.is_ascii_hexdigit())
        || !word[..24].bytes().all(|b| b == b'0')
    {
        return Err(bad("invalid address in receipt"));
    }
    Ok(format!("0x{}", &word[24..]).to_lowercase())
}

fn bad(message: &str) -> Fail {
    Fail::bad(Source::Chain, message)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::providers::NATIVE;
    const WALLET: &str = "0x1111111111111111111111111111111111111111";
    const POOL: &str = "0x9999999999999999999999999999999999999999";
    const COIN: &str = "0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
    const OTHER: &str = "0xbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";
    const USDG: &str = "0x5fc5360d0400a0fd4f2af552add042d716f1d168";

    fn word(a: &str) -> String {
        format!("{:0>64}", a.trim_start_matches("0x"))
    }

    fn moved(asset: &str, from: &str, to: &str, amount: u128) -> Value {
        json!({"address":asset,"topics":[TRANSFER,format!("0x{}",word(from)),format!("0x{}",word(to))],"data":format!("0x{amount:064x}")})
    }

    fn done(emitter: &str, receiver: &str, from: &str, to: &str, to_amount: u128) -> Value {
        let data = [
            word("e0"),
            word("120"),
            word(receiver),
            word(from),
            word(to),
            word("ffff"),
            format!("{to_amount:064x}"),
        ]
        .concat();
        json!({"address":emitter,"topics":[LIFI_COMPLETED,"0x01"],"data":format!("0x{data}")})
    }

    fn receipt(logs: Vec<Value>) -> Receipt {
        serde_json::from_value(json!({
            "transactionHash":"0xtest","blockNumber":"0x1","transactionIndex":"0x0","status":"0x1",
            "from":POOL,"to":POOL,"gasUsed":"0x5208","effectiveGasPrice":"0x1","logs":logs
        }))
        .unwrap()
    }

    /// Sell COIN for USDG, then spend part of it on OTHER, in one transaction.
    fn batch() -> Vec<Value> {
        vec![
            moved(COIN, WALLET, POOL, 500),
            moved(USDG, POOL, WALLET, 16_506_952),
            done(LIFI, WALLET, COIN, USDG, 1),
            moved(USDG, WALLET, POOL, 10_000_000),
            moved(OTHER, POOL, WALLET, 77),
            done(LIFI, WALLET, USDG, OTHER, 1),
        ]
    }

    #[test]
    fn each_swap_keeps_its_own_wallet_consideration() {
        let r = receipt(batch());
        let sold = r.trades(WALLET, COIN).unwrap();
        assert_eq!(sold.len(), 1);
        assert_eq!(sold[0].quantity, BigInt::from(-500));
        assert_eq!(
            sold[0].against,
            BTreeMap::from([(USDG.into(), BigInt::from(16_506_952))])
        );
        assert!(sold[0].shared);
        let bought = r.trades(WALLET, OTHER).unwrap();
        assert_eq!(
            bought[0].against,
            BTreeMap::from([(USDG.into(), BigInt::from(-10_000_000))])
        );
        assert_eq!(r.deltas(WALLET).unwrap()[USDG], BigInt::from(6_506_952));
    }

    #[test]
    fn unbounded_receipts_are_one_trade_and_split_fills_sum() {
        let r = receipt(vec![
            moved(USDG, WALLET, POOL, 3),
            moved(COIN, POOL, WALLET, 40),
            moved(COIN, POOL, WALLET, 60),
            moved(USDG, POOL, WALLET, 1),
        ]);
        let t = r.trades(WALLET, COIN).unwrap();
        assert_eq!(
            (t.len(), t[0].quantity.clone(), t[0].lifi),
            (1, BigInt::from(100), false)
        );
        assert_eq!(t[0].against[USDG], BigInt::from(-2));
    }

    #[test]
    fn untrusted_or_mismatched_events_never_attribute_transfers() {
        // A forged event is not a boundary, so both swaps merge and the
        // real event no longer matches the transfers.
        let mut forged = batch();
        forged[2] = done(POOL, WALLET, COIN, USDG, 1);
        assert!(receipt(forged.clone()).trades(WALLET, COIN).is_err());
        let mut elsewhere = batch();
        elsewhere[2] = done(LIFI, POOL, COIN, USDG, 1);
        assert!(receipt(elsewhere).trades(WALLET, COIN).is_err());
        let mut extra = batch();
        extra.insert(1, moved(OTHER, POOL, WALLET, 5));
        assert!(receipt(extra).trades(WALLET, COIN).is_err());
        let mut trailing = batch();
        trailing.push(moved(COIN, WALLET, POOL, 1));
        assert!(receipt(trailing).trades(WALLET, COIN).is_err());
        let mut removed = receipt(batch());
        removed.logs[5].removed = true;
        assert!(removed.trades(WALLET, OTHER).is_err());
    }

    #[test]
    fn native_payout_comes_from_the_official_router_event() {
        let r = receipt(vec![
            moved(COIN, WALLET, POOL, 9),
            done(LIFI, WALLET, COIN, NATIVE, 0x1234),
        ]);
        let t = r.trades(WALLET, COIN).unwrap();
        assert_eq!(t[0].against[NATIVE], BigInt::from(0x1234));
        let r = receipt(vec![
            moved(COIN, POOL, WALLET, 9),
            done(LIFI, WALLET, NATIVE, COIN, 9),
        ]);
        let t = r.trades(WALLET, COIN).unwrap();
        assert!(t[0].native_input && t[0].against.is_empty());
        assert_eq!(r.gas_eth(WALLET).unwrap(), 0.0);
    }

    #[test]
    fn malformed_receipt_words_fail_without_panicking() {
        assert!(address_word(&format!("{}é{}", "0".repeat(23), "0".repeat(39))).is_err());
        let mut r = receipt(batch());
        r.logs[2].data = "0x1234".into();
        assert!(r.trades(WALLET, COIN).is_err());
    }
}

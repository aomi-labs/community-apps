//! Reconcile each distinct fill transaction once, split into its swaps, so
//! another swap in the same transaction never becomes this coin's cash.
//! Wallet legs already include route fees and refunds. GMGN supplies the
//! history, never cash proceeds. Money stays exact until the card.
use crate::providers::{
    NATIVE, WETH,
    chain::{
        Chain,
        receipts::{Receipt, Trade, raw},
    },
    gmgn::types::Activity,
};
use crate::runtime::{Fail, Turn};
use num_bigint::{BigInt, BigUint};
use num_rational::BigRational;
use num_traits::{Signed, ToPrimitive, Zero};
use std::collections::BTreeSet;

pub const USDG: &str = "0x5fc5360d0400a0fd4f2af552add042d716f1d168";
const MAX_TRANSACTIONS: usize = 24;

pub struct Settlement {
    /// Total wallet spend on buys.
    pub cost: Option<f64>,
    /// Net sale proceeds.
    pub out: f64,
    /// Moving-average basis released by sales, and left on unsold coins.
    pub basis_sold: Option<f64>,
    pub basis_left: Option<f64>,
    pub bought: BigUint,
    pub sold: BigUint,
    pub gas_eth: f64,
    pub gas_transactions: u32,
    pub estimated_fx: bool,
}

/// One buy or sell in chain order: (block, transaction index, swap).
struct Op {
    at: (u64, u64, usize),
    buy: bool,
    quantity: BigUint,
    /// Signed wallet cash flow in USD; None when it cannot be priced.
    cash: Option<BigRational>,
}

pub async fn read(
    chain: Chain<'_>,
    turn: &Turn,
    wallet: &str,
    token: &str,
    rows: &[Activity],
) -> Result<Settlement, Fail> {
    // One entry per transaction, oldest first. A transaction can hold
    // several swaps, including a buy and a sell of this coin.
    let mut trades: Vec<(String, Vec<&Activity>)> = vec![];
    for row in rows
        .iter()
        .filter(|r| matches!(r.event_type.as_str(), "buy" | "sell"))
    {
        let hash = row.tx_hash.to_lowercase();
        if hash.len() != 66
            || !hash.starts_with("0x")
            || !hash[2..].bytes().all(|b| b.is_ascii_hexdigit())
        {
            return Err(Fail::NoData(
                "trade history has an invalid transaction hash".into(),
            ));
        }
        match trades.iter_mut().find(|(h, _)| *h == hash) {
            Some((_, rows)) => rows.push(row),
            None => trades.push((hash, vec![row])),
        }
    }
    if trades.len() > MAX_TRANSACTIONS {
        return Err(Fail::NoData(
            "this round has too many transactions to reconcile in one card".into(),
        ));
    }
    let mut settlement = Settlement {
        cost: None,
        out: 0.0,
        basis_sold: None,
        basis_left: None,
        bought: BigUint::zero(),
        sold: BigUint::zero(),
        gas_eth: 0.0,
        gas_transactions: 0,
        estimated_fx: false,
    };
    let mut ops = vec![];
    let mut gas_seen = BTreeSet::new();
    for (hash, rows) in &trades {
        let (receipt, transaction) =
            tokio::try_join!(chain.receipt(hash), chain.transaction(hash))?;
        let found = receipt.trades(wallet, token)?;
        if found.is_empty() {
            return Err(Fail::NoData(
                "indexed trade has no wallet transfer of this token".into(),
            ));
        }
        for buy in [true, false] {
            let indexed = rows.iter().any(|r| (r.event_type == "buy") == buy);
            if indexed != found.iter().any(|t| t.quantity.is_positive() == buy) {
                return Err(Fail::NoData(
                    "indexed trade direction disagrees with the wallet receipt".into(),
                ));
            }
        }
        let (block, index) = receipt.position()?;
        for (n, trade) in found.iter().enumerate() {
            let buy = trade.quantity.is_positive();
            let row = rows
                .iter()
                .find(|r| (r.event_type == "buy") == buy)
                .expect("direction checked above");
            let native_input =
                trade.native_input || (!trade.lifi && !raw(&transaction.value)?.is_zero());
            let native = if !native_input {
                Ok(None)
            } else if trade.shared {
                Err("native ETH spend is shared with another swap in this transaction".into())
            } else {
                chain
                    .native_delta(&transaction, wallet)
                    .await
                    .map(Some)
                    .map_err(|fail| fail.message())
            };
            let cash = match &native {
                Ok(native) => cashflow(trade, native.as_ref(), row, &mut settlement.estimated_fx)?,
                Err(reason) => {
                    turn.gap(format!("native ETH spend/refund reconciliation unavailable ({reason}); cost basis is unavailable"));
                    None
                }
            };
            if buy && native.is_ok() && cash.as_ref().is_none_or(|c| !c.is_negative()) {
                turn.gap(
                    "one buy's final wallet spend cannot be priced; cost basis is unavailable",
                );
            }
            ops.push(Op {
                at: (block, index, n),
                buy,
                quantity: trade.quantity.magnitude().clone(),
                cash,
            });
        }
        add_gas(&mut settlement, &mut gas_seen, &receipt, wallet)?;
        if transaction.from.eq_ignore_ascii_case(wallet) {
            let spent: Vec<_> = receipt
                .deltas(wallet)?
                .into_iter()
                .filter(|(_, amount)| amount.is_negative())
                .collect();
            for (input, _) in spent {
                match chain.approval(&receipt, &transaction, &input).await {
                    Ok(Some(approval)) => add_gas(&mut settlement, &mut gas_seen, &approval, wallet)?,
                    Ok(None) => {},
                    Err(fail) => turn.gap(format!("approval gas lookup unavailable ({}); gas includes only verified transactions", fail.code())),
                }
            }
        }
    }
    // Stable: same-position records keep their history order.
    ops.sort_by_key(|op| op.at);
    account(&ops, &mut settlement)?;
    Ok(settlement)
}

/// Moving weighted-average cost. A sale releases its share of the
/// remaining basis; selling more than the history bought leaves basis
/// unknown rather than inventing a zero cost.
fn account(ops: &[Op], s: &mut Settlement) -> Result<(), Fail> {
    let zero = || Some(BigRational::zero());
    let (mut cost, mut basis, mut basis_sold) = (zero(), zero(), zero());
    let mut proceeds = BigRational::zero();
    let mut held = BigUint::zero();
    for op in ops {
        if op.buy {
            let spend = op.cash.as_ref().filter(|c| c.is_negative()).map(|c| -c);
            cost = cost.zip(spend.clone()).map(|(a, b)| a + b);
            basis = basis.zip(spend).map(|(a, b)| a + b);
            held += &op.quantity;
            s.bought += &op.quantity;
            continue;
        }
        let Some(cash) = op.cash.as_ref().filter(|c| !c.is_negative()) else {
            return Err(Fail::NoData(
                "final wallet sale proceeds are unavailable; no pool-leg estimate was substituted"
                    .into(),
            ));
        };
        proceeds += cash;
        s.sold += &op.quantity;
        if op.quantity > held {
            (basis, basis_sold, held) = (None, None, BigUint::zero());
            continue;
        }
        let share = BigRational::new(op.quantity.clone().into(), held.clone().into());
        let removed = basis.as_ref().map(|b| b * share);
        basis_sold = basis_sold.zip(removed.clone()).map(|(a, b)| a + b);
        basis = basis.zip(removed).map(|(a, b)| a - b);
        held -= &op.quantity;
    }
    let float = |v: &BigRational| v.to_f64().filter(|f| f.is_finite());
    s.out = float(&proceeds)
        .ok_or_else(|| Fail::NoData("sale proceeds exceed numeric range".into()))?;
    s.cost = cost.as_ref().and_then(float);
    s.basis_sold = basis_sold.as_ref().and_then(float);
    s.basis_left = basis.as_ref().and_then(float);
    Ok(())
}

fn add_gas(
    settlement: &mut Settlement,
    seen: &mut BTreeSet<String>,
    receipt: &Receipt,
    wallet: &str,
) -> Result<(), Fail> {
    if receipt.from.eq_ignore_ascii_case(wallet)
        && seen.insert(receipt.transaction_hash.to_lowercase())
    {
        settlement.gas_eth += receipt.gas_eth(wallet)?;
        settlement.gas_transactions += 1;
    }
    Ok(())
}

/// The trade's signed USD cash flow from its own wallet legs. USDG is $1;
/// ETH uses the indexed trade's implied rate and is marked estimated.
fn cashflow(
    trade: &Trade,
    native: Option<&BigInt>,
    row: &Activity,
    estimated: &mut bool,
) -> Result<Option<BigRational>, Fail> {
    let legs = trade
        .against
        .iter()
        .map(|(asset, amount)| (asset.as_str(), amount))
        .chain(native.map(|amount| (NATIVE, amount)));
    let mut total = BigRational::zero();
    let mut found = false;
    for (asset, amount) in legs {
        let units =
            |decimals: u32| BigRational::new(amount.clone(), BigInt::from(10u32).pow(decimals));
        total += if asset == USDG {
            units(6)
        } else if asset == WETH || asset == NATIVE {
            let Some(fx) = eth_usd(row).and_then(BigRational::from_float) else {
                return Ok(None);
            };
            *estimated = true;
            units(18) * fx
        } else {
            return Ok(None);
        };
        found = true;
    }
    // Zero proceeds is valid only when the wallet's settlement proves it;
    // absent transfer events cannot establish a worthless final payout.
    Ok(found.then_some(total))
}

fn eth_usd(row: &Activity) -> Option<f64> {
    let quote = row.quote_address.as_deref()?;
    if !quote.eq_ignore_ascii_case(NATIVE) && !quote.eq_ignore_ascii_case(WETH) {
        return None;
    }
    let amount = row.quote_amount.get().filter(|v| *v > 0.0)?;
    let fx = row.cost_usd.get()? / amount;
    (fx.is_finite() && fx > 0.0).then_some(fx)
}

pub fn token_amount(raw: &BigUint, decimals: Option<u8>) -> Option<f64> {
    let amount = raw.to_f64()? / 10f64.powi(i32::from(decimals?));
    (amount.is_finite() && amount > 0.0).then_some(amount)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn op(at: u64, buy: bool, quantity: u32, cash: i64) -> Op {
        Op {
            at: (at, 0, 0),
            buy,
            quantity: quantity.into(),
            cash: Some(BigRational::from_integer(cash.into())),
        }
    }

    fn run(ops: &[Op]) -> Settlement {
        let mut s = Settlement {
            cost: None,
            out: 0.0,
            basis_sold: None,
            basis_left: None,
            bought: BigUint::zero(),
            sold: BigUint::zero(),
            gas_eth: 0.0,
            gas_transactions: 0,
            estimated_fx: false,
        };
        account(ops, &mut s).unwrap();
        s
    }

    #[test]
    fn partial_sale_releases_only_the_sold_share_of_basis() {
        // Buy 100 for 20, sell 40 for 12: basis sold 8, realized 4, 12 left.
        let s = run(&[op(1, true, 100, -20), op(2, false, 40, 12)]);
        assert_eq!((s.cost, s.out), (Some(20.0), 12.0));
        assert_eq!((s.basis_sold, s.basis_left), (Some(8.0), Some(12.0)));
    }

    #[test]
    fn moving_average_follows_chain_order() {
        // 100 @ 0.10, 100 @ 0.30, sell 100 (basis 20), rebuy 100 @ 0.50.
        let s = run(&[
            op(1, true, 100, -10),
            op(2, true, 100, -30),
            op(3, false, 100, 25),
            op(4, true, 100, -50),
        ]);
        assert_eq!(
            (s.cost, s.basis_sold, s.basis_left),
            (Some(90.0), Some(20.0), Some(70.0))
        );
        // Selling before the rebuy is a different result than after it.
        let s = run(&[
            op(1, true, 100, -10),
            op(2, false, 100, 25),
            op(3, true, 100, -50),
        ]);
        assert_eq!((s.basis_sold, s.basis_left), (Some(10.0), Some(50.0)));
    }

    #[test]
    fn unknown_inventory_and_unpriced_buys_keep_basis_unknown() {
        let s = run(&[op(1, true, 100, -10), op(2, false, 150, 30)]);
        assert_eq!((s.out, s.basis_sold, s.basis_left), (30.0, None, None));
        let mut unpriced = op(1, true, 100, 0);
        unpriced.cash = None;
        let s = run(&[unpriced, op(2, false, 50, 30)]);
        assert_eq!((s.cost, s.basis_sold, s.out), (None, None, 30.0));
        let mut unpriced = op(1, false, 1, 0);
        unpriced.cash = None;
        let mut s = run(&[]);
        assert!(account(&[op(0, true, 1, -1), unpriced], &mut s).is_err());
    }
}

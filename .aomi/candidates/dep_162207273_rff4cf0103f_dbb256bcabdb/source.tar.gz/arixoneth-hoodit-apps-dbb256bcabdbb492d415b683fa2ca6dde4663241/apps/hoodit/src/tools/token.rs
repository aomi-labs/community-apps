use super::{address, run};
use crate::domain::exit::{Exits, Size};
use crate::domain::market::Stage;
use crate::domain::token::{Depth, TokenSnapshot, snapshot};
use crate::runtime::{Fail, HooditApp, Lane};
use aomi_sdk::schemars::JsonSchema;
use aomi_sdk::{DynAomiTool, DynToolCallCtx};
use serde::Deserialize;
use serde_json::Value;

#[derive(Deserialize, JsonSchema, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum Mode {
    /// Research card with an indicative 0.01 ETH exit probe.
    Full,
    /// Buy checks with one exit quote at the requested size; no research enrichment.
    Trade,
}

#[derive(Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct TokenArgs {
    /// Exact 0x token contract. Resolve tickers with hoodit_find first.
    pub token: String,
    /// trade for a requested buy; full for research. null or omitted = full.
    pub mode: Option<Mode>,
    /// Exact ETH input for trade mode. Give this or usd_amount, never both.
    pub eth_amount: Option<String>,
    /// USD budget for trade mode, converted at the current ETH price.
    pub usd_amount: Option<f64>,
    /// Trade quote slippage in percent. Omitted = 3 above $50k liquidity, else 5 (also 5 on curves). Above 5 needs user consent; maximum 10.
    pub slippage_pct: Option<f64>,
}

impl TokenArgs {
    fn slippage(&self, snap: &TokenSnapshot) -> Result<f64, Fail> {
        if let Some(slippage) = self.slippage_pct {
            return Ok(slippage);
        }
        match snap.liquidity_usd.filter(|l| *l >= 0.0) {
            Some(liquidity) if liquidity > 50_000.0 && snap.stage != Stage::Curve => Ok(3.0),
            Some(_) => Ok(5.0),
            None => Err(Fail::Invalid("liquidity unknown; give the intended slippage_pct without widening existing bounds".into())),
        }
    }

    fn size(&self) -> Result<Option<Size>, Fail> {
        let invalid = |why: &str| Fail::Invalid(why.into());
        if self.mode != Some(Mode::Trade) {
            return if self.eth_amount.is_some()
                || self.usd_amount.is_some()
                || self.slippage_pct.is_some()
            {
                Err(invalid("size and slippage require mode trade"))
            } else {
                Ok(None)
            };
        }
        if self
            .slippage_pct
            .is_some_and(|s| !s.is_finite() || s <= 0.0 || s > 10.0)
        {
            return Err(invalid(
                "slippage_pct must be greater than 0 and at most 10; never silently widen it",
            ));
        }
        match (&self.eth_amount, self.usd_amount) {
            (Some(eth), None) => {
                let wei = crate::domain::amount::from_decimal(eth, 18).map_err(Fail::Invalid)?;
                if wei.bits() == 0 {
                    return Err(invalid("eth_amount must be positive"));
                }
                Ok(Some(Size::Eth(eth.clone())))
            }
            (None, Some(usd)) if usd.is_finite() && usd > 0.0 => Ok(Some(Size::Usd(usd))),
            _ => Err(invalid(
                "trade requires exactly one positive eth_amount or usd_amount",
            )),
        }
    }
}

pub struct Token;

impl DynAomiTool for Token {
    type App = HooditApp;
    type Args = TokenArgs;
    const NAME: &'static str = "hoodit_token";
    const DESCRIPTION: &'static str = "One Robinhood Chain token. mode trade: security, liquidity and one buy/sell exit quote at eth_amount or usd_amount, with slippage_pct or the trade default. Use for specified memecoin buys; do not also call hoodit_exit. checks_passed is advisory: disclose warnings and let the user explicitly proceed despite them. Unknown checks never become a pass. mode full (default): requested research with an indicative 0.01 ETH exit. Quotes are not fills, simulations or host execution eligibility. Price/route base assets and stocks with host tools.";

    fn run(app: &HooditApp, args: TokenArgs, ctx: DynToolCallCtx) -> Result<Value, String> {
        run(app, &ctx, Lane::Chat, async |rt, turn| {
            let token = address(&args.token)?;
            if let Some(size) = args.size()? {
                let snap = snapshot(rt, turn, &token, Depth::Trade).await?;
                let slippage = args.slippage(&snap)?;
                let (trip, eth_usd) = Exits::new(rt, turn)
                    .round_trip_sized(&token, size, slippage / 100.0)
                    .await?;
                return Ok(crate::view::token::trade(
                    &snap,
                    &trip,
                    eth_usd,
                    slippage,
                    turn.wallet.is_some(),
                ));
            }
            // The exit probe runs alongside the reads; it is the only test
            // that catches traps the security screen calls clean.
            let (snap, probe) = tokio::join!(
                snapshot(rt, turn, &token, Depth::Card),
                Exits::new(rt, turn).probe(&token)
            );
            Ok(crate::view::token::card(&snap?, Some(&probe)))
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn default_slippage_preserves_liquidity_and_curve_policy() {
        let args: TokenArgs = serde_json::from_value(
            serde_json::json!({"token":"unused","mode":"trade","eth_amount":"0.01"}),
        )
        .unwrap();
        let mut snap = TokenSnapshot::from_gmgn(Default::default());
        assert!(args.slippage(&snap).is_err());
        snap.liquidity_usd = Some(50_000.0);
        assert_eq!(args.slippage(&snap).unwrap(), 5.0);
        snap.liquidity_usd = Some(50_001.0);
        assert_eq!(args.slippage(&snap).unwrap(), 3.0);
        snap.stage = Stage::Curve;
        assert_eq!(args.slippage(&snap).unwrap(), 5.0);
    }
}

//! Real direct-tool flow with offline providers: warn, accept, recheck, prepare.
use aomi_sdk::testing::{TestCtxBuilder, run_tool};
use hoodit::providers::{NATIVE, USDG};
use hoodit::runtime::{GMGN_KEY, HooditApp};
use hoodit::tools::Buy;
use serde_json::{Value, json};
use std::collections::BTreeMap;

const TOKEN: &str = "0x1111111111111111111111111111111111111111";
const WALLET: &str = "0x2222222222222222222222222222222222222222";
const NEUTRAL: &str = "0x0bf3e6f5ef3d32dccce208a1dd8fa9251893dd91";

fn quote(from: &str, to: &str, amount: &str, wallet: &str) -> String {
    format!("lifi:{from}>{to}:{amount}:{wallet}:0.05")
}

fn responses() -> BTreeMap<String, Value> {
    let tokens = "1000000000000000000000";
    let buy = json!({"estimate":{"toAmount":tokens,"toAmountMin":tokens}});
    BTreeMap::from([
        (
            format!("chain:decimals:{TOKEN}"),
            json!(format!("0x{:064x}", 18)),
        ),
        (
            format!("chain:symbol:{TOKEN}"),
            json!(format!("0x{:0<64}", "485256")),
        ),
        (
            format!("gmgn:/v1/token/info?chain=robinhood&address={TOKEN}"),
            json!({"address":TOKEN,"symbol":"HRV","liquidity":100}),
        ),
        (
            format!("gmgn-live:/v1/token/security?chain=robinhood&address={TOKEN}"),
            json!({"honeypot":false,"buy_tax":"0","sell_tax":"0"}),
        ),
        (
            format!("chain:balance:{USDG}:{WALLET}"),
            json!(format!("0x{:064x}", 10_000_000)),
        ),
        (
            format!("chain:balance:{TOKEN}:{WALLET}"),
            json!(format!("0x{:064x}", 0)),
        ),
        (
            format!("chain:native-balance:{WALLET}"),
            json!("0xde0b6b3a7640000"),
        ),
        (format!("lifi:price:{NATIVE}"), json!({"priceUSD":"2000"})),
        (quote(USDG, TOKEN, "5000000", WALLET), buy.clone()),
        (quote(NATIVE, TOKEN, "2500000000000000", WALLET), buy),
        (
            quote(TOKEN, NATIVE, tokens, NEUTRAL),
            json!({"$fail":{"code":"NO_ROUTE","message":"no executable sell quote","source":"lifi"}}),
        ),
    ])
}

fn call(recorded: BTreeMap<String, Value>, args: Value) -> Value {
    let app = HooditApp::replaying(recorded);
    run_tool::<Buy>(
        &app,
        args,
        TestCtxBuilder::new("hoodit_buy")
            .secret(GMGN_KEY, "recorded")
            .attribute("domain", json!({"evm":{"address":WALLET}}))
            .build(),
    )
    .unwrap()
    .value
}

fn warning() -> Value {
    call(responses(), json!({"token":TOKEN,"amount":"$5"}))
}

#[test]
fn buy_anyway_keeps_spend_and_slippage_and_does_not_mark_exit_as_safe() {
    let first = warning();
    assert!(first.get("tx").is_none(), "{first}");
    assert!(
        first["text"]
            .as_str()
            .unwrap()
            .contains("may be unable to exit"),
        "{first}"
    );
    let control = &first["controls"][0];
    assert_eq!(control["label"], "Buy anyway");
    assert_eq!(control["args"]["amount"], "5 USDG");
    assert_eq!(control["args"]["slippage_bps"], 500);
    assert_eq!(control["args"]["reviewed_wallet"], WALLET);
    let accepted = call(responses(), control["args"].clone());
    assert_eq!(accepted["tx"]["args"]["to_token"], TOKEN, "{accepted}");
    assert_eq!(accepted["tx"]["args"]["from_token"], USDG);
    assert_eq!(accepted["tx"]["args"]["amount"], "5");
    assert_eq!(accepted["tx"]["args"]["slippage_bps"], 500);
    // This is one button's consent, never a saved bypass.
    assert!(warning().get("tx").is_none());
    let mut changed_wallet = control["args"].clone();
    changed_wallet["reviewed_wallet"] = json!(TOKEN);
    assert!(call(responses(), changed_wallet).get("tx").is_none());
}

#[test]
fn risk_consent_cannot_create_a_buy_route_or_balance() {
    let args = warning()["controls"][0]["args"].clone();
    for key in [
        quote(USDG, TOKEN, "5000000", WALLET),
        format!("chain:native-balance:{WALLET}"),
    ] {
        let mut recorded = responses();
        recorded.insert(
            key,
            json!({"$fail":{"code":"NO_ROUTE","message":"unavailable","source":"lifi"}}),
        );
        let out = call(recorded, args.clone());
        assert!(out.get("tx").is_none(), "{out}");
    }
}

#[test]
fn unavailable_research_does_not_erase_an_executable_buy_quote() {
    let mut recorded = responses();
    recorded.remove(&format!(
        "gmgn-live:/v1/token/security?chain=robinhood&address={TOKEN}"
    ));
    recorded.remove(&quote(NATIVE, TOKEN, "2500000000000000", WALLET));
    let first = call(recorded.clone(), json!({"token":TOKEN,"amount":"$5"}));
    assert!(first.get("tx").is_none(), "{first}");
    assert!(
        first["text"]
            .as_str()
            .unwrap()
            .contains("security is unavailable")
    );
    let accepted = call(recorded, first["controls"][0]["args"].clone());
    assert_eq!(accepted["tx"]["args"]["amount"], "5", "{accepted}");
}

#[test]
fn newly_discovered_risks_require_a_new_warning() {
    let args = warning()["controls"][0]["args"].clone();
    let mut recorded = responses();
    recorded.insert(
        format!("gmgn-live:/v1/token/security?chain=robinhood&address={TOKEN}"),
        json!({"honeypot":true,"buy_tax":"0","sell_tax":"0.25"}),
    );
    let out = call(recorded.clone(), args);
    assert!(out.get("tx").is_none(), "{out}");
    assert!(out["text"].as_str().unwrap().contains("25%"));
    assert!(out["text"].as_str().unwrap().contains("honeypot"));
    let accepted = call(recorded, out["controls"][0]["args"].clone());
    assert!(accepted.get("tx").is_some(), "{accepted}");
}

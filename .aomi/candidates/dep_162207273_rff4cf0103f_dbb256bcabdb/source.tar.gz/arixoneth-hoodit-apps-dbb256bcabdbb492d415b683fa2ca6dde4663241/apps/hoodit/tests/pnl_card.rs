//! Exercise the card tool through the SDK and its recorded provider boundary.
use aomi_sdk::testing::{TestCtxBuilder, run_tool};
use hoodit::runtime::{GMGN_KEY, HooditApp};
use hoodit::tools::CardTool;
use hoodit::view::{MAX_REPLY, size};
use serde_json::{Value, json};
use std::collections::BTreeMap;

const WALLET: &str = "0x1111111111111111111111111111111111111111";
const TOKEN: &str = "0x2222222222222222222222222222222222222222";
const SELL: &str = "0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
const BUY: &str = "0xbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";
const OLD_BUY: &str = "0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc";
const NEW_BUY: &str = "0xdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd";
const USDG: &str = "0x5fc5360d0400a0fd4f2af552add042d716f1d168";
const ROUTER: &str = "0x3333333333333333333333333333333333333333";

fn word(address: &str) -> String {
    format!("0x{:0>64}", address.trim_start_matches("0x"))
}

fn transfer(token: &str, from: &str, to: &str, raw: u128) -> Value {
    json!({"address":token,"topics":["0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",word(from),word(to)],"data":format!("0x{raw:064x}")})
}

/// Synthetic provider boundary for chronology/redraw tests. Economic
/// regression tests below use the actual unmodified public TADA receipts.
fn recordings(mut map: BTreeMap<String, Value>) -> BTreeMap<String, Value> {
    let rows: Vec<Value> = map
        .values()
        .filter_map(|v| v["activities"].as_array())
        .flatten()
        .cloned()
        .collect();
    for row in rows {
        let tx = row["tx_hash"].as_str().unwrap();
        let buy = row["event_type"] == "buy";
        let cash = (row["cost_usd"].as_f64().unwrap_or(10.0) * 1_000_000.0) as u128;
        let quantity = 100 * 10u128.pow(18);
        let logs = if buy {
            vec![
                transfer(USDG, WALLET, ROUTER, cash),
                transfer(TOKEN, ROUTER, WALLET, quantity),
            ]
        } else {
            vec![
                transfer(TOKEN, WALLET, ROUTER, quantity),
                transfer(USDG, ROUTER, WALLET, cash),
            ]
        };
        map.insert(format!("chain:receipt:{tx}"),json!({"transactionHash":tx,"blockNumber":"0x1000","transactionIndex":"0x0","status":"0x1","from":WALLET,"to":ROUTER,"gasUsed":"0x5208","effectiveGasPrice":"0x1","logs":logs}));
        map.insert(
            format!("chain:transaction:{tx}"),
            json!({"hash":tx,"from":WALLET,"to":ROUTER,"value":"0x0","nonce":"0x1","input":"0x"}),
        );
        map.insert(
            format!("chain:approvals:{tx}:{}", if buy { USDG } else { TOKEN }),
            json!([]),
        );
    }
    map.insert(format!("chain:decimals:{TOKEN}"), json!(word("12")));
    map.insert(
        format!("chain:balance:{TOKEN}:{WALLET}"),
        json!(format!("0x{:064x}", 100 * 10u128.pow(18))),
    );
    map.entry(format!(
        "gmgn:/v1/token/info?chain=robinhood&address={TOKEN}"
    ))
    .or_insert(json!({"price":{}}));
    map
}

fn replay(map: BTreeMap<String, Value>) -> HooditApp {
    HooditApp::replaying(recordings(map))
}

fn activity(kind: &str, ts: i64, tx: &str, cost: f64) -> Value {
    json!({
        "event_type": kind, "timestamp": ts, "tx_hash": tx,
        "token": {"address": TOKEN, "symbol": "TADA"},
        "token_amount": "100", "cost_usd": cost,
        "is_open_or_close": 1,
    })
}

fn key(cursor: Option<&str>) -> String {
    let tail = cursor.map(|c| format!("&cursor={c}")).unwrap_or_default();
    format!(
        "gmgn:/v1/user/wallet_activity?chain=robinhood&wallet_address={WALLET}&token_address={TOKEN}&limit=50{tail}"
    )
}

fn app() -> HooditApp {
    replay(BTreeMap::from([(
        key(None),
        json!({"activities": [activity("sell", 200, SELL, 20.0), activity("buy", 100, BUY, 10.0)]}),
    )]))
}

fn call(app: &HooditApp, session: &str, args: Value) -> Value {
    let ctx = TestCtxBuilder::new("hoodit_card")
        .session_id(session)
        .secret(GMGN_KEY, "recorded")
        .build();
    let out = run_tool::<CardTool>(app, args, ctx).unwrap().value;
    assert!(size(&out) <= MAX_REPLY, "{out}");
    out
}

fn new_card(app: &HooditApp, session: &str) -> Value {
    call(
        app,
        session,
        json!({"token": TOKEN, "wallet": WALLET, "style": "receipt"}),
    )
}

fn check_photo(out: &Value) {
    assert!(
        matches!(out["status"].as_str(), Some("ok" | "partial")),
        "{out}"
    );
    let path = out["image_path"].as_str().unwrap();
    assert!(std::path::Path::new(path).is_absolute());
    let png = std::fs::read(path).unwrap();
    assert_eq!(&png[..8], b"\x89PNG\r\n\x1a\n");
    assert_eq!(u32::from_be_bytes(png[16..20].try_into().unwrap()), 1080);
    assert_eq!(u32::from_be_bytes(png[20..24].try_into().unwrap()), 1080);
    assert_eq!(out["controls"].as_array().unwrap().len(), 2);
    assert_eq!(out["controls"][0]["action"], "say");
    std::fs::remove_file(path).unwrap();
}

#[test]
fn photo_and_redraw_keep_frozen_figures_and_the_requested_look() {
    let app = app();
    let original = new_card(&app, "first");
    check_photo(&original);
    assert_eq!(original["card"]["profit"], "+$10.00");
    let redraw = call(
        &app,
        "first",
        json!({"redraw": original["card_id"], "big": "mult"}),
    );
    check_photo(&redraw);
    assert_eq!(redraw["card_id"], original["card_id"]);
    assert_eq!(redraw["card"], original["card"]);
    assert_eq!(redraw["style_used"], "Receipt");
    assert_eq!(redraw["big"], "mult");
    assert_ne!(redraw["image_path"], original["image_path"]);

    let shuffled = call(
        &app,
        "first",
        json!({"redraw": original["card_id"], "another_style": true}),
    );
    check_photo(&shuffled);
    assert_ne!(shuffled["style_used"], "Receipt");
    assert_eq!(shuffled["big"], "mult");
    assert_eq!(shuffled["card"], original["card"]);
}

#[test]
fn redraws_are_independent_and_scoped_to_the_chat() {
    let app = app();
    let original = new_card(&app, "first");
    check_photo(&original);
    let other = new_card(&app, "second");
    check_photo(&other);
    assert_ne!(original["card_id"], other["card_id"]);
    let denied = call(&app, "second", json!({"redraw": original["card_id"]}));
    assert_eq!(denied["error"]["code"], "NOT_FOUND");
    assert!(denied.get("image_path").is_none());

    let another = new_card(&app, "first");
    check_photo(&another);
    assert_ne!(original["card_id"], another["card_id"]);
}

#[test]
fn older_sell_is_found_beyond_the_latest_opening_buy() {
    let app = replay(BTreeMap::from([
        (
            key(None),
            json!({"activities": [activity("buy", 300, NEW_BUY, 50.0)], "next": "older"}),
        ),
        (
            key(Some("older")),
            json!({"activities": [activity("sell", 200, SELL, 20.0), activity("buy", 100, OLD_BUY, 10.0)]}),
        ),
    ]));
    let out = call(
        &app,
        "history",
        json!({"token": TOKEN, "wallet": WALLET, "tx_hash": SELL}),
    );
    check_photo(&out);
    assert_eq!(out["card"]["state"], "closed");
    assert_eq!(out["card"]["profit"], "+$10.00");
}

#[test]
fn missing_market_value_returns_no_data_instead_of_a_loss_image() {
    let app = replay(BTreeMap::from([(
        key(None),
        json!({"activities": [activity("buy", 100, BUY, 10.0)]}),
    )]));
    let out = new_card(&app, "no-price");
    assert_eq!(out["error"]["code"], "NO_DATA");
    assert!(out["error"]["message"].as_str().unwrap().contains("price"));
    assert!(out.get("image_path").is_none());
}

#[test]
fn invalid_transaction_hash_is_rejected_before_fetching() {
    let out = call(
        &app(),
        "bad-hash",
        json!({"token": TOKEN, "wallet": WALLET, "tx_hash": "🚀🚀🚀🚀"}),
    );
    assert_eq!(out["error"]["code"], "INVALID_ARGUMENT");
}

#[test]
fn a_buy_and_sell_in_the_same_second_remain_in_chronological_order() {
    let app = replay(BTreeMap::from([
        (
            key(None),
            json!({"activities": [activity("sell", 100, SELL, 20.0)], "next": "older"}),
        ),
        (
            key(Some("older")),
            json!({"activities": [activity("buy", 100, BUY, 10.0)]}),
        ),
    ]));
    let out = new_card(&app, "same-second");
    check_photo(&out);
    assert_eq!(out["card"]["state"], "closed");
    assert_eq!(out["card"]["profit"], "+$10.00");
}

const TADA_WALLET: &str = "0x032448a18a7c67daf1e6d27080a33e55335137ab";
const TADA_TOKEN: &str = "0x69f125ab4bba8f4a87f0d0a4a2eab739f5d1e1ad";
const TADA_SELL: &str = "0x4f6a1a7d63a050fbeff5037f9ff80df77841303ec5aca0c888d74013efec0c50";
const TADA_BUY: &str = "0x6e8f9121da5d9c93c01d86267eb1c9efa008bd0c3b233dbc033c5ecbc946620d";

fn tada_records() -> BTreeMap<String, Value> {
    serde_json::from_str(include_str!("fixtures/pnl-tada.json")).unwrap()
}

fn tada(app: &HooditApp) -> Value {
    call(
        app,
        "receipt-tada",
        json!({"token":TADA_TOKEN,"wallet":TADA_WALLET,"tx_hash":TADA_SELL,"style":"receipt","show":["usd","pct","mult","inout","gas"]}),
    )
}

#[test]
fn actual_tada_receipts_reconcile_route_fees_and_all_four_gas_payments() {
    let out = tada(&HooditApp::replaying(tada_records()));
    check_photo(&out);
    let card = &out["card"];
    assert_eq!(card["cost_usd"], 3.0);
    assert!((card["proceeds_or_value_usd"].as_f64().unwrap() - 4.667558).abs() < 1e-12);
    assert!((card["profit_usd"].as_f64().unwrap() - 1.667558).abs() < 1e-12);
    assert!((card["return_pct"].as_f64().unwrap() - 55.58526666666667).abs() < 1e-10);
    assert!((card["gas_eth"].as_f64().unwrap() - 0.000023337432484).abs() < 1e-18);
    assert_eq!(card["gas_transactions"], 4);
    assert_eq!(card["return"], "+55.6%");
    assert!(out["caption"].as_str().unwrap().contains("before gas"));
    assert!(!out["caption"].as_str().unwrap().contains("after"));
}

#[test]
fn gmgn_pool_values_cannot_override_wallet_cashflows() {
    let mut records = tada_records();
    let key = format!(
        "gmgn:/v1/user/wallet_activity?chain=robinhood&wallet_address={TADA_WALLET}&token_address={TADA_TOKEN}&limit=50"
    );
    for row in records.get_mut(&key).unwrap()["activities"]
        .as_array_mut()
        .unwrap()
    {
        row["cost_usd"] = json!(999999999);
        row["buy_cost_usd"] = json!(0.000001);
        row["gas_usd"] = json!(10000);
        row["dex_usd"] = json!(10000);
    }
    let out = tada(&HooditApp::replaying(records));
    check_photo(&out);
    assert_eq!(out["card"]["cost_usd"], 3.0);
    assert_eq!(out["card"]["return"], "+55.6%");
}

#[test]
fn reverted_or_missing_receipts_never_fall_back_to_gmgn_proceeds() {
    for missing in [false, true] {
        let mut records = tada_records();
        let key = format!("chain:receipt:{TADA_SELL}");
        if missing {
            records.remove(&key);
        } else {
            records.get_mut(&key).unwrap()["status"] = json!("0x0");
        }
        let out = tada(&HooditApp::replaying(records));
        assert!(out.get("error").is_some(), "{out}");
        assert!(out.get("image_path").is_none());
    }
}

#[test]
fn duplicate_indexed_fills_do_not_double_count_a_receipt() {
    let mut records = tada_records();
    let key = format!(
        "gmgn:/v1/user/wallet_activity?chain=robinhood&wallet_address={TADA_WALLET}&token_address={TADA_TOKEN}&limit=50"
    );
    let activity = records.get_mut(&key).unwrap()["activities"]
        .as_array_mut()
        .unwrap();
    let duplicate = activity[0].clone();
    activity[0]["is_open_or_close"] = json!(0);
    activity.insert(0, duplicate);
    let out = tada(&HooditApp::replaying(records));
    check_photo(&out);
    assert_eq!(out["card"]["return"], "+55.6%");
    assert_eq!(out["card"]["gas_transactions"], 4);
}

#[test]
fn multiple_buys_and_partial_sales_use_the_complete_wallet_spend() {
    let mut second_buy = activity("buy", 110, OLD_BUY, 20.0);
    second_buy["is_open_or_close"] = json!(0);
    let mut partial = activity("sell", 150, NEW_BUY, 20.0);
    partial["is_open_or_close"] = json!(0);
    let app = replay(BTreeMap::from([(
        key(None),
        json!({"activities":[activity("sell",200,SELL,25.0),partial,second_buy,activity("buy",100,BUY,10.0)]}),
    )]));
    let out = new_card(&app, "partial");
    check_photo(&out);
    assert_eq!(out["card"]["cost_usd"], 30.0);
    assert_eq!(out["card"]["proceeds_or_value_usd"], 45.0);
    assert_eq!(out["card"]["return_pct"], 50.0);
    assert_eq!(out["card"]["realized_pnl_usd"], 15.0);
    assert_eq!(out["card"]["gas_transactions"], 4);
}

fn open_records() -> BTreeMap<String, Value> {
    let mut records = recordings(BTreeMap::from([(
        key(None),
        json!({"activities":[activity("buy",100,BUY,10.0)]}),
    )]));
    records.insert(
        format!("gmgn:/v1/token/info?chain=robinhood&address={TOKEN}"),
        json!({"price":{"price":"0.12"}}),
    );
    records
}

#[test]
fn open_value_is_estimated_and_failed_balance_is_identified() {
    let records = open_records();
    let out = new_card(&HooditApp::replaying(records.clone()), "open");
    check_photo(&out);
    assert_eq!(out["card"]["cost_usd"], 10.0);
    assert_eq!(out["card"]["proceeds_or_value_usd"], 12.0);
    assert_eq!(out["card"]["return_pct"], 20.0);
    assert!(
        out["card"]["accounting"]
            .as_str()
            .unwrap()
            .contains("EST. CURRENT VALUE")
    );
    let mut records = records;
    records.insert(
        format!("chain:balance:{TOKEN}:{WALLET}"),
        json!({"$fail":{"code":"UNAVAILABLE","source":"chain","message":"network busy"}}),
    );
    let out = new_card(&HooditApp::replaying(records), "failed-balance");
    assert_eq!(out["error"]["code"], "NO_DATA");
    assert!(
        out["error"]["message"]
            .as_str()
            .unwrap()
            .contains("balance")
    );
    assert!(
        out["error"]["message"]
            .as_str()
            .unwrap()
            .contains("network busy")
    );
    assert!(out.get("image_path").is_none());
}

#[test]
fn native_input_and_missing_opening_history_do_not_invent_a_basis() {
    let mut records = open_records();
    records
        .get_mut(&format!("chain:transaction:{BUY}"))
        .unwrap()["value"] = json!("0x1234");
    let out = new_card(&HooditApp::replaying(records), "native-unknown");
    assert_eq!(out["status"], "partial", "{out}");
    assert!(out["card"]["cost_usd"].is_null());
    assert!(out["card"]["return_pct"].is_null());
    assert_eq!(out["card"]["proceeds_or_value_usd"], 12.0);
    std::fs::remove_file(out["image_path"].as_str().unwrap()).unwrap();

    let mut records = tada_records();
    let key = format!(
        "gmgn:/v1/user/wallet_activity?chain=robinhood&wallet_address={TADA_WALLET}&token_address={TADA_TOKEN}&limit=50"
    );
    records.get_mut(&key).unwrap()["activities"]
        .as_array_mut()
        .unwrap()
        .retain(|r| r["tx_hash"] != TADA_BUY);
    let out = tada(&HooditApp::replaying(records));
    assert_eq!(out["status"], "ok", "{out}");
    assert!(out["card"]["cost_usd"].is_null());
    assert!(out["card"]["return_pct"].is_null());
    assert_eq!(out["card"]["proceeds_or_value_usd"], 4.667558);
    std::fs::remove_file(out["image_path"].as_str().unwrap()).unwrap();
}

const LIFI: &str = "0xb477751b76cf82d00a686a1232f5fcd772414af3";
const LIFI_COMPLETED: &str = "0x38eee76fd911eabac79da7af16053e809be0e12c8637f156e77e1af309b99537";
const ORBIO_WALLET: &str = "0xe60292db0da5f692feaadef901981e8d6bef33d9";
const ORBIO: &str = "0xaa07a0e9209e16ac99708c3ec70159c6ef3128a3";
const HYDX: &str = "0xaa5751ff3fb61e613993b2eb4eab1fce017081fc";
const BATCH: &str = "0x201b3f7f21d338b038f0f35f53fc3f51c7dae6b2e6d3a397b66e54119e994c5c";
const ENTRY_POINT: &str = "0x0000000071727de22e5e9d8baf0edac6f37da032";
const BUNDLER: &str = "0x4444444444444444444444444444444444444444";
const POOL: &str = "0x5555555555555555555555555555555555555555";

fn completed(from: &str, to: &str, from_amount: u128, to_amount: u128) -> Value {
    let w = |a: &str| format!("{:0>64}", a.trim_start_matches("0x"));
    let data = [
        w("e0"),
        w("120"),
        w(ORBIO_WALLET),
        w(from),
        w(to),
        format!("{from_amount:064x}"),
        format!("{to_amount:064x}"),
    ]
    .concat();
    json!({"address":LIFI,"topics":[LIFI_COMPLETED,"0x4fd5591735525a98449086b20f62a55603bb86a54845c14cf9c3a6b44ca846f3"],"data":format!("0x{data}")})
}

/// Reconstruction of issue #35's receipt from its documented wallet
/// transfers and LI.FI events (logs 70, 92, 93, 95, 118, 119), sent through
/// an EntryPoint by a bundler. Pool-internal legs and misleading event
/// amounts are included; only the wallet's own transfers may count.
fn batch_records(kind: &str, token: &str, symbol: &str) -> BTreeMap<String, Value> {
    let orbio_out = 529_462_312_492_091_834_368u128;
    let hydx_in = 5_565_291_661_963_738_218_496u128;
    let logs = vec![
        transfer(ORBIO, ORBIO_WALLET, LIFI, orbio_out),
        transfer(ORBIO, LIFI, POOL, orbio_out),
        transfer(USDG, POOL, LIFI, 16_600_000),
        transfer(USDG, LIFI, ORBIO_WALLET, 16_506_952),
        completed(ORBIO, USDG, orbio_out, 99_000_000),
        transfer(USDG, ORBIO_WALLET, LIFI, 10_000_000),
        transfer(USDG, LIFI, POOL, 10_000_000),
        transfer(HYDX, POOL, ORBIO_WALLET, hydx_in),
        completed(USDG, HYDX, 10_000_000, 1),
    ];
    let row = json!({"event_type":kind,"timestamp":1_793_262_211,"tx_hash":BATCH,"token":{"address":token,"symbol":symbol},"cost_usd":999.0,"is_open_or_close":1});
    BTreeMap::from([
        (
            format!(
                "gmgn:/v1/user/wallet_activity?chain=robinhood&wallet_address={ORBIO_WALLET}&token_address={token}&limit=50"
            ),
            json!({"activities":[row]}),
        ),
        (
            format!("chain:receipt:{BATCH}"),
            json!({"transactionHash":BATCH,"blockNumber":"0x2000","transactionIndex":"0x1","status":"0x1","from":BUNDLER,"to":ENTRY_POINT,"gasUsed":"0x5208","effectiveGasPrice":"0x1","logs":logs}),
        ),
        (
            format!("chain:transaction:{BATCH}"),
            json!({"hash":BATCH,"from":BUNDLER,"to":ENTRY_POINT,"value":"0x0","nonce":"0x9","input":"0x"}),
        ),
        (format!("chain:decimals:{HYDX}"), json!(word("12"))),
        (
            format!("chain:balance:{HYDX}:{ORBIO_WALLET}"),
            json!(format!("0x{hydx_in:064x}")),
        ),
        (
            format!("gmgn:/v1/token/info?chain=robinhood&address={HYDX}"),
            json!({"price":{"price":"0.002"}}),
        ),
    ])
}

fn batch_card(kind: &str, token: &str, symbol: &str) -> Value {
    let out = call(
        &HooditApp::replaying(batch_records(kind, token, symbol)),
        &format!("batch-{symbol}"),
        json!({"token":token,"wallet":ORBIO_WALLET,"tx_hash":BATCH,"style":"receipt"}),
    );
    assert_eq!(out["status"], "ok", "{out}");
    std::fs::remove_file(out["image_path"].as_str().unwrap()).unwrap();
    out
}

#[test]
fn one_transaction_with_two_swaps_keeps_each_swaps_own_cash() {
    let orbio = batch_card("sell", ORBIO, "ORBIO");
    let card = &orbio["card"];
    assert_eq!(card["sale_proceeds_usd"], 16.506952, "{card}");
    assert_eq!(card["proceeds_or_value_usd"], 16.506952);
    assert!(card["cost_usd"].is_null() && card["realized_pnl_usd"].is_null());
    // A bundler paid the outer transaction: not wallet gas.
    assert_eq!(card["gas_transactions"], 0);

    let hydx = batch_card("buy", HYDX, "HYDX");
    let card = &hydx["card"];
    assert_eq!(card["cost_usd"], 10.0, "{card}");
    assert_eq!(card["state"], "open");
    let value = 5_565.291_661_963_738 * 0.002;
    assert!((card["unrealized_pnl_usd"].as_f64().unwrap() - (value - 10.0)).abs() < 1e-9);
}

#[test]
fn open_partial_sale_splits_realized_and_unrealized() {
    // Buy 100 for 20 USDG, sell 40 for 12, mark the other 60 at 0.25.
    let e18 = 10u128.pow(18);
    let receipt = |tx: &str, block: &str, logs: Vec<Value>| json!({"transactionHash":tx,"blockNumber":block,"transactionIndex":"0x0","status":"0x1","from":WALLET,"to":ROUTER,"gasUsed":"0x5208","effectiveGasPrice":"0x1","logs":logs});
    let mut buy = activity("buy", 100, BUY, 20.0);
    buy["is_open_or_close"] = json!(1);
    let mut sell = activity("sell", 200, SELL, 12.0);
    sell["is_open_or_close"] = json!(0);
    let mut records = BTreeMap::from([
        (key(None), json!({"activities":[sell, buy]})),
        (
            format!("chain:receipt:{BUY}"),
            receipt(
                BUY,
                "0x10",
                vec![
                    transfer(USDG, WALLET, ROUTER, 20_000_000),
                    transfer(TOKEN, ROUTER, WALLET, 100 * e18),
                ],
            ),
        ),
        (
            format!("chain:receipt:{SELL}"),
            receipt(
                SELL,
                "0x20",
                vec![
                    transfer(TOKEN, WALLET, ROUTER, 40 * e18),
                    transfer(USDG, ROUTER, WALLET, 12_000_000),
                ],
            ),
        ),
        (format!("chain:decimals:{TOKEN}"), json!(word("12"))),
        (
            format!("chain:balance:{TOKEN}:{WALLET}"),
            json!(format!("0x{:064x}", 60 * e18)),
        ),
        (
            format!("gmgn:/v1/token/info?chain=robinhood&address={TOKEN}"),
            json!({"price":{"price":"0.25"}}),
        ),
    ]);
    for (tx, input) in [(BUY, USDG), (SELL, TOKEN)] {
        records.insert(
            format!("chain:transaction:{tx}"),
            json!({"hash":tx,"from":WALLET,"to":ROUTER,"value":"0x0","nonce":"0x1","input":"0x"}),
        );
        records.insert(format!("chain:approvals:{tx}:{input}"), json!([]));
    }
    let out = new_card(&HooditApp::replaying(records), "partial-open");
    check_photo(&out);
    let card = &out["card"];
    assert_eq!(card["cost_usd"], 20.0, "{card}");
    assert_eq!(card["sale_proceeds_usd"], 12.0);
    assert_eq!(card["proceeds_or_value_usd"], 27.0);
    assert_eq!(card["profit_usd"], 7.0);
    assert_eq!(card["realized_pnl_usd"], 4.0);
    assert_eq!(card["unrealized_pnl_usd"], 3.0);
}

# Direct-trade conversation contracts (H1–H5)

Run the offline suite from the repository root:

```sh
python3 -m unittest discover -s tests -p 'test_*.py' -v
```

CI runs the same command. It uses only the Python standard library and synthetic
addresses, tool results and callbacks. It cannot sign, stage a real transaction,
contact a provider, load credentials, or mutate a database. The existing deployed
guest runner remains read-only by default: its trade boundary now includes
`stage_lifi_swap`, `evm_commit_txs`, `simulate_batch` and `evm_stage_tx` as well as
legacy signing/preparation names and wallet actions.

| Plan | Fixture and counterexample |
| --- | --- |
| H-AC1 | Fresh exact-contract card and size check → one stage, exact ordered simulation, one review, later explicit yes, commit. Reject early commit, reordered IDs, failed simulation, redundant reads/review and optional chart work. |
| H-AC2 | Warn about honeypot, tax >10%, loss and unknown exit/security; honor explicit risk consent for the same bounds. Changed token/size/slippage requires new consent. Risk consent never replaces a passing simulation. A sell still needs a sell route. |
| H-AC3 | Stablecoin, ETH and stock execution use no meme discovery; stocks require the retained resolver skill. |
| H-AC4 | Approval callback stays pending; swap callback or receipt on the actual swap hash establishes completion. Reject approval-only/failed-swap success, bridge queries, sleeps, history detours and unsolicited receipt watchers. |
| H-AC5 | With retained instructions supplied at ordinary/callback/compaction boundaries, no reactivation. Load missing skills additively. **Does not prove host retention** or repair legacy lineage A2. |
| H-AC6 | Known pre-admission min-output rejection → new stage IDs, new simulation within consent. Lower output floor, higher slippage/size/fees or changed token/recipient need another reviewed yes. Unknown admission and failed-old-ID retries are rejected. |
| H-AC7 | Combined trade check and independent holdings read share a response with distinct IDs and progress text. Reject duplicate IDs, missing progress and grouped stage/simulation mutations. This tests requested grouping, not concurrent host I/O. |

`scripts/hoodit_trade_checks.py` scores normalized traces and can also read one
JSON trace file. `tests/test_trade_conversations.py` builds reference traces and
deliberately invalid variants. The messages preserve response boundaries and call
IDs. Tool names and argument shapes follow the current host contracts:
`stage_lifi_swap` returns `pending_tx_ids`; `simulate_batch` accepts ordered
`transactions` and reports `batch_success`; `evm_commit_txs` accepts `tx_ids`.

Evaluator annotations (`bounds`, `authorizes`, `risk_review`, `accepts_risk`, `card`, `exit`, `admission`,
`receipt`, `outcome`, `context.active_skills`) are normalized observations, **not
host tool fields or a new structured error schema**. `authorizes` means a human
has identified an explicit user yes to the previously reviewed bounds; `outcome`
labels a claimed success. `risk_review` identifies the bounds covered by the disclosed warning; `accepts_risk` identifies the user's explicit acceptance of that warning. Neither changes the transaction consent or simulation requirements. `admission=not_admitted` requires authoritative evidence
that no send was admitted; a generic error or transport timeout alone cannot
establish that. The current host's pre-admission replay rejection can be identified
from its execution path, while richer diagnostics remain host B2 work. An adapter
for real transcripts must derive these observations from actual messages/results,
never fill them from expected answers. Malformed/unannotated exports are not valid
inputs to this bounded checker.

These are evaluator and conversation-contract regressions, plus an embedded prompt
byte-budget check. They do not run a model against the changed prompts, verify host
callbacks, or measure latency. A passing synthetic reference trace proves the
checker accepts that trace; rejecting counterexamples proves its relevant gates.
It does not establish that a live model will produce the reference trace.

A specified buy uses `hoodit_token` mode `trade`, with security and exact-size
exit evidence together; a full card before execution is rejected unless the
normalized context explicitly records requested research. See
[`docs/token-trade-mode.md`](../../docs/token-trade-mode.md) for mode behavior,
actual tool regression tests and bounded live measurements.

Before marking integrated acceptance complete, run the changed app with an
isolated mock host/provider, real model output and retained-skill callback recovery
(A2), then retain and review the resulting traces. No hosted guest trade, funded
wallet, deployment or shared schema repair is needed for these offline checks.
The prior direct OpenAI credential returned `credit_balance_exhausted`; it is not
a successful model or performance baseline. No production latency savings or
Telegram delivery timing are claimed here.

# Token trade mode

`hoodit_token` has two modes. `full` (also omitted/null) preserves the research
card and indicative 0.01 ETH exit probe. `trade` returns buy security and one
requested-size exit check, without Pons/developer display enrichment. Other
research tools remain available. No new tool, SDK dependency or host workflow.

For a specified small-coin buy:

```json
{
  "tool": "hoodit_token",
  "args": {
    "token": "0x98096d17e191b3da1d5f99a6d7b3584351b11e18",
    "mode": "trade",
    "eth_amount": "0.000021153",
    "slippage_pct": 3
  }
}
```

Give exactly one positive `eth_amount` or `usd_amount`. Omitted slippage uses
3% above $50k liquidity, otherwise 5%, including curves. Unknown liquidity needs
an explicit intended bound; supplied slippage is validated, never clamped.
Above 5% still requires user consent; 10% is the maximum. The resolved ETH amount
and slippage are returned for staging. USD conversion preserves ETH precision
and requires a current price rather than expired research data.

`checks_passed` requires known non-honeypot status, known nonnegative buy/sell
tax, sell tax at most 10%, and a passing exit. Missing/unsafe facts never pass.
This is advisory: `warnings` describe the findings. Disclose them and honor
an explicit decision to proceed, keeping the requested size and slippage.
Telegram quick buys offer **Buy anyway**, bound to the reviewed wallet, exact
spend and slippage. Freshly changed warnings require another review. A failed
security or exit read can be accepted; a missing actual buy route cannot.
Market/security use a separate 20-second cache without stale fallback, rather
than the longer research cache. No automatic reuse across changed identity,
account, size, slippage or intervening execution is instructed.

The exit remains two independent live quotes, potentially quoted from a neutral
address/holder; it is not a round-trip execution simulation or proof of a fill.
`no_sell_route` means no sell quote, not a proven honeypot. LI.FI errors 1001
(transaction generation failed) and 1002 (no quotes) both trigger the existing
holder fallback. A pre-buy quote cannot include the balances and curve reserves
created by the hypothetical purchase.
The actual host still quotes/stages, validates supported route/bounds, simulates
the exact ordered cohort and performs authorized commit. `checks_passed` does
not replace those requirements. Sells retain `hoodit_exit` sell mode.

## Local verification, 28 October 2026

The `live` example ran the old `hoodit_token` + exact `hoodit_exit` against the
new trade mode in separate cold app processes, with matching wallet, token,
ETH amount and explicit 3% slippage. A/B order alternated. Two tokens, three
pairs, no model inference, paid Codex data, signatures or transactions.

| Case | Old card + exact exit | Trade mode | Provider sends, old → new |
| --- | ---: | ---: | ---: |
| BONER | 4.52 s | 1.37 s | 9 → 6 |
| PRIORS | 6.93 s | 2.47 s | 10 → 6 |
| BONER repeat | 3.17 s | 1.52 s | 9 → 6 |

Every run succeeded. Trade mode returned `checks_passed: true`. The change
reduced two tool calls to one and four LI.FI quotes to two in every pair.
Combined pretty-printed app results were 2,533–2,559 bytes before versus
1,321–1,332 bytes after; these are not measured model input-token savings.

These are small local samples at changing market state, not production p50/p95
or end-to-end model latency. The historical 38-second outlier did not reproduce.
The baseline used a timing-instrumented copy of commit
`9bb179ee0c67e824d116a90af7194e25d479d228`; no timeout reduction was used to
manufacture a faster success. USD sizing, failures and research preservation
are tested offline; these live comparisons use native ETH inputs.

To reproduce, build the `live` example on the base and PR revisions, keep both
binaries, then run a plan containing the old card+exit sequence and a separate
plan containing the trade-mode call above. Add the same connected `wallet` to
each plan step. Restart the example between variants for cold app caches,
alternate order, and retain all failures. Keep provider quotas and other machine
work constant; do not run a full build during timing. `HOODIT_RECORD=<path>` saves
provider responses; leave `CODEX_MPP_KEY` unset for a native-ETH-only comparison.

## Timing the remaining tail

The existing `HOODIT_TRACE=<path>` now also writes JSON timing rows: call ID,
provider/operation, phase, milliseconds and outcome. Runtime phases distinguish
cache hits, in-flight wait, gate wait, provider duration, shared failures and
stale fallback. Chain RPC attempts are logged separately. No keys, addresses,
raw request arguments or provider bodies are added to those timing rows.
Existing GMGN request-completion lines remain in the same file; it is a mixed
trace log, not a JSON-only stream. Logging is opt-in and does not change budgets
or retry policy.

Regression coverage includes combined checks without research dependencies,
unknown/unsafe tax/security, unavailable routes, conflicting market identity,
separate research cache scope, amount/slippage validation, default slippage,
small USD precision/missing prices, existing full research and exact ordered
simulation/authorization conversation contracts. Synthetic conversation tests
verify the checker, not live model behavior.

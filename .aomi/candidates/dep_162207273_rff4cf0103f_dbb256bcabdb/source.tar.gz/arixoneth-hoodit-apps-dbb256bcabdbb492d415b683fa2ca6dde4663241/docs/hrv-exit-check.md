# HRV exit-check investigation, 30 October 2026

Reported contract: `0xa693f8aba8ead73d075ea17fa677a25da41db46a`
(Harvestia/HRV, Robinhood Chain 4663).

The screenshot shows a buy refused before submission because an exit could not
be verified. It does not show an on-chain sell reverting. The original hosted
conversation could not be retrieved: both staging SSH endpoints and the first
host's tailnet endpoint timed out. The findings below are a live reproduction,
source inspection and a disposable fork test, not the original server trace.

## Findings

- The verified Pons factory's `getLaunchedToken` record and curve getters report
  `creatorTaxBps = 300` (3%) and `feeBps = 100` (1%). GMGN's security endpoint
  reports buy/sell token tax as zero. Its result omits the curve's trade fees.
- LI.FI returned a Kyberswap buy quote for 0.0022 ETH (approximately $5).
  Selling that prospective output from a neutral address or the creator's
  wallet returned HTTP 422, code 1001: “None of the available routes could
  successfully generate a tx.” A 1,000-HRV sell from the creator got a quote.
- The prospective output was approximately 1.25 million HRV. GMGN reported
  only approximately 381,000 tokens outside the curve. Hoodit's existing
  fallback requires a current holder with enough tokens. It cannot represent
  the ownership and reserve changes caused by a hypothetical purchase.
- `sell_quote` only tried the holder fallback after code 1002. The observed
  1001 instead became `BadResponse` and an unknown exit. Separately, code 1002
  was labeled `trap`, overstating the evidence.
- The chat trade skill explicitly required `checks_passed: true` and refused
  unknown checks. Quick buys separately returned a terminal `Plan::No` for
  security/exit warnings. Neither provided a risk acceptance path.

## Sequential verification

A disposable Anvil fork at block **101871367** ran a direct Pons curve buy,
approval and sale using a synthetic EOA and local funds. The 0.0022 ETH buy
received 1,254,608.662144127565286350 HRV; selling all returned
0.002027520000000001 ETH. Both receipts succeeded, with no HRV remaining.
The round-trip loss before gas was **7.84%**, consistent with 4% on each leg.
This establishes that these fees did not prevent the tested sequential exit.
It does not validate the host's LI.FI execution pipeline or promise future fills.

The fork used direct curve calls with diagnostic minimum outputs of one atomic
unit. No mainnet transaction was submitted. The common Anvil account's inherited
EIP-7702 code was cleared on the local fork to create a synthetic EOA; otherwise
that code forwards received ETH and makes its native balance delta misleading.

## Behavior after this change

- Keep `checks_passed` factual and return advisory `warnings`. A missing sell
  quote is `no_sell_route`, distinct from a quoted loss above 50%.
- Interpret both LI.FI 1001 and 1002 as no executable quote for holder fallback;
  other invalid requests remain errors.
- Chat discloses risks and honors an explicit “just buy it” response. Quick
  buys offer **Buy anyway**, preserving the wallet, exact spend and slippage.
  Re-read facts; changed warnings require a new review. Consent is per trade.
- An unavailable security/exit check does not erase a valid actual buy quote.
  Actual buy-route, balance, authorization and simulation failures still need
  resolution before execution.

Raw provider replies, verified contract source, fork receipts and the local
reproduction script are retained in the operator workspace at
`/home/aron/Documents/Reports/hoodit-hrv-exit-2026-10-30/`.

# Hoodit trade

Use when the user asks to buy, sell or send a Robinhood Chain token. Activate the host `lifi_swap` skill too (and `robinhood_stocks` for a stock token) and follow its prepare → simulate → commit flow. These rules come first.

## The right contract
- Pass a 0x address to the swap tool, never a ticker. A contract the user pasted is the token.
- USDG, WETH, ETH and the majors: `lifi_get_quote` resolves the ticker. Stock tokens: `resolve_robinhood_stock_token`. A memecoin ticker: `hoodit_find`.
- Ask which one only when there are two real candidates (both liquid). Copies with a few hundred dollars of liquidity aren't candidates; don't list them.

## Before a buy
- Memecoin or small coin: read `hoodit_token` unless you have a card from the last few minutes. `exit_check.result` `trap`, `security.honeypot: yes` or a sell tax over 10%: don't buy, say why. For a size bigger than the card's check, run `hoodit_exit` round_trip at that size; `loss_pct` over 10% means suggest a smaller size first.
- USDG, ETH, stock tokens and other liquid tokens: the LI.FI quote is the check. No meme research.
- If a route quotes, the coin can be traded; that's the test, not any label.
- The user's size is their call. If gas is more than the trade, say it in a few words inside the confirm line ("gas ~2¢, more than the buy") and still offer it.

## Before a sell
- Selling is always allowed: it's their bag. For a memecoin, quote it with `hoodit_exit` mode sell at `token_amount`; `loss_pct` over 10%: say so and offer to sell in parts. No route: say the router can't sell it now and don't prepare a swap.

## Slippage
Always pass `slippage_bps`: the user's number if given; otherwise 50 for USDG, ETH and stock tokens, 300 for memecoins with over $50k liquidity, 500 below that or on a curve. Above 500 only if the user agrees; never above 1000.

## Confirm, then commit
In Telegram a committed trade signs right away from the user's Hoodit wallet; there is no wallet popup to catch a mistake.
- After a passing simulation, send one line (coin, contract, amount in, expected and minimum out, slippage, gas if notable) and ask "go?".
- Amounts read like a person wrote them: "$5 of ETH (0.00195 ETH)", four significant digits, never 18 decimals.
- Gas is the LI.FI quote's `gas_costs` in dollars. The simulation's `observed_gas_cost` uses the test fork's gas price and overstates Robinhood Chain gas about 40×; never show it.
- Don't mention guard or safety "coverage"; say something only when the simulation fails or the host refuses.
- Commit only after the user's next message clearly says yes. Never ask and commit in the same reply.
- A changed coin, size or slippage, a vague reply, or a stale quote: re-quote and ask again.

## Withdrawals
"Send my X to 0x…" is a transfer from the Hoodit wallet. Confirm token, amount and the full destination address, say it can't be undone, and commit only after a clear yes. Never send to an address the user didn't write.

## Executing
- Pass chain_id 4663 on every staged call and quote: the Telegram wallet has no default chain, so don't stop because the wallet "isn't on Robinhood Chain". Native ETH is 0x0000000000000000000000000000000000000000.
- For a memecoin buy, add an exit plan in one line: where the idea is wrong (from the chart) and a time stop. Offer a watcher (`hoodit/watch`).
- Minimum output not met: say how far price moved if known, re-quote at the same tolerance and ask again. Raise the tolerance only if the user asks.
- Gas, balance, approval and stale-simulation failures aren't slippage: name the real cause in plain words.
- A trade is done only when the host reports the transaction; then give the amount and the explorer link it returned.

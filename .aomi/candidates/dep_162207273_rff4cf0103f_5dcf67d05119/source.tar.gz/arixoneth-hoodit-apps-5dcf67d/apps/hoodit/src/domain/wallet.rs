//! A wallet's record and bag: win rate, PnL and hold time from GMGN (the
//! audit found Codex's inflated: 78% vs 31% wins for the same KOL), the
//! bag from Codex (balances matched GMGN exactly).
use super::holders::tags;
use crate::providers::codex::Codex;
use crate::providers::gmgn::{Gmgn, types as gm};
use crate::providers::text;
use crate::runtime::{Fail, Runtime, Turn};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Period {
    Week,
    Month,
}

impl Period {
    fn gmgn(self) -> &'static str {
        match self {
            Period::Week => "7d",
            Period::Month => "30d",
        }
    }

    pub fn label(self) -> &'static str {
        self.gmgn()
    }
}

#[derive(Clone, Debug, Default, PartialEq)]
pub struct Record {
    pub realized_profit_usd: Option<f64>,
    pub realized_profit_pct: Option<f64>,
    pub win_rate_pct: Option<f64>,
    pub tokens: Option<f64>,
    pub buys: Option<f64>,
    pub sells: Option<f64>,
    pub avg_hold_min: Option<f64>,
    /// Closed tokens by outcome: under −50%, −50–0%, 0–2×, 2–5×, over 5×.
    pub outcomes: [Option<f64>; 5],
    pub last_trade_at: Option<i64>,
}

#[derive(Clone, Debug, PartialEq)]
pub struct Position {
    pub token: String,
    pub symbol: Option<String>,
    pub usd: f64,
    pub since: Option<i64>,
}

#[derive(Clone, Debug, PartialEq)]
pub struct Move {
    pub at: Option<i64>,
    pub side: String,
    pub token: String,
    pub symbol: Option<String>,
    pub usd: Option<f64>,
    pub closed_position: bool,
}

pub struct WalletView {
    pub wallet: String,
    pub name: Option<String>,
    pub twitter: Option<String>,
    pub tags: Vec<&'static str>,
    pub period: Period,
    pub record: Option<Record>,
    pub bag: Vec<Position>,
    pub recent: Vec<Move>,
}

pub async fn wallet(
    rt: &Runtime,
    turn: &Turn,
    wallet: &str,
    period: Period,
    with_trades: bool,
) -> Result<WalletView, Fail> {
    let gmgn = Gmgn::new(rt, turn);
    let (stats, bag, activity) = tokio::join!(
        gmgn.wallet_stats(wallet, period.gmgn()),
        Codex::new(rt, turn).balances(wallet),
        async {
            if with_trades {
                Some(gmgn.wallet_activity(wallet).await)
            } else {
                None
            }
        }
    );
    if let (Err(fail), Err(_)) = (&stats, &bag) {
        return Err(fail.clone());
    }
    let stats = match stats {
        Ok(s) => Some(s),
        Err(fail) => {
            turn.gap(format!("wallet record unavailable: {}", fail.message()));
            None
        }
    };
    let mut positions: Vec<Position> = match bag {
        Ok(items) => items
            .into_iter()
            .filter_map(|b| {
                let usd = b.balance_usd.get()?;
                (usd >= 1.0).then(|| Position {
                    token: b.token_address.to_ascii_lowercase(),
                    symbol: b.token.symbol,
                    usd,
                    since: b.first_held_timestamp.ts(),
                })
            })
            .collect(),
        Err(fail) => {
            turn.gap(format!("bag unavailable: {}", fail.message()));
            vec![]
        }
    };
    positions.sort_by(|a, b| b.usd.total_cmp(&a.usd));
    positions.truncate(10);
    let recent = match activity {
        Some(Ok(items)) => items.into_iter().take(10).map(move_of).collect(),
        Some(Err(fail)) => {
            turn.gap(format!("recent trades unavailable: {}", fail.message()));
            vec![]
        }
        None => vec![],
    };
    let common = stats.as_ref().map(|s| &s.common);
    Ok(WalletView {
        wallet: wallet.to_string(),
        name: common.and_then(|c| text(&c.twitter_name).or(text(&c.name)).map(str::to_string)),
        twitter: common.and_then(|c| text(&c.twitter_username).map(str::to_string)),
        tags: common.map(|c| tags(&[&c.tags])).unwrap_or_default(),
        period,
        record: stats.as_ref().map(record),
        bag: positions,
        recent,
    })
}

fn record(s: &gm::WalletStats) -> Record {
    let p = &s.pnl_stat;
    Record {
        realized_profit_usd: s.realized_profit.get(),
        realized_profit_pct: s.realized_profit_pnl.get().map(|r| r * 100.0),
        win_rate_pct: p.winrate.get().map(|r| r * 100.0),
        tokens: p.token_num.get(),
        buys: s.buy.get(),
        sells: s.sell.get(),
        avg_hold_min: p.avg_holding_period.get().map(|s| s / 60.0),
        outcomes: [
            p.pnl_lt_nd5_num.get(),
            p.pnl_nd5_0x_num.get(),
            p.pnl_0x_2x_num.get(),
            p.pnl_2x_5x_num.get(),
            p.pnl_gt_5x_num.get(),
        ],
        last_trade_at: s.last_timestamp.ts(),
    }
}

fn move_of(a: gm::Activity) -> Move {
    Move {
        at: a.timestamp.ts(),
        side: a.event_type,
        token: a.token.address.to_ascii_lowercase(),
        symbol: a.token.symbol,
        usd: a.cost_usd.get(),
        closed_position: a.is_open_or_close.get() == Some(1.0),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn gmgn_record_reads_win_rate_and_outcomes() {
        let text = std::fs::read_to_string(format!(
            "{}/src/fixtures/gmgn/wallet_stats.json",
            env!("CARGO_MANIFEST_DIR")
        ))
        .unwrap();
        let v: serde_json::Value = serde_json::from_str(&text).unwrap();
        let stats: gm::WalletStats = serde_json::from_value(v["data"].clone()).unwrap();
        let r = record(&stats);
        assert!((r.win_rate_pct.unwrap() - 76.19).abs() < 0.01);
        assert_eq!(r.outcomes[2], Some(32.0));
        assert!(r.realized_profit_usd.unwrap() < 0.0);
    }
}

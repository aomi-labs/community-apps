//! One module per data source. Each owns its auth, endpoints and response
//! types (only the fields Hoodit reads) and knows nothing about Hoodit's
//! rules. Every request goes through [`crate::runtime::Runtime::fetch`].
pub mod chain;
pub mod codex;
pub mod gmgn;
pub mod lifi;

use crate::runtime::{Fail, Source};
use serde::de::DeserializeOwned;
use serde::{Deserialize, Deserializer};
use serde_json::Value;

/// Robinhood Chain.
pub const CHAIN_ID: u64 = 4663;
pub const NATIVE: &str = "0x0000000000000000000000000000000000000000";
pub const WETH: &str = "0x0bd7d308f8e1639fab988df18a8011f41eacad73";

/// A provider number that may arrive as a JSON number, a string, or null.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Num(pub Option<f64>);

impl Num {
    pub fn get(self) -> Option<f64> {
        self.0
    }

    /// As a unix timestamp; 0 means unset.
    pub fn ts(self) -> Option<i64> {
        self.0.filter(|t| *t > 0.0).map(|t| t as i64)
    }
}

impl<'de> Deserialize<'de> for Num {
    fn deserialize<D: Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
        let value = Value::deserialize(d)?;
        Ok(Num(num(&value)))
    }
}

pub fn num(value: &Value) -> Option<f64> {
    match value {
        Value::Number(n) => n.as_f64(),
        Value::String(s) => s.trim().parse::<f64>().ok(),
        _ => None,
    }
    .filter(|v| v.is_finite())
}

/// A yes / no / unknown flag in any of the shapes GMGN uses for it
/// (`true`, `1`, `"yes"`, `"1"`; `-1` and null are unknown).
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Flag(pub Option<bool>);

impl Flag {
    pub fn get(self) -> Option<bool> {
        self.0
    }
}

impl<'de> Deserialize<'de> for Flag {
    fn deserialize<D: Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
        let value = Value::deserialize(d)?;
        Ok(Flag(match &value {
            Value::Bool(b) => Some(*b),
            Value::Number(n) => match n.as_i64() {
                Some(1) => Some(true),
                Some(0) => Some(false),
                _ => None,
            },
            Value::String(s) => match s.trim() {
                "yes" | "1" | "true" => Some(true),
                "no" | "0" | "false" => Some(false),
                _ => None,
            },
            _ => None,
        }))
    }
}

/// Decodes a provider response into its typed shape. Nulls are dropped
/// first, so a null anywhere reads as "missing" and takes the default
/// instead of failing the whole response.
pub fn parse<T: DeserializeOwned>(source: Source, value: Value) -> Result<T, Fail> {
    serde_json::from_value(drop_nulls(value))
        .map_err(|e| Fail::bad(source, format!("unexpected response shape: {e}")))
}

fn drop_nulls(value: Value) -> Value {
    match value {
        Value::Object(map) => Value::Object(
            map.into_iter()
                .filter(|(_, v)| !v.is_null())
                .map(|(k, v)| (k, drop_nulls(v)))
                .collect(),
        ),
        Value::Array(items) => Value::Array(items.into_iter().map(drop_nulls).collect()),
        other => other,
    }
}

/// A string that may be null; empty means unset.
pub fn text(value: &Option<String>) -> Option<&str> {
    value.as_deref().map(str::trim).filter(|s| !s.is_empty())
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    #[test]
    fn nulls_read_as_missing() {
        #[derive(Deserialize, Default)]
        #[serde(default)]
        struct Row {
            labels: Vec<String>,
            n: Num,
        }
        let row: Row = parse(Source::Codex, json!({ "labels": null, "n": null })).unwrap();
        assert!(row.labels.is_empty() && row.n.get().is_none());
        let rows: Vec<Row> = parse(Source::Codex, json!([{ "labels": ["BOT"] }])).unwrap();
        assert_eq!(rows[0].labels, ["BOT"]);
    }

    #[test]
    fn numbers_and_flags_parse_every_shape() {
        let n: Num = serde_json::from_value(json!("18.77")).unwrap();
        assert_eq!(n.get(), Some(18.77));
        let n: Num = serde_json::from_value(json!(null)).unwrap();
        assert_eq!(n.get(), None);
        for (raw, want) in [
            (json!(true), Some(true)),
            (json!(0), Some(false)),
            (json!(-1), None),
            (json!("yes"), Some(true)),
            (json!("no"), Some(false)),
            (json!(null), None),
        ] {
            let f: Flag = serde_json::from_value(raw).unwrap();
            assert_eq!(f.get(), want);
        }
    }
}

use super::{address, run};
use crate::domain::find::{Candidate, is_dust, search};
use crate::domain::token::{Depth, snapshot};
use crate::runtime::{Fail, HooditApp, Lane};
use aomi_sdk::schemars::JsonSchema;
use aomi_sdk::{DynAomiTool, DynToolCallCtx};
use serde::Deserialize;
use serde_json::{Value, json};

#[derive(Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct FindArgs {
    /// Ticker ("PRIORS", "$PRIORS"), name, or an exact 0x contract.
    pub query: String,
}

pub struct Find;

impl DynAomiTool for Find {
    type App = HooditApp;
    type Args = FindArgs;
    const NAME: &'static str = "hoodit_find";
    const DESCRIPTION: &'static str = "Resolve a ticker, name or exact 0x contract to Robinhood Chain tokens. A 0x address returns exactly that token or NOT_FOUND, never a substitute. A ticker returns candidate contracts, exact symbol matches first, then by holders, with KOL holder counts and honeypot flags to tell the real one from lookalikes.";

    fn run(app: &HooditApp, args: FindArgs, ctx: DynToolCallCtx) -> Result<Value, String> {
        run(app, &ctx, Lane::Chat, async |rt, turn| {
            let q = args.query.trim().trim_start_matches('$');
            if q.is_empty() || q.len() > 64 {
                return Err(Fail::Invalid("query must be 1–64 characters".into()));
            }
            if q.starts_with("0x") {
                let token = address(q)?;
                let s = snapshot(rt, turn, &token, Depth::Basic).await?;
                let exact = Candidate {
                    token: s.token,
                    symbol: s.symbol,
                    name: s.name,
                    launchpad: s.launchpad,
                    stage: s.stage,
                    created_at: s.created_at,
                    fdv_usd: s.fdv_usd,
                    liquidity_usd: s.liquidity_usd,
                    volume_1h_usd: None,
                    holders: s.holders,
                    kols: s.tagged.kol,
                    honeypot: None,
                    exact_symbol: true,
                };
                return Ok(
                    json!({ "match": "exact_address", "token": crate::view::token::candidate(&exact) }),
                );
            }
            let found = search(rt, turn, q).await?;
            if found.is_empty() {
                return Err(Fail::NotFound(
                    "no Robinhood Chain token matches that name".into(),
                ));
            }
            let same = found.iter().filter(|c| c.exact_symbol).count();
            let dust = found.iter().filter(|c| is_dust(c)).count();
            let shown: Vec<Value> = found
                .iter()
                .filter(|c| !is_dust(c))
                .take(5)
                .map(crate::view::token::candidate)
                .collect();
            Ok(json!({
                "query": q,
                "same_symbol_contracts": same,
                "dead_copies_hidden": dust,
                "ranked_by": "exact symbol, then holders (not proof of the official contract)",
                "candidates": shown,
            }))
        })
    }
}

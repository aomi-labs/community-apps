//! Admission control, one gate per provider. Every request asks its gate
//! before it goes out; a refusal turns into a stale answer or a gap.
use super::{Fail, Source};
use std::collections::{HashMap, VecDeque};
use std::sync::Mutex;
use std::time::{Duration, Instant};

/// Watch polls run in their own lane so they can never starve a chat.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum Lane {
    #[default]
    Chat,
    Watch,
}

/// GMGN's free plan is a leaky bucket of 5 weight draining 5 a second, per
/// IP; going over earns an IP ban that blocks every user on the host. We
/// drain at 70% of that.
const GMGN_RATE: f64 = 3.5;
const GMGN_CAPACITY: f64 = 5.0;
/// A chat call waits at most this long in the queue; longer means a gap.
const GMGN_MAX_WAIT: Duration = Duration::from_secs(2);
/// Weight a watch poll must leave free for chats.
const GMGN_WATCH_HEADROOM: f64 = 2.0;

/// Paid Codex requests one thread may make within [`CODEX_WINDOW`], about
/// one answer's worth. The host passes no turn id, so the thread is the unit.
pub const CODEX_PER_THREAD: usize = 16;
const CODEX_WINDOW: Duration = Duration::from_secs(120);
/// Paid Codex requests per host per UTC day (~$0.001 each), by lane.
const CODEX_DAILY_CHAT: u32 = 5000;
const CODEX_DAILY_WATCH: u32 = 1500;

/// Keyless LI.FI allows ~100 quotes per 2 h per IP; stay well under it.
const LIFI_KEYLESS_PER_HOUR: u32 = 40;

#[derive(Default)]
pub struct Gates {
    gmgn: Mutex<Bucket>,
    codex: Mutex<Spend>,
    lifi: Mutex<Option<(Instant, u32)>>,
}

struct Bucket {
    level: f64,
    at: Instant,
    paused_until: Option<Instant>,
}

impl Default for Bucket {
    fn default() -> Self {
        Self {
            level: 0.0,
            at: Instant::now(),
            paused_until: None,
        }
    }
}

#[derive(Default)]
struct Spend {
    day: i64,
    chat: u32,
    watch: u32,
    threads: HashMap<String, VecDeque<Instant>>,
}

/// What a request costs at its gate.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Cost {
    /// GMGN rate-limit weight.
    Gmgn(u32),
    /// One paid Codex request.
    Codex,
    /// One LI.FI quote; keyed quotes aren't paced here.
    Lifi {
        keyed: bool,
    },
    Free,
}

impl Cost {
    pub fn source(self) -> Option<Source> {
        match self {
            Cost::Gmgn(_) => Some(Source::Gmgn),
            Cost::Codex => Some(Source::Codex),
            Cost::Lifi { .. } => Some(Source::Lifi),
            Cost::Free => None,
        }
    }
}

impl Gates {
    /// Admits one request, returning how long to wait before sending it.
    pub fn admit(&self, cost: Cost, lane: Lane, thread: &str) -> Result<Duration, Fail> {
        let now = Instant::now();
        match cost {
            Cost::Gmgn(weight) => self.admit_gmgn(weight, lane, now),
            Cost::Codex => self
                .admit_codex(thread, lane, now, crate::view::now() / 86_400)
                .map(|()| Duration::ZERO),
            Cost::Lifi { keyed } => self.admit_lifi(keyed, now).map(|()| Duration::ZERO),
            Cost::Free => Ok(Duration::ZERO),
        }
    }

    /// Stops GMGN traffic until `retry_after_s` from now (a 429 or a ban).
    pub fn pause_gmgn(&self, retry_after_s: u64) {
        let Ok(mut bucket) = self.gmgn.lock() else {
            return;
        };
        let until = Instant::now() + Duration::from_secs(retry_after_s.max(2));
        bucket.paused_until = Some(bucket.paused_until.map_or(until, |p| p.max(until)));
    }

    fn admit_gmgn(&self, weight: u32, lane: Lane, now: Instant) -> Result<Duration, Fail> {
        let mut bucket = self
            .gmgn
            .lock()
            .map_err(|_| Fail::Budget("gmgn gate poisoned"))?;
        if let Some(until) = bucket.paused_until {
            if now < until {
                return Err(Fail::RateLimited {
                    source: Source::Gmgn,
                    retry_after_s: (until - now).as_secs().max(1),
                });
            }
            bucket.paused_until = None;
        }
        let elapsed = now.saturating_duration_since(bucket.at).as_secs_f64();
        let level = (bucket.level - GMGN_RATE * elapsed).max(0.0);
        let after = level + weight as f64;
        let wait = Duration::from_secs_f64(((after - GMGN_CAPACITY) / GMGN_RATE).max(0.0));
        let refused = match lane {
            Lane::Chat => wait > GMGN_MAX_WAIT,
            Lane::Watch => after > GMGN_CAPACITY - GMGN_WATCH_HEADROOM,
        };
        if refused {
            return Err(Fail::Budget("gmgn request queue is full right now"));
        }
        bucket.level = after;
        bucket.at = now;
        Ok(wait)
    }

    fn admit_codex(&self, thread: &str, lane: Lane, now: Instant, today: i64) -> Result<(), Fail> {
        let mut spend = self
            .codex
            .lock()
            .map_err(|_| Fail::Budget("codex gate poisoned"))?;
        if spend.day != today {
            *spend = Spend {
                day: today,
                ..Spend::default()
            };
        }
        spend.threads.retain(|_, calls| {
            while calls
                .front()
                .is_some_and(|t| now.duration_since(*t) > CODEX_WINDOW)
            {
                calls.pop_front();
            }
            !calls.is_empty()
        });
        let (used, cap) = match lane {
            Lane::Chat => (spend.chat, CODEX_DAILY_CHAT),
            Lane::Watch => (spend.watch, CODEX_DAILY_WATCH),
        };
        if used >= cap {
            return Err(Fail::Budget("daily market-data budget used up"));
        }
        let recent = spend.threads.get(thread).map_or(0, VecDeque::len);
        if lane == Lane::Chat && recent >= CODEX_PER_THREAD {
            return Err(Fail::Budget("this answer's market-data budget is used up"));
        }
        match lane {
            Lane::Chat => spend.chat += 1,
            Lane::Watch => spend.watch += 1,
        }
        spend
            .threads
            .entry(thread.to_string())
            .or_default()
            .push_back(now);
        Ok(())
    }

    fn admit_lifi(&self, keyed: bool, now: Instant) -> Result<(), Fail> {
        if keyed {
            return Ok(());
        }
        let mut window = self
            .lifi
            .lock()
            .map_err(|_| Fail::Budget("quote gate poisoned"))?;
        let (start, used) = window.get_or_insert((now, 0));
        if now.duration_since(*start) >= Duration::from_secs(3600) {
            *start = now;
            *used = 0;
        }
        if *used >= LIFI_KEYLESS_PER_HOUR {
            return Err(Fail::RateLimited {
                source: Source::Lifi,
                retry_after_s: 600,
            });
        }
        *used += 1;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn gmgn_paces_and_queues_briefly() {
        let gates = Gates::default();
        let t0 = Instant::now();
        // Fills the 5-weight bucket without waiting.
        assert_eq!(gates.admit_gmgn(3, Lane::Chat, t0).unwrap(), Duration::ZERO);
        assert_eq!(gates.admit_gmgn(2, Lane::Chat, t0).unwrap(), Duration::ZERO);
        // The next 3 waits 3 / 3.5 s for the bucket to drain.
        let wait = gates.admit_gmgn(3, Lane::Chat, t0).unwrap();
        assert!((wait.as_secs_f64() - 3.0 / 3.5).abs() < 1e-6);
        // Past two seconds of queue the call is refused, not queued.
        assert!(gates.admit_gmgn(5, Lane::Chat, t0).is_err());
        // After draining, it goes again.
        let later = t0 + Duration::from_secs(5);
        assert_eq!(
            gates.admit_gmgn(5, Lane::Chat, later).unwrap(),
            Duration::ZERO
        );
    }

    #[test]
    fn watch_polls_leave_room_for_chat() {
        let gates = Gates::default();
        let t0 = Instant::now();
        assert!(gates.admit_gmgn(1, Lane::Watch, t0).is_ok());
        assert!(gates.admit_gmgn(2, Lane::Chat, t0).is_ok());
        // 3 of 5 used: a watch poll would leave less than 2 for chat.
        assert!(gates.admit_gmgn(1, Lane::Watch, t0).is_err());
        assert!(gates.admit_gmgn(2, Lane::Chat, t0).is_ok());
    }

    #[test]
    fn a_pause_refuses_until_reset() {
        let gates = Gates::default();
        gates.pause_gmgn(30);
        let err = gates.admit_gmgn(1, Lane::Chat, Instant::now()).unwrap_err();
        assert!(matches!(err, Fail::RateLimited { retry_after_s, .. } if retry_after_s >= 29));
        let later = Instant::now() + Duration::from_secs(31);
        assert!(gates.admit_gmgn(1, Lane::Chat, later).is_ok());
    }

    #[test]
    fn codex_budget_is_per_thread_window_and_refusals_are_free() {
        let gates = Gates::default();
        let t0 = Instant::now();
        for _ in 0..CODEX_PER_THREAD {
            gates.admit_codex("a", Lane::Chat, t0, 1).unwrap();
        }
        assert!(gates.admit_codex("a", Lane::Chat, t0, 1).is_err());
        assert!(gates.admit_codex("a", Lane::Chat, t0, 1).is_err());
        // Refusals didn't count against the day.
        assert_eq!(gates.codex.lock().unwrap().chat, CODEX_PER_THREAD as u32);
        assert!(gates.admit_codex("b", Lane::Chat, t0, 1).is_ok());
        // The thread's window slides.
        let later = t0 + CODEX_WINDOW + Duration::from_secs(1);
        assert!(gates.admit_codex("a", Lane::Chat, later, 1).is_ok());
        // Watch polls have their own daily count and no thread window.
        for _ in 0..30 {
            gates.admit_codex("w", Lane::Watch, later, 1).unwrap();
        }
    }

    #[test]
    fn keyless_quotes_are_paced() {
        let gates = Gates::default();
        let t0 = Instant::now();
        for _ in 0..LIFI_KEYLESS_PER_HOUR {
            gates.admit_lifi(false, t0).unwrap();
        }
        assert!(gates.admit_lifi(false, t0).is_err());
        assert!(gates.admit_lifi(true, t0).is_ok());
    }
}

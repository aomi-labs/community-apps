//! Who is buying and selling: dollar windows from GMGN (one definition of
//! flow), wallet breadth and the actual trades from Codex's pool events
//! across the busiest pools, with KOL and smart wallets marked.
use super::signals::{WalletKind, known_wallets};
use super::token::{Flow, TokenSnapshot, Window};
use crate::providers::codex::{Codex, types::Pool};
use crate::providers::gmgn::Gmgn;
use crate::runtime::{Fail, Runtime, Turn};
use std::collections::{HashMap, HashSet};

/// Unique wallets and dollars in the last hour, summed over the pools
/// where the coin is the traded side (a wallet in two pools counts twice).
#[derive(Clone, Debug, Default, PartialEq)]
pub struct Breadth {
    pub pools: usize,
    pub buyers_1h: f64,
    pub sellers_1h: f64,
    pub buy_usd_1h: f64,
    pub sell_usd_1h: f64,
    /// Pool ids, busiest in the last hour first.
    pub busiest: Vec<String>,
}

pub fn breadth(pools: &[Pool], token: &str) -> Option<Breadth> {
    let mut out = Breadth::default();
    let mut ranked: Vec<(f64, String)> = vec![];
    for pool in pools {
        if !pool.traded().is_some_and(|t| t.eq_ignore_ascii_case(token)) {
            continue;
        }
        out.pools += 1;
        let (buy, sell) = (
            pool.buy_volume_usd1.get().unwrap_or(0.0),
            pool.sell_volume_usd1.get().unwrap_or(0.0),
        );
        out.buy_usd_1h += buy;
        out.sell_usd_1h += sell;
        out.buyers_1h += pool.unique_buys1.get().unwrap_or(0.0);
        out.sellers_1h += pool.unique_sells1.get().unwrap_or(0.0);
        if let Some(id) = &pool.pair.address {
            ranked.push((buy + sell, id.clone()));
        }
    }
    ranked.sort_by(|a, b| b.0.total_cmp(&a.0));
    out.busiest = ranked.into_iter().map(|(_, id)| id).collect();
    (out.pools > 0).then_some(out)
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, serde::Serialize)]
#[serde(rename_all = "snake_case")]
pub enum Side {
    Buy,
    Sell,
}

#[derive(Clone, Debug, PartialEq)]
pub struct TradeRow {
    pub side: Side,
    pub usd: f64,
    pub wallet: String,
    pub at: Option<i64>,
    /// Codex wallet labels (e.g. SMART_TRADER, BOT).
    pub labels: Vec<String>,
    /// KOL or smart-money per GMGN's feeds, with a name when known.
    pub tag: Option<(WalletKind, Option<String>)>,
}

pub struct Tape {
    pub symbol: Option<String>,
    pub windows: Vec<(Window, Flow)>,
    pub breadth: Option<Breadth>,
    pub largest: Vec<TradeRow>,
    pub sampled: usize,
    pub sampled_pools: usize,
    /// Minutes the busiest pool's recent sample reaches back.
    pub busiest_pool_covers_min: Option<i64>,
    pub top_seller_share_pct: Option<f64>,
}

pub struct Query {
    pub side: Option<Side>,
    pub min_usd: f64,
    pub limit: usize,
}

pub async fn tape(rt: &Runtime, turn: &Turn, token: &str, q: &Query) -> Result<Tape, Fail> {
    let codex = Codex::new(rt, turn);
    let (info, pools, known) = tokio::join!(
        Gmgn::new(rt, turn).token_info(token),
        codex.pools(token, 25),
        known_wallets(rt, turn)
    );
    let snap = info
        .ok()
        .filter(|i| !i.address.is_empty())
        .map(TokenSnapshot::from_gmgn);
    let breadth = pools.as_ref().ok().and_then(|p| breadth(p, token));
    if snap.is_none() && breadth.is_none() {
        return Err(pools.err().unwrap_or(Fail::NotFound(
            "no Robinhood Chain market indexed for this exact contract".into(),
        )));
    }
    let windows = match &snap {
        Some(s) => s.flow.clone(),
        None => {
            turn.gap("gmgn flow unavailable; 1h window summed from codex pools");
            let b = breadth.as_ref().expect("checked above");
            vec![(
                Window::H1,
                Flow {
                    buy_usd: Some(b.buy_usd_1h),
                    sell_usd: Some(b.sell_usd_1h),
                    buys: None,
                    sells: None,
                },
            )]
        }
    };
    let busiest: Vec<String> = match &breadth {
        Some(b) if !b.busiest.is_empty() => b.busiest.iter().take(3).cloned().collect(),
        _ => vec![token.to_string()],
    };
    let (buys, sells) = match q.side {
        Some(Side::Buy) => (true, false),
        Some(Side::Sell) => (false, true),
        None => (true, true),
    };
    let (recent, large) = match codex
        .events(&busiest, buys, sells, q.min_usd, q.min_usd.max(1000.0))
        .await
    {
        Ok(found) => found,
        Err(fail) => {
            turn.gap(format!("trade sample unavailable: {}", fail.message()));
            (vec![], vec![])
        }
    };
    let now = crate::view::now();
    // Recent events come back pool by pool, newest first; the first pool is
    // the busiest, so its span is the honest coverage figure.
    let busiest_pool_covers_min = recent
        .iter()
        .take(60)
        .filter_map(|e| e.timestamp.ts())
        .min()
        .map(|t| (now - t) / 60);
    let mut seen = HashSet::new();
    let mut rows: Vec<TradeRow> = vec![];
    let mut sold: HashMap<String, f64> = HashMap::new();
    for e in recent.iter().chain(large.iter()) {
        let id = format!(
            "{}:{}:{}",
            e.transaction_hash, e.maker, e.event_display_type
        );
        if !seen.insert(id) {
            continue;
        }
        let side = if e.event_display_type == "Sell" {
            Side::Sell
        } else {
            Side::Buy
        };
        let usd = e.data.price_usd_total.get().unwrap_or(0.0);
        let wallet = e.maker.to_ascii_lowercase();
        if side == Side::Sell {
            *sold.entry(wallet.clone()).or_default() += usd;
        }
        rows.push(TradeRow {
            side,
            usd,
            tag: known.get(&wallet).cloned(),
            wallet,
            at: e.timestamp.ts(),
            labels: short_labels(&e.wallet_labels),
        });
    }
    let sampled = rows.len();
    let sold_total: f64 = sold.values().sum();
    let top_seller = sold.values().copied().fold(0.0, f64::max);
    rows.sort_by(|a, b| b.usd.total_cmp(&a.usd));
    rows.truncate(q.limit);
    Ok(Tape {
        symbol: snap.as_ref().and_then(|s| s.symbol.clone()),
        windows,
        breadth,
        largest: rows,
        sampled,
        sampled_pools: busiest.len(),
        busiest_pool_covers_min,
        top_seller_share_pct: (sold_total > 0.0).then(|| top_seller / sold_total * 100.0),
    })
}

/// Codex labels such as SMART_TRADER_TOKENS_UNDER_TWO_DAYS_OLD, shortened
/// and deduplicated.
fn short_labels(raw: &[String]) -> Vec<String> {
    let mut out: Vec<String> = raw
        .iter()
        .map(|l| {
            let l = l.to_ascii_lowercase();
            if l.starts_with("smart_trader") {
                "smart_trader".to_string()
            } else {
                l
            }
        })
        .collect();
    out.sort();
    out.dedup();
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    #[test]
    fn breadth_sums_only_pools_trading_the_token() {
        let pools: Vec<Pool> = serde_json::from_value(json!([
            { "quoteToken": "token0", "pair": { "address": "0xp1", "token0": "0xAA", "token1": "0xbb" },
              "buyVolumeUSD1": "100", "sellVolumeUSD1": "40", "uniqueBuys1": 5, "uniqueSells1": 2 },
            { "quoteToken": "token1", "pair": { "address": "0xp2", "token0": "0xcc", "token1": "0xaa" },
              "buyVolumeUSD1": "500", "sellVolumeUSD1": "10", "uniqueBuys1": 3, "uniqueSells1": 1 },
            { "quoteToken": "token0", "pair": { "address": "0xp3", "token0": "0xdd", "token1": "0xaa" },
              "buyVolumeUSD1": "999", "sellVolumeUSD1": "999", "uniqueBuys1": 99, "uniqueSells1": 99 }
        ]))
        .unwrap();
        let b = breadth(&pools, "0xaa").unwrap();
        assert_eq!(b.pools, 2);
        assert_eq!((b.buyers_1h, b.sellers_1h), (8.0, 3.0));
        assert_eq!(b.busiest, ["0xp2", "0xp1"]);
    }

    #[test]
    fn labels_are_short() {
        let raw = [
            "SMART_TRADER_TOKENS_OVER_TWO_DAYS_OLD",
            "SMART_TRADER_TOKENS_UNDER_TWO_DAYS_OLD",
            "SNIPER",
        ];
        let raw: Vec<String> = raw.iter().map(|s| s.to_string()).collect();
        assert_eq!(short_labels(&raw), ["smart_trader", "sniper"]);
    }
}

//! Who holds a coin. The plain list comes from Codex (it matched GMGN's
//! exactly in the audit at a fraction of the cost); names, tags and PnL
//! come from GMGN when asked for; the dev's launch record is GMGN's.
use super::signals::{WalletKind, known_wallets};
use super::token::{Depth, snapshot};
use crate::providers::chain::Chain;
use crate::providers::codex::Codex;
use crate::providers::gmgn::{Gmgn, types as gm};
use crate::providers::text;
use crate::runtime::{Fail, Runtime, Turn};

/// Contracts that hold supply without being a trader.
const KNOWN: &[(&str, &str)] = &[
    (
        "0x8366a39cc670b4001a1121b8f6a443a643e40951",
        "uniswap v4 pool",
    ),
    ("0x267444d099b10fb5ed7c3cc7b7c767adca574952", "pons locker"),
    ("0xe5e702641ea86f4ae6cc3cdaed2b886f976be044", "pons hook"),
    (
        "0xd3afeb2a57f70ef218aa82451c51b2fb0416ac9e",
        "pons fee escrow",
    ),
    ("0x000000000000000000000000000000000000dead", "burn"),
    (crate::providers::NATIVE, "burn"),
];

/// GMGN wallet tags worth showing, in our words.
fn tag(raw: &str) -> Option<&'static str> {
    Some(match raw {
        "renowned" | "kol" => "kol",
        "smart_degen" => "smart",
        "sniper" => "sniper",
        "bundler" => "bundler",
        "whale" => "whale",
        "fresh_wallet" => "fresh",
        "rat_trader" => "rat",
        "sandwich_bot" | "bot" => "bot",
        "dev" | "creator" => "dev",
        "insider" => "insider",
        "fomo" => "fomo_user",
        _ => return None,
    })
}

pub fn tags(lists: &[&[String]]) -> Vec<&'static str> {
    let mut out: Vec<&'static str> = lists
        .iter()
        .flat_map(|l| l.iter())
        .filter_map(|t| tag(t))
        .collect();
    out.sort_unstable();
    out.dedup();
    out
}

pub fn contract_label(address: &str) -> Option<&'static str> {
    KNOWN
        .iter()
        .find(|(a, _)| a.eq_ignore_ascii_case(address))
        .map(|(_, l)| *l)
}

#[derive(Clone, Debug, PartialEq)]
pub struct HolderRow {
    pub wallet: String,
    /// A known contract (pool, locker, curve) or "dev".
    pub label: Option<&'static str>,
    pub tags: Vec<&'static str>,
    pub name: Option<String>,
    pub twitter: Option<String>,
    pub pct: Option<f64>,
    pub usd: Option<f64>,
    pub since: Option<i64>,
    pub unrealized_usd: Option<f64>,
    pub realized_usd: Option<f64>,
    pub bought_usd: Option<f64>,
    pub sold_usd: Option<f64>,
}

pub struct Top {
    pub symbol: Option<String>,
    pub holders: Option<f64>,
    pub top10_pct: Option<f64>,
    pub rows: Vec<HolderRow>,
}

/// The biggest holders, with contracts labelled and KOL or smart wallets
/// marked from the trade feeds.
pub async fn top(rt: &Runtime, turn: &Turn, token: &str) -> Result<Top, Fail> {
    let (list, snap, known) = tokio::join!(
        Codex::new(rt, turn).holders(token, 12),
        snapshot(rt, turn, token, Depth::Basic),
        known_wallets(rt, turn)
    );
    let list = list?;
    let snap = snap.ok();
    let chain = Chain::new(rt, turn);
    let launch = chain.pons(token).await.ok().flatten();
    let dev = super::pons::dev(
        &chain,
        launch.as_ref(),
        snap.as_ref().and_then(|s| s.creator.as_deref()),
    )
    .await;
    let shown: Vec<_> = list.items.iter().take(10).collect();
    let addresses: Vec<String> = shown
        .iter()
        .map(|h| h.address.to_ascii_lowercase())
        .collect();
    let contracts = chain.contracts(&addresses).await;
    let supply = list.supply.filter(|s| *s > 0.0);
    let rows = shown
        .iter()
        .zip(addresses.iter().zip(contracts))
        .map(|(h, (address, contract))| {
            let label = contract_label(address)
                .or_else(|| {
                    (Some(address) == launch.as_ref().map(|l| &l.curve)).then_some("pons curve")
                })
                .or_else(|| (list.pool.as_deref() == Some(address.as_str())).then_some("pool"))
                .or_else(|| (dev.as_ref().map(|d| &d.wallet) == Some(address)).then_some("dev"))
                .or_else(|| (contract == Some(true)).then_some("smart account or contract"));
            let marked = known.get(address);
            HolderRow {
                wallet: address.clone(),
                label,
                tags: marked
                    .map(|(kind, _)| {
                        vec![if *kind == WalletKind::Kol {
                            "kol"
                        } else {
                            "smart"
                        }]
                    })
                    .unwrap_or_default(),
                name: marked.and_then(|(_, name)| name.clone()),
                twitter: None,
                pct: supply
                    .zip(h.shifted_balance.get())
                    .map(|(s, b)| b / s * 100.0),
                usd: h.balance_usd.get(),
                since: h.first_held_timestamp.ts(),
                unrealized_usd: None,
                realized_usd: None,
                bought_usd: None,
                sold_usd: None,
            }
        })
        .collect();
    Ok(Top {
        symbol: list.symbol.or(snap.as_ref().and_then(|s| s.symbol.clone())),
        holders: snap.as_ref().and_then(|s| s.holders).or(list.count),
        top10_pct: snap.as_ref().and_then(|s| s.top10_pct),
        rows,
    })
}

/// GMGN's holder list with tags, names and PnL; `only` keeps one kind.
pub async fn labelled(
    rt: &Runtime,
    turn: &Turn,
    token: &str,
    only: Option<&str>,
) -> Result<Vec<HolderRow>, Fail> {
    let rows = Gmgn::new(rt, turn).top_holders(token, only).await?;
    Ok(rows
        .into_iter()
        .filter(|h| h.addr_type.get() != Some(2.0))
        .map(gmgn_row)
        .collect())
}

/// The most profitable traders of the coin (GMGN).
pub async fn traders(rt: &Runtime, turn: &Turn, token: &str) -> Result<Vec<HolderRow>, Fail> {
    let rows = Gmgn::new(rt, turn).top_traders(token).await?;
    Ok(rows
        .into_iter()
        .filter(|h| h.addr_type.get() != Some(2.0))
        .map(gmgn_row)
        .collect())
}

fn gmgn_row(h: gm::Holder) -> HolderRow {
    let address = h.address.to_ascii_lowercase();
    HolderRow {
        label: contract_label(&address),
        tags: tags(&[&h.tags, &h.maker_token_tags]),
        name: text(&h.twitter_name)
            .or(text(&h.name))
            .map(|s| s.chars().take(24).collect()),
        twitter: text(&h.twitter_username).map(str::to_string),
        pct: h.amount_percentage.get().map(|r| r * 100.0),
        usd: h.usd_value.get(),
        since: h.start_holding_at.ts(),
        unrealized_usd: h.unrealized_profit.get(),
        realized_usd: h.realized_profit.get(),
        bought_usd: h.buy_volume_cur.get(),
        sold_usd: h.sell_volume_cur.get(),
        wallet: address,
    }
}

pub struct Launch {
    pub token: String,
    pub symbol: Option<String>,
    pub created_at: Option<i64>,
    pub graduated: Option<bool>,
    pub fdv_usd: Option<f64>,
    pub ath_fdv_usd: Option<f64>,
    pub holders: Option<f64>,
}

pub struct DevRecord {
    pub wallet: String,
    pub source: &'static str,
    pub holds_pct: Option<f64>,
    pub sold_out: Option<bool>,
    pub graduated: Option<f64>,
    pub launches: Vec<Launch>,
}

/// The dev wallet, what it still holds, and its launches.
pub async fn dev(rt: &Runtime, turn: &Turn, token: &str) -> Result<DevRecord, Fail> {
    let snap = snapshot(rt, turn, token, Depth::Card).await?;
    let Some(dev) = snap.dev.clone() else {
        return Err(Fail::NotFound("dev wallet unknown for this token".into()));
    };
    let gmgn_dev = snap.creator.as_deref() == Some(dev.wallet.as_str());
    let (created, holds_pct) =
        tokio::join!(Gmgn::new(rt, turn).created_tokens(&dev.wallet), async {
            if gmgn_dev && snap.mix.dev_pct.is_some() {
                return snap.mix.dev_pct;
            }
            let supply = snap
                .fdv_usd
                .zip(snap.price_usd)
                .filter(|(_, p)| *p > 0.0)
                .map(|(f, p)| f / p)?;
            let chain = Chain::new(rt, turn);
            let (balance, decimals) =
                tokio::join!(chain.balance(token, &dev.wallet), chain.decimals(token));
            let held = balance.ok()? as f64 / 10f64.powi(decimals.ok()? as i32);
            Some(held / supply * 100.0)
        });
    let (graduated, launches) = match created {
        Ok(c) => (
            c.open_count.get(),
            c.tokens
                .into_iter()
                .take(10)
                .map(|t| Launch {
                    token: t.token_address.to_ascii_lowercase(),
                    symbol: t.symbol,
                    created_at: t.create_timestamp.ts(),
                    graduated: t.is_open.get(),
                    fdv_usd: t.market_cap.get(),
                    ath_fdv_usd: t.token_ath_mc.get(),
                    holders: t.holders.get(),
                })
                .collect(),
        ),
        Err(fail) => {
            turn.gap(format!(
                "dev launch history unavailable: {}",
                fail.message()
            ));
            (None, vec![])
        }
    };
    Ok(DevRecord {
        wallet: dev.wallet,
        source: dev.source,
        holds_pct,
        sold_out: if gmgn_dev { snap.dev_sold_out } else { None },
        graduated,
        launches,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn gmgn_holders_carry_names_and_tags_and_skip_pools() {
        let text = std::fs::read_to_string(format!(
            "{}/src/fixtures/gmgn/holders_vrax_smart.json",
            env!("CARGO_MANIFEST_DIR")
        ))
        .unwrap();
        let v: serde_json::Value = serde_json::from_str(&text).unwrap();
        let rows: Vec<gm::Holder> = serde_json::from_value(v["data"]["list"].clone()).unwrap();
        let rows: Vec<HolderRow> = rows.into_iter().map(gmgn_row).collect();
        let hitman = rows
            .iter()
            .find(|r| r.name.as_deref() == Some("Hitman 80"))
            .unwrap();
        assert!(hitman.tags.contains(&"smart"));
        assert_eq!(hitman.twitter.as_deref(), Some("Hitman0611"));
        assert_eq!(
            contract_label("0x267444D099B10FB5ED7C3CC7B7C767ADCA574952"),
            Some("pons locker")
        );
        assert_eq!(
            tags(&[&["smart_degen".into(), "gmgn".into()], &["bundler".into()]]),
            ["bundler", "smart"]
        );
    }
}

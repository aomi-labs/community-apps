//! Can a size get out? Live LI.FI quotes: a round trip (buy, then sell the
//! tokens straight back) or a sell, with one loss definition and one
//! verdict scale for both and for the small probe on every card.
use super::amount;
use crate::providers::chain::Chain;
use crate::providers::codex::Codex;
use crate::providers::lifi::{Lifi, Quote};
use crate::providers::{NATIVE, WETH};
use crate::runtime::{Fail, Runtime, Turn};
use num_bigint::BigUint;
use serde::{Deserialize, Serialize};
use std::time::Duration;

/// Quotes come from this address when the user has no wallet connected;
/// LI.FI prices a route without moving funds.
const NEUTRAL: &str = "0x0bf3e6f5ef3d32dccce208a1dd8fa9251893dd91";
pub const THIN_PCT: f64 = 10.0;
const TRAP_PCT: f64 = 50.0;
/// The round trip quoted on every card.
pub const PROBE_ETH: &str = "0.01";
const PROBE_TTL: Duration = Duration::from_secs(120);

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ExitResult {
    Ok,
    /// Loses more than 10%: size down.
    Thin,
    /// No sell route, or more than half lost: no way back out.
    Trap,
    NoBuyRoute,
    Unknown,
}

impl ExitResult {
    pub fn of(sell: Option<&Result<Quote, Fail>>, loss_pct: Option<f64>) -> Self {
        match (sell, loss_pct) {
            (Some(Err(Fail::NoRoute(_))), _) => ExitResult::Trap,
            (_, Some(l)) if l > TRAP_PCT => ExitResult::Trap,
            (_, Some(l)) if l > THIN_PCT => ExitResult::Thin,
            (_, Some(_)) => ExitResult::Ok,
            _ => ExitResult::Unknown,
        }
    }
}

/// Where a sell was quoted from.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum QuotedFrom {
    YourWallet,
    NeutralAddress,
    /// Curve sells only quote from a wallet that holds the token.
    AHolder,
}

pub struct RoundTrip {
    pub eth_in: String,
    pub buy: Result<Quote, Fail>,
    pub tokens: Option<BigUint>,
    pub decimals: u8,
    pub sell: Option<Result<Quote, Fail>>,
    pub sold_from: Option<QuotedFrom>,
    pub eth_back: Option<f64>,
    pub loss_pct: Option<f64>,
    pub result: ExitResult,
}

pub struct Sale {
    pub tokens_in: BigUint,
    pub decimals: u8,
    pub sell: Result<Quote, Fail>,
    pub sold_from: QuotedFrom,
    pub eth_out: Option<f64>,
    pub eth_min_out: Option<f64>,
    pub value_usd: Option<f64>,
    /// ETH out vs the tokens' value at the current price.
    pub loss_pct: Option<f64>,
    pub result: ExitResult,
}

/// The small round trip on every card, cached per token.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct Probe {
    pub eth_in: String,
    pub loss_pct: Option<f64>,
    pub no_sell_route: bool,
    pub result: ExitResult,
}

#[derive(Clone, Copy)]
pub struct Exits<'a> {
    rt: &'a Runtime,
    turn: &'a Turn,
}

impl<'a> Exits<'a> {
    pub fn new(rt: &'a Runtime, turn: &'a Turn) -> Self {
        Self { rt, turn }
    }

    pub async fn probe(self, token: &str) -> Probe {
        let key = format!("probe:{token}");
        if let Some(hit) = self.rt.cache.fresh(&key)
            && let Ok(probe) = serde_json::from_value::<Probe>(hit)
        {
            return probe;
        }
        let probe = match self.round_trip(token, PROBE_ETH, 0.1).await {
            Ok(trip) => Probe {
                eth_in: PROBE_ETH.into(),
                loss_pct: trip.loss_pct,
                no_sell_route: matches!(trip.sell, Some(Err(Fail::NoRoute(_)))),
                result: trip.result,
            },
            Err(_) => Probe {
                eth_in: PROBE_ETH.into(),
                loss_pct: None,
                no_sell_route: false,
                result: ExitResult::Unknown,
            },
        };
        if probe.result != ExitResult::Unknown
            && let Ok(value) = serde_json::to_value(&probe)
        {
            self.rt.cache.put(key, value, PROBE_TTL);
        }
        probe
    }

    pub async fn round_trip(
        self,
        token: &str,
        eth: &str,
        slippage: f64,
    ) -> Result<RoundTrip, Fail> {
        let wei = amount::from_decimal(eth, 18).map_err(Fail::Invalid)?;
        let decimals = Chain::new(self.rt, self.turn).decimals(token).await?;
        let from = self.turn.wallet.as_deref().unwrap_or(NEUTRAL);
        let buy = Lifi::new(self.rt, self.turn)
            .quote(NATIVE, token, &wei.to_string(), from, slippage)
            .await;
        let tokens = buy
            .as_ref()
            .ok()
            .and_then(|q| q.to_amount.parse::<BigUint>().ok());
        let (sell, sold_from) = match &tokens {
            Some(got) => {
                let (sell, from) = self.sell_quote(token, got, slippage).await;
                (Some(sell), Some(from))
            }
            None => (None, None),
        };
        let eth_in = units(&wei, 18);
        let eth_back = sell
            .as_ref()
            .and_then(|s| s.as_ref().ok())
            .and_then(|q| units_str(&q.to_amount, 18));
        let loss_pct = match (eth_in, eth_back) {
            (Some(i), Some(b)) if i > 0.0 => Some((1.0 - b / i) * 100.0),
            _ => None,
        };
        let result = match &buy {
            Err(Fail::NoRoute(_)) => ExitResult::NoBuyRoute,
            _ => ExitResult::of(sell.as_ref(), loss_pct),
        };
        Ok(RoundTrip {
            eth_in: eth.to_string(),
            buy,
            tokens,
            decimals,
            sell,
            sold_from,
            eth_back,
            loss_pct,
            result,
        })
    }

    /// Sells `tokens` for ETH. The loss compares ETH out with the tokens'
    /// value at the current price, so it needs both prices.
    pub async fn sell(self, token: &str, tokens: BigUint, slippage: f64) -> Result<Sale, Fail> {
        let decimals = Chain::new(self.rt, self.turn).decimals(token).await?;
        let ((eth_usd, token_usd), (sell, sold_from)) = tokio::join!(
            self.prices(token),
            self.sell_quote(token, &tokens, slippage)
        );
        let eth_out = sell.as_ref().ok().and_then(|q| units_str(&q.to_amount, 18));
        let eth_min_out = sell
            .as_ref()
            .ok()
            .and_then(|q| units_str(&q.to_amount_min, 18));
        let value_usd = token_usd.zip(units(&tokens, decimals)).map(|(p, t)| p * t);
        let loss_pct = match (eth_out, eth_usd, value_usd) {
            (Some(o), Some(p), Some(v)) if v > 0.0 => Some((1.0 - o * p / v) * 100.0),
            _ => None,
        };
        if loss_pct.is_none() && sell.is_ok() {
            self.turn
                .gap("prices unavailable, so the sell's loss is unknown");
        }
        let result = ExitResult::of(Some(&sell), loss_pct);
        Ok(Sale {
            tokens_in: tokens,
            decimals,
            sell,
            sold_from,
            eth_out,
            eth_min_out,
            value_usd,
            loss_pct,
            result,
        })
    }

    /// ETH and token prices in USD, one paid read.
    pub async fn prices(self, token: &str) -> (Option<f64>, Option<f64>) {
        let tokens = [token.to_string(), WETH.to_string()];
        let Ok(rows) = Codex::new(self.rt, self.turn).tokens(&tokens).await else {
            return (None, None);
        };
        let price = |address: &str| {
            rows.iter()
                .find(|r| r.token.address.eq_ignore_ascii_case(address))
                .and_then(|r| r.price_usd.get())
        };
        (price(WETH), price(token))
    }

    /// Quotes the sell from the user's wallet if it holds enough, else a
    /// neutral address, else (curve tokens only quote from a holder) a real
    /// holder wallet.
    async fn sell_quote(
        &self,
        token: &str,
        tokens: &BigUint,
        slippage: f64,
    ) -> (Result<Quote, Fail>, QuotedFrom) {
        let lifi = Lifi::new(self.rt, self.turn);
        let chain = Chain::new(self.rt, self.turn);
        let raw = tokens.to_string();
        let wanted = raw.parse::<u128>().unwrap_or(u128::MAX);
        if let Some(wallet) = &self.turn.wallet
            && chain
                .balance(token, wallet)
                .await
                .is_ok_and(|b| b >= wanted)
        {
            let quote = lifi.quote(token, NATIVE, &raw, wallet, slippage).await;
            return (quote, QuotedFrom::YourWallet);
        }
        let first = lifi.quote(token, NATIVE, &raw, NEUTRAL, slippage).await;
        if !matches!(first, Err(Fail::NoRoute(_))) {
            return (first, QuotedFrom::NeutralAddress);
        }
        let Ok(holders) = Codex::new(self.rt, self.turn).holders(token, 8).await else {
            return (first, QuotedFrom::NeutralAddress);
        };
        let addresses: Vec<String> = holders
            .items
            .iter()
            .map(|h| h.address.to_ascii_lowercase())
            .collect();
        let contracts = chain.contracts(&addresses).await;
        for (address, contract) in addresses.iter().zip(contracts) {
            if contract == Some(false)
                && chain
                    .balance(token, address)
                    .await
                    .is_ok_and(|b| b >= wanted)
            {
                let quote = lifi.quote(token, NATIVE, &raw, address, slippage).await;
                return (quote, QuotedFrom::AHolder);
            }
        }
        (first, QuotedFrom::NeutralAddress)
    }
}

fn units(value: &BigUint, decimals: u8) -> Option<f64> {
    units_str(&value.to_string(), decimals)
}

fn units_str(raw: &str, decimals: u8) -> Option<f64> {
    raw.parse::<f64>()
        .ok()
        .map(|v| v / 10f64.powi(decimals as i32))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn quote() -> Result<Quote, Fail> {
        Ok(Quote {
            to_amount: "1".into(),
            to_amount_min: "1".into(),
            route: vec![],
            fee_usd: None,
            gas_usd: None,
        })
    }

    #[test]
    fn one_verdict_scale() {
        let no_route: Result<Quote, Fail> = Err(Fail::NoRoute("none".into()));
        assert_eq!(ExitResult::of(Some(&no_route), None), ExitResult::Trap);
        assert_eq!(ExitResult::of(Some(&quote()), Some(95.0)), ExitResult::Trap);
        assert_eq!(ExitResult::of(Some(&quote()), Some(12.0)), ExitResult::Thin);
        assert_eq!(ExitResult::of(Some(&quote()), Some(3.0)), ExitResult::Ok);
        assert_eq!(ExitResult::of(None, None), ExitResult::Unknown);
    }

    #[test]
    fn probe_round_trips_through_the_cache() {
        let probe = Probe {
            eth_in: PROBE_ETH.into(),
            loss_pct: Some(4.2),
            no_sell_route: false,
            result: ExitResult::Ok,
        };
        let back: Probe = serde_json::from_value(serde_json::to_value(&probe).unwrap()).unwrap();
        assert_eq!(back, probe);
    }
}

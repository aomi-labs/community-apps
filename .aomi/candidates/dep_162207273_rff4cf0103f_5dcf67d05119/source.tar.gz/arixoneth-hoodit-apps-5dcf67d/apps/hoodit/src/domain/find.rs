//! Ticker or name → contracts. The same ticker on different contracts is
//! a different token; KOL counts and honeypot flags separate the real one
//! from lookalikes better than holders alone.
use super::market::{Stage, is_base_asset, launchpad};
use super::token::{TokenSnapshot, gmgn_stage};
use crate::providers::codex::Codex;
use crate::providers::gmgn::Gmgn;
use crate::runtime::{Fail, Runtime, Turn};

#[derive(Clone, Debug, PartialEq)]
pub struct Candidate {
    pub token: String,
    pub symbol: Option<String>,
    pub name: Option<String>,
    pub launchpad: Option<String>,
    pub stage: Stage,
    pub created_at: Option<i64>,
    pub fdv_usd: Option<f64>,
    pub liquidity_usd: Option<f64>,
    pub volume_1h_usd: Option<f64>,
    pub holders: Option<f64>,
    pub kols: Option<f64>,
    pub honeypot: Option<bool>,
    pub exact_symbol: bool,
}

/// Up to eight candidates, most holders first.
pub async fn search(rt: &Runtime, turn: &Turn, query: &str) -> Result<Vec<Candidate>, Fail> {
    let upper = query.to_ascii_uppercase();
    let exact = |symbol: &Option<String>| {
        symbol
            .as_deref()
            .is_some_and(|s| s.to_ascii_uppercase() == upper)
    };
    let mut out: Vec<Candidate> = match Gmgn::new(rt, turn).search(query).await {
        Ok(coins) => coins
            .into_iter()
            .map(|c| {
                let pad = launchpad(c.launchpad_platform.as_deref());
                Candidate {
                    stage: gmgn_stage(pad.is_some(), c.launchpad_status.get(), c.progress.get()),
                    exact_symbol: exact(&c.symbol),
                    token: c.address.to_ascii_lowercase(),
                    symbol: c.symbol,
                    name: c.name,
                    launchpad: pad,
                    created_at: c.created_at.ts(),
                    fdv_usd: c.mcp.get(),
                    liquidity_usd: c.liquidity.get(),
                    volume_1h_usd: c.volume_1h.get(),
                    holders: c.holder_count.get(),
                    kols: c.kol_count.get(),
                    honeypot: c.is_honeypot.get(),
                }
            })
            .collect(),
        Err(fail) if fail.stale_ok() || matches!(fail, Fail::Unconfigured(_)) => {
            turn.gap(format!(
                "{}; search from codex, without KOL counts",
                fail.message()
            ));
            Codex::new(rt, turn)
                .search(query)
                .await?
                .into_iter()
                .map(|row| {
                    let snap = TokenSnapshot::from_codex(row);
                    Candidate {
                        exact_symbol: exact(&snap.symbol),
                        token: snap.token,
                        symbol: snap.symbol,
                        name: snap.name,
                        launchpad: snap.launchpad,
                        stage: snap.stage,
                        created_at: snap.created_at,
                        fdv_usd: snap.fdv_usd,
                        liquidity_usd: snap.liquidity_usd,
                        volume_1h_usd: None,
                        holders: snap.holders,
                        kols: None,
                        honeypot: None,
                    }
                })
                .collect()
        }
        Err(fail) => return Err(fail),
    };
    out.retain(|c| !is_base_asset(&c.token, None) || c.exact_symbol);
    out.sort_by(|a, b| {
        b.exact_symbol.cmp(&a.exact_symbol).then(
            b.holders
                .unwrap_or(0.0)
                .total_cmp(&a.holders.unwrap_or(0.0)),
        )
    });
    Ok(out)
}

/// Copies with under $100 of liquidity and no trades in the last hour.
pub fn is_dust(c: &Candidate) -> bool {
    c.liquidity_usd.is_some_and(|l| l < 100.0) && c.volume_1h_usd.is_none_or(|v| v <= 0.0)
}

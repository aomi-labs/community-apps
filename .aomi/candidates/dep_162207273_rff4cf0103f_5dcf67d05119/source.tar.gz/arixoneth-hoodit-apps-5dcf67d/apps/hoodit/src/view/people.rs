//! People-shaped replies: who's buying, who holds, the dev, a wallet.
use super::{int, label, min_ago, pct, put_span, usd};
use crate::domain::holders::{DevRecord, HolderRow, Top};
use crate::domain::signals::{Buyer, Feed, SignalKind, WalletKind};
use crate::domain::wallet::WalletView;
use serde_json::{Map, Value, json};

pub fn signals(feed: &Feed, window_min: i64) -> Value {
    let coins: Vec<Value> = feed
        .coins
        .iter()
        .map(|c| {
            let buying = |kind| {
                c.buyers
                    .iter()
                    .filter(|b| b.kind == kind && b.buy_usd > 0.0)
                    .count()
            };
            // KOLs first, then named smart wallets; unnamed ones are counted.
            let named: Vec<Value> = c
                .buyers
                .iter()
                .filter(|b| b.kind == WalletKind::Kol || b.name.is_some())
                .take(4)
                .map(buyer)
                .collect();
            let events: Vec<Value> = c
                .events
                .iter()
                .take(3)
                .map(|e| {
                    let at = match e.fdv_usd {
                        Some(f) => format!(" at ${}", short_usd(f)),
                        None => String::new(),
                    };
                    json!(format!("{} {}m ago{at}", event_name(e.kind), minutes(e.at)))
                })
                .collect();
            json!({
                "symbol": label(c.symbol.as_deref(), 20),
                "token": c.token,
                "launchpad": c.launchpad,
                "kols_buying": buying(WalletKind::Kol),
                "smart_buying": buying(WalletKind::Smart),
                "still_holding": c.buyers.iter().filter(|b| b.holding == Some(true)).count(),
                "labelled_buy_usd": usd(Some(c.buy_usd()).filter(|v| *v > 0.0)),
                "labelled_sell_usd": usd(Some(c.sell_usd()).filter(|v| *v > 0.0)),
                "fdv_usd": usd(c.fdv_at_last_trade_usd),
                "last_min_ago": minutes(c.last_at()),
                "buyers": named,
                "events": events,
            })
        })
        .collect();
    json!({
        "window_min": window_min,
        "kol_feed_covers_min": feed.kol_covers_min,
        "smart_feed_covers_min": feed.smart_covers_min,
        "coins": coins,
    })
}

/// "professor @0xossalivan (kol): bought $535, sold $535, 55m ago, out"
/// ("out" = their last trade closed the position).
fn buyer(b: &Buyer) -> Value {
    let name: String = b
        .name
        .as_deref()
        .map(|n| n.chars().filter(|c| !c.is_control()).take(24).collect())
        .unwrap_or_else(|| format!("{}…{}", &b.wallet[..6], &b.wallet[b.wallet.len() - 4..]));
    let handle = b
        .twitter
        .as_deref()
        .map(|x| format!(" @{x}"))
        .unwrap_or_default();
    let kind = match b.kind {
        WalletKind::Kol => "kol",
        WalletKind::Smart => "smart",
    };
    let traded = match (b.buy_usd > 0.0, b.sell_usd > 0.0) {
        (true, true) => format!(
            "bought ${}, sold ${}",
            short_usd(b.buy_usd),
            short_usd(b.sell_usd)
        ),
        (false, true) => format!("sold ${}", short_usd(b.sell_usd)),
        _ => format!("bought ${}", short_usd(b.buy_usd)),
    };
    let state = match b.holding {
        Some(true) => ", holds",
        Some(false) => ", out",
        None => "",
    };
    json!(format!(
        "{name}{handle} ({kind}): {traded}, {}m ago{state}",
        minutes(b.last_at)
    ))
}

fn event_name(kind: SignalKind) -> &'static str {
    match kind {
        SignalKind::SmartBuy => "smart buy",
        SignalKind::KolBuy => "kol buy",
        SignalKind::PriceSpike => "price spike",
        SignalKind::Ath => "new ATH",
        SignalKind::McapLevel => "market-cap level",
    }
}

fn minutes(at: i64) -> i64 {
    ((super::now() - at) / 60).max(0)
}

/// $535, $12.3k, $1.4M
fn short_usd(v: f64) -> String {
    match v.abs() {
        a if a >= 1e6 => format!("{}M", super::sig(v / 1e6, 3)),
        a if a >= 1e4 => format!("{}k", super::sig(v / 1e3, 3)),
        _ => format!("{}", v.round() as i64),
    }
}

pub fn holder(h: &HolderRow) -> Value {
    let mut out = Map::new();
    out.insert("wallet".into(), json!(h.wallet));
    out.insert("label".into(), json!(h.label));
    out.insert("tags".into(), json!(h.tags));
    out.insert("name".into(), label(h.name.as_deref(), 24));
    out.insert("x".into(), json!(h.twitter));
    out.insert("pct".into(), pct(h.pct));
    out.insert("usd".into(), usd(h.usd));
    put_span(&mut out, "held", h.since);
    out.insert("unrealized_usd".into(), usd(h.unrealized_usd));
    out.insert("realized_usd".into(), usd(h.realized_usd));
    out.insert("bought_usd".into(), usd(h.bought_usd));
    out.insert("sold_usd".into(), usd(h.sold_usd));
    Value::Object(out)
}

pub fn top(token: &str, t: &Top) -> Value {
    json!({
        "token": token,
        "symbol": label(t.symbol.as_deref(), 20),
        "holders": int(t.holders),
        "top10_pct": pct(t.top10_pct),
        "top_holders": t.rows.iter().map(holder).collect::<Vec<_>>(),
    })
}

/// Tagged holders or top traders; wallets with under $1 held and nothing
/// bought are left out.
pub fn rows(token: &str, view: &str, rows: &[HolderRow]) -> Value {
    let live =
        |h: &&HolderRow| h.usd.is_some_and(|u| u >= 1.0) || h.bought_usd.is_some_and(|b| b >= 1.0);
    json!({
        "token": token,
        "view": view,
        "listed": rows.iter().filter(live).count(),
        "rows": rows.iter().filter(live).take(8).map(holder).collect::<Vec<_>>(),
    })
}

pub fn dev(token: &str, d: &DevRecord) -> Value {
    let launches: Vec<Value> = d
        .launches
        .iter()
        .map(|l| {
            let mut out = Map::new();
            out.insert("symbol".into(), label(l.symbol.as_deref(), 20));
            out.insert("token".into(), json!(l.token));
            if l.token == token {
                out.insert("this_token".into(), json!(true));
            }
            out.insert("graduated".into(), json!(l.graduated));
            put_span(&mut out, "age", l.created_at);
            out.insert("fdv_usd".into(), usd(l.fdv_usd));
            out.insert("ath_fdv_usd".into(), usd(l.ath_fdv_usd));
            out.insert("holders".into(), int(l.holders));
            Value::Object(out)
        })
        .collect();
    json!({
        "token": token,
        "dev": d.wallet,
        "dev_source": d.source,
        "dev_holds_pct": pct(d.holds_pct),
        "dev_sold_out": d.sold_out,
        "launches_listed": d.launches.len(),
        "launches_graduated": int(d.graduated),
        "launches": launches,
    })
}

pub fn wallet(w: &WalletView, is_user: bool) -> Value {
    let record = w.record.as_ref().map(|r| {
        json!({
            "period": w.period.label(),
            "realized_profit_usd": usd(r.realized_profit_usd),
            "realized_profit_pct": pct(r.realized_profit_pct),
            "win_rate_pct": pct(r.win_rate_pct),
            "tokens_traded": int(r.tokens),
            "buys": int(r.buys),
            "sells": int(r.sells),
            "avg_hold_h": r.avg_hold_min.map(|m| super::sig(m / 60.0, 2)),
            "closed_under_minus_50_pct": int(r.outcomes[0]),
            "closed_minus_50_to_0": int(r.outcomes[1]),
            "closed_0_to_2x": int(r.outcomes[2]),
            "closed_2x_to_5x": int(r.outcomes[3]),
            "closed_over_5x": int(r.outcomes[4]),
            "last_trade_min_ago": min_ago(r.last_trade_at),
        })
    });
    let bag: Vec<Value> = w
        .bag
        .iter()
        .map(|p| {
            let mut out = Map::new();
            out.insert("symbol".into(), label(p.symbol.as_deref(), 20));
            out.insert("token".into(), json!(p.token));
            out.insert("usd".into(), usd(Some(p.usd)));
            put_span(&mut out, "held", p.since);
            Value::Object(out)
        })
        .collect();
    let recent: Vec<Value> = w
        .recent
        .iter()
        .map(|m| {
            json!({
                "side": m.side,
                "symbol": label(m.symbol.as_deref(), 20),
                "token": m.token,
                "usd": usd(m.usd),
                "min_ago": min_ago(m.at),
                "closed_position": m.closed_position.then_some(true),
            })
        })
        .collect();
    json!({
        "wallet": w.wallet,
        "is_user": is_user,
        "name": label(w.name.as_deref(), 24),
        "x": w.twitter,
        "tags": w.tags,
        "record": record,
        "bag": bag,
        "recent_trades": recent,
    })
}

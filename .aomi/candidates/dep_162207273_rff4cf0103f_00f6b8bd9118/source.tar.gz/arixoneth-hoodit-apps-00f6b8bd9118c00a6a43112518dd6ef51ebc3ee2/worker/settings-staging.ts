import settings from "./index";

// This deployment serves only the staging settings API.
export default {
  fetch(request: Request, env: Parameters<typeof settings.fetch>[1]): Promise<Response> | Response {
    return new URL(request.url).pathname.startsWith("/api/")
      ? settings.fetch(request, env)
      : new Response("Not found", { status: 404 });
  },
};

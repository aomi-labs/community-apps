# Instant trade settings integration

Quick buys and sells read settings for the canonical hosted.account_id supplied
by the host. The account is not taken from user tool arguments. Hoodit's
manifest already declares HOODIT_SETTINGS_URL and HOODIT_SETTINGS_TOKEN;
the runtime resolves them through the normal app-secret path. The backend
does not need a second Hoodit-specific persistence implementation.

The settings URL points to the Worker serving worker/index.ts. Its /api/settings/
route requires the bearer token, a SETTINGS KV binding, and an account ID.
SETTINGS_TOKEN on that Worker must match HOODIT_SETTINGS_TOKEN supplied to
the app. The committed wrangler.jsonc namespace ID is still a placeholder:
the actual environment must bind its real KV namespace before enabling the
feature. This change creates no namespace, configures no credentials, and
performs no deployment.

A signed-in trade refuses missing configuration, an unavailable store, or an
invalid saved document. It never substitutes a different default slippage
after a saved-settings failure. An account with an empty saved document gets
the documented per-coin defaults. Display-only previews can show defaults,
but execution reads settings again. A successful settings update refreshes
the same host's account cache; KV's cross-location consistency still applies.

The Worker returns saved JSON per account; Rust validates the complete settings
document. The selected slippage_bps is passed unchanged to stage_lifi_swap,
which obtains a new wallet-bound quote after the amount is set. It is not
taken from the earlier card's indicative output.

Local verification uses npm run test:settings with the declared Node 24 runtime.
The tests run in memory, without Cloudflare or real credentials, and are also
part of CI's landing job. Rust's library tests cover missing/unavailable/invalid
settings and exact amount/slippage forwarding. No test executes a real trade.
Production namespace/token wiring and actual settlement remain separate
rollout checks; passing these mocks does not prove production configuration.

## Staging deployment

`wrangler.settings-staging.jsonc` deploys only the settings API as
`hoodit-settings-staging` in Aron's Cloudflare account
`9ba300423c115b1220f357ceac4d4230`, using KV namespace
`3c576fc7e62d41a18997a0abd9c78001`. The site Worker and custom domains remain
in Han's account `210e3092c7936592ca2078b5e26f7ea2`. This temporary staging
placement was authorized on October 29, 2026 because KV access in Han's account
was unavailable. Deploy with `npx wrangler deploy --config
wrangler.settings-staging.jsonc`. Configure `SETTINGS_TOKEN` through Wrangler
secrets, then set the matching token and the deployed base URL in Hoodit's
Build Environment. Never commit secret values.

To migrate, create the destination KV namespace, copy settings by account,
deploy this API under the destination account, provision its token, update
Build's two settings values, and verify an authenticated read/write and an
isolated account before retiring the old service.

# Hoodit direct-trade prompt and eval validation

22 October 2026. Branch `fix/hoodit-trade-latency`, based on fetched
`origin/main` at `2a8c9fb3d55e418cc9ad8f920f0ab3b2f4a8e11f`.

H1–H4 are implemented as model-facing instruction changes: direct execution with
reused facts and ordered simulation/consent, same-chain swap receipt completion,
quote refresh within consent, and missing-only skill activation. The trade skill's
catalog description also uses missing-only wording. H5 adds offline conversation
contracts/counterexamples and fixes the guest evaluator's modern trade boundary.
No host implementation is part of this patch.

| Check | Result |
| --- | --- |
| `python3 -m unittest discover -s tests -p 'test_*.py' -v` | 17 tests passed, including parameterized unsafe-trade and consent variants. No network or credentials. |
| `aomi-dev cargo hoodit-latency -- test --manifest-path /home/aron/Documents/hoodit-cards/Cargo.toml -p hoodit --lib manifest_has_fourteen_unowned_tools_and_small_prompts -- --exact tests::manifest_has_fourteen_unowned_tools_and_small_prompts` | 1 existing Rust manifest test passed, 0 ignored. Managed job `904b28c67a264a4a8832982f90c0a450`; 92.1 s queued, command completed in 56 s. |
| `python3 -m py_compile scripts/hoodit-eval.py scripts/hoodit_trade_checks.py tests/test_trade_conversations.py` | Passed. |
| `git diff --check` | Passed. |

The Rust test command selects the Hoodit manifest through its absolute path while
using the existing registered workspace's machine-wide scheduler/cache. It does
not build or change the host implementation, launch a stack, copy configuration,
or change database schemas. The first restricted-sandbox attempt could not open
the shared scheduler lock; the permitted managed execution above passed. An early
Python budget check caught oversized draft prompts; the final prompts fit the
unchanged Rust limits (preamble <3,000 bytes, each skill <7,000 bytes).

[Fixture coverage and trace format](../tests/evals/trade-regressions.md) map the
tests to H-AC1–H-AC7. These tests verify the normalized trace checker, invalid-trace
rejection, read-only eval boundary and embedded prompt budgets. They do **not**
execute a model against these prompts or establish production behavior, concurrent
host execution, Telegram delivery latency, or end-to-end host retention.

H-AC5's fixture supplies retained instructions for ordinary/callback/compaction
contexts. Actual legacy callback retention still requires host A2 and its own
integration test. H2 uses existing callbacks/`get_transaction`; host B1's status
schema clarification is separate. H3 accepts currently available generic failure
diagnostics and stops on ambiguous admission; richer B2 diagnostics are separate.
No unavailable generic status tool or structured admission field is assumed.

No paid model calls, real swaps, hosted database mutations, deployments or merges
were performed. The earlier investigation's direct OpenAI credential failed with
`credit_balance_exhausted`; that is not a successful model benchmark. The existing
untracked `.aomi/deployment.json` was excluded from the patch and left untouched.

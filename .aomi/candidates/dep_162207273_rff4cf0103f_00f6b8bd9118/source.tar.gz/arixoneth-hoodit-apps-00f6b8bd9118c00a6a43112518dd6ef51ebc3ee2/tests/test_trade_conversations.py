"""Offline contract fixtures and counterexamples; no model, wallet or network."""
from copy import deepcopy
import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, ROOT / path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


checks = load("trade_checks", "scripts/hoodit_trade_checks.py")
live_eval = load("hoodit_eval", "scripts/hoodit-eval.py")
TOKEN = "0x1111111111111111111111111111111111111111"
USDG = "0x2222222222222222222222222222222222222222"
OWNER = "0x3333333333333333333333333333333333333333"
BOUNDS = dict(chain_id=4663, from_token=USDG, to_token=TOKEN, amount="2",
              recipient=OWNER, slippage_bps=300, minimum_out="590", max_fee_usd="0.02")
CARD = dict(fresh=True, token=TOKEN, chain_id=4663, honeypot="no", sell_tax_pct=0,
            checks_passed=True, exit_result="ok")
EXIT = dict(fresh=True, token=TOKEN, amount="2", loss_pct=2)
SKILLS = ["hoodit/trade", "lifi_swap", "hoodit/research"]


def response(tool, identity, args=None, result=None, **annotations):
    return dict(role="assistant", text="checking the next step", calls=[
        dict(tool=tool, id=identity, args=args or {}, result=result or {}, **annotations)])


def stage(ids=(1, 2), bounds=None):
    bounds = deepcopy(bounds or BOUNDS)
    args = {k: bounds[k] for k in ("chain_id", "from_token", "to_token", "amount", "slippage_bps")}
    return response("stage_lifi_swap", f"stage-{ids[0]}", args,
                    {"pending_tx_ids": list(ids)}, bounds=bounds)


def simulate(ids=(1, 2), passed=True):
    return response("simulate_batch", f"sim-{ids[0]}",
                    {"transactions": [dict(id=i, kind="erc20_approve" if n == 0 else "swap", label="fixture") for n, i in enumerate(ids)]},
                    {"batch_success": passed})


def commit(ids=(1, 2), error=None, **annotations):
    return response("evm_commit_txs", f"commit-{ids[0]}", {"tx_ids": list(ids)},
                    {"error": error} if error else {"status": "submitted"}, **annotations)


def buy(asset="memecoin"):
    return dict(context=dict(asset=asset, execution_intent=True, same_chain=True,
                             active_skills=SKILLS.copy(), card=deepcopy(CARD), exit=deepcopy(EXIT)),
                messages=[dict(role="user", text=f"buy 2 USDG of {TOKEN}"), stage(), simulate(),
                          dict(role="assistant", text="2 USDG, minimum 590 tokens, 3% slippage to your wallet. go?", review=deepcopy(BOUNDS)),
                          dict(role="user", text="yes", authorizes=deepcopy(BOUNDS)), commit()],
                expect=dict(stages=1, commits=1, reviews=1, simulations=1, forbid_tools=["hoodit_token", "hoodit_exit"]))


class TradeConversations(unittest.TestCase):
    def assert_good(self, trace):
        self.assertEqual(checks.check_trace(trace), [])

    def assert_bad(self, trace, reason):
        self.assertTrue(any(reason in f for f in checks.check_trace(trace)), checks.check_trace(trace))

    def test_combined_trade_check_needs_no_full_card_or_second_exit(self):
        trace = buy()
        trace["context"].pop("card")
        trace["context"].pop("exit")
        trace["messages"].insert(1, response(
            "hoodit_token", "trade", {"token": TOKEN, "mode": "trade", "usd_amount": 2},
            {"checks_passed": True}, card=deepcopy(CARD), exit=deepcopy(EXIT)))
        trace["expect"]["forbid_tools"] = ["hoodit_exit"]
        self.assert_good(trace)
        trace["messages"][1]["calls"][0]["result"]["checks_passed"] = False
        self.assert_bad(trace, "unsafe buy facts")
        trace["messages"][1]["calls"][0]["result"]["checks_passed"] = True
        trace["messages"][1]["calls"][0]["args"]["mode"] = "full"
        self.assert_bad(trace, "full research before trade")
        trace["context"]["research_requested"] = True
        self.assert_good(trace)

    def test_ac1_fresh_buy_one_review_exact_cohort(self):
        self.assert_good(buy())
        for mutation, reason in (("early", "consent"), ("reorder", "exact ordered"), ("failed", "passing exact"), ("advice", "optional research")):
            with self.subTest(mutation=mutation):
                trace = buy()
                if mutation == "early":
                    del trace["messages"][4]
                elif mutation == "reorder":
                    trace["messages"][-1]["calls"][0]["args"]["tx_ids"] = [2, 1]
                elif mutation == "failed":
                    trace["messages"][2]["calls"][0]["result"]["batch_success"] = False
                else:
                    trace["messages"].insert(1, response("hoodit_chart", "chart"))
                self.assert_bad(trace, reason)

    def test_ac2_refusals_and_missing_safety(self):
        for field, value in (("honeypot", "yes"), ("sell_tax_pct", 11), ("exit_result", "trap"),
                             ("honeypot", None), ("sell_tax_pct", None), ("checks_passed", False), ("fresh", False), ("token", USDG)):
            with self.subTest(field=field, value=value):
                trace = buy()
                trace["context"]["card"][field] = value
                self.assert_bad(trace, "unsafe buy facts")
                trace["messages"] = [trace["messages"][0], dict(role="assistant", text="can't clear that buy")]
                trace["expect"] = dict(stages=0, commits=0, reviews=0)
                self.assert_good(trace)

    def test_ac2_fetch_missing_size_check_before_staging(self):
        trace = buy()
        trace["context"]["exit"]["amount"] = "1"
        self.assert_bad(trace, "size-specific exit")
        trace["messages"].insert(1, response("hoodit_exit", "exit", {"mode": "round_trip", "usd_amount": 2}, exit=EXIT))
        trace["expect"]["forbid_tools"] = []
        self.assert_good(trace)

    def test_staging_cannot_silently_change_size_chain_or_slippage(self):
        for field, value in (("chain_id", 1), ("amount", "3"), ("to_token", USDG), ("slippage_bps", 1001)):
            with self.subTest(field=field):
                trace = buy()
                trace["messages"][1]["calls"][0]["args"][field] = value
                self.assert_bad(trace, "staged arguments differ")

    def test_sell_does_not_apply_buy_refusal(self):
        trace = buy()
        trace["context"].update(side="sell", card=dict(CARD, honeypot="yes"), exit=dict(mode="sell", route=True))
        self.assert_good(trace)
        trace["context"]["exit"]["route"] = False
        self.assert_bad(trace, "sell route")

    def test_ac3_liquid_assets_avoid_discovery(self):
        for asset in ("stablecoin", "eth", "stock"):
            with self.subTest(asset=asset):
                trace = buy(asset)
                trace["context"].update(card=None, exit=None)
                if asset == "stock":
                    trace["context"]["active_skills"].append("robinhood_stocks")
                self.assert_good(trace)
                trace["messages"].insert(1, response("hoodit_scan", "scan"))
                self.assert_bad(trace, "optional research")

    def test_ac4_approval_is_not_swap_completion(self):
        trace = buy()
        approval = dict(kind="approval", status="confirmed", tx_hash="0xapproval")
        trace["messages"] += [dict(role="callback", receipt=approval),
                              dict(role="assistant", text="approval confirmed; swap pending", outcome="pending")]
        self.assert_good(trace)
        trace["messages"][-1].update(outcome="confirmed", swap_hash="0xapproval")
        self.assert_bad(trace, "confirmed swap receipt")
        swap = dict(kind="swap", status="confirmed", tx_hash="0xswap")
        trace["messages"].insert(-1, dict(role="callback", receipt=swap))
        trace["messages"][-1]["swap_hash"] = "0xswap"
        trace["expect"]["complete"] = True
        self.assert_good(trace)
        swap["status"] = "failed"
        self.assert_bad(trace, "confirmed swap receipt")

    def test_ac4_known_swap_hash_and_no_completion_detours(self):
        trace = buy()
        trace["messages"] += [response("get_transaction", "receipt", {"hash": "0xswap", "chain": "4663"},
                                      receipt=dict(kind="swap", status="confirmed", tx_hash="0xswap")),
                              dict(role="assistant", text="bought, swap confirmed", outcome="confirmed", swap_hash="0xswap")]
        self.assert_good(trace)
        for name in ("lifi_get_status", "sleep", "wake_on_condition", "list_transactions"):
            bad = deepcopy(trace)
            bad["messages"].insert(-1, response(name, "detour"))
            self.assert_bad(bad, "completion detour")

    def test_ac5_missing_only_activation_with_retention_supplied(self):
        for boundary in ("ordinary", "callback", "compaction"):
            with self.subTest(boundary=boundary):
                trace = buy()
                trace["messages"].insert(1, dict(role="context", boundary=boundary, active_skills=SKILLS.copy()))
                self.assert_good(trace)
                trace["messages"].insert(2, response("activate_skills", "redundant", {"skill_ids": SKILLS}, {"activated": []}))
                self.assert_bad(trace, "reactivated retained")
        trace = buy()
        trace["context"]["active_skills"] = ["hoodit/research"]
        trace["messages"].insert(1, response("activate_skills", "missing", {"skill_ids": ["hoodit/trade", "lifi_swap"]}, {"activated": ["hoodit/trade", "lifi_swap"]}))
        self.assert_good(trace)

    def refresh(self, bounds=None, admission="not_admitted"):
        trace = buy()
        trace["messages"][-1] = commit(error="simulation_not_passed", admission=admission)
        trace["messages"] += [stage((3, 4), bounds), simulate((3, 4)), commit((3, 4))]
        trace["expect"].update(stages=2, commits=2, simulations=2)
        return trace

    def test_ac6_refresh_within_existing_consent(self):
        self.assert_good(self.refresh())
        self.assert_good(self.refresh(dict(BOUNDS, minimum_out="591")))
        for change in (dict(minimum_out="589"), dict(slippage_bps=500), dict(amount="3"),
                       dict(recipient=TOKEN), dict(to_token=USDG), dict(max_fee_usd="0.03")):
            with self.subTest(change=change):
                bounds = dict(BOUNDS, **change)
                trace = self.refresh(bounds)
                self.assert_bad(trace, "consent")
                trace["messages"][-1:-1] = [dict(role="assistant", text="changed bounds, go?", review=bounds),
                                           dict(role="user", text="yes to the updated trade", authorizes=bounds)]
                trace["expect"]["reviews"] = 2
                # These bounds tests use a liquid asset to isolate consent from meme safety.
                trace["context"]["asset"] = "eth"
                self.assert_good(trace)

    def test_ac6_no_retry_after_unknown_admission_or_old_failed_ids(self):
        trace = self.refresh(admission="unknown")
        self.assert_bad(trace, "ambiguous admitted")
        trace = buy()
        trace["messages"][-1] = commit(error="simulation_not_passed", admission="not_admitted")
        trace["messages"].append(commit())
        self.assert_bad(trace, "retried failed")
        trace = self.refresh()
        del trace["messages"][-2]
        self.assert_bad(trace, "passing exact")

    def test_ac6_diagnostics_only_when_generic_cause_is_unavailable(self):
        trace = self.refresh()
        diagnostic = simulate()
        diagnostic["calls"][0]["id"] = "diagnostic"
        trace["messages"].insert(6, diagnostic)
        self.assert_bad(trace, "simulations")
        # A known non-admitted generic rejection may need one diagnostic replay.
        trace["expect"]["simulations"] = 3
        self.assert_good(trace)

    def test_ac7_reads_share_response_distinct_ids_mutations_ordered(self):
        trace = buy()
        trace["context"].update(card=None, exit=None)
        trace["expect"]["forbid_tools"] = []
        reads = response("hoodit_token", "card", {"mode": "trade"}, {"checks_passed": True}, card=CARD, exit=EXIT)
        reads["calls"] += response("hoodit_positions", "holdings")["calls"]
        trace["messages"].insert(1, reads)
        trace["expect"]["grouped_reads"] = True
        self.assert_good(trace)
        reads["calls"][1]["id"] = "card"
        self.assert_bad(trace, "duplicate call ID")
        trace = buy()
        trace["messages"][1]["calls"] += trace["messages"][2]["calls"]
        self.assert_bad(trace, "sequential barrier")
        trace = buy()
        trace["messages"][1]["text"] = ""
        self.assert_bad(trace, "same response")

    def test_ac1_redundant_reads_and_reconfirmation(self):
        trace = buy()
        trace["messages"].insert(1, response("hoodit_token", "again", card=CARD))
        self.assert_bad(trace, "unnecessary hoodit_token")
        trace = buy()
        trace["messages"].insert(4, dict(role="assistant", text="go again?", review=BOUNDS))
        self.assert_bad(trace, "reviews")

    def test_guest_eval_rejects_modern_trade_tools_and_actions(self):
        for tool in live_eval.TRADE_TOOLS:
            with self.subTest(tool=tool):
                case = dict(prompts=["is this coin interesting?"], checks={})
                turn = dict(prompt=case["prompts"][0], calls=[dict(tool=tool, result={}, chars=2)],
                            answer="there is not enough evidence to recommend a buy here", seconds=0, actions=0)
                self.assertIn(f"called {tool}", live_eval.check(case, [turn]))
        turn["calls"] = []
        turn["actions"] = 1
        self.assertIn("produced a wallet action", live_eval.check(case, [turn]))

    def test_preamble_names_available_execution_tools(self):
        preamble = (ROOT / "apps/hoodit/src/preamble.md").read_text()
        self.assertNotIn("lifi_prepare_swap_batch", preamble)
        for tool in ("stage_lifi_swap", "simulate_batch", "evm_commit_txs"):
            self.assertIn(tool, preamble)

    def test_embedded_prompt_byte_budgets(self):
        # Same limits as the existing Rust manifest contract, without a Rust build.
        self.assertLess(len((ROOT / "apps/hoodit/src/preamble.md").read_bytes()), 3000)
        for path in (ROOT / "apps/hoodit/src/skills").glob("*.md"):
            with self.subTest(skill=path.name):
                self.assertLess(len(path.read_bytes()), 7000)


if __name__ == "__main__":
    unittest.main()

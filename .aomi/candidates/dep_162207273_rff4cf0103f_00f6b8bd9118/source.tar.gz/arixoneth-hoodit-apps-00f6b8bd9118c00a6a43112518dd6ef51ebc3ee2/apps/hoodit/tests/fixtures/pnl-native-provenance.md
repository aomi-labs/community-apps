# Native ETH PnL fixtures

Read-only provider responses recorded on 2026-10-22 for wallet
`0xbc13dc73e1b814b24aacaf20ea90f69e81c7bd54`.
No credentials or request headers are included.

- SURPLUS `0xe1838f0dff03a9327dea87b2a2285850791297ec`: buy
  `0x7737d6f561b6bc208a6300f5a50cd5580ca3e018c89f410debfa94c08723576a`, sale
  `0x5a99a18ac789cefaaccd20ddc2eb106278e65eb53050ad14c00ddda32d144268`.
  Full execution trace proves 0.0000398633 ETH spent, with no EVM refund.
  Sale receipt proves 0.000041109603391879 ETH paid out. Three matched
  swap/approval receipts total 0.000013130092642 ETH gas, separate from PnL.
- REET `0xc3c849c1e226af7a24f4b0bffbcdb03976aa2d80`: buy
  `0xc0c46d72bffe7dc5a026d16c0f04c7912fb8f0c8826b187776e0c2af55beb1e2`.
  Full trace proves 0.00000401464 ETH spent, with no EVM refund.

Trace source: authenticated Blockscout `/4663/api/v2/transactions/<hash>/raw-trace`.
Robinhood's response is a Geth call tree with Arbitrum before/after EVM gas
transfers. Gas records are excluded from trade settlement; DELEGATECALL
apparent value is not an ETH transfer. Receipts/transactions came from
Robinhood public RPCs. History and estimated historical ETH/USD ratios came
from GMGN. USD prices are estimates; exact native amounts are not USD prices.

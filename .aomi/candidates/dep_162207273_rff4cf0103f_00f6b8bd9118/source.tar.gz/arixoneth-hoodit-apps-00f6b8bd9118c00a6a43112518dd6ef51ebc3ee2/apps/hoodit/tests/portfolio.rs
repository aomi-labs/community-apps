use aomi_sdk::{
    DynAomiTool,
    testing::{TestCtxBuilder, run_tool},
};
use hoodit::{
    runtime::{GMGN_KEY, HooditApp},
    tools::{CardTool, History, Pnl, Positions},
    view::{MAX_REPLY, size},
};
use serde_json::{Value, json};
use std::collections::BTreeMap;

const WALLET: &str = "0xbc13dc73e1b814b24aacaf20ea90f69e81c7bd54";
const TOKEN: &str = "0xe1838f0dff03a9327dea87b2a2285850791297ec";
const BUY: &str = "0x7737d6f561b6bc208a6300f5a50cd5580ca3e018c89f410debfa94c08723576a";
fn call<T: DynAomiTool<App = HooditApp>>(app: &HooditApp, session: &str, args: Value) -> Value {
    let ctx = TestCtxBuilder::new(T::NAME)
        .session_id(session)
        .secret(GMGN_KEY, "recorded")
        .attribute("domain", json!({"evm":{"address":WALLET}}))
        .build();
    let out = run_tool::<T>(app, args, ctx).unwrap().value;
    assert!(size(&out) <= MAX_REPLY, "{out}");
    out
}
fn native() -> BTreeMap<String, Value> {
    serde_json::from_str(include_str!("fixtures/pnl-native.json")).unwrap()
}

#[test]
fn actual_surplus_cost_is_recovered_and_structured_pnl_matches_the_image() {
    let app = HooditApp::replaying(native());
    let args = json!({"token":TOKEN});
    let out = call::<Pnl>(&app, "surplus", args.clone());
    assert_eq!(out["status"], "ok", "{out}");
    assert_eq!(out["pnl"]["basis_known"], true);
    assert!((out["pnl"]["cost_usd"].as_f64().unwrap() - 0.100025789626).abs() < 1e-12);
    assert!((out["pnl"]["return_pct"].as_f64().unwrap() - 3.640591640434734).abs() < 1e-10);
    assert!((out["pnl"]["gas_eth"].as_f64().unwrap() - 0.000013130092642).abs() < 1e-18);
    assert_eq!(out["pnl"]["gas_transactions"], 3);
    assert_eq!(out["pnl"]["accounting"], "BEFORE GAS · EST. ETH/USD");
    assert!(out.get("image_path").is_none());
    let image = call::<CardTool>(&app, "surplus", args);
    assert_eq!(image["card"], out["pnl"]);
    std::fs::remove_file(image["image_path"].as_str().unwrap()).unwrap();
}

#[test]
fn missing_or_mismatched_native_trace_never_invents_a_purchase_cost() {
    for mismatch in [true, false] {
        let mut records = native();
        let key = format!("chain:native-trace:{BUY}");
        if mismatch {
            records.get_mut(&key).unwrap()["value"] = json!("0x1");
        } else {
            records.remove(&key);
        }
        let out = call::<Pnl>(
            &HooditApp::replaying(records),
            "missing-trace",
            json!({"token":TOKEN}),
        );
        assert_eq!(out["status"], "partial");
        assert_eq!(out["pnl"]["basis_known"], false);
        assert!(out["pnl"]["cost_usd"].is_null());
        assert!(out["pnl"]["return_pct"].is_null());
        assert!(
            (out["pnl"]["proceeds_or_value_usd"].as_f64().unwrap() - 0.10366732016140301).abs()
                < 1e-12
        );
    }
}

fn activity(side: &str, at: i64, index: u64) -> Value {
    json!({"tx_hash":format!("0x{index:064x}"),"event_type":side,"timestamp":at,"token":{"address":TOKEN,"symbol":"SURPLUS"},"token_amount":"10","cost_usd":"0.1","is_open_or_close":1})
}
fn history_key(cursor: Option<&str>) -> String {
    let tail = cursor.map(|c| format!("&cursor={c}")).unwrap_or_default();
    format!("gmgn:/v1/user/wallet_activity?chain=robinhood&wallet_address={WALLET}&limit=50{tail}")
}

#[test]
fn history_filters_and_continuations_preserve_every_matching_trade_and_chat_scope() {
    let app = HooditApp::replaying(BTreeMap::from([
        (
            history_key(None),
            json!({"activities":[activity("buy",300,3),activity("sell",250,2),activity("buy",200,1)],"next":"older"}),
        ),
        (
            history_key(Some("older")),
            json!({"activities":[activity("buy",150,0),activity("buy",50,4)],"next":""}),
        ),
    ]));
    let mut args = json!({"side":"buy","from_ts":100,"to_ts":300,"min_usd":0.05,"limit":1});
    let first = call::<History>(&app, "history", args.clone());
    assert_eq!(first["items"][0]["timestamp"], 300);
    assert_eq!(first["items"][0]["position_event"], "opened");
    args["cursor"] = first["next_cursor"].clone();
    let mut changed = args.clone();
    changed["side"] = json!("sell");
    assert_eq!(
        call::<History>(&app, "history", changed)["error"]["code"],
        "INVALID_ARGUMENT"
    );
    assert_eq!(
        call::<History>(&app, "other-chat", args.clone())["error"]["code"],
        "NOT_FOUND"
    );
    let second = call::<History>(&app, "history", args.clone());
    assert_eq!(second["items"][0]["timestamp"], 200);
    args["cursor"] = second["next_cursor"].clone();
    let third = call::<History>(&app, "history", args);
    assert_eq!(third["items"][0]["timestamp"], 150);
    assert_eq!(third["has_more"], false);
    let sells = call::<History>(&app, "history", json!({"side":"sell"}));
    assert_eq!(sells["items"][0]["position_event"], "closed");
}

fn position(token: &str, price: Value) -> Value {
    json!({"token":{"address_hash":token,"symbol":"DUST","decimals":"18","exchange_rate":price},"value":"1000000000000000"})
}
#[test]
fn positions_keep_dust_and_unpriced_assets_and_paginate_without_losing_rows() {
    let mut unpriced = position(TOKEN, Value::Null);
    unpriced["value"] = json!("2000000000000000");
    let app = HooditApp::replaying(BTreeMap::from([
        (
            format!("chain:holdings:{WALLET}:null"),
            json!({"items":[position("0x1111111111111111111111111111111111111111",json!("1")),unpriced],"next_page_params":null}),
        ),
        (
            format!("chain:native-balance:{WALLET}"),
            json!("0xde0b6b3a7640000"),
        ),
    ]));
    let first = call::<Positions>(&app, "positions", json!({"limit":1}));
    assert_eq!(first["status"], "ok", "{first}");
    assert_eq!(first["native_eth"], 1.0);
    assert_eq!(first["items"][0]["estimated_value_usd"], 0.001);
    let next = call::<Positions>(
        &app,
        "positions",
        json!({"limit":1,"cursor":first["next_cursor"]}),
    );
    assert_eq!(next["items"][0]["token"], TOKEN);
    assert!(next["items"][0]["estimated_value_usd"].is_null());
    assert_eq!(next["has_more"], false);
    let filtered = call::<Positions>(&app, "positions", json!({"min_value_usd":0.01}));
    assert!(filtered["items"].is_null());
    assert_eq!(filtered["has_more"], false);
    assert_eq!(
        call::<History>(&app, "bad", json!({"from_ts":10,"to_ts":5}))["error"]["code"],
        "INVALID_ARGUMENT"
    );
    assert_eq!(
        call::<Positions>(&app, "bad", json!({"limit":0}))["error"]["code"],
        "INVALID_ARGUMENT"
    );
}

#[test]
fn response_size_pagination_does_not_skip_history_rows() {
    let rows: Vec<_> = (0..40)
        .rev()
        .map(|i| activity("buy", 100 + i, i as u64))
        .collect();
    let app = HooditApp::replaying(BTreeMap::from([(
        history_key(None),
        json!({"activities":rows,"next":""}),
    )]));
    let mut args = json!({"limit":5});
    let mut got = vec![];
    loop {
        let out = call::<History>(&app, "wide", args.clone());
        assert_eq!(out["status"], "ok", "{out}");
        for item in out["items"].as_array().unwrap() {
            got.push(item["timestamp"].as_i64().unwrap());
        }
        if out["has_more"] == false {
            break;
        }
        args["cursor"] = out["next_cursor"].clone();
        assert!(got.len() <= 40);
    }
    assert_eq!(got, (100..140).rev().collect::<Vec<_>>());
}

//! Direct tools: the host runs them from Telegram shortcuts and buttons,
//! without the model, and shows their reply as is (`view::direct`). Their
//! descriptions are notes for maintainers; the model never sees them.
use super::address;
use crate::domain::amount::{Amount, order, parse};
use crate::domain::token::identity;
use crate::domain::{portfolio, settings, trade};
use crate::providers::NATIVE;
use crate::providers::chain::Chain;
use crate::providers::lifi::Lifi;
use crate::runtime::{Fail, HooditApp, Lane, Runtime, Turn};
use crate::view::direct as view;
use aomi_sdk::schemars::{JsonSchema, schema_for};
use aomi_sdk::{DynAomiApp, DynAomiTool, DynToolCallCtx, DynToolMetadata};
use serde::Deserialize;
use serde_json::{Value, json};

/// A direct tool's descriptor: its own, in the `direct` namespace the
/// host keeps away from the model.
fn direct<T: DynAomiTool>(app: &T::App) -> DynToolMetadata {
    DynToolMetadata {
        name: T::NAME.into(),
        app: app.name().into(),
        description: T::DESCRIPTION.into(),
        parameters_schema: serde_json::to_value(schema_for!(T::Args)).unwrap_or(Value::Null),
        supports_async: T::IS_ASYNC,
        namespace: Some("direct".into()),
    }
}

/// Runs a direct tool body; a failure becomes a short reply too.
fn reply<F>(app: &HooditApp, ctx: &DynToolCallCtx, body: F) -> Result<Value, String>
where
    F: AsyncFnOnce(&Runtime, &Turn) -> Result<Value, Fail>,
{
    let rt = app.runtime()?;
    let turn = Turn::new(ctx, Lane::Chat);
    let out = rt.tokio.block_on(body(&rt, &turn));
    Ok(out.unwrap_or_else(|fail| view::failed(&fail)))
}

/// The token and size from a button's `amount`, typed `text` ("0x… 5"),
/// or both.
fn order_of(
    token: Option<&str>,
    amount: Option<&str>,
    text: Option<&str>,
) -> Result<(Option<String>, Option<Amount>), Fail> {
    let (typed, size) = order(text.unwrap_or("")).map_err(Fail::Invalid)?;
    let token = typed.or(token.map(address).transpose()?);
    let size = match amount {
        Some(a) => Some(parse(a).map_err(Fail::Invalid)?),
        None => size,
    };
    Ok((token, size))
}

#[derive(Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct PreviewArgs {
    /// The pasted 0x contract.
    pub token: String,
}

pub struct Preview;
impl DynAomiTool for Preview {
    type App = HooditApp;
    type Args = PreviewArgs;
    const NAME: &'static str = view::PREVIEW;
    const DESCRIPTION: &'static str =
        "Direct: a pasted contract's identity card, holding and buy/sell buttons.";
    fn descriptor(app: &HooditApp) -> DynToolMetadata {
        direct::<Self>(app)
    }
    fn run(app: &HooditApp, args: PreviewArgs, ctx: DynToolCallCtx) -> Result<Value, String> {
        reply(app, &ctx, async |rt, turn| {
            let token = address(&args.token)?;
            let (id, settings, held) = tokio::join!(
                identity(rt, turn, &token),
                settings::load(rt, turn),
                async {
                    let wallet = turn.wallet.as_deref()?;
                    Some(Chain::new(rt, turn).balance(&token, wallet).await.ok())
                }
            );
            let id = id?;
            let scale = 10f64.powi(id.decimals as i32);
            let held = held.map(|h| h.map(|raw| raw as f64 / scale));
            Ok(view::preview(&id, held, &settings))
        })
    }
}

#[derive(Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct BuyArgs {
    /// 0x contract; null = from text.
    pub token: Option<String>,
    /// "$5", "0.002 ETH" or "5 USDG"; null = from text.
    pub amount: Option<String>,
    /// What the user typed: "/buy" rest ("0x… 5") or a reply ("5").
    pub text: Option<String>,
}

pub struct Buy;
impl DynAomiTool for Buy {
    type App = HooditApp;
    type Args = BuyArgs;
    const NAME: &'static str = view::BUY;
    const DESCRIPTION: &'static str =
        "Direct: a checked buy for ETH or USDG, returned as a stage_lifi_swap tx.";
    fn descriptor(app: &HooditApp) -> DynToolMetadata {
        direct::<Self>(app)
    }
    fn run(app: &HooditApp, args: BuyArgs, ctx: DynToolCallCtx) -> Result<Value, String> {
        reply(app, &ctx, async |rt, turn| {
            let (token, size) = order_of(
                args.token.as_deref(),
                args.amount.as_deref(),
                args.text.as_deref(),
            )?;
            let Some(token) = token else {
                return Ok(view::text(
                    "Which coin? Send `/buy <address> <amount>`, e.g. `/buy 0x… 5`, or paste its contract.",
                ));
            };
            let (id, settings) =
                tokio::join!(identity(rt, turn, &token), settings::saved(rt, turn));
            let id = id?;
            let settings = settings?;
            let Some(size) = size else {
                return Ok(view::how_much(&id, &settings, false));
            };
            let plan = trade::buy(rt, turn, &id, &size, &settings).await?;
            Ok(view::buy(&id, plan))
        })
    }
}

#[derive(Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct SellArgs {
    /// 0x contract; null = from text.
    pub token: Option<String>,
    /// "25%", "1000 PONS", "$5" or "0.002 ETH" to receive; null = from text.
    pub amount: Option<String>,
    /// What the user typed: "/sell" rest ("0x… 50%") or a reply ("50%").
    pub text: Option<String>,
    /// Sell even though price impact loses over 10%. null = false.
    pub accept_loss: Option<bool>,
}

pub struct Sell;
impl DynAomiTool for Sell {
    type App = HooditApp;
    type Args = SellArgs;
    const NAME: &'static str = view::SELL;
    const DESCRIPTION: &'static str =
        "Direct: a sell for ETH from a fresh balance, returned as a stage_lifi_swap tx.";
    fn descriptor(app: &HooditApp) -> DynToolMetadata {
        direct::<Self>(app)
    }
    fn run(app: &HooditApp, args: SellArgs, ctx: DynToolCallCtx) -> Result<Value, String> {
        reply(app, &ctx, async |rt, turn| {
            let (token, size) = order_of(
                args.token.as_deref(),
                args.amount.as_deref(),
                args.text.as_deref(),
            )?;
            let Some(token) = token else {
                return Ok(view::text(
                    "Which coin? Send `/sell <address> <amount>`, e.g. `/sell 0x… 50%`.",
                ));
            };
            let (id, settings) =
                tokio::join!(identity(rt, turn, &token), settings::saved(rt, turn));
            let id = id?;
            let settings = settings?;
            let Some(size) = size else {
                return Ok(view::how_much(&id, &settings, true));
            };
            let accept = args.accept_loss == Some(true);
            let plan = trade::sell(rt, turn, &id, &size, &settings, accept).await?;
            let again = json!({
                "token": token,
                "amount": args.amount,
                "text": args.text,
                "accept_loss": true,
            });
            Ok(view::sell(&id, plan, &settings, again))
        })
    }
}

#[derive(Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct PositionsViewArgs {
    /// "/positions" rest; ignored.
    pub text: Option<String>,
    /// Next page from this tool's Next button; null = first page.
    pub cursor: Option<String>,
}

pub struct PositionsView;
impl DynAomiTool for PositionsView {
    type App = HooditApp;
    type Args = PositionsViewArgs;
    const NAME: &'static str = view::POSITIONS;
    const DESCRIPTION: &'static str =
        "Direct: the connected wallet's holdings, five per page, one button each.";
    fn descriptor(app: &HooditApp) -> DynToolMetadata {
        direct::<Self>(app)
    }
    fn run(app: &HooditApp, args: PositionsViewArgs, ctx: DynToolCallCtx) -> Result<Value, String> {
        reply(app, &ctx, async |rt, turn| {
            let wallet = turn.wallet.clone().ok_or(Fail::NoWallet)?;
            let cursor = args.cursor.as_deref().filter(|c| !c.is_empty());
            let page = portfolio::positions(rt, turn, &wallet, None, 0.0, 5, cursor).await?;
            let eth = match (cursor, page["native_eth"].as_f64()) {
                (None, Some(eth)) => Some((eth, Lifi::new(rt, turn).price(NATIVE).await.ok())),
                _ => None,
            };
            Ok(view::positions(&wallet, &page, eth))
        })
    }
}

#[derive(Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct SettingsViewArgs {
    /// "/settings" rest; ignored.
    pub text: Option<String>,
}

pub struct SettingsView;
impl DynAomiTool for SettingsView {
    type App = HooditApp;
    type Args = SettingsViewArgs;
    const NAME: &'static str = view::SETTINGS;
    const DESCRIPTION: &'static str = "Direct: the user's quick-action settings.";
    fn descriptor(app: &HooditApp) -> DynToolMetadata {
        direct::<Self>(app)
    }
    fn run(app: &HooditApp, _args: SettingsViewArgs, ctx: DynToolCallCtx) -> Result<Value, String> {
        reply(app, &ctx, async |rt, turn| {
            let note = match (&turn.account, turn.settings_store()) {
                (None, _) => Some("Sign in to save settings."),
                (_, None) => Some("Settings can't be saved here yet."),
                _ => None,
            };
            Ok(view::settings(&settings::load(rt, turn).await, note))
        })
    }
}

//! Authenticated, bounded Blockscout reads. Keys never enter cache IDs or errors.
use super::{
    Chain, TIMEOUT,
    receipts::{raw, scaled},
};
use crate::runtime::{Cost, Fail, Request, Source};
use serde_json::{Value, json};
use std::time::Duration;

const MAX_BYTES: usize = 4 * 1024 * 1024;

impl Chain<'_> {
    pub(super) async fn explorer<F>(
        self,
        path: &str,
        query: &[(String, String)],
        key: &str,
        ttl: Duration,
        validate: F,
    ) -> Result<Value, Fail>
    where
        F: FnOnce(&Value) -> Result<(), Fail>,
    {
        self.rt
            .fetch(
                self.turn,
                Request::new(Source::Chain, key, Cost::Free, ttl).live_only(),
                || async {
                    let key = self.turn.key(Source::Chain).ok_or_else(|| {
                        Fail::unavailable(Source::Chain, "Blockscout reads need BLOCKSCOUT_API_KEY")
                    })?;
                    let mut response = self
                        .rt
                        .http
                        .get(format!("https://api.blockscout.com/4663/api/v2/{path}"))
                        .query(query)
                        .query(&[("apikey", key)])
                        .timeout(TIMEOUT)
                        .send()
                        .await
                        .map_err(|_| {
                            Fail::unavailable(Source::Chain, "Blockscout request failed")
                        })?;
                    if !response.status().is_success() {
                        return Err(Fail::unavailable(
                            Source::Chain,
                            format!("Blockscout HTTP {}", response.status().as_u16()),
                        ));
                    }
                    if response
                        .content_length()
                        .is_some_and(|n| n > MAX_BYTES as u64)
                    {
                        return Err(Fail::bad(
                            Source::Chain,
                            "Blockscout response exceeds size limit",
                        ));
                    }
                    let mut body = Vec::new();
                    while let Some(chunk) = response.chunk().await.map_err(|_| {
                        Fail::unavailable(Source::Chain, "Blockscout body unavailable")
                    })? {
                        if body.len() + chunk.len() > MAX_BYTES {
                            return Err(Fail::bad(
                                Source::Chain,
                                "Blockscout response exceeds size limit",
                            ));
                        }
                        body.extend_from_slice(&chunk);
                    }
                    let value = serde_json::from_slice(&body)
                        .map_err(|_| Fail::bad(Source::Chain, "Blockscout response is not JSON"))?;
                    validate(&value)?;
                    Ok(value)
                },
            )
            .await
    }

    pub async fn holdings(self, wallet: &str, page: &Value) -> Result<Value, Fail> {
        let mut query = vec![("type".into(), "ERC-20".into())];
        if let Some(params) = page.as_object() {
            for (k, v) in params {
                if k == "fiat_value" && v.is_null() {
                    continue;
                }
                let v = match v {
                    Value::String(s) => s.clone(),
                    Value::Number(n) => n.to_string(),
                    _ => return Err(Fail::bad(Source::Chain, "invalid holdings page")),
                };
                if v.len() > 256 {
                    return Err(Fail::bad(Source::Chain, "holdings cursor value too large"));
                }
                if !matches!(k.as_str(), "fiat_value" | "id" | "items_count" | "value") {
                    return Err(Fail::bad(Source::Chain, "unsupported holdings cursor"));
                }
                query.push((k.clone(), v));
            }
        }
        let key = format!("chain:holdings:{wallet}:{page}");
        self.explorer(
            &format!("addresses/{wallet}/tokens"),
            &query,
            &key,
            Duration::from_secs(15),
            |_| Ok(()),
        )
        .await
    }

    pub async fn native_balance(self, wallet: &str) -> Result<f64, Fail> {
        let request = Request::new(
            Source::Chain,
            format!("chain:native-balance:{wallet}"),
            Cost::Free,
            Duration::from_secs(10),
        )
        .live_only();
        let value = self
            .rt
            .fetch(self.turn, request, || {
                self.rpc("eth_getBalance", json!([wallet, "latest"]))
            })
            .await?;
        scaled(
            &raw(value
                .as_str()
                .ok_or_else(|| Fail::bad(Source::Chain, "native balance missing"))?)?,
            18,
        )
    }
}

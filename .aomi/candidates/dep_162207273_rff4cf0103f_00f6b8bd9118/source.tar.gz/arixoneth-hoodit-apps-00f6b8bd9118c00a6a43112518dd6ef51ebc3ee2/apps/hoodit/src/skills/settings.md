# Hoodit settings

Use when the user wants to change their quick actions: the Telegram buy buttons ("set my buys to $10, $25 and $100"), the sell buttons, what pays for quick buys (auto, ETH or USDG), or their default slippage.

- Read `hoodit_settings_get` only when you need the current values; otherwise pass just what changes to `hoodit_settings_set`.
- Buy sizes are dollars or ETH ("$10", "0.01 ETH"), 1 to 3 of them; sell buttons are 1 to 3 percents. Slippage is in bps; 0 goes back to Hoodit's per-coin defaults.
- Confirm the saved values in one line. A refusal ("Sign in to save settings.") or a validation message: say it plainly.

//! Structured wallet reads. Filtered pages preserve unreturned rows in a
//! chat-scoped cursor, so response size limits cannot silently skip trades.
use crate::providers::{
    chain::{Chain, receipts::scaled},
    gmgn::{Gmgn, types::Activity},
};
use crate::runtime::{Fail, Runtime, Turn};
use num_traits::Zero;
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use std::time::Duration;

#[derive(Default, Deserialize, Serialize)]
struct Page {
    scope: String,
    at: i64,
    rows: Vec<Value>,
    next: Option<Value>,
}

fn start(rt: &Runtime, turn: &Turn, scope: Value, cursor: Option<&str>) -> Result<Page, Fail> {
    let scope = scope.to_string();
    let Some(cursor) = cursor else {
        return Ok(Page {
            scope,
            at: crate::view::now(),
            ..Page::default()
        });
    };
    if cursor.len() > 100
        || !cursor
            .bytes()
            .all(|b| b.is_ascii_alphanumeric() || b == b'-')
    {
        return Err(Fail::Invalid("invalid page cursor".into()));
    }
    let page: Page = rt
        .cache
        .fresh(&cursor_key(turn, cursor))
        .and_then(|v| serde_json::from_value(v).ok())
        .ok_or_else(|| {
            Fail::NotFound(
                "page cursor expired or belongs to another chat; start again without cursor".into(),
            )
        })?;
    if page.scope != scope {
        return Err(Fail::Invalid(
            "cursor does not match this wallet and filters".into(),
        ));
    }
    Ok(page)
}

fn cursor_key(turn: &Turn, id: &str) -> String {
    format!("portfolio:{}:{}:{id}", turn.thread.len(), turn.thread)
}

fn finish(rt: &Runtime, turn: &Turn, mut page: Page, limit: usize) -> Value {
    let mut items = vec![];
    // Budget before making the continuation: envelope trimming must never
    // remove an item that the next cursor has already advanced past.
    while !page.rows.is_empty() && items.len() < limit {
        let row = page.rows.remove(0);
        items.push(row);
        if crate::view::size(&json!({"items":items})) > 1900 && items.len() > 1 {
            page.rows.insert(0, items.pop().unwrap());
            break;
        }
    }
    let more = !page.rows.is_empty() || page.next.is_some();
    let at = page.at;
    let cursor = if more {
        use std::sync::atomic::{AtomicU64, Ordering};
        static NEXT: AtomicU64 = AtomicU64::new(0);
        let time = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_or(0, |d| d.as_nanos());
        let id = format!("p{time:x}-{:x}", NEXT.fetch_add(1, Ordering::Relaxed));
        rt.cache.put(
            cursor_key(turn, &id),
            serde_json::to_value(page).unwrap(),
            Duration::from_secs(600),
        );
        Some(id)
    } else {
        None
    };
    json!({"items":items,"has_more":more,"next_cursor":cursor,"snapshot_at":at})
}

pub struct HistoryQuery<'a> {
    pub wallet: &'a str,
    pub token: Option<&'a str>,
    pub side: Option<&'a str>,
    pub from: Option<i64>,
    pub to: Option<i64>,
    pub min_usd: f64,
    pub limit: usize,
    pub cursor: Option<&'a str>,
}

pub async fn history(rt: &Runtime, turn: &Turn, q: HistoryQuery<'_>) -> Result<Value, Fail> {
    let scope = json!([
        "history", q.wallet, q.token, q.side, q.from, q.to, q.min_usd
    ]);
    let mut page = start(rt, turn, scope, q.cursor)?;
    if page.rows.is_empty() {
        let next = page.next.take();
        let data = Gmgn::new(rt, turn)
            .activity_page(q.wallet, q.token, next.as_ref().and_then(Value::as_str))
            .await?;
        page.at = crate::view::now();
        let rows = data["activities"]
            .as_array()
            .filter(|r| r.len() <= 50)
            .ok_or_else(|| {
                Fail::bad(
                    crate::runtime::Source::Gmgn,
                    "wallet history page missing or too large",
                )
            })?;
        for value in rows {
            let row: Activity =
                crate::providers::parse(crate::runtime::Source::Gmgn, value.clone())?;
            if crate::view::address(&row.token.address).is_err()
                || row.tx_hash.len() != 66
                || !row.tx_hash.starts_with("0x")
                || !row.tx_hash[2..].bytes().all(|b| b.is_ascii_hexdigit())
                || !matches!(
                    row.event_type.as_str(),
                    "buy" | "sell" | "transferIn" | "transferOut" | "add" | "remove"
                )
            {
                return Err(Fail::bad(
                    crate::runtime::Source::Gmgn,
                    "wallet history identifiers are invalid",
                ));
            }
            let at = row.timestamp.ts();
            if q.side.is_some_and(|s| s != row.event_type)
                || q.token
                    .is_some_and(|t| !t.eq_ignore_ascii_case(&row.token.address))
                || q.from.is_some_and(|t| at.is_none_or(|a| a < t))
                || q.to.is_some_and(|t| at.is_none_or(|a| a > t))
                || (q.min_usd > 0.0 && row.cost_usd.get().is_none_or(|v| v < q.min_usd))
            {
                continue;
            }
            let event = if row.is_open_or_close.get() == Some(1.0) {
                match row.event_type.as_str() {
                    "buy" => Some("opened"),
                    "sell" => Some("closed"),
                    _ => None,
                }
            } else {
                None
            };
            page.rows.push(json!({"tx_hash":row.tx_hash,"token":row.token.address,"symbol":row.token.symbol.map(|s|crate::card::format::clamp(&s,20)),"side":row.event_type,"timestamp":at,"token_amount":row.token_amount.get(),"indexed_value_usd":row.cost_usd.get(),"position_event":event}));
        }
        page.next = provider_next(&data, "next")?;
        if page.next == next && page.next.is_some() {
            return Err(Fail::bad(
                crate::runtime::Source::Gmgn,
                "wallet history cursor did not advance",
            ));
        }
    }
    let mut out = finish(rt, turn, page, q.limit);
    out["wallet"] = json!(q.wallet);
    turn.used(crate::runtime::Source::Gmgn);
    out["value_policy"] = json!(
        "indexed_value_usd is GMGN's pool-leg estimate, not wallet spend or PnL. Use hoodit_pnl for verified round accounting. Pages cover indexed history only."
    );
    Ok(out)
}

pub async fn positions(
    rt: &Runtime,
    turn: &Turn,
    wallet: &str,
    token: Option<&str>,
    min_usd: f64,
    limit: usize,
    cursor: Option<&str>,
) -> Result<Value, Fail> {
    let mut page = start(
        rt,
        turn,
        json!(["positions", wallet, token, min_usd]),
        cursor,
    )?;
    let chain = Chain::new(rt, turn);
    if page.rows.is_empty() {
        let previous = page.next.take();
        let data = chain
            .holdings(wallet, previous.as_ref().unwrap_or(&Value::Null))
            .await?;
        page.at = crate::view::now();
        let items = data["items"]
            .as_array()
            .filter(|r| r.len() <= 50)
            .ok_or_else(|| {
                Fail::bad(
                    crate::runtime::Source::Chain,
                    "holdings page missing or too large",
                )
            })?;
        for row in items {
            let t = &row["token"];
            let contract = t["address_hash"].as_str().ok_or_else(|| {
                Fail::bad(
                    crate::runtime::Source::Chain,
                    "holding token address missing",
                )
            })?;
            crate::view::address(contract).map_err(|_| {
                Fail::bad(
                    crate::runtime::Source::Chain,
                    "holding token address invalid",
                )
            })?;
            if token.is_some_and(|v| !v.eq_ignore_ascii_case(contract)) {
                continue;
            }
            let amount = row["value"]
                .as_str()
                .filter(|v| v.len() <= 78)
                .and_then(|v| num_bigint::BigUint::parse_bytes(v.as_bytes(), 10))
                .ok_or_else(|| {
                    Fail::bad(crate::runtime::Source::Chain, "holding balance missing")
                })?;
            if amount.is_zero() {
                continue;
            }
            let decimals = t["decimals"]
                .as_str()
                .and_then(|v| v.parse::<u8>().ok())
                .or_else(|| t["decimals"].as_u64().and_then(|v| v.try_into().ok()));
            let quantity = decimals.and_then(|d| scaled(&amount, d).ok());
            let price = number(&t["exchange_rate"]);
            let usd = quantity
                .zip(price)
                .map(|(a, p)| a * p)
                .filter(|v| v.is_finite());
            if min_usd > 0.0 && usd.is_none_or(|v| v < min_usd) {
                continue;
            }
            page.rows.push(json!({"token":contract.to_lowercase(),"symbol":t["symbol"].as_str().map(|s|crate::card::format::clamp(s,20)),"balance_raw":amount.to_string(),"decimals":decimals,"amount":quantity,"estimated_value_usd":usd}));
        }
        page.next = provider_next(&data, "next_page_params")?;
        if page.next == previous && page.next.is_some() {
            return Err(Fail::bad(
                crate::runtime::Source::Chain,
                "holdings cursor did not advance",
            ));
        }
    }
    let native = match chain.native_balance(wallet).await {
        Ok(v) => Some(v),
        Err(fail) => {
            turn.gap(format!(
                "native ETH balance unavailable: {}",
                fail.message()
            ));
            None
        }
    };
    let mut out = finish(rt, turn, page, limit);
    out["wallet"] = json!(wallet);
    turn.used(crate::runtime::Source::Chain);
    out["native_eth"] = json!(native);
    out["value_policy"] = json!(
        "ERC-20 balances include dust and unpriced assets when min_value_usd is 0. USD values are explorer estimates; these are holdings, not verified cost basis. Use hoodit_pnl for a token's round."
    );
    Ok(out)
}

fn number(v: &Value) -> Option<f64> {
    v.as_f64()
        .or_else(|| v.as_str()?.parse().ok())
        .filter(|n| n.is_finite() && *n >= 0.0)
}

fn provider_next(data: &Value, key: &str) -> Result<Option<Value>, Fail> {
    if key == "next_page_params" && data.get(key).is_none() {
        return Err(Fail::NoData("holdings pagination metadata missing".into()));
    }
    match &data[key] {
        Value::Null => Ok(None),
        Value::String(s) if key == "next" && s.is_empty() => Ok(None),
        Value::String(s) if key == "next" && s.len() <= 2048 => Ok(Some(json!(s))),
        Value::Object(m) if key == "next_page_params" && !m.is_empty() && m.len() <= 6 => {
            Ok(Some(json!(m)))
        }
        _ => Err(Fail::NoData("provider page cursor is invalid".into())),
    }
}

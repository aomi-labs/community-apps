//! Exact token amounts, and sizes as people type them. A decimal the token
//! can't represent is an error, never a rounding.
use num_bigint::BigUint;
use num_traits::Zero;
use std::str::FromStr;

fn atomic(digits: &str) -> Result<BigUint, String> {
    let value = BigUint::from_str(digits).map_err(|_| "invalid amount".to_string())?;
    if value.bits() > 256 {
        return Err("amount exceeds uint256".into());
    }
    Ok(value)
}

/// Whole-unit decimal string ("0.05") to atomic units.
pub fn from_decimal(value: &str, decimals: u8) -> Result<BigUint, String> {
    let value = value.trim();
    let (whole, fractional) = value.split_once('.').unwrap_or((value, ""));
    let plain = |s: &str| s.bytes().all(|b| b.is_ascii_digit());
    if whole.is_empty()
        || value.len() > 96
        || !plain(whole)
        || !plain(fractional)
        || (value.contains('.') && fractional.is_empty())
    {
        return Err("expected a plain non-negative decimal such as 0.05".into());
    }
    if fractional.len() > decimals as usize {
        return Err(format!("this token supports at most {decimals} decimals"));
    }
    let digits = format!("{whole}{fractional:0<width$}", width = decimals as usize);
    let digits = digits.trim_start_matches('0');
    atomic(if digits.is_empty() { "0" } else { digits })
}

/// Atomic units back to a whole-unit decimal string.
pub fn format(value: &BigUint, decimals: u8) -> String {
    if decimals == 0 {
        return value.to_string();
    }
    let scale = BigUint::from(10u8).pow(decimals as u32);
    let (whole, rem) = (value / &scale, value % &scale);
    if rem.is_zero() {
        return whole.to_string();
    }
    let frac = format!("{:0>width$}", rem, width = decimals as usize);
    format!("{whole}.{}", frac.trim_end_matches('0'))
}

/// A size as a person types it after /buy or /sell, or in a reply.
#[derive(Clone, Debug, PartialEq)]
pub enum Amount {
    /// "$5", "5 usd".
    Usd(f64),
    /// "0.002 eth".
    Eth(String),
    /// "5 usdg".
    Usdg(String),
    /// "25%"; "all" is 100.
    Pct(f64),
    /// "1000 pons": whole units of the token named, lowercased.
    Tokens(String, String),
    /// A plain number: dollars on a buy, unclear on a sell.
    Bare(String),
}

/// Splits command text into an optional 0x token and an optional size:
/// "0xabc… 5", "$20", "0.002 eth", "25%", "1000 pons".
pub fn order(text: &str) -> Result<(Option<String>, Option<Amount>), String> {
    let mut token = None;
    let mut rest = String::new();
    for word in text.split(|c: char| c.is_whitespace() || c == ',') {
        if let Some(hex) = word.strip_prefix("0x") {
            if hex.len() != 40 || !hex.bytes().all(|b| b.is_ascii_hexdigit()) {
                return Err("That's not a full 0x contract address.".into());
            }
            if token.replace(word.to_ascii_lowercase()).is_some() {
                return Err("One token at a time.".into());
            }
        } else {
            rest.push_str(word);
        }
    }
    let size = (!rest.is_empty()).then(|| parse(&rest)).transpose()?;
    Ok((token, size))
}

/// One size, spaces ignored: "$5", "5$", "0.002eth", "25%", "all".
pub fn parse(text: &str) -> Result<Amount, String> {
    let bad = || "Say an amount like $5, 0.002 ETH or 25%.".to_string();
    let t: String = text
        .chars()
        .filter(|c| !c.is_whitespace())
        .collect::<String>()
        .to_ascii_lowercase();
    if t == "all" || t == "max" {
        return Ok(Amount::Pct(100.0));
    }
    let (n, unit) = match t.strip_prefix('$') {
        Some(n) => (n, "usd"),
        None => t.split_at(
            t.find(|c: char| !c.is_ascii_digit() && c != '.')
                .unwrap_or(t.len()),
        ),
    };
    let n = if n.starts_with('.') {
        format!("0{n}")
    } else {
        n.to_string()
    };
    let value: f64 = n.parse().map_err(|_| bad())?;
    if from_decimal(&n, 18).map_or(true, |v| v.is_zero()) {
        return Err(bad());
    }
    Ok(match unit {
        "" => Amount::Bare(n),
        "$" | "usd" | "dollar" | "dollars" => Amount::Usd(value),
        "%" if value <= 100.0 => Amount::Pct(value),
        "eth" => Amount::Eth(n),
        "usdg" => Amount::Usdg(n),
        symbol
            if symbol.len() <= 16
                && symbol.starts_with(|c: char| c.is_ascii_alphabetic())
                && symbol.bytes().all(|b| b.is_ascii_alphanumeric()) =>
        {
            Amount::Tokens(n, symbol.to_string())
        }
        _ => return Err(bad()),
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn decimals_convert_exactly() {
        assert_eq!(
            from_decimal("0.05", 18).unwrap().to_string(),
            "50000000000000000"
        );
        assert_eq!(from_decimal("1.5", 6).unwrap().to_string(), "1500000");
        assert_eq!(from_decimal("0", 6).unwrap().to_string(), "0");
        assert!(from_decimal("0.1234567", 6).is_err());
        assert!(from_decimal("-1", 6).is_err());
        assert!(from_decimal("1e5", 6).is_err());
        assert!(from_decimal("1.", 6).is_err());
        assert_eq!(format(&from_decimal("1.2345", 6).unwrap(), 6), "1.2345");
    }

    #[test]
    fn sizes_read_like_people_type_them() {
        let pons = "0x44318785554bf11ffd164a6f98d9a453e2fa74af";
        assert_eq!(
            order(" 0x44318785554BF11FFD164A6F98D9A453E2FA74AF 5 ").unwrap(),
            (Some(pons.into()), Some(Amount::Bare("5".into())))
        );
        assert_eq!(order("").unwrap(), (None, None));
        assert_eq!(parse("$20").unwrap(), Amount::Usd(20.0));
        assert_eq!(parse("2.5 usd").unwrap(), Amount::Usd(2.5));
        assert_eq!(parse("0.002 ETH").unwrap(), Amount::Eth("0.002".into()));
        assert_eq!(parse(".5eth").unwrap(), Amount::Eth("0.5".into()));
        assert_eq!(parse("5 usdg").unwrap(), Amount::Usdg("5".into()));
        assert_eq!(parse("25%").unwrap(), Amount::Pct(25.0));
        assert_eq!(parse("All").unwrap(), Amount::Pct(100.0));
        assert_eq!(
            order("1,000 PONS").unwrap().1,
            Some(Amount::Tokens("1000".into(), "pons".into()))
        );
        for bad in ["0", "$0", "150%", "-5", "five", "5 $$", "0.1.2 eth"] {
            assert!(parse(bad).is_err(), "{bad}");
        }
        assert!(order("0x1234 5").is_err());
        assert!(order(&format!("{pons} {pons}")).is_err());
    }
}

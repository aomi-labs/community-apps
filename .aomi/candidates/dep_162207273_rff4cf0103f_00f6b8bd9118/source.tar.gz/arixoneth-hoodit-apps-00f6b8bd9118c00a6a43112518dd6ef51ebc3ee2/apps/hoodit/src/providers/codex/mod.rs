//! Codex GraphQL, paid per request over MPP (Tempo). Several aliased
//! queries in one document are billed once.
mod queries;
pub mod types;

pub use queries::BarSpan;

use crate::runtime::{Cost, Fail, Request, Runtime, Source, Turn};
use mpp::client::{Fetch, TempoProvider};
use serde::de::DeserializeOwned;
use serde_json::{Value, json};
use std::sync::{Arc, Mutex};
use std::time::Duration;
use types::*;

const URL: &str = "https://graph.codex.io/graphql";

const LIVE: Duration = Duration::from_secs(20);
const MINUTE: Duration = Duration::from_secs(60);

#[derive(Clone, Copy)]
pub struct Codex<'a> {
    rt: &'a Runtime,
    turn: &'a Turn,
    live: bool,
}

impl<'a> Codex<'a> {
    pub fn new(rt: &'a Runtime, turn: &'a Turn) -> Self {
        Self {
            rt,
            turn,
            live: false,
        }
    }

    /// Prices used to size live quotes cannot fall back to expired research data.
    pub fn live(mut self) -> Self {
        self.live = true;
        self
    }

    /// Market rows for exact contracts, in no particular order.
    pub async fn tokens(self, tokens: &[String]) -> Result<Vec<Token>, Fail> {
        let data = self.query(&queries::tokens(tokens), LIVE).await?;
        results(&data["s"])
    }

    pub async fn token(self, token: &str) -> Result<Token, Fail> {
        self.tokens(&[token.to_string()])
            .await?
            .into_iter()
            .next()
            .ok_or_else(not_indexed)
    }

    pub async fn search(self, phrase: &str) -> Result<Vec<Token>, Fail> {
        let data = self
            .query(&queries::search(phrase), Duration::from_secs(180))
            .await?;
        results(&data["s"])
    }

    pub async fn trending(self, limit: u32) -> Result<Vec<Token>, Fail> {
        let data = self.query(&queries::trending(limit), LIVE).await?;
        results(&data["s"])
    }

    pub async fn holders(self, token: &str, limit: u32) -> Result<Holders, Fail> {
        let data = self.query(&queries::holders(token, limit), MINUTE).await?;
        let items: Vec<Holder> = parse(data["h"]["items"].clone())?;
        let s = &data["s"]["results"][0];
        Ok(Holders {
            count: crate::providers::num(&data["h"]["count"]),
            items,
            price_usd: crate::providers::num(&s["priceUSD"]),
            pool: s["pair"]["address"].as_str().map(str::to_string),
            symbol: s["token"]["symbol"].as_str().map(str::to_string),
            supply: crate::providers::num(&s["token"]["info"]["totalSupply"]),
        })
    }

    pub async fn pools(self, token: &str, limit: u32) -> Result<Vec<Pool>, Fail> {
        let data = self.query(&queries::pools(token, limit), LIVE).await?;
        results(&data["p"])
    }

    /// Recent and large trades on each pool, recent first per pool.
    pub async fn events(
        &self,
        pools: &[String],
        buys: bool,
        sells: bool,
        min_usd: f64,
        big_usd: f64,
    ) -> Result<(Vec<Event>, Vec<Event>), Fail> {
        let query = queries::events(pools, buys, sells, min_usd, big_usd);
        let data = self.query(&query, LIVE).await?;
        let collect = |prefix: &str| -> Result<Vec<Event>, Fail> {
            let mut out = vec![];
            for i in 0..pools.len() {
                let items = data[format!("{prefix}{i}")]["items"].clone();
                if !items.is_null() {
                    out.extend(parse::<Vec<Event>>(items)?);
                }
            }
            Ok(out)
        };
        Ok((collect("e")?, collect("b")?))
    }

    /// Main bars and, when asked, the context range's bars.
    pub async fn bars(
        &self,
        token: &str,
        main: &BarSpan,
        context: Option<&BarSpan>,
    ) -> Result<(Bars, Option<Bars>), Fail> {
        // Bars are cached for their own step, so a repeat within one bar is free.
        let ttl =
            Duration::from_secs(((main.to - main.from) / main.bars.max(1)).clamp(20, 300) as u64);
        let data = self
            .query(&queries::bars(token, main, context), ttl)
            .await?;
        let main_bars: Bars = parse(data["m"].clone())?;
        let context_bars = match context {
            Some(_) if !data["x"].is_null() => Some(parse(data["x"].clone())?),
            _ => None,
        };
        Ok((main_bars, context_bars))
    }

    pub async fn balances(self, wallet: &str) -> Result<Vec<Balance>, Fail> {
        let data = self.query(&queries::balances(wallet), MINUTE).await?;
        let items = data["b"]["items"].clone();
        if items.is_null() {
            return Ok(vec![]);
        }
        parse(items)
    }

    async fn query(self, query: &str, ttl: Duration) -> Result<Value, Fail> {
        let secret = self
            .turn
            .key(Source::Codex)
            .ok_or(Fail::Unconfigured(Source::Codex))?
            .to_string();
        let mut request = Request::new(Source::Codex, format!("codex:{query}"), Cost::Codex, ttl);
        if self.live {
            request = request.live_only();
        }
        let http = &self.rt.http;
        let query = query.to_string();
        self.rt
            .fetch(self.turn, request, || async move {
                let provider = tempo(&secret)?;
                let response = http
                    .post(URL)
                    .header("X-Codex-Payment", "mpp")
                    .json(&json!({ "query": query }))
                    .send_with_payment(provider.as_ref())
                    .await
                    .map_err(|_| Fail::unavailable(Source::Codex, "request failed"))?;
                let status = response.status();
                if status.as_u16() == 429 {
                    return Err(Fail::RateLimited {
                        source: Source::Codex,
                        retry_after_s: 30,
                    });
                }
                if !status.is_success() {
                    return Err(Fail::unavailable(Source::Codex, format!("HTTP {status}")));
                }
                let body: Value = response
                    .json()
                    .await
                    .map_err(|_| Fail::bad(Source::Codex, "response was not JSON"))?;
                unwrap_response(body)
            })
            .await
    }
}

/// GraphQL `{data, errors}`: data with every alias null is a failure; a
/// "not found" error means the contract isn't indexed.
fn unwrap_response(body: Value) -> Result<Value, Fail> {
    let errors: Vec<&str> = body["errors"]
        .as_array()
        .map(|e| e.iter().filter_map(|x| x["message"].as_str()).collect())
        .unwrap_or_default();
    let data = body.get("data").cloned().unwrap_or(Value::Null);
    let empty = data
        .as_object()
        .is_none_or(|m| m.values().all(Value::is_null));
    if !empty {
        return Ok(data);
    }
    let message = errors.join("; ").to_ascii_lowercase();
    if message.contains("not found") || message.contains("could not find") {
        return Err(not_indexed());
    }
    Err(Fail::bad(Source::Codex, "query returned no data"))
}

fn not_indexed() -> Fail {
    Fail::NotFound(
        "no Robinhood Chain market indexed for this exact contract; check the address and chain"
            .into(),
    )
}

fn results<T: DeserializeOwned>(list: &Value) -> Result<Vec<T>, Fail> {
    parse(list["results"].clone())
}

fn parse<T: DeserializeOwned>(value: Value) -> Result<T, Fail> {
    crate::providers::parse(Source::Codex, value)
}

/// Tempo payment provider for the operator's MPP wallet, built once per key.
fn tempo(key: &str) -> Result<Arc<TempoProvider>, Fail> {
    static SLOT: Mutex<Option<(String, Arc<TempoProvider>)>> = Mutex::new(None);
    let mut slot = SLOT.lock().unwrap_or_else(|e| e.into_inner());
    if let Some((cached, provider)) = slot.as_ref()
        && cached == key
    {
        return Ok(provider.clone());
    }
    let invalid = || Fail::Unconfigured(Source::Codex);
    let signer: mpp::PrivateKeySigner = key.trim().parse().map_err(|_| invalid())?;
    let provider = TempoProvider::new(signer, "https://rpc.tempo.xyz")
        .map_err(|_| invalid())?
        .with_client_id("hoodit");
    let provider = Arc::new(provider);
    *slot = Some((key.to_string(), provider.clone()));
    Ok(provider)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn small_usd_buys_keep_eth_precision_and_require_a_price() {
        use crate::domain::exit::{Exits, Size};
        use crate::providers::{NATIVE, WETH};
        let token = "0x1111111111111111111111111111111111111111";
        let neutral = "0x0bf3e6f5ef3d32dccce208a1dd8fa9251893dd91";
        let prices = format!("codex:{}", queries::tokens(&[token.into(), WETH.into()]));
        let quote = json!({"estimate":{"toAmount":"10","toAmountMin":"9"}});
        let recorded = std::collections::BTreeMap::from([
            (
                prices,
                json!({"s":{"results":[{"token":{"address":WETH},"priceUSD":"3000"}]}}),
            ),
            (
                format!("chain:decimals:{token}"),
                json!(format!("0x{:064x}", 18)),
            ),
            (
                format!("lifi:{NATIVE}>{token}:16666666666667:{neutral}:0.1"),
                quote.clone(),
            ),
            (format!("lifi:{token}>{NATIVE}:10:{neutral}:0.1"), quote),
        ]);
        let app = crate::runtime::HooditApp::replaying(recorded);
        let rt = app.runtime().unwrap();
        let turn = Turn::with_keys(None, Some("recorded"));
        let (trip, _) = rt
            .tokio
            .block_on(Exits::new(&rt, &turn).round_trip_sized(token, Size::Usd(0.05), 0.1))
            .unwrap();
        assert_eq!(trip.eth_in, "0.000016666666666667");
        assert!(trip.buy.is_ok(), "exact atomic input must match the quote");
        let unknown = crate::runtime::HooditApp::replaying(Default::default());
        let rt = unknown.runtime().unwrap();
        assert!(
            rt.tokio
                .block_on(Exits::new(&rt, &turn).round_trip_sized(token, Size::Usd(0.05), 0.1))
                .is_err()
        );
    }

    #[test]
    fn recorded_tokens_parse() {
        let data: Value =
            serde_json::from_str(include_str!("../../fixtures/filter-tokens.json")).unwrap();
        let rows: Vec<Token> = results(&data["data"]["s"]).unwrap();
        assert!(!rows.is_empty());
        assert!(rows.iter().all(|r| r.token.address.starts_with("0x")));
    }

    #[test]
    fn missing_contracts_are_not_found() {
        let body = json!({ "data": { "s": null }, "errors": [{ "message": "Token not found" }] });
        assert!(matches!(unwrap_response(body), Err(Fail::NotFound(_))));
        let body = json!({ "data": { "s": null }, "errors": [{ "message": "boom" }] });
        assert!(matches!(
            unwrap_response(body),
            Err(Fail::BadResponse { .. })
        ));
    }

    #[test]
    fn pools_know_their_traded_side() {
        let pool: Pool = serde_json::from_value(json!({
            "quoteToken": "token1", "pair": { "address": "0xp", "token0": "0xweth", "token1": "0xcoin" }
        }))
        .unwrap();
        assert_eq!(pool.traded(), Some("0xcoin"));
    }
}

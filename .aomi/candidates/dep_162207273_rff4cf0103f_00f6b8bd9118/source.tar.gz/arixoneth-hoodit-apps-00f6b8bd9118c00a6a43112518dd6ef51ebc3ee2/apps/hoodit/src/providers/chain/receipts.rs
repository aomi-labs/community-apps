//! Confirmed receipts and wallet-local ERC-20 deltas. Pool events are not
//! wallet settlement. Native input needs a complete execution trace because
//! an event's declared fromAmount does not account for ETH refunds.
use super::Chain;
use crate::runtime::{Cost, Fail, Request, Source};
use num_bigint::{BigInt, BigUint};
use num_traits::{ToPrimitive, Zero};
use serde::Deserialize;
use serde_json::{Value, json};
use std::collections::BTreeMap;
use std::time::Duration;

const TRANSFER: &str = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef";
const APPROVAL: &str = "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925";
const LIFI_COMPLETED: &str = "0x38eee76fd911eabac79da7af16053e809be0e12c8637f156e77e1af309b99537";
const LIFI: &str = "0xb477751b76cf82d00a686a1232f5fcd772414af3";
const TTL: Duration = Duration::from_secs(24 * 3600);

#[derive(Clone, Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Receipt {
    pub transaction_hash: String,
    pub block_number: String,
    pub transaction_index: String,
    pub status: String,
    pub from: String,
    pub to: Option<String>,
    pub gas_used: String,
    pub effective_gas_price: String,
    pub logs: Vec<Log>,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Log {
    pub address: String,
    pub topics: Vec<String>,
    pub data: String,
    #[serde(default)]
    pub transaction_hash: String,
    #[serde(default)]
    pub block_number: String,
    #[serde(default)]
    pub transaction_index: String,
    #[serde(default)]
    pub removed: bool,
}

#[derive(Debug, Deserialize)]
pub struct Transaction {
    pub hash: String,
    pub from: String,
    pub to: Option<String>,
    pub value: String,
    pub nonce: String,
    pub input: String,
}

impl Chain<'_> {
    pub async fn receipt(self, tx: &str) -> Result<Receipt, Fail> {
        let value = self
            .read("receipt", tx, "eth_getTransactionReceipt", json!([tx]))
            .await?;
        let receipt: Receipt = crate::providers::parse(Source::Chain, value)?;
        if !receipt.transaction_hash.eq_ignore_ascii_case(tx) || receipt.status != "0x1" {
            return Err(Fail::NoData(
                "trade receipt is not a successful confirmed transaction".into(),
            ));
        }
        Ok(receipt)
    }

    pub async fn transaction(self, tx: &str) -> Result<Transaction, Fail> {
        let value = self
            .read("transaction", tx, "eth_getTransactionByHash", json!([tx]))
            .await?;
        let transaction: Transaction = crate::providers::parse(Source::Chain, value)?;
        if !transaction.hash.eq_ignore_ascii_case(tx) {
            return Err(bad("transaction hash mismatch"));
        }
        Ok(transaction)
    }

    async fn read(self, kind: &str, tx: &str, method: &str, params: Value) -> Result<Value, Fail> {
        let request =
            Request::new(Source::Chain, format!("chain:{kind}:{tx}"), Cost::Free, TTL).live_only();
        self.rt
            .fetch(self.turn, request, || self.rpc(method, params))
            .await
    }

    /// Only a distinct approve transaction immediately preceding this swap
    /// in the sender's nonce sequence can be charged to this trade. Older or
    /// unrelated approvals are not silently attributed to the round.
    pub async fn approval(
        self,
        swap: &Receipt,
        tx: &Transaction,
        token: &str,
    ) -> Result<Option<Receipt>, Fail> {
        let Some(spender) = &tx.to else {
            return Ok(None);
        };
        let block = hex_u64(&swap.block_number)?;
        let owner_topic = format!("0x{:0>64}", tx.from.trim_start_matches("0x"));
        let spender_topic = format!("0x{:0>64}", spender.trim_start_matches("0x"));
        let params = json!([{"address":token,"fromBlock":format!("0x{:x}", block.saturating_sub(1200)),"toBlock":swap.block_number,"topics":[APPROVAL,owner_topic,spender_topic]}]);
        let value = self
            .read(
                "approvals",
                &format!("{}:{token}", swap.transaction_hash),
                "eth_getLogs",
                params,
            )
            .await?;
        let logs: Vec<Log> = crate::providers::parse(Source::Chain, value)?;
        let mut candidates: Vec<_> = logs
            .iter()
            .filter(|log| {
                !log.removed
                    && log.address.eq_ignore_ascii_case(token)
                    && log.topics.first().is_some_and(|t| t == APPROVAL)
                    && log.topics.get(1) == Some(&owner_topic)
                    && log.topics.get(2) == Some(&spender_topic)
                    && log.transaction_hash != swap.transaction_hash
                    && position(log)
                        .is_some_and(|p| p < (block, hex_u64(&swap.transaction_index).unwrap_or(0)))
            })
            .collect();
        candidates.sort_by_key(|log| position(log));
        let Some(log) = candidates.last() else {
            return Ok(None);
        };
        let previous = self.transaction(&log.transaction_hash).await?;
        if !previous.from.eq_ignore_ascii_case(&tx.from)
            || !previous
                .to
                .as_ref()
                .is_some_and(|to| to.eq_ignore_ascii_case(token))
            || hex_u64(&previous.nonce)?.checked_add(1) != Some(hex_u64(&tx.nonce)?)
            || !previous.input.starts_with("0x095ea7b3")
            || previous.input.len() != 138
            || !previous.input[2..].bytes().all(|b| b.is_ascii_hexdigit())
            || !previous.input[34..74].eq_ignore_ascii_case(spender.trim_start_matches("0x"))
            || !raw(&previous.value)?.is_zero()
        {
            return Ok(None);
        }
        let receipt = self.receipt(&previous.hash).await?;
        if !receipt.deltas(&tx.from)?.is_empty() {
            return Ok(None);
        }
        Ok(Some(receipt))
    }
}

fn position(log: &Log) -> Option<(u64, u64)> {
    Some((
        hex_u64(&log.block_number).ok()?,
        hex_u64(&log.transaction_index).ok()?,
    ))
}

impl Receipt {
    pub fn gas_eth(&self, wallet: &str) -> Result<f64, Fail> {
        if !self.from.eq_ignore_ascii_case(wallet) {
            return Ok(0.0);
        }
        scaled(
            &(raw(&self.gas_used)? * raw(&self.effective_gas_price)?),
            18,
        )
    }

    pub fn deltas(&self, wallet: &str) -> Result<BTreeMap<String, BigInt>, Fail> {
        let mut deltas: BTreeMap<String, BigInt> = BTreeMap::new();
        for log in &self.logs {
            if log.removed || log.topics.len() != 3 || log.topics[0] != TRANSFER {
                continue;
            }
            let from = address_word(&log.topics[1])?;
            let to = address_word(&log.topics[2])?;
            if !from.eq_ignore_ascii_case(wallet) && !to.eq_ignore_ascii_case(wallet) {
                continue;
            }
            if log.data.len() != 66 {
                return Err(bad("malformed wallet transfer"));
            }
            let amount = BigInt::from(raw(&log.data)?);
            let delta = deltas.entry(log.address.to_lowercase()).or_default();
            if from.eq_ignore_ascii_case(wallet) {
                *delta -= &amount;
            }
            if to.eq_ignore_ascii_case(wallet) {
                *delta += amount;
            }
        }
        deltas.retain(|_, amount| !amount.is_zero());
        Ok(deltas)
    }

    /// LI.FI emits this after sending the final native payout. Its input
    /// amount is intentionally ignored: it can be caller-declared, refunded.
    pub fn native_payout(&self, wallet: &str) -> Result<Option<BigUint>, Fail> {
        let mut payout = None;
        if !self
            .to
            .as_ref()
            .is_some_and(|to| to.eq_ignore_ascii_case(LIFI))
        {
            return Ok(None);
        }
        for log in &self.logs {
            if log.removed
                || !log.address.eq_ignore_ascii_case(LIFI)
                || log.topics.first().is_none_or(|t| t != LIFI_COMPLETED)
            {
                continue;
            }
            let words: Vec<_> = log
                .data
                .strip_prefix("0x")
                .ok_or_else(|| bad("malformed swap event"))?
                .as_bytes()
                .chunks(64)
                .collect();
            if words.len() < 7 {
                return Err(bad("malformed swap event"));
            }
            let word =
                |i: usize| std::str::from_utf8(words[i]).map_err(|_| bad("malformed swap event"));
            if address_word(word(2)?)?.eq_ignore_ascii_case(wallet)
                && address_word(word(4)?)? == crate::providers::NATIVE
            {
                if payout.is_some() {
                    return Err(bad("multiple native payouts require reconciliation"));
                }
                payout = Some(raw(word(6)?)?);
            }
        }
        Ok(payout)
    }
}

pub fn raw(hex: &str) -> Result<BigUint, Fail> {
    let value = hex.strip_prefix("0x").unwrap_or(hex);
    if value.is_empty() || value.len() > 64 {
        return Err(bad("invalid EVM quantity"));
    }
    BigUint::parse_bytes(value.as_bytes(), 16).ok_or_else(|| bad("invalid EVM quantity"))
}

pub fn scaled(amount: &BigUint, decimals: u8) -> Result<f64, Fail> {
    let value = amount
        .to_f64()
        .ok_or_else(|| bad("amount exceeds numeric range"))?
        / 10f64.powi(i32::from(decimals));
    if value.is_finite() {
        Ok(value)
    } else {
        Err(bad("amount exceeds numeric range"))
    }
}

fn hex_u64(value: &str) -> Result<u64, Fail> {
    raw(value)?
        .to_u64()
        .ok_or_else(|| bad("EVM index exceeds numeric range"))
}

fn address_word(value: &str) -> Result<String, Fail> {
    let word = value.strip_prefix("0x").unwrap_or(value);
    if word.len() != 64
        || !word.bytes().all(|b| b.is_ascii_hexdigit())
        || !word[..24].bytes().all(|b| b == b'0')
    {
        return Err(bad("invalid address in receipt"));
    }
    Ok(format!("0x{}", &word[24..]).to_lowercase())
}

fn bad(message: &str) -> Fail {
    Fail::bad(Source::Chain, message)
}

#[cfg(test)]
mod tests {
    use super::*;
    const WALLET: &str = "0x1111111111111111111111111111111111111111";

    fn payout() -> Receipt {
        let address = |a: &str| format!("{:0>64}", a.trim_start_matches("0x"));
        serde_json::from_value(json!({
            "transactionHash":"0xtest","blockNumber":"0x1","transactionIndex":"0x0","status":"0x1",
            "from":WALLET,"to":LIFI,"gasUsed":"0x5208","effectiveGasPrice":"0x1",
            "logs":[{"address":LIFI,"topics":[LIFI_COMPLETED,"0xtest"],"data":format!("0x{}{}{}{}{}{}{}",address("e0"),address("120"),address(WALLET),address("22"),address(crate::providers::NATIVE),address("ffff"),address("1234"))}]
        })).unwrap()
    }

    #[test]
    fn native_output_is_only_the_official_routers_final_wallet_payout() {
        let receipt = payout();
        assert_eq!(
            receipt.native_payout(WALLET).unwrap(),
            Some(BigUint::from(0x1234u32))
        );
        assert_eq!(
            receipt
                .native_payout("0x2222222222222222222222222222222222222222")
                .unwrap(),
            None
        );
        assert_eq!(
            receipt
                .gas_eth("0x2222222222222222222222222222222222222222")
                .unwrap(),
            0.0
        );
        let mut forged = receipt.clone();
        forged.logs[0].address = WALLET.into();
        assert_eq!(forged.native_payout(WALLET).unwrap(), None);
        let mut duplicate = receipt.clone();
        duplicate.logs.push(receipt.logs[0].clone());
        assert!(duplicate.native_payout(WALLET).is_err());
    }

    #[test]
    fn malformed_receipt_words_fail_without_panicking() {
        assert!(address_word(&format!("{}é{}", "0".repeat(23), "0".repeat(39))).is_err());
        let mut receipt = payout();
        receipt.logs[0].data = "0x1234".into();
        assert!(receipt.native_payout(WALLET).is_err());
    }
}

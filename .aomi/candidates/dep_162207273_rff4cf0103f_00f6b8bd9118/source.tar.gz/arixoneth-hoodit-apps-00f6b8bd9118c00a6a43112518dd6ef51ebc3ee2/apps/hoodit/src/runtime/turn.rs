//! Per-tool-call context: credentials, the thread and wallet it belongs to,
//! and the gaps and sources the reply must disclose. Shared by reference
//! across the concurrent reads of one tool call.
use super::{Lane, Source};
use aomi_sdk::DynToolCallCtx;
use serde_json::Value;
use std::collections::BTreeSet;
use std::sync::Mutex;

pub const CODEX_KEY: &str = "CODEX_MPP_KEY";
pub const GMGN_KEY: &str = "GMGN_API_KEY";
pub const LIFI_KEY: &str = "LIFI_API_KEY";
pub const BLOCKSCOUT_KEY: &str = "BLOCKSCOUT_API_KEY";
pub const SETTINGS_URL: &str = "HOODIT_SETTINGS_URL";
pub const SETTINGS_TOKEN: &str = "HOODIT_SETTINGS_TOKEN";

#[derive(Default)]
pub struct Turn {
    /// The chat thread; budgets that should be per answer key on it.
    pub thread: String,
    call_id: String,
    /// The user's connected wallet, lowercased.
    pub wallet: Option<String>,
    /// The host account the chat belongs to; `None` for guests.
    pub account: Option<String>,
    pub lane: Lane,
    codex_key: Option<String>,
    gmgn_key: Option<String>,
    lifi_key: Option<String>,
    blockscout_key: Option<String>,
    settings_url: Option<String>,
    settings_token: Option<String>,
    notes: Mutex<Notes>,
}

#[derive(Default)]
struct Notes {
    gaps: Vec<String>,
    sources: BTreeSet<Source>,
}

impl Turn {
    pub fn new(ctx: &DynToolCallCtx, lane: Lane) -> Self {
        let secret = |name: &str| {
            aomi_sdk::resolve_secret_value(ctx, None, name, "")
                .ok()
                .map(|v| v.trim().trim_matches(|c| c == '"' || c == '\'').to_string())
                .filter(|v| !v.is_empty())
        };
        let wallet = ctx
            .attribute_path(&["domain", "evm", "address"])
            .and_then(Value::as_str)
            .and_then(|a| crate::view::address(a).ok());
        // It becomes a URL path segment in the settings store.
        let account = ctx
            .attribute_path(&["hosted", "account_id"])
            .and_then(Value::as_str)
            .filter(|a| {
                (1..=128).contains(&a.len())
                    && a.bytes()
                        .all(|b| b.is_ascii_alphanumeric() || b == b'-' || b == b'_')
            })
            .map(str::to_string);
        Self {
            thread: ctx.session_id.clone(),
            call_id: ctx.call_id.clone(),
            wallet,
            account,
            lane,
            codex_key: secret(CODEX_KEY),
            gmgn_key: secret(GMGN_KEY),
            lifi_key: secret(LIFI_KEY),
            blockscout_key: secret(BLOCKSCOUT_KEY),
            settings_url: secret(SETTINGS_URL),
            settings_token: secret(SETTINGS_TOKEN),
            notes: Mutex::default(),
        }
    }

    pub fn key(&self, source: Source) -> Option<&str> {
        match source {
            Source::Codex => self.codex_key.as_deref(),
            Source::Gmgn => self.gmgn_key.as_deref(),
            Source::Lifi => self.lifi_key.as_deref(),
            Source::Chain => self.blockscout_key.as_deref(),
            Source::Settings => self.settings_token.as_deref(),
        }
    }

    /// The settings store's base URL and token, when both are set.
    pub fn settings_store(&self) -> Option<(&str, &str)> {
        self.settings_url
            .as_deref()
            .zip(self.settings_token.as_deref())
    }

    /// Opt-in timing rows alongside the existing GMGN trace. No arguments or credentials.
    pub fn trace(
        &self,
        source: Source,
        operation: &str,
        phase: &str,
        elapsed: std::time::Duration,
        outcome: &str,
    ) {
        use std::io::Write;
        let Some(path) = std::env::var_os("HOODIT_TRACE") else {
            return;
        };
        let row = serde_json::json!({"at":crate::view::now(),"call_id":self.call_id,
            "source":source,"operation":operation,"phase":phase,"ms":elapsed.as_secs_f64()*1000.0,"outcome":outcome});
        if let Ok(mut file) = std::fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(path)
        {
            let _ = file.write_all(format!("{row}\n").as_bytes());
        }
    }

    /// Something the reply is missing or approximating, said once.
    pub fn gap(&self, gap: impl Into<String>) {
        let gap = gap.into();
        if let Ok(mut notes) = self.notes.lock()
            && !notes.gaps.contains(&gap)
        {
            notes.gaps.push(gap);
        }
    }

    pub fn used(&self, source: Source) {
        if let Ok(mut notes) = self.notes.lock() {
            notes.sources.insert(source);
        }
    }

    pub fn gaps(&self) -> Vec<String> {
        self.notes
            .lock()
            .map(|n| n.gaps.clone())
            .unwrap_or_default()
    }

    pub fn sources(&self) -> Vec<Source> {
        self.notes
            .lock()
            .map(|n| n.sources.iter().copied().collect())
            .unwrap_or_default()
    }

    #[cfg(test)]
    pub fn with_keys(gmgn: Option<&str>, codex: Option<&str>) -> Self {
        Self {
            thread: "test".into(),
            gmgn_key: gmgn.map(str::to_string),
            codex_key: codex.map(str::to_string),
            ..Self::default()
        }
    }
}

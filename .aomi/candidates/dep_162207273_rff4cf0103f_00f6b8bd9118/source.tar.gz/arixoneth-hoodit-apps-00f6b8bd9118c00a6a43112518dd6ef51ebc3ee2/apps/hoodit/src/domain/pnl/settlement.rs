//! Reconcile each distinct fill transaction once, including wallet-level
//! route fees and refunds. GMGN supplies the history, never cash proceeds.
use crate::providers::{
    NATIVE, WETH,
    chain::{
        Chain,
        receipts::{Receipt, raw, scaled},
    },
    gmgn::types::Activity,
};
use crate::runtime::{Fail, Turn};
use num_bigint::{BigInt, BigUint};
use num_traits::{Signed, ToPrimitive, Zero};
use std::collections::{BTreeMap, BTreeSet};

pub const USDG: &str = "0x5fc5360d0400a0fd4f2af552add042d716f1d168";
const MAX_TRANSACTIONS: usize = 24;

pub struct Settlement {
    pub cost: Option<f64>,
    pub out: f64,
    pub bought: BigUint,
    pub sold: BigUint,
    pub gas_eth: f64,
    pub gas_transactions: u32,
    pub estimated_fx: bool,
}

pub async fn read(
    chain: Chain<'_>,
    turn: &Turn,
    wallet: &str,
    token: &str,
    rows: &[Activity],
) -> Result<Settlement, Fail> {
    let mut trades = BTreeMap::new();
    for row in rows
        .iter()
        .filter(|r| matches!(r.event_type.as_str(), "buy" | "sell"))
    {
        let hash = row.tx_hash.to_lowercase();
        if hash.len() != 66
            || !hash.starts_with("0x")
            || !hash[2..].bytes().all(|b| b.is_ascii_hexdigit())
        {
            return Err(Fail::NoData(
                "trade history has an invalid transaction hash".into(),
            ));
        }
        if let Some(previous) = trades.insert(hash, row)
            && previous.event_type != row.event_type
        {
            return Err(Fail::NoData("one transaction buys and sells this token; wallet settlement needs separate reconciliation".into()));
        }
    }
    if trades.len() > MAX_TRANSACTIONS {
        return Err(Fail::NoData(
            "this round has too many transactions to reconcile in one card".into(),
        ));
    }
    let mut settlement = Settlement {
        cost: Some(0.0),
        out: 0.0,
        bought: BigUint::zero(),
        sold: BigUint::zero(),
        gas_eth: 0.0,
        gas_transactions: 0,
        estimated_fx: false,
    };
    let mut gas_seen = BTreeSet::new();
    for (hash, row) in trades {
        let (receipt, transaction) =
            tokio::try_join!(chain.receipt(&hash), chain.transaction(&hash))?;
        let deltas = receipt.deltas(wallet)?;
        let quantity = deltas.get(token).ok_or_else(|| {
            Fail::NoData("indexed trade has no wallet transfer of this token".into())
        })?;
        let buy = row.event_type == "buy";
        if buy != quantity.is_positive() {
            return Err(Fail::NoData(
                "indexed trade direction disagrees with the wallet receipt".into(),
            ));
        }
        if buy {
            settlement.bought += quantity.magnitude();
        } else {
            settlement.sold += quantity.magnitude();
        }
        let native_input = !raw(&transaction.value)?.is_zero();
        let native = if native_input {
            match chain.native_delta(&transaction, wallet).await {
                Ok(delta) => Some(delta),
                Err(fail) => {
                    turn.gap(format!("native ETH spend/refund reconciliation unavailable ({}); cost basis is unavailable", fail.message()));
                    None
                }
            }
        } else {
            None
        };
        let cash = if native_input && native.is_none() {
            None
        } else {
            cashflow(
                &receipt,
                wallet,
                token,
                &deltas,
                row,
                native.as_ref(),
                &mut settlement.estimated_fx,
            )?
        };
        match (buy, cash) {
            (true, Some(value)) if value < 0.0 => {
                settlement.cost = settlement.cost.map(|c| c - value)
            }
            (true, _) => {
                settlement.cost = None;
                if !native_input || native.is_some() {
                    turn.gap(
                        "one buy's final wallet spend cannot be priced; cost basis is unavailable",
                    );
                }
            }
            (false, Some(value)) if value >= 0.0 => settlement.out += value,
            (false, _) => return Err(Fail::NoData(
                "final wallet sale proceeds are unavailable; no pool-leg estimate was substituted"
                    .into(),
            )),
        }
        add_gas(&mut settlement, &mut gas_seen, &receipt, wallet)?;
        if transaction.from.eq_ignore_ascii_case(wallet) {
            let spent: Vec<_> = deltas
                .iter()
                .filter(|(_, amount)| amount.is_negative())
                .collect();
            for (input, _) in spent {
                match chain.approval(&receipt, &transaction, input).await {
                    Ok(Some(approval)) => add_gas(&mut settlement, &mut gas_seen, &approval, wallet)?,
                    Ok(None) => {},
                    Err(fail) => turn.gap(format!("approval gas lookup unavailable ({}); gas includes only verified transactions", fail.code())),
                }
            }
        }
    }
    Ok(settlement)
}

fn add_gas(
    settlement: &mut Settlement,
    seen: &mut BTreeSet<String>,
    receipt: &Receipt,
    wallet: &str,
) -> Result<(), Fail> {
    if receipt.from.eq_ignore_ascii_case(wallet)
        && seen.insert(receipt.transaction_hash.to_lowercase())
    {
        settlement.gas_eth += receipt.gas_eth(wallet)?;
        settlement.gas_transactions += 1;
    }
    Ok(())
}

fn cashflow(
    receipt: &Receipt,
    wallet: &str,
    token: &str,
    deltas: &BTreeMap<String, BigInt>,
    row: &Activity,
    native: Option<&BigInt>,
    estimated: &mut bool,
) -> Result<Option<f64>, Fail> {
    let mut total = 0.0;
    let mut found = false;
    for (asset, amount) in deltas.iter().filter(|(asset, _)| *asset != token) {
        let value = if asset == USDG {
            scaled(amount.magnitude(), 6)?
        } else if asset == WETH {
            let Some(fx) = eth_usd(row) else {
                return Ok(None);
            };
            *estimated = true;
            scaled(amount.magnitude(), 18)? * fx
        } else {
            return Ok(None);
        };
        found = true;
        total += if amount.is_negative() { -value } else { value };
    }
    if let Some(delta) = native {
        let Some(fx) = eth_usd(row) else {
            return Ok(None);
        };
        *estimated = true;
        let value = scaled(delta.magnitude(), 18)? * fx;
        total += if delta.is_negative() { -value } else { value };
        found = true;
    } else if let Some(payout) = receipt.native_payout(wallet)? {
        let Some(fx) = eth_usd(row) else {
            return Ok(None);
        };
        *estimated = true;
        total += scaled(&payout, 18)? * fx;
        found = true;
    }
    // Zero proceeds is valid only when the wallet's settlement proves it;
    // absent transfer events cannot establish a worthless final payout.
    Ok(found.then_some(total))
}

fn eth_usd(row: &Activity) -> Option<f64> {
    let quote = row.quote_address.as_deref()?;
    if !quote.eq_ignore_ascii_case(NATIVE) && !quote.eq_ignore_ascii_case(WETH) {
        return None;
    }
    let amount = row.quote_amount.get().filter(|v| *v > 0.0)?;
    let fx = row.cost_usd.get()? / amount;
    (fx.is_finite() && fx > 0.0).then_some(fx)
}

pub fn token_amount(raw: &BigUint, decimals: Option<u8>) -> Option<f64> {
    let amount = raw.to_f64()? / 10f64.powi(i32::from(decimals?));
    (amount.is_finite() && amount > 0.0).then_some(amount)
}

//! Complete Blockscout execution traces, not pool events or block-wide
//! balances. Count committed native transfers only, excluding gas.
use super::{
    Chain,
    receipts::{Transaction, raw},
};
use crate::runtime::{Fail, Source};
use num_bigint::BigInt;
use num_traits::Zero;
use serde_json::Value;
use std::time::Duration;

const MAX_FRAMES: usize = 4096;

impl Chain<'_> {
    pub async fn native_delta(self, tx: &Transaction, wallet: &str) -> Result<BigInt, Fail> {
        let value = self
            .explorer(
                &format!("transactions/{}/raw-trace", tx.hash),
                &[],
                &format!("chain:native-trace:{}", tx.hash),
                Duration::from_secs(24 * 3600),
                |value| delta(value, tx, wallet).map(|_| ()),
            )
            .await?;
        delta(&value, tx, wallet)
    }
}

fn delta(value: &Value, tx: &Transaction, wallet: &str) -> Result<BigInt, Fail> {
    // Robinhood's Arbitrum tracer returns a Geth call tree, including extra
    // before/afterEVMTransfers for gas. Those fee records are deliberately
    // excluded: receipt gas is reported separately.
    if text(value, "type")? != "CALL"
        || !address(value, "from")?.eq_ignore_ascii_case(&tx.from)
        || tx
            .to
            .as_ref()
            .is_none_or(|to| !address(value, "to").is_ok_and(|a| a.eq_ignore_ascii_case(to)))
        || raw(text(value, "value")?)? != raw(&tx.value)?
        || !text(value, "input")?.eq_ignore_ascii_case(&tx.input)
        || failed(value)?
        || value["calls"].as_array().is_none_or(Vec::is_empty)
    {
        return Err(bad("native ETH trace root disagrees with confirmed swap"));
    }
    let mut net = BigInt::zero();
    let mut stack = vec![(value, 0)];
    let mut count = 0;
    while let Some((frame, depth)) = stack.pop() {
        count += 1;
        if count > MAX_FRAMES || depth > 128 || !frame.is_object() {
            return Err(bad("native ETH trace is malformed or too large"));
        }
        // All effects beneath a reverted call are rolled back, even if a
        // nested call itself succeeded.
        if failed(frame)? {
            continue;
        }
        raw(text(frame, "gasUsed")?)?;
        if let Some(calls) = frame.get("calls") {
            for child in calls
                .as_array()
                .ok_or_else(|| bad("native ETH trace children missing"))?
            {
                stack.push((child, depth + 1));
            }
        }
        match text(frame, "type")? {
            "CALL" | "CREATE" | "CREATE2" | "SELFDESTRUCT" => {
                let from = address(frame, "from")?;
                let to = address(frame, "to")?;
                let amount = BigInt::from(raw(text(frame, "value")?)?);
                if from.eq_ignore_ascii_case(wallet) {
                    net -= &amount;
                }
                if to.eq_ignore_ascii_case(wallet) {
                    net += amount;
                }
            }
            // These carry apparent value without transferring ETH, but their
            // children can still make genuine payments/refunds.
            "DELEGATECALL" | "CALLCODE" | "STATICCALL" => {}
            _ => return Err(bad("unsupported native ETH trace frame")),
        }
    }
    Ok(net)
}

fn text<'a>(value: &'a Value, name: &str) -> Result<&'a str, Fail> {
    value[name]
        .as_str()
        .ok_or_else(|| bad("native ETH trace field missing"))
}

fn failed(value: &Value) -> Result<bool, Fail> {
    match value.get("error") {
        None | Some(Value::Null) => Ok(false),
        Some(Value::String(message)) if !message.is_empty() => Ok(true),
        _ => Err(bad("native ETH trace error field is malformed")),
    }
}

fn address<'a>(value: &'a Value, name: &str) -> Result<&'a str, Fail> {
    let address = text(value, name)?;
    if address.len() != 42
        || !address.starts_with("0x")
        || !address[2..].bytes().all(|b| b.is_ascii_hexdigit())
    {
        return Err(bad("invalid native ETH trace address"));
    }
    Ok(address)
}

fn bad(message: &str) -> Fail {
    Fail::bad(Source::Chain, message)
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;
    const WALLET: &str = "0x1111111111111111111111111111111111111111";
    const ROUTER: &str = "0x2222222222222222222222222222222222222222";

    fn tx() -> Transaction {
        serde_json::from_value(json!({"hash":"0xaaaa","from":WALLET,"to":ROUTER,"value":"0x64","nonce":"0x0","input":"0x1234"})).unwrap()
    }
    fn call(from: &str, to: &str, amount: u64) -> Value {
        json!({"type":"CALL","from":from,"to":to,"value":format!("0x{amount:x}"),"input":"0x","gasUsed":"0x1"})
    }
    fn trace() -> Value {
        let mut root = call(WALLET, ROUTER, 100);
        root["input"] = json!("0x1234");
        root["calls"] = json!([call(ROUTER, WALLET, 20)]);
        root
    }

    #[test]
    fn native_spend_subtracts_refunds_but_keeps_gas_separate() {
        let mut root = trace();
        root["beforeEVMTransfers"] =
            json!([{"from":WALLET,"to":null,"purpose":"feePayment","value":"0x500"}]);
        root["afterEVMTransfers"] =
            json!([{"from":null,"to":WALLET,"purpose":"gasRefund","value":"0x200"}]);
        assert_eq!(delta(&root, &tx(), WALLET).unwrap(), BigInt::from(-80));
        root["calls"] = json!([call(ROUTER, ROUTER, 100)]);
        assert_eq!(delta(&root, &tx(), WALLET).unwrap(), BigInt::from(-100));
    }

    #[test]
    fn reverted_subtrees_and_delegate_value_are_not_wallet_refunds() {
        let mut root = trace();
        let mut reverted = call(ROUTER, WALLET, 40);
        reverted["error"] = json!("execution reverted");
        reverted["calls"] = json!([call(ROUTER, WALLET, 30)]);
        let mut delegated = call(ROUTER, WALLET, 100);
        delegated["type"] = json!("DELEGATECALL");
        delegated["calls"] = json!([call(ROUTER, WALLET, 5)]);
        root["calls"]
            .as_array_mut()
            .unwrap()
            .extend([reverted, delegated]);
        assert_eq!(delta(&root, &tx(), WALLET).unwrap(), BigInt::from(-75));
    }

    #[test]
    fn malformed_partial_or_wrong_transaction_trace_cannot_establish_cost() {
        for field in ["from", "to", "value", "input", "type", "gasUsed", "calls"] {
            let mut root = trace();
            root.as_object_mut().unwrap().remove(field);
            assert!(delta(&root, &tx(), WALLET).is_err(), "{field}");
        }
        for (field, value) in [
            ("from", json!(ROUTER)),
            ("value", json!("0x65")),
            ("input", json!("0x1235")),
            ("error", json!("reverted")),
            ("calls", json!([])),
        ] {
            let mut root = trace();
            root[field] = value;
            assert!(delta(&root, &tx(), WALLET).is_err(), "{field}");
        }
        let mut root = trace();
        root["calls"][0]["type"] = json!("UNKNOWN");
        assert!(delta(&root, &tx(), WALLET).is_err());
        root["calls"] = json!(vec![call(ROUTER, WALLET, 0); MAX_FRAMES]);
        assert!(delta(&root, &tx(), WALLET).is_err());
    }
}

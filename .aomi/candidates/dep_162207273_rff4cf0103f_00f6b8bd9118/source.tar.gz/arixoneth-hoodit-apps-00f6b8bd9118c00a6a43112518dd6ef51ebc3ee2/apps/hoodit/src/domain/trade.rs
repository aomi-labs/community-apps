//! Hoodit's trade rules as code, for quick actions that run without the
//! model (the trade skill states the same rules for the agent): what pays
//! for a buy, exact sizes, slippage, and when to refuse. A plan that
//! passes is a complete swap for the host to stage, simulate and commit.
use super::amount::{self, Amount};
use super::exit::{ExitResult, Exits, THIN_PCT};
use super::market::Stage;
use super::settings::{Pay, Settings};
use super::token::{Identity, Security, security};
use crate::card::format::usd;
use crate::providers::chain::Chain;
use crate::providers::gmgn::Gmgn;
use crate::providers::lifi::Lifi;
use crate::providers::{NATIVE, USDG};
use crate::runtime::{Fail, Runtime, Turn};
use crate::view::sig;
use num_bigint::BigUint;
use num_traits::Zero;

/// Less ETH than this can't pay for a swap's gas on Robinhood Chain.
pub const GAS_USD: f64 = 0.10;

/// One swap, sized exactly now.
#[derive(Clone, Debug, PartialEq)]
pub struct Trade {
    pub from_token: String,
    pub to_token: String,
    /// Exact input in the from token's whole units.
    pub amount: String,
    pub slippage_bps: u32,
    /// What the input is worth.
    pub value_usd: Option<f64>,
    /// Expected output in whole units.
    pub out: Option<f64>,
}

pub enum Plan {
    Ready(Trade),
    /// A sell that loses more than [`THIN_PCT`] to price impact; placed
    /// only once the user accepts the loss.
    Lossy(Trade, f64),
    /// Hoodit won't place it; the reason, said for the user.
    No(String),
}

/// What pays for a buy of `usd`: the user's pick, else USDG when it
/// covers the buy, else ETH when it covers the buy plus gas. Balances in
/// dollars; the result is never `Auto`.
pub fn pay_with(usd_amount: f64, pick: Pay, usdg: f64, eth_usd: f64) -> Result<Pay, String> {
    let usdg_covers = usdg >= usd_amount;
    let eth_covers = eth_usd >= usd_amount + GAS_USD;
    let pay = match pick {
        Pay::Usdg | Pay::Auto if usdg_covers => Pay::Usdg,
        Pay::Eth | Pay::Auto if eth_covers => Pay::Eth,
        _ => {
            return Err(format!(
                "Not enough: you have {} USDG and {} of ETH.",
                usd(usdg, false),
                usd(eth_usd, false)
            ));
        }
    };
    if pay == Pay::Usdg && eth_usd < GAS_USD {
        return Err("You need a little ETH for gas.".into());
    }
    Ok(pay)
}

/// The trade skill's defaults: 0.5% for base assets, 3% for memecoins
/// with over $50k liquidity, 5% below that or on a curve.
pub fn slippage_bps(id: &Identity) -> u32 {
    if id.base {
        50
    } else if id.stage != Stage::Curve && id.liquidity_usd.is_some_and(|l| l > 50_000.0) {
        300
    } else {
        500
    }
}

/// Why a memecoin or small coin fails Hoodit's buy rules at this size.
/// Unknown honeypot or tax facts fail too.
pub fn refusal(
    security: Option<&Security>,
    exit: ExitResult,
    loss_pct: Option<f64>,
) -> Option<String> {
    let Some(s) = security else {
        return Some("its contract screen is unavailable right now".into());
    };
    if s.honeypot == Some(true) {
        return Some("it's flagged as a honeypot".into());
    }
    if let Some(tax) = s.sell_tax_pct.filter(|t| *t > 10.0) {
        return Some(format!("its sell tax is {tax:.0}%"));
    }
    if s.honeypot.is_none() || s.sell_tax_pct.is_none() {
        return Some("its honeypot and sell-tax facts are unknown".into());
    }
    match exit {
        ExitResult::Ok => None,
        ExitResult::Thin => Some(format!(
            "selling back would lose {:.0}% at this size; try a smaller size",
            loss_pct.unwrap_or(THIN_PCT)
        )),
        ExitResult::Trap => Some("it's an exit trap: no way back out at this size".into()),
        ExitResult::NoBuyRoute => Some("there's no route to buy it right now".into()),
        ExitResult::Unknown => Some("its exit couldn't be checked right now".into()),
    }
}

/// Plans a buy: picks what pays, fixes the exact amount, quotes it and,
/// for memecoins, runs the security and exit rules at this size.
pub async fn buy(
    rt: &Runtime,
    turn: &Turn,
    id: &Identity,
    size: &Amount,
    settings: &Settings,
) -> Result<Plan, Fail> {
    let wallet = turn.wallet.as_deref().ok_or(Fail::NoWallet)?;
    let (chain, lifi) = (Chain::new(rt, turn), Lifi::new(rt, turn));
    let (eth_price, usdg, eth) = tokio::join!(
        lifi.price(NATIVE),
        chain.balance(USDG, wallet),
        chain.native_balance(wallet)
    );
    let (eth_price, eth) = (eth_price?, eth?);
    let usdg = usdg? as f64 / 1e6;
    let number = |n: &str| n.parse::<f64>().unwrap_or(0.0);
    let (usd_amount, pick) = match size {
        Amount::Usd(d) => (*d, settings.pay),
        Amount::Bare(n) => (number(n), settings.pay),
        Amount::Eth(e) => (number(e) * eth_price, Pay::Eth),
        Amount::Usdg(u) => (number(u), Pay::Usdg),
        Amount::Pct(_) | Amount::Tokens(..) => {
            return Ok(Plan::No(
                "Say how much to spend, like $5 or 0.002 ETH.".into(),
            ));
        }
    };
    // USDG itself is only ever bought with ETH.
    let pick = if id.token == USDG { Pay::Eth } else { pick };
    let pay = match pay_with(usd_amount, pick, usdg, eth * eth_price) {
        Ok(pay) => pay,
        Err(why) => return Ok(Plan::No(why)),
    };
    let eth_size = sig(usd_amount / eth_price, 4).to_string();
    let (from, decimals, amount) = match (size, pay) {
        (Amount::Eth(e), _) => (NATIVE, 18, e.clone()),
        (Amount::Usdg(u), _) => (USDG, 6, u.clone()),
        (_, Pay::Usdg) => (USDG, 6, format!("{usd_amount:.6}")),
        _ => (NATIVE, 18, eth_size.clone()),
    };
    let atomic = amount::from_decimal(&amount, decimals).map_err(Fail::Invalid)?;
    let (amount, atomic) = (amount::format(&atomic, decimals), atomic.to_string());
    let bps = settings.slippage_bps.unwrap_or_else(|| slippage_bps(id));
    let slippage = bps as f64 / 10_000.0;
    // Paying ETH, the exit check's buy leg is usually this same quote,
    // read once.
    let (quote, why) = tokio::join!(
        lifi.quote(from, &id.token, &atomic, wallet, slippage),
        async {
            if id.base {
                return Ok(None);
            }
            let (screen, trip) = tokio::join!(
                Gmgn::new(rt, turn).security(&id.token),
                Exits::new(rt, turn).round_trip(&id.token, &eth_size, slippage)
            );
            let trip = trip?;
            Ok::<_, Fail>(refusal(
                screen.ok().map(security).as_ref(),
                trip.result,
                trip.loss_pct,
            ))
        }
    );
    if let Some(why) = why? {
        return Ok(Plan::No(format!("Not buying **{}**: {why}.", id.symbol)));
    }
    let quote = match quote {
        Err(Fail::NoRoute(_)) => {
            return Ok(Plan::No(format!(
                "There's no route to buy **{}** right now.",
                id.symbol
            )));
        }
        other => other?,
    };
    Ok(Plan::Ready(Trade {
        from_token: from.into(),
        to_token: id.token.clone(),
        amount,
        slippage_bps: bps,
        value_usd: Some(usd_amount),
        out: whole(&quote.to_amount, id.decimals),
    }))
}

/// Plans a sell for ETH from a fresh balance: a percent becomes an exact
/// token amount now; dollars and ETH are sized at current prices.
/// Selling is always allowed; only a missing route stops it.
pub async fn sell(
    rt: &Runtime,
    turn: &Turn,
    id: &Identity,
    size: &Amount,
    settings: &Settings,
    accept_loss: bool,
) -> Result<Plan, Fail> {
    let wallet = turn.wallet.as_deref().ok_or(Fail::NoWallet)?;
    let symbol = &id.symbol;
    let held = match Chain::new(rt, turn).balance(&id.token, wallet).await {
        Ok(0) => return Ok(Plan::No(format!("You don't hold any **{symbol}**."))),
        Ok(held) => BigUint::from(held),
        Err(_) => {
            return Ok(Plan::No(format!(
                "Couldn't read your **{symbol}** balance right now."
            )));
        }
    };
    let worth = |usd_amount: f64| match id.price_usd.filter(|p| *p > 0.0) {
        Some(price) => Ok(format!(
            "{:.*}",
            id.decimals.min(6) as usize,
            usd_amount / price
        )),
        None => Err(Plan::No(format!(
            "**{symbol}** has no price right now; sell a percent instead."
        ))),
    };
    let tokens = match size {
        Amount::Pct(p) => &held * BigUint::from((p * 100.0).round() as u64) / 10_000u32,
        Amount::Tokens(n, s) if s.eq_ignore_ascii_case(symbol) => {
            amount::from_decimal(n, id.decimals).map_err(Fail::Invalid)?
        }
        Amount::Usd(d) => match worth(*d) {
            Ok(n) => amount::from_decimal(&n, id.decimals).map_err(Fail::Invalid)?,
            Err(no) => return Ok(no),
        },
        Amount::Eth(e) => {
            let eth_price = Lifi::new(rt, turn).price(NATIVE).await?;
            match worth(e.parse::<f64>().unwrap_or(0.0) * eth_price) {
                Ok(n) => amount::from_decimal(&n, id.decimals).map_err(Fail::Invalid)?,
                Err(no) => return Ok(no),
            }
        }
        _ => {
            return Ok(Plan::No(format!(
                "Say how much to sell: 50%, $10 or 1000 {symbol}."
            )));
        }
    };
    if tokens.is_zero() {
        return Ok(Plan::No("That's too small to sell.".into()));
    }
    if tokens > held {
        return Ok(Plan::No(format!(
            "You only have {} **{symbol}**.",
            amount::format(&held, id.decimals)
        )));
    }
    let bps = settings.slippage_bps.unwrap_or_else(|| slippage_bps(id));
    let sale = Exits::new(rt, turn)
        .sell(&id.token, tokens.clone(), bps as f64 / 10_000.0)
        .await?;
    match sale.sell {
        Err(Fail::NoRoute(_)) => {
            return Ok(Plan::No(format!(
                "The router can't sell **{symbol}** right now."
            )));
        }
        Err(fail) => return Err(fail),
        Ok(_) => {}
    }
    let trade = Trade {
        from_token: id.token.clone(),
        to_token: NATIVE.into(),
        amount: amount::format(&tokens, id.decimals),
        slippage_bps: bps,
        value_usd: sale.value_usd,
        out: sale.eth_out,
    };
    Ok(match sale.loss_pct {
        Some(loss) if loss > THIN_PCT && !accept_loss => Plan::Lossy(trade, loss),
        _ => Plan::Ready(trade),
    })
}

fn whole(atomic: &str, decimals: u8) -> Option<f64> {
    atomic
        .parse::<f64>()
        .ok()
        .map(|v| v / 10f64.powi(decimals as i32))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn usdg_pays_first_then_eth_keeping_gas() {
        assert_eq!(pay_with(5.0, Pay::Auto, 10.0, 20.0), Ok(Pay::Usdg));
        assert_eq!(pay_with(5.0, Pay::Auto, 3.0, 20.0), Ok(Pay::Eth));
        assert_eq!(pay_with(5.0, Pay::Eth, 10.0, 20.0), Ok(Pay::Eth));
        assert_eq!(pay_with(5.0, Pay::Usdg, 3.0, 20.0).ok(), None);
        assert_eq!(
            pay_with(5.0, Pay::Auto, 3.0, 2.0),
            Err("Not enough: you have $3.00 USDG and $2.00 of ETH.".into())
        );
        // ETH must cover the buy and its gas.
        assert!(pay_with(5.0, Pay::Auto, 0.0, 5.05).is_err());
        assert_eq!(
            pay_with(5.0, Pay::Auto, 10.0, 0.05),
            Err("You need a little ETH for gas.".into())
        );
    }

    #[test]
    fn memecoin_buys_need_a_clean_screen_and_exit() {
        let clean = Security {
            honeypot: Some(false),
            sell_tax_pct: Some(1.0),
            ..Security::default()
        };
        assert_eq!(refusal(Some(&clean), ExitResult::Ok, Some(3.0)), None);
        assert!(refusal(None, ExitResult::Ok, Some(3.0)).is_some());
        let taxed = Security {
            sell_tax_pct: Some(25.0),
            ..clean.clone()
        };
        assert_eq!(
            refusal(Some(&taxed), ExitResult::Ok, None).as_deref(),
            Some("its sell tax is 25%")
        );
        let unknown = Security {
            honeypot: None,
            ..clean.clone()
        };
        assert!(refusal(Some(&unknown), ExitResult::Ok, None).is_some());
        assert!(
            refusal(Some(&clean), ExitResult::Thin, Some(14.0))
                .unwrap()
                .contains("lose 14%")
        );
    }
}

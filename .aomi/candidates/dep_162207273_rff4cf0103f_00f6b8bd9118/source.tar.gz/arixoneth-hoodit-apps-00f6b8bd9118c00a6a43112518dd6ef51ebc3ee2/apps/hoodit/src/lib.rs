//! Hoodit: a Robinhood Chain trading friend. The host's tools cover majors,
//! stock tokens, prices and swaps; Hoodit's own go deep on memecoins: GMGN
//! finds coins and labels wallets, Codex reads depth and history, LI.FI
//! proves the exit.
//!
//! Layers, one way down: `tools` (thin adapters) → `domain` (Hoodit's
//! rules) → `providers` (one per source) → `runtime` (cache, gates, the
//! one request path); `view` builds every model-facing reply.
use aomi_sdk::*;

pub mod card;
pub mod domain;
pub mod providers;
pub mod runtime;
pub mod tools;
pub mod view;

const PREAMBLE: &str = include_str!("preamble.md");

const CODEX: Secret = Secret::new(
    runtime::CODEX_KEY,
    "Payment key for the operator's Codex market-data wallet (MPP on Tempo)",
    false,
);
const GMGN: Secret = Secret::new(
    runtime::GMGN_KEY,
    "GMGN OpenAPI key for discovery boards, KOL and smart-money feeds and wallet labels",
    false,
);
const LIFI: Secret = Secret::new(
    runtime::LIFI_KEY,
    "LI.FI integrator API key for exit quotes",
    false,
);
const BLOCKSCOUT: Secret = Secret::new(
    runtime::BLOCKSCOUT_KEY,
    "Blockscout API key for reconciling native ETH spend and refunds in PnL cards",
    false,
);
const SETTINGS_URL: Secret = Secret::new(
    runtime::SETTINGS_URL,
    "Base URL of the hoodit.trade settings store, e.g. https://hoodit.trade",
    false,
);
const SETTINGS_TOKEN: Secret = Secret::new(
    runtime::SETTINGS_TOKEN,
    "Bearer token for the hoodit.trade settings store",
    false,
);

dyn_aomi_app!(
    app = runtime::HooditApp,
    name = "hoodit",
    version = "3.2.0",
    preamble = PREAMBLE,
    tools = [
        tools::Signals,
        tools::Scan,
        tools::Find,
        tools::Token,
        tools::Chart,
        tools::Trades,
        tools::Holders,
        tools::Wallet,
        tools::Exit,
        tools::Check,
        tools::CardTool,
        tools::History,
        tools::Positions,
        tools::Pnl,
        tools::Preview,
        tools::Buy,
        tools::Sell,
        tools::PositionsView,
        tools::SettingsView
    ],
    secrets = [CODEX, GMGN, LIFI, BLOCKSCOUT, SETTINGS_URL, SETTINGS_TOKEN],
    namespaces = ["aomi-core", "evm-core"],
    skills = [
        {
            id: "hoodit/research",
            description: "Find and judge Robinhood Chain memecoins and small coins: what KOLs and smart money are buying, what's trending in a market-cap band, Pons curves near graduation, opinions on a ticker or contract, charts, who is buying or dumping, holders and the dev, wallets, bag checks, and whether a size can get out. Not needed for USDG, ETH or stock tokens.",
            tags: ["memecoins", "robinhood", "kol", "smart money", "scan", "pons", "chart", "holders", "exit"],
            sections: { instructions: "skills/research.md" },
        },
        {
            id: "hoodit/trade",
            description: "Execute a requested Robinhood Chain buy, sell or send. Use hoodit_token mode trade for small-coin buy checks and the host lifi_swap skill for swaps; preserve simulation and wallet consent. Activate only missing skills.",
            tags: ["buy", "sell", "ape", "swap", "slippage"],
            sections: { instructions: "skills/trade.md" },
        },
        {
            id: "hoodit/card",
            description: "PnL cards: a shareable image of a trade's profit, after a sell that closes a position, when the user asks for a pnl or flex card, or for a \"Redraw my … card\" message from a card's button.",
            tags: ["pnl", "card", "flex", "share", "image", "redraw"],
            sections: { instructions: "skills/card.md" },
        },
        {
            id: "hoodit/watch",
            description: "Set, list or cancel alerts on a Robinhood Chain coin: tell me when the curve hits X%, the price crosses a level, the dev sells, KOLs pile in.",
            tags: ["alert", "watch", "notify", "remind"],
            sections: { instructions: "skills/watch.md" },
        },
        {
            id: "hoodit/settings",
            description: "Change quick-action settings: the Telegram buy and sell buttons, what pays for quick buys (ETH or USDG), default slippage.",
            tags: ["settings", "quick buy", "buttons", "slippage", "preferences"],
            tools: [tools::SettingsGet, tools::SettingsSet],
            sections: { instructions: "skills/settings.md" },
        },
    ],
);

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn manifest_has_unowned_direct_and_settings_tools_and_small_prompts() {
        let manifest = runtime::HooditApp::default().manifest();
        assert_eq!(manifest.version, "3.2.0");
        let names: Vec<&str> = manifest.tools.iter().map(|t| t.name.as_str()).collect();
        assert_eq!(
            names,
            [
                "hoodit_signals",
                "hoodit_scan",
                "hoodit_find",
                "hoodit_token",
                "hoodit_chart",
                "hoodit_trades",
                "hoodit_holders",
                "hoodit_wallet",
                "hoodit_exit",
                "hoodit_check",
                "hoodit_card",
                "hoodit_history",
                "hoodit_positions",
                "hoodit_pnl",
                "hoodit_preview",
                "hoodit_buy",
                "hoodit_sell",
                "hoodit_positions_view",
                "hoodit_settings_view",
                "hoodit_settings_get",
                "hoodit_settings_set"
            ]
        );
        let direct: Vec<&str> = manifest
            .tools
            .iter()
            .filter(|t| t.namespace.as_deref() == Some("direct"))
            .map(|t| t.name.as_str())
            .collect();
        assert_eq!(direct, &names[14..19]);
        let settings = manifest.skills.iter().find(|s| s.id == "hoodit/settings");
        assert_eq!(
            settings.unwrap().injected_tools,
            ["hoodit_settings_get", "hoodit_settings_set"]
        );
        assert!(
            manifest
                .tools
                .iter()
                .all(|t| t.parameters_schema["additionalProperties"] == false)
        );
        // Always-on tools only: direct tools never reach the model, and
        // skill-owned ones only once their skill is active.
        let owned: Vec<&String> = manifest
            .skills
            .iter()
            .flat_map(|s| &s.injected_tools)
            .collect();
        let descriptions: usize = manifest
            .tools
            .iter()
            .filter(|t| t.namespace.is_none() && !owned.contains(&&t.name))
            .map(|t| t.description.len())
            .sum();
        assert!(
            descriptions < 4500,
            "tool descriptions are {descriptions} chars"
        );
        for skill in &manifest.skills {
            let chars: usize = skill.sections.iter().map(|s| s.content.len()).sum();
            assert!(chars < 7000, "{} is {chars} chars", skill.id);
        }
        assert!(manifest.preamble.len() < 3000);
    }

    /// The host makes every property required, so optional ones must accept null.
    #[test]
    fn optional_arguments_accept_null() {
        let manifest = runtime::HooditApp::default().manifest();
        for tool in &manifest.tools {
            let schema = &tool.parameters_schema;
            let required: Vec<&str> = schema["required"]
                .as_array()
                .map(|r| r.iter().filter_map(|v| v.as_str()).collect())
                .unwrap_or_default();
            // No properties (hoodit_settings_get): the host adds an empty map.
            for (name, prop) in schema["properties"].as_object().into_iter().flatten() {
                if required.contains(&name.as_str()) {
                    continue;
                }
                let text = prop.to_string();
                assert!(
                    text.contains("\"null\""),
                    "{}.{name} is optional but not nullable: {text}",
                    tool.name
                );
            }
        }
    }
}

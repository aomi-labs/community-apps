use super::run;
use crate::domain::settings::{self, Pay};
use crate::runtime::{HooditApp, Lane};
use aomi_sdk::schemars::JsonSchema;
use aomi_sdk::{DynAomiTool, DynToolCallCtx};
use serde::Deserialize;
use serde_json::{Value, json};

#[derive(Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
#[schemars(extend("properties" = {}, "required" = []))]
pub struct SettingsGetArgs {}

pub struct SettingsGet;
impl DynAomiTool for SettingsGet {
    type App = HooditApp;
    type Args = SettingsGetArgs;
    const NAME: &'static str = "hoodit_settings_get";
    const DESCRIPTION: &'static str = "The user's quick-action settings: Telegram buy sizes, sell percents, what pays for buys, default slippage.";
    fn run(app: &HooditApp, _args: SettingsGetArgs, ctx: DynToolCallCtx) -> Result<Value, String> {
        run(app, &ctx, Lane::Chat, async |rt, turn| {
            let saved = settings::saved(rt, turn).await?;
            let can_save = turn.account.is_some() && turn.settings_store().is_some();
            Ok(json!({ "settings": saved, "can_save": can_save }))
        })
    }
}

#[derive(Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct SettingsSetArgs {
    /// 1–3 quick-buy sizes, $1–$10,000 or 0.0001–5 ETH, e.g. ["$10","$25","0.01 ETH"]. null = unchanged.
    pub buy: Option<Vec<String>>,
    /// 1–3 sell-button percents, e.g. ["25%","100%"]. null = unchanged.
    pub sell: Option<Vec<String>>,
    /// auto (USDG when it covers the buy, else ETH), eth or usdg. null = unchanged.
    pub pay: Option<Pay>,
    /// Default slippage for quick trades, 1–1000 bps; 0 = Hoodit's per-coin defaults. null = unchanged.
    pub slippage_bps: Option<u32>,
}

pub struct SettingsSet;
impl DynAomiTool for SettingsSet {
    type App = HooditApp;
    type Args = SettingsSetArgs;
    const NAME: &'static str = "hoodit_settings_set";
    const DESCRIPTION: &'static str =
        "Save quick-action settings. Pass only what changes; replies with everything saved.";
    fn run(app: &HooditApp, args: SettingsSetArgs, ctx: DynToolCallCtx) -> Result<Value, String> {
        run(app, &ctx, Lane::Chat, async |rt, turn| {
            let mut s = settings::saved(rt, turn).await?;
            s.buy = args.buy.unwrap_or(s.buy);
            s.sell = args.sell.unwrap_or(s.sell);
            s.pay = args.pay.unwrap_or(s.pay);
            if let Some(bps) = args.slippage_bps {
                s.slippage_bps = (bps > 0).then_some(bps);
            }
            Ok(json!({ "saved": settings::save(rt, turn, s).await? }))
        })
    }
}

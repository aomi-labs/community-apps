import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import type { FuzzCampaignReport } from "@aomi-labs/arc-studio-fuzz-core";
import { MissingBuildError } from "@aomi-labs/arc-studio-fuzz-core";
import { redirect } from "@tanstack/react-router";

import { StudioSession } from "@/server/studio-session";
import { prepareTarget } from "@/server/prepare-target";

/** Plain-data form of a FuzzTarget, safe to cross the server-action boundary. */
export interface TargetData {
  name: string;
  sourcePath: string;
  source: string;
  abi: Array<{ type?: string; name?: string; stateMutability?: string }>;
  deployedBytecode: string;
  chainId: number;
  immutableReferences?: Array<{ start: number; length: number }>;
  /** Live Arc deployment fuzzed in place; absent means the bytecode is installed. */
  deployment?: { address: string; chainId: number };
  /** The app's other contracts deployed on the same chain, which the fork also holds. */
  protocol?: Array<{ name: string; address: string }>;
  /** Immutable build selected for preview and the whole campaign. */
  snapshotId?: string;
  snapshotHash?: string;
  capturedAt?: string;
  /**
   * Short-lived link the Aomi fuzzer app downloads the artifact from, so large
   * contracts never pass through the chat. Only minted on the production host,
   * the one the app accepts; elsewhere the prompt inlines the artifact.
   */
  artifactUrl?: string;
  /** The same artifact, telling the app the harness installed the runtime at INSTALL_ADDRESS. */
  installedArtifactUrl?: string;
}

async function session(): Promise<StudioSession> {
  const current = await StudioSession.current();
  if (!current) throw redirect({ to: "/" });
  return current;
}

function failure(error: unknown): { ok: false; error: string; missingBuild?: boolean } {
  return {
    ok: false,
    error: error instanceof Error ? error.message : String(error),
    missingBuild: error instanceof MissingBuildError || undefined,
  };
}

export const connect = createServerFn({ method: "POST" })
  .validator(z.object({ token: z.string().max(4096) }))
  .handler(async ({ data }) => {
    try {
      await StudioSession.start(data.token);
    } catch (error) {
      return { error: error instanceof Error ? error.message : String(error) };
    }
    return {};
  });

export const disconnect = createServerFn({ method: "POST" }).handler(async () => {
  await StudioSession.end();
});

export const loadTarget = createServerFn({ method: "POST" })
  .validator(
    z.object({
      appId: z.string().uuid(),
      sourcePath: z.string().min(1).max(4096),
      contract: z.string().min(1).max(256),
      snapshotId: z.string().uuid().optional(),
      refresh: z.boolean().optional(),
    }),
  )
  .handler(async ({ data }) => {
    try {
      const current = await session();
      return { ok: true as const, value: await prepareTarget(current, data) };
    } catch (error) {
      return failure(error);
    }
  });

/** Explicitly replaces the saved workspace listing with Arc Studio's latest files. */
export const refreshApp = createServerFn({ method: "POST" })
  .validator(z.object({ appId: z.string().uuid() }))
  .handler(async ({ data: { appId } }) => {
    const { loadWorkspace } = await import("@/server/prepare-workspace");
    await loadWorkspace(await session(), appId, true);
  });

export const requestBuild = createServerFn({ method: "POST" })
  .validator(z.object({ appId: z.string().uuid() }))
  .handler(async ({ data: { appId } }) => {
    try {
      const { webUrl } = await (await (await session()).app(appId)).requestBuild();
      return { ok: true as const, value: { webUrl } };
    } catch (error) {
      return failure(error);
    }
  });

export const requestFix = createServerFn({ method: "POST" })
  .validator(
    z.object({
      appId: z.string().uuid(),
      sourcePath: z.string().min(1).max(4096),
      contract: z.string().min(1).max(256),
      report: z.custom<FuzzCampaignReport>((value) =>
        Boolean(value && typeof value === "object" && "campaign_id" in value && "findings" in value),
      ),
    }),
  )
  .handler(async ({ data: { appId, sourcePath, contract, report } }) => {
    try {
      const app = await (await session()).app(appId);
      const { webUrl } = await app.requestFix(await app.target(sourcePath, contract), report);
      return { ok: true as const, value: { webUrl } };
    } catch (error) {
      return failure(error);
    }
  });

"use client";

import { ArcStudioApp, CampaignTrace, FuzzTarget, INSTALL_ADDRESS } from "@aomi-labs/arc-studio-fuzz-core";
import { useAomiRuntime, usePerThreadControl } from "@aomi-labs/react";
import { AomiFrame } from "@aomi-labs/widget-lib";
import {
  AlertTriangle,
  Check,
  ChevronRight,
  CircleDot,
  ExternalLink,
  Play,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  Wrench,
  X,
} from "lucide-react";
import { useEffect, useLayoutEffect, useMemo, useRef, useState, useTransition } from "react";
import { createPortal, flushSync } from "react-dom";

import { AomiMark } from "@/components/brand";
import { campaignError, type Campaign } from "@/lib/campaign";
import { loadTarget, requestFix, type TargetData } from "@/app/actions";
import type { AomiAccount } from "@/lib/aomi-account";

const MAX_RESUMES = 6;
const FALLBACK_MODELS = ["Claude Opus 5.5", "Claude Sonnet 5.5"];
/** Models a campaign runs on when nothing valid was picked, in order of preference. */
const DEFAULT_MODELS = [process.env.NEXT_PUBLIC_AOMI_MODEL, "Claude Opus 5.5", "Claude Sonnet 5.5"].filter(
  (model): model is string => Boolean(model),
);

/** The backend's current catalog, or the bundled list when it cannot be read. */
async function modelCatalog(backendUrl: string, threadId: string, signal?: AbortSignal): Promise<string[]> {
  const url = new URL("/api/thread/models", backendUrl);
  const response = await fetch(url, { headers: { "X-Session-Id": threadId, "X-Thread-Id": threadId }, signal });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  const available = (await response.json()) as unknown;
  if (Array.isArray(available) && available.every((model) => typeof model === "string") && available.length > 0) {
    return available;
  }
  return FALLBACK_MODELS;
}

function CampaignModelSelect({ backendUrl, disabled }: { backendUrl: string; disabled: boolean }) {
  const { currentThreadId } = useAomiRuntime();
  const {
    actions: { getCurrentThreadControl, onModelSelect },
  } = usePerThreadControl();
  const [models, setModels] = useState(FALLBACK_MODELS);
  const control = getCurrentThreadControl();
  const auto = control.modelMode === "auto" || !control.model;
  const value = auto ? "auto" : (control.model ?? "auto");

  useEffect(() => {
    const controller = new AbortController();
    void modelCatalog(backendUrl, currentThreadId, controller.signal)
      .then(setModels)
      .catch((error: unknown) => {
        if (!(error instanceof DOMException && error.name === "AbortError")) {
          console.warn("Could not refresh the Aomi model catalog; using the bundled list.", error);
        }
      });
    return () => controller.abort();
  }, [backendUrl, currentThreadId]);

  return (
    <select
      aria-label="Campaign model"
      disabled={disabled}
      value={value}
      onChange={(event) => {
        const model = event.target.value;
        if (model === "auto") {
          void onModelSelect(models[0] ?? DEFAULT_MODELS[0], { mode: "auto" });
        } else {
          void onModelSelect(model, { mode: "manual" });
        }
      }}
      className="h-8 max-w-40 rounded-pill border border-border bg-bg px-2.5 text-[11px] text-ink outline-none hover:bg-hover disabled:cursor-not-allowed disabled:opacity-50"
    >
      <option value="auto">Balanced</option>
      {models.map((model) => (
        <option key={model} value={model}>
          {model}
        </option>
      ))}
    </select>
  );
}

function short(value: string, head = 8, tail = 6): string {
  return value.length <= head + tail + 1 ? value : `${value.slice(0, head)}…${value.slice(-tail)}`;
}

function pretty(value: unknown): string {
  if (value === undefined) return "";
  const output = typeof value === "string" ? value : JSON.stringify(value, null, 2);
  return output.length > 1_200 ? `${output.slice(0, 1_200)}\n…` : output;
}

function messageText(content: unknown): string {
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    return content
      .map((item) => (item && typeof item === "object" ? (item as { text?: unknown }).text : undefined))
      .filter((item): item is string => typeof item === "string")
      .join("\n");
  }
  return pretty(content);
}

export function FuzzPanel({
  appId,
  backendUrl,
  applicationId,
  account,
  target: data,
  onRefresh,
  visible = true,
  saved,
  onChange,
  onNew,
  onSource,
}: {
  appId: string;
  backendUrl: string;
  /** The arc-studio-fuzzer application campaigns are pinned to, when the host fixes one. */
  applicationId?: number;
  /** Signed-in runs seed the world first; guests hit the per-call input cap partway through. */
  account: AomiAccount | null;
  target: TargetData;
  onRefresh: () => void;
  visible?: boolean;
  saved?: Campaign;
  onChange?: (update: Partial<Campaign>) => void;
  onNew?: () => void;
  onSource?: (name: string, contract?: string | null) => void;
}) {
  const runtime = useAomiRuntime();
  const { createThread, events, getMessages, isRunning, isSubmitting, sendMessage, setUser, turnState } = runtime;
  const committedRuntime = useRef(runtime);
  useLayoutEffect(() => {
    committedRuntime.current = runtime;
  }, [runtime]);
  const starting = useRef(false);
  const launch = useRef<AbortController | null>(null);
  useEffect(() => () => launch.current?.abort(), []);
  const [preparing, setPreparing] = useState(false);
  const signedIn = Boolean(account);
  const threadControl = usePerThreadControl();
  const {
    actions: { getCurrentThreadControl },
  } = threadControl;
  // As with the runtime above: read and write the control through the object
  // committed after the campaign thread became active.
  const committedControl = useRef(threadControl);
  useLayoutEffect(() => {
    committedControl.current = threadControl;
  }, [threadControl]);
  const target = useMemo(
    () =>
      new FuzzTarget(
        data.name,
        data.sourcePath,
        data.source,
        data.abi,
        data.deployedBytecode,
        data.chainId,
        data.deployment,
        data.immutableReferences,
      ),
    [data],
  );
  const [started, setStarted] = useState(Boolean(saved?.threadId));
  /** Automatic "continue" messages sent after execution-limit stops in this run. */
  const [resumes, setResumes] = useState(saved?.resumes ?? 0);
  const [follow, setFollow] = useState(true);
  const [activityHost, setActivityHost] = useState<HTMLElement | null>(null);
  useEffect(() => {
    setActivityHost(document.getElementById("campaign-activity"));
  }, []);
  const [stopped, setStopped] = useState(saved?.status === "Stopped" || saved?.status === "Stopping");
  const continued = useRef<string | undefined>(undefined);
  const change = useRef(onChange);
  change.current = onChange;
  /** Tool calls, every runtime event, or the canonical Aomi conversation. */
  const [view, setView] = useState<"tools" | "ledger" | "chat">("tools");
  const [failure, setFailure] = useState<string | null>(null);
  const [targetChanged, setTargetChanged] = useState(false);
  /** This run's world was seeded by the harness rather than set up in the chat. */
  const [seeded, setSeeded] = useState(false);
  const [fix, setFix] = useState<{ webUrl?: string; error?: string } | null>(null);
  const [fixing, startFix] = useTransition();
  const traceEnd = useRef<HTMLDivElement>(null);

  const trace = useMemo(() => new CampaignTrace(events), [events]);
  const { report, finding } = trace;
  const wrongThread = Boolean(saved?.threadId && runtime.currentThreadId !== saved.threadId);
  const busy = preparing || (started && (isSubmitting || isRunning || turnState === "processing"));
  const finished = started && !busy && turnState === "complete";
  /** The backend ended the turn without a campaign result. */
  const turnFailed = started && !busy && (turnState === "failed" || turnState === "interrupted");
  const turnError = turnFailed
    ? (trace.errors.at(-1) ??
      trace.notice ??
      (signedIn
        ? `The agent's turn ended (${turnState}) before the campaign finished.`
        : "The guest session hit Aomi's per-call input cap. Sign in to Aomi (top right) and run again for a complete campaign."))
    : null;
  const finalMessage = [...getMessages()].reverse().find((message) => message.role === "assistant");

  useEffect(() => {
    if (!wrongThread) setUser(target.userState(appId, "Arc Studio app"));
  }, [appId, setUser, target, wrongThread]);

  const status = wrongThread
    ? "Thread unavailable"
    : failure
      ? "Failed"
      : preparing
        ? "Preparing fork"
        : stopped && busy
          ? "Stopping"
          : busy
            ? "Running"
            : finding
              ? "Finding reproduced"
              : report?.status === "complete"
                ? "Complete"
                : turnState === "interrupted" || stopped
                  ? "Stopped"
                  : turnFailed
                    ? "Failed"
                    : started
                      ? "Incomplete"
                      : "Ready";
  useEffect(() => {
    if (!started || wrongThread) return;
    change.current?.({ threadId: runtime.currentThreadId, status, resumes });
  }, [started, wrongThread, runtime.currentThreadId, status, resumes]);

  // One continuation per terminal ledger position, even if React renders twice.
  useEffect(() => {
    if (
      starting.current ||
      stopped ||
      wrongThread ||
      !started ||
      busy ||
      !trace.resumable ||
      report?.status === "complete" ||
      resumes >= MAX_RESUMES
    )
      return;
    const terminal = events.findLast((event) => event.type === "turn_state_changed" && event.state !== "processing");
    if (!terminal) return;
    const cursor = `${runtime.currentThreadId}:${terminal.turn_id ?? terminal.sequence}`;
    if (continued.current === cursor) return;
    continued.current = cursor;
    starting.current = true;
    setResumes((count) => count + 1);
    void sendMessage(CampaignTrace.CONTINUE_PROMPT)
      .catch((error: unknown) => setFailure(campaignError(error)))
      .finally(() => {
        starting.current = false;
      });
  }, [
    started,
    busy,
    stopped,
    wrongThread,
    trace.resumable,
    report?.status,
    resumes,
    sendMessage,
    events,
    runtime.currentThreadId,
  ]);

  useEffect(() => {
    if (!visible || !follow) return;
    traceEnd.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }, [trace.rows.length, turnState, visible, follow]);

  async function run(): Promise<void> {
    if (starting.current || busy || wrongThread) return;
    starting.current = true;
    const controller = new AbortController();
    launch.current = controller;
    setStopped(false);
    setPreparing(true);
    setFailure(null);
    setTargetChanged(false);
    setFix(null);
    setSeeded(false);
    try {
      // Renew only the capability for the exact build shown in the preview.
      // The launch path reads the app snapshot store and never calls Arc Studio.
      const refreshed = await loadTarget({
        data: {
          appId,
          sourcePath: data.sourcePath,
          contract: data.name,
          ...(data.snapshotId ? { snapshotId: data.snapshotId } : {}),
        },
      });
      controller.signal.throwIfAborted();
      if (!refreshed.ok) throw new Error(refreshed.error);
      const identity = (value: TargetData) => value.snapshotHash ?? JSON.stringify([value.source, value.abi, value.deployedBytecode, value.chainId, value.deployment ?? null, value.protocol ?? [], value.immutableReferences ?? []]);
      if (identity(refreshed.value) !== identity(data) || (data.snapshotId && refreshed.value.snapshotId !== data.snapshotId)) {
        setTargetChanged(true);
        throw new Error("The compiled target changed. Prepare a new campaign to use the current build.");
      }
      const fresh = refreshed.value;
      const control = getCurrentThreadControl();
      // Commit the SDK's React selection before reading its ID and capturing
      // its render-bound sender.
      const threadId = await flushSync(createThread);
      controller.signal.throwIfAborted();
      const campaign = committedRuntime.current;
      if (campaign.currentThreadId !== threadId)
        throw new Error("Campaign thread did not become active. Please retry.");
      // A name the backend no longer serves (its catalog moves) would silently
      // fall back to auto routing, so the choice is checked against the catalog.
      const catalog = await modelCatalog(backendUrl, threadId, controller.signal).catch(() => FALLBACK_MODELS);
      const model =
        [control.model, ...DEFAULT_MODELS].find((model): model is string =>
          Boolean(model && catalog.includes(model)),
        ) ?? catalog[0];
      const mode = control.model === model ? (control.modelMode ?? "manual") : "manual";
      change.current?.({ threadId, status: "Preparing fork", resumes: 0 });
      controller.signal.throwIfAborted();
      setStarted(true);
      setResumes(0);
      // Carry the user's picker choice into the fresh campaign thread. The new
      // thread's metadata can lag its selection by a tick, in which case the
      // write is dropped and the turn would route on auto (whose first choice
      // stalls on this prompt), so re-apply until the control reads back.
      for (let attempt = 0; attempt < 20; attempt += 1) {
        const { actions } = committedControl.current;
        controller.signal.throwIfAborted();
        await actions.onModelSelect(model, { mode });
        if (actions.getCurrentThreadControl().model === model) break;
        await new Promise((resolve) => setTimeout(resolve, 100));
      }
      if (committedControl.current.actions.getCurrentThreadControl().model !== model) {
        throw new Error(`Could not pin the campaign to ${model}. Please retry.`);
      }
      const bearer = account ? await account.session() : null;
      if (account && !bearer) throw new Error("Your Aomi session expired. Sign in and retry the campaign.");
      // The runtime keeps the picker's choice client-side; the backend learns a
      // thread's model only through /api/thread/model, and without it a fresh
      // thread routes on auto. Pin it there before the first message.
      if (bearer) {
        const url = new URL("/api/thread/model", backendUrl);
        url.searchParams.set("rig", model);
        url.searchParams.set("app", "arc-studio-fuzzer");
        if (applicationId) url.searchParams.set("application_id", String(applicationId));
        try {
          const clientId = localStorage.getItem("aomi_client_id");
          if (clientId) url.searchParams.set("client_id", clientId);
        } catch {
          /* the backend falls back to the session's client */
        }
        const pinned = await fetch(url, {
          method: "POST",
          signal: controller.signal,
          headers: { authorization: `Bearer ${bearer}`, "X-Session-Id": threadId, "X-Thread-Id": threadId },
        }).catch((error: unknown) => error);
        if (!(pinned instanceof Response && pinned.ok)) {
          const reason = pinned instanceof Response ? `HTTP ${pinned.status} ${await pinned.text()}` : String(pinned);
          throw new Error(`Could not pin the campaign to ${model} on the backend (${reason}). Please retry.`);
        }
      }
      // A signed-in launch must establish its world before the first message.
      // A setup failure cannot silently become an agent-created campaign.
      const link = fresh.deployment ? fresh.artifactUrl : fresh.installedArtifactUrl;
      let seededLink: string | undefined;
      if (bearer && link) {
        const url = new URL("/api/thread/sim/world", backendUrl);
        url.searchParams.set("user_state", JSON.stringify(target.userState(appId, "Arc Studio app")));
        const response = await fetch(url, {
          method: "POST",
          headers: {
            authorization: `Bearer ${bearer}`,
            "content-type": "application/json",
            "X-Session-Id": threadId,
            "X-Thread-Id": threadId,
          },
          body: JSON.stringify(target.seedWorld()),
          signal: controller.signal,
        }).catch((error: unknown) => error);
        if (response instanceof Response && response.ok) {
          const stamp = await response.json() as { verified_code_checks?: number };
          if (data.deployment && stamp.verified_code_checks !== 1) {
            throw new Error("This backend has not verified the compiled code against the deployment. Update the simulation backend before running this build.");
          }
          seededLink = link;
        } else {
          const reason = response instanceof Response ? `HTTP ${response.status} ${await response.text()}` : response;
          throw new Error(`Could not seed the simulation world (${reason}). Retry the campaign.`);
        }
      }
      controller.signal.throwIfAborted();
      setSeeded(Boolean(seededLink));
      await campaign.sendMessage(
        seededLink
          ? target.seededPrompt(
              seededLink,
              (data.protocol ?? []).map((contract) => contract.name),
            )
          : target.prompt(fresh.artifactUrl),
      );
    } catch (error) {
      setStopped(true);
      if (controller.signal.aborted) return;
      const message = campaignError(error);
      setFailure(
        message === "Failed to fetch"
          ? `Could not reach the Aomi backend at ${backendUrl}. Is it running with the arc-studio-fuzzer app loaded?`
          : message,
      );
    } finally {
      starting.current = false;
      setPreparing(false);
    }
  }

  const activity = (
    <div className={`min-h-0 flex-1 ${view === "chat" && started ? "overflow-hidden" : "overflow-auto p-4"}`}>
      {!started && (
        <div>
          <div className="rounded-lg border border-border bg-bg p-4">
            <div className="mb-3 flex items-center gap-2 text-[13px] font-medium text-ink">
              <Sparkles className="size-4 text-accent" /> {data.capturedAt
                ? `Pinned Arc build · ${new Date(data.capturedAt).toLocaleString()}`
                : "Compiled artifact loaded from Arc Studio"}
              {data.snapshotId && <button onClick={onRefresh} className="ml-auto text-xs text-accent-strong underline">
                Refresh build
              </button>}
            </div>
            <p className="text-[13px] leading-5 text-ink-muted">
              Source, ABI, and runtime bytecode for <code>{target.name}</code> (
              {ArcStudioApp.workspacePath(target.sourcePath)}) go to the Aomi fuzzer. Every row below comes from the
              agent&apos;s live event stream.
            </p>
            <p className="mt-2 font-mono text-[12px] text-ink-muted">
              writes: {target.writableFunctions.join(", ") || "none"}
            </p>
            {target.deployment ? (
              <p className="mt-3 rounded-md border border-success/30 bg-success/8 px-3 py-2 text-[12px] leading-5 text-ink">
                Fuzzing your live deployment at{" "}
                <span className="font-mono">
                  {target.deployment.address.slice(0, 8)}…{target.deployment.address.slice(-6)}
                </span>{" "}
                on Arc {target.deployment.chainId === 5042 ? "mainnet" : "testnet"}, with its real owner, tokens and
                state.
                {data.protocol && data.protocol.length > 0 && (
                  <>
                    {" "}
                    The fork also holds {data.protocol.map((contract) => contract.name).join(", ")}, deployed alongside
                    it, so the agent can attack the protocol as a whole.
                  </>
                )}{" "}
                Nothing is sent to the chain.
              </p>
            ) : (
              <p className="mt-3 rounded-md border border-warning/40 bg-warning/10 px-3 py-2 text-[12px] leading-5 text-ink">
                No Arc deployment found for this contract, so the fuzzer installs its compiled code on a fresh address.
                The constructor does not run, so owner and token setup will be empty. Deploy it to Arc in Arc Studio to
                fuzz the real thing.
              </p>
            )}
          </div>
          {!signedIn && (
            <div className="mt-4 rounded-lg border border-warning/40 bg-warning/10 p-3 text-[12px] leading-5 text-ink">
              You&apos;re running as an Aomi guest. Guest sessions stop after about 15 tool calls (a per-call input
              cap), before a full campaign can minimize and reproduce a finding. <strong>Sign in to Aomi</strong> (top
              right) for complete campaigns.
            </div>
          )}
          <div className="mt-4 space-y-2">
            {[
              "Agent authors the threat model, actors, and properties",
              "Runtime holds one Arc fork; nothing is broadcast",
              "A finding needs two clean reproductions",
            ].map((label) => (
              <div
                key={label}
                className="flex items-center gap-3 rounded-md border border-border bg-bg px-3 py-3 text-[12px] text-ink-muted"
              >
                <ShieldCheck className="size-4 text-accent" /> {label}
              </div>
            ))}
          </div>
        </div>
      )}

      {started && (
        <div className={view === "chat" ? "flex h-full min-h-0 flex-col p-4" : undefined}>
          <div
            className={`mb-4 flex items-start gap-3 rounded-lg border p-3 ${
              failure || turnError || finding ? "border-danger/35 bg-danger/8" : "border-border bg-bg"
            }`}
          >
            <div className="mt-0.5 grid size-8 shrink-0 place-items-center rounded-pill bg-surface-2">
              {busy ? (
                <RefreshCw className="size-4 animate-spin text-accent" />
              ) : failure || turnError || finding ? (
                <AlertTriangle className="size-4 text-danger" />
              ) : (
                <Check className="size-4 text-success" />
              )}
            </div>
            <div className="min-w-0">
              <h2 className="text-[13px] font-semibold text-ink">
                {failure || turnError
                  ? "Campaign failed"
                  : busy
                    ? "Agent is exploring the fork"
                    : finding
                      ? "Reproduced invariant violation"
                      : finished
                        ? report?.status === "complete"
                          ? "Campaign complete"
                          : "Turn ended · campaign incomplete"
                        : "Connecting to agent"}
              </h2>
              <p className="mt-1 font-mono text-[11px] text-ink-muted">
                {turnState ?? "submitting"} · {trace.rows.length} tool events · {events.length} ledger events
                {resumes > 0 && ` · continued ${resumes}×`}
              </p>
            </div>
          </div>

          <div className="mb-2 flex items-center justify-between">
            <h3 className="text-[11px] font-semibold uppercase tracking-[0.12em] text-ink-muted">Live agent trace</h3>
            <div className="flex rounded-pill border border-border bg-surface-2 p-0.5 text-[11px]" role="tablist">
              {(
                [
                  ["tools", `Tools ${trace.rows.length}`],
                  ["ledger", `All events ${trace.ledger.length}`],
                  ["chat", "Chat"],
                ] as const
              )
                .filter(([key]) => !activityHost || key !== "chat")
                .map(([key, label]) => (
                  <button
                    key={key}
                    role="tab"
                    aria-selected={view === key}
                    onClick={() => setView(key)}
                    className={`rounded-pill px-2.5 py-0.5 transition ${view === key ? "bg-bg text-ink" : "text-ink-muted hover:text-ink"}`}
                  >
                    {label}
                  </button>
                ))}
            </div>
          </div>

          {view === "tools" ? (
            <div data-testid="agent-trace" className="space-y-2">
              {seeded && (
                <div
                  data-testid="seeded-world"
                  className="flex items-center gap-2 rounded-md border border-success/30 bg-success/8 px-3 py-2 text-[12px] text-success"
                >
                  <ShieldCheck className="size-3.5 shrink-0" />
                  World seeded by the harness on chain {target.chainId}:{" "}
                  {target.deployment ? "live deployment" : "runtime installed"} at{" "}
                  <code className="font-mono">{short(target.deployment?.address ?? INSTALL_ADDRESS)}</code>
                </div>
              )}
              {trace.rows.length === 0 && (
                <div className="rounded-md border border-border bg-bg px-3 py-4 text-center text-[12px] text-ink-muted">
                  Waiting for the first tool call…
                </div>
              )}
              {trace.rows.map((row) => {
                const result = row.result as { error?: { message?: string } | string } | string | undefined;
                const errorText =
                  row.state !== "failed"
                    ? null
                    : typeof result === "string"
                      ? result
                      : typeof result?.error === "string"
                        ? result.error
                        : (result?.error?.message ?? pretty(result));
                return (
                  <details
                    key={row.key}
                    data-tool-name={row.name}
                    className="group rounded-md border border-border bg-bg px-3 py-2.5"
                  >
                    <summary className="flex cursor-pointer list-none items-center gap-2">
                      {row.state === "calling" ? (
                        <CircleDot className="size-3.5 shrink-0 animate-pulse text-accent" />
                      ) : row.state === "failed" ? (
                        <X className="size-3.5 shrink-0 text-danger" />
                      ) : (
                        <Check className="size-3.5 shrink-0 text-success" />
                      )}
                      <span className="min-w-0 flex-1 truncate font-mono text-[12px] text-ink">{row.name}</span>
                      <span className="text-[11px] text-ink-muted/70">#{row.sequence}</span>
                      <ChevronRight className="size-3 text-ink-muted/70 transition group-open:rotate-90" />
                    </summary>
                    {errorText && (
                      <p className="mt-1.5 line-clamp-3 font-mono text-[11px] leading-[1.5] text-danger group-open:line-clamp-none">
                        {errorText}
                      </p>
                    )}
                    {row.result !== undefined && !errorText && (
                      <pre className="mt-2 max-h-72 overflow-auto whitespace-pre-wrap border-t border-border pt-2 font-mono text-[11px] leading-[1.5] text-ink-muted">
                        {`result\n${pretty(row.result)}`}
                      </pre>
                    )}
                    {row.arguments !== undefined && (
                      <details className="mt-2 border-t border-border pt-2">
                        <summary className="cursor-pointer text-[11px] text-ink-muted">args</summary>
                        <pre className="mt-1 max-h-72 overflow-auto whitespace-pre-wrap font-mono text-[11px] leading-[1.5] text-ink-muted">
                          {pretty(row.arguments)}
                        </pre>
                      </details>
                    )}
                  </details>
                );
              })}
            </div>
          ) : view === "ledger" ? (
            <div data-testid="ledger" className="space-y-1">
              {trace.ledger.length === 0 && (
                <div className="rounded-md border border-border bg-bg px-3 py-4 text-center text-[12px] text-ink-muted">
                  No events yet.
                </div>
              )}
              {trace.ledger.map((entry) => (
                <details key={entry.key} className="group rounded-md border border-border bg-bg px-3 py-2">
                  <summary className="flex cursor-pointer list-none items-center gap-2">
                    <span className="w-9 shrink-0 text-[11px] text-ink-muted/70">#{entry.sequence}</span>
                    <span
                      className={`shrink-0 rounded-pill px-1.5 py-0.5 font-mono text-[10.5px] ${
                        entry.type === "error"
                          ? "bg-danger/10 text-danger"
                          : entry.type === "message"
                            ? "bg-accent/10 text-accent-strong"
                            : "bg-surface-2 text-ink-muted"
                      }`}
                    >
                      {entry.type}
                    </span>
                    <span className="min-w-0 flex-1 truncate text-[12px] text-ink">{entry.label}</span>
                    <ChevronRight className="size-3 shrink-0 text-ink-muted/70 transition group-open:rotate-90" />
                  </summary>
                  <pre className="mt-2 max-h-80 overflow-auto whitespace-pre-wrap border-t border-border pt-2 font-mono text-[11px] leading-[1.5] text-ink-muted">
                    {JSON.stringify(entry.event, null, 2)}
                  </pre>
                </details>
              ))}
            </div>
          ) : (
            <div
              data-testid="aomi-chat"
              className="min-h-0 flex-1 overflow-hidden rounded-lg border border-border bg-bg"
            >
              <AomiFrame.Composer className="fuzzer-composer h-full" welcomeTitle="Ask Aomi about this campaign" />
            </div>
          )}

          {view !== "chat" && finding && report && (
            <div data-testid="verified-finding" className="mt-4 rounded-lg border border-danger/35 bg-danger/8 p-3">
              <div className="flex items-center justify-between">
                <span className="text-[12px] font-bold uppercase tracking-wider text-danger">Verified finding</span>
                <span className="rounded-pill bg-success/10 px-2 py-1 font-mono text-[11px] text-success">
                  REPLAYED 2×
                </span>
              </div>
              <p className="mt-2 text-[13px] leading-5 text-ink">{finding.property}</p>
              <div className="mt-3 space-y-1.5">
                {finding.minimized_trace.map((call, index) => (
                  <div
                    key={`${call.label}-${index}`}
                    className="flex items-center gap-2 rounded-sm border border-border bg-bg px-2.5 py-2"
                  >
                    <span className="grid size-5 place-items-center rounded-pill bg-accent-subtle font-mono text-[11px] text-accent-strong">
                      {index + 1}
                    </span>
                    <span className="font-mono text-[12px] text-ink">
                      {call.actor} → {call.contract ? `${call.contract}.` : ""}{" "}
                      <button className="underline" onClick={() => onSource?.(call.function, call.contract)}>
                        {call.function}
                      </button>
                    </span>
                  </div>
                ))}
              </div>
              {finding.balances.length > 0 && (
                <details className="mt-3 text-xs">
                  <summary className="cursor-pointer">Observed balance changes</summary>
                  <table className="mt-2 w-full text-left">
                    <thead>
                      <tr>
                        <th>Address</th>
                        <th>Before (base units)</th>
                        <th>After (base units)</th>
                      </tr>
                    </thead>
                    <tbody>
                      {finding.balances.map((balance) => (
                        <tr key={balance.address}>
                          <td title={balance.address}>{short(balance.address)}</td>
                          <td>{balance.before}</td>
                          <td>{balance.after}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </details>
              )}
              <div className="mt-3 grid grid-cols-3 gap-2">
                {(
                  [
                    ["round", report.round],
                    ["executions", report.executions],
                    ["corpus", report.corpus_size],
                  ] as const
                ).map(([label, value]) => (
                  <div key={label} className="rounded-sm border border-border bg-bg p-2">
                    <div className="text-[11px] uppercase text-ink-muted">{label}</div>
                    <div className="mt-1 font-mono text-[13px] text-ink">{value}</div>
                  </div>
                ))}
              </div>
              <p className="mt-3 text-center font-mono text-[11px] text-ink-muted/70">
                {short(report.campaign_id)} · Arc fork · no signing
              </p>
            </div>
          )}

          {view !== "chat" && finalMessage?.content && finished && (
            <div className="mt-4 rounded-lg border border-border bg-bg p-3">
              <div className="mb-2 text-[12px] font-semibold uppercase tracking-wider text-accent-strong">
                Agent conclusion
              </div>
              <div className="max-h-80 overflow-auto whitespace-pre-wrap text-[13px] leading-6 text-ink">
                {messageText(finalMessage.content)}
              </div>
            </div>
          )}
          {view !== "chat" && (failure ?? turnError) && (
            <p className="mt-3 text-[12px] leading-5 text-danger">{failure ?? turnError}</p>
          )}
          <div ref={traceEnd} />
        </div>
      )}
    </div>
  );

  if (wrongThread)
    return (
      <div role="alert" className="p-4 text-danger">
        This saved thread is unavailable. No messages will be sent to a replacement thread.
        {onNew && (
          <button className="block underline" onClick={onNew}>
            Start a new campaign
          </button>
        )}
      </div>
    );

  return (
    <>
      <div className="flex h-14 items-center justify-between border-b border-border px-5">
        <div className="flex items-center gap-2.5">
          <span role="img" aria-label="Aomi">
            <AomiMark className="size-7 text-ink" />
          </span>
          <div>
            <h1 className="text-[15px] font-semibold text-ink">Agentic Fuzzer</h1>
            <p className="text-[12px] text-ink-muted">
              {target.name} · {target.writableFunctions.length} writable function
              {target.writableFunctions.length === 1 ? "" : "s"}
            </p>
          </div>
        </div>
        <div className="flex min-w-0 items-center gap-2">
          <CampaignModelSelect backendUrl={backendUrl} disabled={busy} />
          <span className="shrink-0 rounded-pill border border-accent/45 bg-accent/10 px-2 py-0.5 font-mono text-[11px] text-accent-strong">
            LIVE
          </span>
        </div>
      </div>

      {started && activityHost ? (
        <>
          {visible && createPortal(activity, activityHost)}
          <div className="min-h-0 flex-1 overflow-hidden">
            <AomiFrame.Composer className="fuzzer-composer h-full" welcomeTitle="Ask about this campaign" />
          </div>
        </>
      ) : (
        activity
      )}

      <div className="space-y-2 border-t border-border p-4">
        {wrongThread && (
          <p role="alert" className="text-danger">
            This saved thread is unavailable. Start a new campaign from the contract; no messages will be sent to a
            replacement thread.
          </p>
        )}
        {started && (
          <div className="flex flex-wrap items-center gap-3 text-xs">
            <label>
              <input type="checkbox" checked={follow} onChange={(event) => setFollow(event.target.checked)} /> Follow
              live
            </label>
            <span>{status}</span>
            {busy && (
              <button
                disabled={stopped}
                onClick={() => {
                  setStopped(true);
                  launch.current?.abort();
                  runtime.cancelGeneration();
                }}
                className="text-danger"
              >
                Stop execution
              </button>
            )}
            {!busy &&
              !wrongThread &&
              events.some((event) => event.type === "message" && event.sender === "user") &&
              report?.status !== "complete" && (
                <button
                  onClick={() => {
                    if (starting.current) return;
                    starting.current = true;
                    setStopped(false);
                    setFailure(null);
                    void sendMessage(CampaignTrace.CONTINUE_PROMPT)
                      .catch((error: unknown) => setFailure(campaignError(error)))
                      .finally(() => {
                        starting.current = false;
                      });
                  }}
                >
                  Continue campaign
                </button>
              )}
            <button
              onClick={() => {
                const url = URL.createObjectURL(
                  new Blob(
                    [JSON.stringify({ target: data.name, threadId: runtime.currentThreadId, report, events }, null, 2)],
                    { type: "application/json" },
                  ),
                );
                const link = document.createElement("a");
                link.href = url;
                link.download = `${data.name}-campaign.json`;
                link.click();
                URL.revokeObjectURL(url);
              }}
            >
              Export evidence
            </button>
          </div>
        )}

        {finding && report && finished && (
          <>
            {fix?.webUrl ? (
              <div className="rounded-md border border-success/30 bg-success/8 p-3 text-[13px] text-ink">
                Fix request sent to Arc Studio.{" "}
                <a
                  href={fix.webUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 underline"
                >
                  Follow it there <ExternalLink className="size-3" />
                </a>
                <button onClick={onRefresh} className="mt-2 block text-ink-muted underline">
                  Arc Studio finished? Reload the contract, then fuzz again
                </button>
              </div>
            ) : (
              <button
                data-testid="send-fix"
                disabled={fixing}
                onClick={() =>
                  startFix(async () => {
                    const result = await requestFix({
                      data: { appId, sourcePath: target.sourcePath, contract: target.name, report },
                    });
                    setFix(result.ok ? { webUrl: result.value.webUrl } : { error: result.error });
                  })
                }
                className="flex h-10 w-full items-center justify-center gap-2 rounded-pill bg-danger-strong text-[13px] font-medium text-on-danger transition hover:brightness-110 disabled:opacity-70"
              >
                {fixing ? <RefreshCw className="size-3.5 animate-spin" /> : <Wrench className="size-3.5" />}
                Send finding to Arc Studio for a fix
              </button>
            )}
            {fix?.error && <p className="text-[12px] text-danger">{fix.error}</p>}
          </>
        )}
        <button
          data-testid="run-aomi-fuzz"
          onClick={() => ((started || targetChanged) && onNew ? onNew() : void run())}
          disabled={busy || wrongThread}
          className="flex h-10 w-full items-center justify-center gap-2 rounded-pill bg-ink text-[13px] font-medium text-bg transition hover:bg-ink/85 disabled:cursor-wait disabled:opacity-70"
        >
          {busy ? (
            <>
              <RefreshCw className="size-3.5 animate-spin" /> Running campaign…
            </>
          ) : targetChanged ? (
            <>
              <RefreshCw className="size-3.5" /> Prepare the current build
            </>
          ) : started ? (
            <>
              <RefreshCw className="size-3.5" /> Run a new campaign
            </>
          ) : (
            <>
              <Play className="size-3.5 fill-current" /> Fuzz {target.name} on an Arc fork
            </>
          )}
        </button>
        <p className="text-center text-[12px] text-ink-muted/70">
          Real model · {signedIn ? "$50 maximum per run · " : ""}held Arc fork · no signing or broadcast
        </p>
      </div>
    </>
  );
}

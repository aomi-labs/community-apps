//! One session's fuzz campaign: a bounded breadth-first search over call
//! sequences, run on the host's `evm-sim` world. The app owns the search
//! (frontier, state deduplication, property checks, minimization and the
//! two-reproduction rule); the host only executes the batches it emits.

use std::collections::{BTreeMap, BTreeSet, HashMap, VecDeque};
use std::str::FromStr;

use alloy_primitives::{Address, B256, Bytes, U256, keccak256};
use aomi_sdk::schemars::JsonSchema;
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};

use crate::abi::{ContractAbi, Targets};
use crate::plan::{FuzzCall, FuzzContract, FuzzPlan, PreparedPlan};
use crate::replay::{
    BASELINE, CompactTrace, ReplayBalance, ReplayBatch, ReplayProbe, ReplayStatus, ReplayTrace,
};

#[derive(Debug, Clone, Serialize, Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub(crate) struct FuzzStartArgs {
    /// Arc chain of the open simulation world: 5042 (mainnet) or 5042002 (testnet).
    pub chain_id: u64,
    #[serde(flatten)]
    pub plan: FuzzPlan,
}

#[derive(Debug, Clone, Serialize, Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub(crate) struct FuzzRoundArgs {
    /// Every compact trace from the last `sim_replay_traces` call, unchanged.
    pub replay: Vec<CompactTrace>,
    /// Optional revised plan. Actors must stay identical.
    #[serde(default)]
    pub plan: Option<FuzzPlan>,
}

impl FuzzContract {
    /// The runtime bytecode, checked against the EIP-170 size limit.
    pub fn runtime(&self) -> Result<Bytes, String> {
        let code = Bytes::from_str(self.deployed_bytecode.trim())
            .map_err(|_| "deployed_bytecode must be 0x-prefixed hex".to_string())?;
        if code.is_empty() || code.len() > FuzzCampaign::MAX_RUNTIME_BYTES {
            return Err(format!(
                "deployed_bytecode must be 1..={} bytes, got {}",
                FuzzCampaign::MAX_RUNTIME_BYTES,
                code.len()
            ));
        }
        Ok(code)
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
enum Work {
    Explore(Vec<usize>),
    Minimize(Vec<usize>),
    Reproduce(Vec<usize>),
}

impl Work {
    fn trace(&self) -> &[usize] {
        match self {
            Self::Explore(trace) | Self::Minimize(trace) | Self::Reproduce(trace) => trace,
        }
    }
}

/// A violating trace waiting to be shrunk and reproduced.
#[derive(Debug, Clone, Serialize, Deserialize)]
struct Suspect {
    property: usize,
    trace: Vec<usize>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
enum Stage {
    Minimizing,
    Reproducing,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct Confirmation {
    property: usize,
    best: Vec<usize>,
    stage: Stage,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct FindingStep {
    label: String,
    actor: String,
    function: String,
    status: ReplayStatus,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct Finding {
    property: String,
    minimized_trace: Vec<FuzzCall>,
    steps: Vec<FindingStep>,
    balances: Vec<ReplayBalance>,
    probes: Vec<ReplayProbe>,
    reproductions: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct Unconfirmed {
    property: String,
    trace: Vec<FuzzCall>,
    reason: String,
}

#[derive(Debug, Clone, Copy, Serialize)]
#[serde(rename_all = "snake_case")]
enum CampaignStatus {
    Exploring,
    Confirming,
    Complete,
}

#[derive(Debug, Serialize)]
struct Setup {
    /// Null when the code already sits in the world (a live deployment or a
    /// harness install).
    set_code: Option<Value>,
    set_balances: Vec<Value>,
    snapshot: Value,
}

// Every batch the campaign emits must fit one sim_replay_traces call.
const _: () = assert!(
    FuzzCampaign::EXPLORE_BATCH <= ReplayBatch::MAX_TRACES
        && FuzzPlan::MAX_DEPTH <= ReplayBatch::MAX_TRACES
);

pub(crate) struct FuzzCampaign {
    id: B256,
    chain_id: u64,
    contract: FuzzContract,
    targets: Targets,
    artifact: B256,
    target: Address,
    hypothesis: String,
    max_depth: usize,
    max_executions: usize,
    plan: PreparedPlan,
    plan_source: FuzzPlan,
    writable: BTreeSet<String>,
    frontier: VecDeque<Vec<usize>>,
    pending: HashMap<String, Work>,
    /// State fingerprints already expanded: the search corpus.
    expanded: BTreeSet<B256>,
    covered: BTreeSet<String>,
    /// Each action label run so far, and whether it ever succeeded. One that
    /// never does has unmet preconditions (amounts, ordering) worth revising.
    outcomes: BTreeMap<String, bool>,
    behavior: BTreeSet<String>,
    suspects: VecDeque<Suspect>,
    confirming: Option<Confirmation>,
    findings: Vec<Finding>,
    unconfirmed: Vec<Unconfirmed>,
    round: u32,
    executions: usize,
    inconclusive: usize,
    serial: u64,
    batch: Option<ReplayBatch>,
    last_round: Option<(Value, Value)>,
}

/// Mutable search state only. The artifact and derived ABI indexes are
/// reconstructed on a new worker; accepted rounds are never replayed.
#[derive(Serialize, Deserialize)]
pub(crate) struct CampaignCheckpoint {
    id: B256,
    plan_source: FuzzPlan,
    frontier: VecDeque<Vec<usize>>,
    pending: HashMap<String, Work>,
    expanded: BTreeSet<B256>,
    covered: BTreeSet<String>,
    outcomes: BTreeMap<String, bool>,
    behavior: BTreeSet<String>,
    suspects: VecDeque<Suspect>,
    confirming: Option<Confirmation>,
    findings: Vec<Finding>,
    unconfirmed: Vec<Unconfirmed>,
    round: u32,
    executions: usize,
    inconclusive: usize,
    serial: u64,
    batch: Option<ReplayBatch>,
    last_round: Option<(Value, Value)>,
}

impl CampaignCheckpoint {
    pub fn start_args(&self, chain_id: u64) -> FuzzStartArgs {
        FuzzStartArgs {
            chain_id,
            plan: self.plan_source.clone(),
        }
    }
}

impl FuzzCampaign {
    pub fn checkpoint(&self) -> CampaignCheckpoint {
        CampaignCheckpoint {
            id: self.id,
            plan_source: self.plan_source.clone(),
            frontier: self.frontier.clone(),
            pending: self.pending.clone(),
            expanded: self.expanded.clone(),
            covered: self.covered.clone(),
            outcomes: self.outcomes.clone(),
            behavior: self.behavior.clone(),
            suspects: self.suspects.clone(),
            confirming: self.confirming.clone(),
            findings: self.findings.clone(),
            unconfirmed: self.unconfirmed.clone(),
            round: self.round,
            executions: self.executions,
            inconclusive: self.inconclusive,
            serial: self.serial,
            batch: self.batch.clone(),
            last_round: self.last_round.clone(),
        }
    }

    pub fn restore(
        contract: FuzzContract,
        start: FuzzStartArgs,
        saved: CampaignCheckpoint,
    ) -> Result<Self, String> {
        let mut campaign = Self::new(contract, start)?;
        campaign.plan =
            saved
                .plan_source
                .prepare(&campaign.targets, campaign.artifact, &saved.covered)?;
        campaign.hypothesis = saved.plan_source.hypothesis.clone();
        campaign.max_depth = saved.plan_source.max_depth;
        campaign.max_executions = saved.plan_source.max_executions;
        campaign.plan_source = saved.plan_source;
        campaign.id = saved.id;
        campaign.frontier = saved.frontier;
        campaign.pending = saved.pending;
        campaign.expanded = saved.expanded;
        campaign.covered = saved.covered;
        campaign.outcomes = saved.outcomes;
        campaign.behavior = saved.behavior;
        campaign.suspects = saved.suspects;
        campaign.confirming = saved.confirming;
        campaign.findings = saved.findings;
        campaign.unconfirmed = saved.unconfirmed;
        campaign.round = saved.round;
        campaign.executions = saved.executions;
        campaign.inconclusive = saved.inconclusive;
        campaign.serial = saved.serial;
        campaign.batch = saved.batch;
        campaign.last_round = saved.last_round;
        Ok(campaign)
    }

    pub const ARC_CHAINS: [u64; 2] = [5042, 5_042_002];
    pub const MAX_RUNTIME_BYTES: usize = 24_576;
    /// Traces per exploration batch. Every trace transits the model twice,
    /// so this stays well under the host's own limit.
    const EXPLORE_BATCH: usize = 8;
    const REPRODUCTIONS: usize = 2;
    const INSTALLED_LIMITATION: &'static str = "Installed runtime bytecode runs no constructor; its storage is only what the harness seeded (empty unless it seeded a deployment's state).";
    const DEPLOYED_LIMITATION: &'static str = "Fuzzes the live deployment with its on-chain state at the pinned block; fixed-address actors act without signatures in simulation only.";
    const STUCK_ADVICE: &'static str = "Actions in never_succeeded have unmet preconditions, so paths through them are never tested. Resize their amounts from the state you read, or add enabling steps, and send the revised plan with the next arc_fuzz_round.";
    const LIMITATIONS: [&'static str; 2] = [
        "Coverage measures writable entrypoints and distinct observed states, not opcode coverage.",
        "A completed budget is evidence for the tested properties, not proof of contract safety.",
    ];

    pub fn new(contract: FuzzContract, args: FuzzStartArgs) -> Result<Self, String> {
        if !Self::ARC_CHAINS.contains(&args.chain_id) {
            return Err(format!(
                "Arc fuzzing supports chain {:?}, got {}",
                Self::ARC_CHAINS,
                args.chain_id
            ));
        }
        let abi = ContractAbi::parse(&contract.abi)?;
        let runtime = contract.runtime()?;
        let artifact = keccak256([contract.abi.as_bytes(), runtime.as_ref()].concat());
        let target = match &contract.deployment {
            Some(deployment) if deployment.chain_id != args.chain_id => {
                return Err(format!(
                    "this contract is deployed on chain {}; open that chain and pass chain_id {}",
                    deployment.chain_id, deployment.chain_id
                ));
            }
            Some(deployment) => deployment.target()?,
            None => Address::from_slice(&artifact[12..]),
        };
        let writable = abi.writable();
        let targets = Targets::new(&contract.name, target, abi, &contract.protocol)?;
        let plan = args.plan.prepare(&targets, artifact, &BTreeSet::new())?;
        let plan_source = args.plan.clone();
        let mut campaign = Self {
            id: keccak256([artifact.as_slice(), args.plan.hypothesis.as_bytes()].concat()),
            chain_id: args.chain_id,
            writable,
            contract,
            targets,
            artifact,
            target,
            hypothesis: args.plan.hypothesis,
            max_depth: args.plan.max_depth,
            max_executions: args.plan.max_executions,
            plan,
            plan_source,
            frontier: VecDeque::new(),
            pending: HashMap::new(),
            expanded: BTreeSet::new(),
            covered: BTreeSet::new(),
            outcomes: BTreeMap::new(),
            behavior: BTreeSet::new(),
            suspects: VecDeque::new(),
            confirming: None,
            findings: Vec::new(),
            unconfirmed: Vec::new(),
            round: 0,
            executions: 0,
            inconclusive: 0,
            serial: 0,
            batch: None,
            last_round: None,
        };
        campaign.frontier = campaign
            .scenario()
            .chain((0..campaign.plan.actions.len()).map(|i| vec![i]))
            .collect();
        Ok(campaign)
    }

    /// Setup operations for the host, then the first batch.
    pub fn start(&mut self) -> Value {
        let setup = Setup {
            set_code: self.contract.deployment.is_none().then(|| {
                json!({
                    "chain_id": self.chain_id,
                    "address": format!("{:#x}", self.target),
                    "runtime_bytecode": self.contract.deployed_bytecode.trim(),
                })
            }),
            set_balances: self
                .plan
                .actors
                .iter()
                .map(|(name, actor)| {
                    json!({
                        "chain_id": self.chain_id,
                        "actor": name,
                        "address": format!("{:#x}", actor.address),
                        "balance": actor.balance.to_string(),
                    })
                })
                .collect(),
            snapshot: json!({ "label": BASELINE }),
        };
        self.batch = self.next_batch();
        json!({
            "campaign_id": self.id,
            "setup": setup,
            "next_batch": self.batch,
            "progress": self.progress(),
        })
    }

    pub fn round(&mut self, args: FuzzRoundArgs) -> Result<Value, String> {
        let request = serde_json::to_value(&args).map_err(|e| e.to_string())?;
        if let Some((previous, response)) = &self.last_round
            && previous == &request
        {
            return Ok(response.clone());
        }
        self.ingest(args.replay)?;
        self.round += 1;
        // A revision re-indexes actions, which would orphan an open
        // confirmation; defer it instead of failing after ingestion.
        let revision = match args.plan {
            None => None,
            Some(_) if self.confirming.is_some() || !self.suspects.is_empty() => Some(
                "deferred: a violation is being confirmed; resend the revised plan after it completes"
                    .to_string(),
            ),
            // The replay is already ingested, so a rejected revision must not
            // fail the round: that would drop the next batch.
            Some(plan) => Some(match self.revise(plan) {
                Ok(()) => "applied".to_string(),
                Err(error) => format!("rejected, the previous plan continues: {error}"),
            }),
        };
        self.batch = self.next_batch();
        let response = json!({
            "revision": revision,
            "next_batch": self.batch,
            "progress": self.progress(),
        });
        self.last_round = Some((request, response.clone()));
        Ok(response)
    }

    /// What a round needs to steer the search, without the growing coverage
    /// lists or static text the full report carries. Every round result stays
    /// in the conversation, so this keeps history small; `arc_fuzz_report`
    /// returns everything.
    fn progress(&self) -> Value {
        json!({
            "campaign_id": self.id,
            "status": self.status(),
            "target": format!("{:#x}", self.target),
            "deployed": self.deployed(),
            "round": self.round,
            "executions": self.executions,
            "max_executions": self.max_executions,
            "inconclusive_traces": self.inconclusive,
            "corpus_size": self.expanded.len(),
            "frontier_size": self.frontier.len(),
            "uncovered_writes": self.writable.difference(&self.covered).collect::<Vec<_>>(),
            "never_succeeded": self.never_succeeded(),
            "advice": (!self.never_succeeded().is_empty()).then_some(Self::STUCK_ADVICE),
            "findings": self.findings,
            "unconfirmed": self.unconfirmed,
        })
    }

    pub fn report(&self) -> Value {
        let mode = if self.deployed() {
            Self::DEPLOYED_LIMITATION
        } else {
            Self::INSTALLED_LIMITATION
        };
        let limitations: Vec<&str> = [mode].into_iter().chain(Self::LIMITATIONS).collect();
        json!({
            "campaign_id": self.id,
            "hypothesis": self.hypothesis,
            "status": self.status(),
            "round": self.round,
            "executions": self.executions,
            "max_executions": self.max_executions,
            "inconclusive_traces": self.inconclusive,
            "corpus_size": self.expanded.len(),
            "frontier_size": self.frontier.len(),
            "covered_writes": self.covered,
            "uncovered_writes": self.writable.difference(&self.covered).collect::<Vec<_>>(),
            "never_succeeded": self.never_succeeded(),
            "behavior_coverage": self.behavior,
            "findings": self.findings,
            "unconfirmed": self.unconfirmed,
            "target": format!("{:#x}", self.target),
            "deployed": self.deployed(),
            "limitations": limitations,
            "next_batch": self.batch,
        })
    }

    /// A live deployment, as opposed to code installed at a fresh address.
    fn deployed(&self) -> bool {
        self.contract
            .deployment
            .as_ref()
            .is_some_and(|deployment| !deployment.installed)
    }

    /// Action labels that ran but never succeeded.
    fn never_succeeded(&self) -> Vec<&str> {
        self.outcomes
            .iter()
            .filter(|(_, succeeded)| !**succeeded)
            .map(|(label, _)| label.as_str())
            .collect()
    }

    fn status(&self) -> CampaignStatus {
        if self.confirming.is_some() || !self.suspects.is_empty() {
            CampaignStatus::Confirming
        } else if !self.pending.is_empty() {
            CampaignStatus::Exploring
        } else {
            CampaignStatus::Complete
        }
    }

    fn revise(&mut self, plan: FuzzPlan) -> Result<(), String> {
        let prepared = plan.prepare(&self.targets, self.artifact, &self.covered)?;
        if prepared.actors != self.plan.actors {
            return Err("a revised plan cannot change actors, addresses, or balances".into());
        }
        // Carry the search over: queued traces keep their place when every
        // action they use survives, and new actions start at depth one.
        // Re-sending an unchanged plan is therefore a no-op.
        let remap: Vec<Option<usize>> = self
            .plan
            .actions
            .iter()
            .map(|old| {
                prepared
                    .actions
                    .iter()
                    .position(|new| new.input == old.input)
            })
            .collect();
        let added = (0..prepared.actions.len())
            .filter(|new| !remap.contains(&Some(*new)))
            .map(|new| vec![new]);
        let remapped = |trace: &Vec<usize>| -> Option<Vec<usize>> {
            trace.iter().map(|old| remap[*old]).collect()
        };
        let queued: Vec<Vec<usize>> = self.scenario().filter_map(|t| remapped(&t)).collect();
        let kept: Vec<Vec<usize>> = self
            .frontier
            .drain(..)
            .filter_map(|trace| remapped(&trace))
            .chain(added)
            .collect();
        self.plan_source = plan.clone();
        self.hypothesis = plan.hypothesis;
        self.max_depth = plan.max_depth;
        self.max_executions = plan.max_executions;
        self.plan = prepared;
        // A reordered scenario is the new hypothesis, so it runs first;
        // prefixes the old order already queued are not repeated.
        let scenario: Vec<Vec<usize>> = self
            .scenario()
            .filter(|trace| !queued.contains(trace) && !kept.contains(trace))
            .collect();
        self.frontier = scenario.into_iter().chain(kept).collect();
        Ok(())
    }

    /// The plan's own order is the hypothesized attack path. Breadth-first
    /// search over many actions cannot reach a deep path within budget, so
    /// each ordered prefix of the plan is queued ahead of the search.
    fn scenario(&self) -> impl Iterator<Item = Vec<usize>> + use<> {
        let depth = self.max_depth.min(self.plan.actions.len());
        (2..=depth).map(|len| (0..len).collect())
    }

    fn confirmed(&self, property: usize) -> bool {
        let name = &self.plan.properties[property].name;
        self.findings
            .iter()
            .any(|finding| &finding.property == name)
    }

    fn next_batch(&mut self) -> Option<ReplayBatch> {
        if self.confirming.is_none() {
            while let Some(suspect) = self.suspects.pop_front() {
                if !self.confirmed(suspect.property) {
                    self.confirming = Some(Confirmation {
                        property: suspect.property,
                        best: suspect.trace,
                        stage: Stage::Minimizing,
                    });
                    break;
                }
            }
        }
        let work: Vec<Work> = match self.confirming.as_mut() {
            Some(confirmation) => {
                if confirmation.best.len() <= 1 {
                    confirmation.stage = Stage::Reproducing;
                }
                match confirmation.stage {
                    Stage::Reproducing => {
                        vec![Work::Reproduce(confirmation.best.clone()); Self::REPRODUCTIONS]
                    }
                    Stage::Minimizing => (0..confirmation.best.len())
                        .map(|drop| {
                            let mut shorter = confirmation.best.clone();
                            shorter.remove(drop);
                            Work::Minimize(shorter)
                        })
                        .collect(),
                }
            }
            None => {
                let watch = self.plan.actors.len() + 1;
                let worst = self.max_depth + self.plan.probes.len() + 2 * watch;
                let capacity = (ReplayBatch::MAX_EXECUTIONS / worst)
                    .clamp(1, Self::EXPLORE_BATCH)
                    .min(self.max_executions.saturating_sub(self.executions));
                (0..capacity)
                    .map_while(|_| self.frontier.pop_front())
                    .map(Work::Explore)
                    .collect()
            }
        };
        if work.is_empty() {
            return None;
        }
        let probes: Vec<_> = self
            .plan
            .probes
            .iter()
            .enumerate()
            .map(|(index, probe)| probe.replay(format!("p{index}")))
            .collect();
        let traces = work
            .into_iter()
            .map(|work| {
                self.serial += 1;
                let id = format!("{}-{}", self.round + 1, self.serial);
                let trace = ReplayTrace {
                    id: id.clone(),
                    calls: work
                        .trace()
                        .iter()
                        .map(|index| self.plan.actions[*index].replay(format!("a{index}")))
                        .collect(),
                    probes: probes.clone(),
                };
                self.pending.insert(id, work);
                trace
            })
            .collect();
        Some(ReplayBatch {
            snapshot: BASELINE.to_owned(),
            chain_id: self.chain_id,
            watch: self
                .plan
                .actors
                .iter()
                .map(|(_, actor)| actor.address)
                .chain([self.target])
                .map(|address| format!("{address:#x}"))
                .collect(),
            traces,
        })
    }

    fn ingest(&mut self, replay: Vec<CompactTrace>) -> Result<(), String> {
        if self.pending.is_empty() {
            return Err("campaign has no pending replay batch".into());
        }
        if replay.len() != self.pending.len() {
            return Err(format!(
                "expected {} replayed traces, got {}; pass every compact trace unchanged",
                self.pending.len(),
                replay.len()
            ));
        }
        let ids: BTreeSet<&str> = replay.iter().map(|r| r.id.as_str()).collect();
        if ids.len() != replay.len() {
            return Err("replay repeats a trace id".into());
        }
        if let Some(unknown) = replay.iter().find(|r| !self.pending.contains_key(&r.id)) {
            return Err(format!("unknown replay trace id `{}`", unknown.id));
        }
        let observations: Vec<(Work, CompactTrace)> = replay
            .into_iter()
            .map(|report| {
                (
                    self.pending.remove(&report.id).expect("checked above"),
                    report,
                )
            })
            .collect();
        self.executions += observations.len();

        let mut evaluated = Vec::with_capacity(observations.len());
        for (work, report) in observations {
            let trace = work.trace();
            let conclusive = report.conclusive(trace.len());
            if !conclusive {
                self.inconclusive += 1;
            }
            let violations = if conclusive {
                self.violations(trace, &report)
            } else {
                Vec::new()
            };
            evaluated.push((work, report, conclusive, violations));
        }

        if let Some(confirmation) = self.confirming.take() {
            self.confirming = match confirmation.stage {
                Stage::Minimizing => {
                    let shorter = evaluated
                        .iter()
                        .find(|(_, _, _, violations)| violations.contains(&confirmation.property))
                        .map(|(work, ..)| work.trace().to_vec());
                    Some(match shorter {
                        Some(best) => Confirmation {
                            best,
                            ..confirmation
                        },
                        None => Confirmation {
                            stage: Stage::Reproducing,
                            ..confirmation
                        },
                    })
                }
                Stage::Reproducing => {
                    let reproduced = evaluated
                        .iter()
                        .all(|(_, _, _, violations)| violations.contains(&confirmation.property));
                    let calls = confirmation
                        .best
                        .iter()
                        .map(|i| self.plan.actions[*i].input.clone())
                        .collect::<Vec<_>>();
                    let property = self.plan.properties[confirmation.property].name.clone();
                    if reproduced {
                        let (_, report, _, _) = &evaluated[0];
                        self.findings.push(Finding {
                            property,
                            steps: calls
                                .iter()
                                .zip(&report.statuses)
                                .map(|(call, status)| FindingStep {
                                    label: call.label.clone(),
                                    actor: call.actor.clone(),
                                    function: call.function.clone(),
                                    status: *status,
                                })
                                .collect(),
                            minimized_trace: calls,
                            balances: report.balances.clone(),
                            // Replay probe labels are short ids; restore the plan's prose.
                            probes: report
                                .probes
                                .iter()
                                .map(|probe| ReplayProbe {
                                    label: probe
                                        .label
                                        .strip_prefix('p')
                                        .and_then(|i| i.parse::<usize>().ok())
                                        .and_then(|i| self.plan.probes.get(i))
                                        .map_or_else(
                                            || probe.label.clone(),
                                            |p| p.input.label.clone(),
                                        ),
                                    ..probe.clone()
                                })
                                .collect(),
                            reproductions: Self::REPRODUCTIONS,
                        });
                    } else {
                        self.unconfirmed.push(Unconfirmed {
                            property,
                            trace: calls,
                            reason: if evaluated.iter().all(|(_, _, conclusive, _)| *conclusive) {
                                "violation did not reproduce from the baseline"
                            } else {
                                "host engine error during reproduction"
                            }
                            .to_owned(),
                        });
                    }
                    None
                }
            };
            return Ok(());
        }

        for (work, report, conclusive, violations) in evaluated {
            let Work::Explore(trace) = work else { continue };
            for (index, status) in trace.iter().zip(&report.statuses) {
                let call = &self.plan.actions[*index].input;
                *self.outcomes.entry(call.label.clone()).or_default() |= status.succeeded();
                // Coverage is the contract under test's writable surface.
                if self.targets.is_primary(call.contract.as_deref()) {
                    self.covered.insert(call.function.clone());
                }
                self.behavior.insert(format!(
                    "{}:{}{}:{}",
                    call.actor,
                    call.contract
                        .as_deref()
                        .map(|name| format!("{name}."))
                        .unwrap_or_default(),
                    call.function,
                    status.as_str()
                ));
            }
            if !conclusive {
                continue;
            }
            for property in violations {
                if !self.suspects.iter().any(|s| s.property == property) {
                    self.suspects.push_back(Suspect {
                        property,
                        trace: trace.clone(),
                    });
                }
            }
            if self.suspects.iter().any(|s| s.trace == trace) {
                continue;
            }
            let fingerprint = self.fingerprint(&trace, &report);
            if self.expanded.insert(fingerprint) && trace.len() < self.max_depth {
                for action in 0..self.plan.actions.len() {
                    let mut next = trace.clone();
                    next.push(action);
                    self.frontier.push_back(next);
                }
            }
        }
        Ok(())
    }

    /// Properties (not yet confirmed) this conclusive trace violates.
    fn violations(&self, trace: &[usize], report: &CompactTrace) -> Vec<usize> {
        let mut out = BTreeSet::new();
        for (index, property) in self.plan.properties.iter().enumerate() {
            if self.confirmed(index) {
                continue;
            }
            let actor = format!("{:#x}", property.actor_address);
            let profit = report
                .balances
                .iter()
                .find(|balance| balance.address.eq_ignore_ascii_case(&actor))
                .and_then(|balance| {
                    let before = U256::from_str(&balance.before).ok()?;
                    let after = U256::from_str(&balance.after).ok()?;
                    Some(after.saturating_sub(before))
                })
                .unwrap_or_default();
            let violated = trace.iter().zip(&report.statuses).any(|(action, status)| {
                property.violated_by(&self.plan.actions[*action].input, *status, profit)
            });
            if violated {
                out.insert(index);
            }
        }
        out.into_iter().collect()
    }

    /// Identity of the state a trace reached: changed balances and probe
    /// outputs. Without probes, storage-only effects are invisible, so the
    /// call sequence and its statuses are included to avoid over-pruning.
    fn fingerprint(&self, trace: &[usize], report: &CompactTrace) -> B256 {
        let mut balances: Vec<_> = report
            .balances
            .iter()
            .map(|b| (b.address.to_ascii_lowercase(), &b.after))
            .collect();
        balances.sort();
        let sequence = self
            .plan
            .probes
            .is_empty()
            .then_some((trace, &report.statuses));
        keccak256(
            serde_json::to_vec(&(balances, &report.probes, sequence))
                .expect("fingerprint inputs serialize"),
        )
    }
}

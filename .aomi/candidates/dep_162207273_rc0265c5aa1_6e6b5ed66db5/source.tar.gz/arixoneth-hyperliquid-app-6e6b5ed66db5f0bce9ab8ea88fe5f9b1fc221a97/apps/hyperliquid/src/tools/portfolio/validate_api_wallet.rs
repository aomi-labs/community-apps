use std::sync::Arc;

use aomi_sdk::DynToolCallCtx;
use schemars::JsonSchema;
use serde::Deserialize;
use serde_json::{Value, json};

use crate::{
    client::{HyperliquidApp, hypersdk::HyperSdkVenue},
    domain::{account::wallet, api_wallet, market::Network},
};

#[derive(Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct ValidateApiWalletArgs {
    pub network: Network,
}

pub fn run(
    app: &HyperliquidApp,
    args: ValidateApiWalletArgs,
    ctx: DynToolCallCtx,
) -> Result<Value, String> {
    let selected = match args.network {
        Network::Mainnet => app.clone(),
        Network::Testnet => {
            HyperliquidApp::new(Network::Testnet, Arc::new(HyperSdkVenue::testnet()))
        }
    };
    let owner = wallet(&ctx)?;
    let signer = api_wallet::signer(&selected, &ctx, "order")?.ok_or_else(|| {
        format!(
            "No user-owned {} API-wallet credential is configured",
            args.network.as_str()
        )
    })?;
    Ok(json!({
        "validated": true,
        "network": args.network,
        "owner": owner,
        "agent": signer.address().to_string().to_lowercase(),
        "writes_submitted": false,
    }))
}

read_tool!(
    ValidateApiWallet,
    ValidateApiWalletArgs,
    "hl_validate_api_wallet",
    "Validate that the selected user-owned Hyperliquid API-wallet credential belongs to the connected account. This performs a read-only userRole check and never signs or submits an exchange action.",
    run
);

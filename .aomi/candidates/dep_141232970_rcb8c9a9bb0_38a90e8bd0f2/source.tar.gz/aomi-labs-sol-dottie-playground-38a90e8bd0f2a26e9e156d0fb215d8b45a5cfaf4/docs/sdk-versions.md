# Dottie SDK versions

| Repository | SDK | Backend | Telegram wallet configuration |
| --- | --- | --- | --- |
| `aomi-labs/sol-dottie-playground` | Exact `6.0.0` | Current staging backend | Agent wallet, additional creation, Solana (`svm`), Instant suggested |
| `aomi-labs/sol-dottie` | Exact `7.0.0` in its SDK 7 PR | Backend with product-mono #1618 deployed | Same wallet configuration |

This repository is the SDK 6 deployment source for Project 1672, app 2937818 and @DottieSolBot. Its main-merge workflow deploys only this binding. Keep the root SDK pin, app dependency, and Cargo.lock on SDK 6 here; do not merge the superseded SDK 7 playground PR.

The canonical `sol-dottie` repository has a separate Project (1671). SDK 7 preparation there does not move or replace the existing bot. Wait for product-mono #1618 to merge and deploy before switching to its Solana tool contract (`svm_simulate` and `svm_commit_message`). Current SDK 6 hosts use `svm_simulate_ix`, `svm_simulate_tx`, and `svm_sign_data`.

Both manifests use:

```toml
[wallets]
agent = true
create = true
families = ["svm"]
suggest = "instant"
```

These flags provision the app wallet and enable additional wallets. The suggested lane applies at onboarding; owner-selected permissions stay in effect. Existing chats created before agent wallets were enabled can select Sol Dottie again through `/app` to run provisioning. `/wallet` displays the Solana address and deposit action. Linking a portal account can leave the wallet in Ask mode; use its wallet controls to choose the desired lane.

SDK pins and passing builds alone do not prove a live trade. Verify activation, runtime loading, chat, and wallet/deposit screens for the chosen deployment. Do not execute a trade without the user's transaction authorization.

import { spawn } from 'node:child_process';
import { access, mkdir, chmod } from 'node:fs/promises';
import { openBrowser } from './browser.mjs';
const profile=process.env.FOMO_PROFILE_DIR;
if(!profile)throw new Error('Resolve FOMO_PROFILE_DIR from 1Password');
const chrome='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
let stockChrome=false;
if(process.platform==='darwin'){try{await access(chrome);stockChrome=true;}catch{}}
if(stockChrome){
 await mkdir(profile,{recursive:true,mode:0o700});await chmod(profile,0o700);
 // One-time account login happens in ordinary vendor Chrome, without automation or debugging flags.
 // Close this dedicated Chrome instance before starting the relay with CHROME_CHANNEL=chrome.
 const child=spawn(chrome,[`--user-data-dir=${profile}`,'--no-first-run','https://fomo.family'],{stdio:'inherit'});
 console.log('Sign into fomo in the dedicated Chrome window, open a token thesis, then close that window. Start the relay with CHROME_CHANNEL=chrome and the same profile.');
 child.on('error',()=>{console.error('Could not start the dedicated Chrome login');process.exitCode=1;});
 await new Promise(resolve=>child.on('close',resolve));
}else{
 const browser=await openBrowser({headed:true});
 console.log('Complete fomo login, open a token thesis, then close the window. The private profile persists.');
 await new Promise(resolve=>browser.context.on('close',resolve));
}

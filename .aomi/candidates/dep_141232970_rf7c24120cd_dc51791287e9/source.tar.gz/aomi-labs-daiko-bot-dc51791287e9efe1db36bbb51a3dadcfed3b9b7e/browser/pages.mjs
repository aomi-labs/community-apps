import { GMGN_PANELS, validMint } from './contract.mjs';
import { readThesis } from '../browser-extension/reader.js';
export const PANELS = { fomo: ['overview', 'thesis', 'holders'], gmgn: ['overview', 'trades', ...Object.keys(GMGN_PANELS)] };
export function researchArgs(value) {
  if (!value || !Object.hasOwn(PANELS, value.site) || Object.keys(value).some(k => !['site','mint','panel','page','screenshot'].includes(k)) || !validMint(value.mint)) throw new Error('invalid_request');
  const panel = value.panel ?? (value.site === 'fomo' ? 'thesis' : 'overview');
  if (!PANELS[value.site].includes(panel)) throw new Error('invalid_panel');
  const page = value.page ?? 0;
  if (!Number.isInteger(page) || page < 0 || page > 2 || (value.screenshot !== undefined && typeof value.screenshot !== 'boolean')) throw new Error('invalid_request');
  return { site: value.site, mint: value.mint, panel, page, screenshot: value.screenshot === true };
}
export async function researchPage(page, args) {
  let selected = true, gmgnPanel;
  const gmgnControls = { trades:'activity', holders:'holders', top_traders:'traders', early_buyers:'early_buyers', dev_token:'dev_token' };
  if (args.site === 'gmgn' && args.panel !== 'overview') {
    const suffix = gmgnControls[args.panel];
    const selector = `[role="tab"][id$="-tab-${suffix}"]`;
    const control = page.locator(selector);
    try {
      await control.waitFor({ state:'visible', timeout:12000 });
      await control.press('Enter');
      await page.locator(`${selector}[aria-selected="true"]`).waitFor({ state:'visible', timeout:5000 });
      gmgnPanel = page.locator(`[role="tabpanel"][id$="-panel-${suffix}"][aria-hidden="false"]`);
      await gmgnPanel.waitFor({ state:'visible', timeout:5000 });
      await page.waitForTimeout(2000);
    } catch { selected = false; }
  }
  if (args.site === 'fomo' && args.panel === 'holders') {
    const control = page.getByRole('button', {name:/^Holders \(/}).first();
    try {
      await control.waitFor({ state:'visible', timeout:8000 });
      await control.click();
      await page.waitForTimeout(1000);
      selected = await control.getAttribute('aria-pressed') === 'true';
    } catch { selected = false; }
  }
  const scrolls = [];
  for (let i = 0; selected && i < args.page * 2; i++) {
    if (gmgnPanel) scrolls.push(await gmgnPanel.evaluate(panel => {
      const target = panel.querySelector('.g-table-recycler-scroll');
      if (!target) return null;
      const before = target.scrollTop; target.scrollTop += 600;
      return { before, after:target.scrollTop };
    }));
    else scrolls.push(await page.evaluate(({site,panel}) => {
      // Restrict Fomo holder pagination to its verified public table, never
      // the account/position sidebars or a larger unrelated scrolling panel.
      let candidates;
      if (site === 'fomo' && panel === 'holders') {
        const control = [...document.querySelectorAll('button')].find(x=>/^Holders \(/.test(x.innerText));
        const root = control?.parentElement?.parentElement?.parentElement;
        candidates = [...root?.querySelectorAll('div') ?? []];
      } else candidates = [...document.querySelectorAll('div')];
      const target = candidates.filter(e => {
        const r = e.getBoundingClientRect();
        return r.width > innerWidth * .3 && r.height > 100 && r.left < innerWidth * .65 && r.top >= 80 && e.scrollHeight > e.clientHeight + 50;
      }).sort((a,b)=>b.clientWidth*b.clientHeight-a.clientWidth*a.clientHeight)[0];
      if (!target) return null;
      const before = target.scrollTop; target.scrollTop += 600;
      return {before,after:target.scrollTop};
    },args));
    await page.waitForTimeout(700);
  }
  let evidence;
  if (args.site === 'fomo') {
    evidence = await page.evaluate(readThesis,args.mint);
    if (args.panel === 'holders' && selected) evidence = await page.evaluate(() => {
      const control = [...document.querySelectorAll('button')].find(x=>/^Holders \(/.test(x.innerText));
      const root = control?.parentElement?.parentElement?.parentElement;
      const rows = [...root?.querySelectorAll('[data-index]') ?? []].slice(0,20).flatMap(row=>{
        const cells = row.querySelector('button')?.children;
        if (!cells || cells.length !== 5) return [];
        return [{rank:Number(row.getAttribute('data-index'))+1,trader:cells[0].innerText.split('\n')[0],token_amount:cells[1].lastElementChild?.innerText,thesis:cells[4].innerText.slice(0,1000)}];
      });
      return {holder_count:control?.innerText,holder_rows:rows};
    });
  } else evidence = { text:selected ? (gmgnPanel ? await gmgnPanel.innerText() : await page.locator('body').innerText()).slice(0,16000) : '' };
  const coverage = [args.site === 'fomo' ? (args.panel === 'holders' ? 'Public token-holder rows only: trader, token amount and thesis. PnL, entry-price and private account fields are excluded. Rendered sample only, not every holder.' : 'Public thesis comments only; token/account positions and trading panels are excluded. Chart pixels are not numerical price-history evidence.') : 'Logged-out token page and selected public research table. Rendered rows only; chart pixels are not numerical price-history evidence.'];
  const panelError = args.site === 'gmgn' && /network error|failed to load/i.test(evidence.text ?? '') || args.site === 'fomo' && args.panel === 'holders' && !evidence.holder_rows?.length;
  if (panelError) coverage.push('Requested research table has no readable rows or reports a load failure.');
  if (!selected) coverage.push('Requested public research panel could not be selected.');
  if (args.page && !scrolls.some(x=>x&&x.after>x.before)) coverage.push('No advancing research scroll container was observed; this is not an additional page.');
  let screenshot;
  if (args.screenshot) {
    if (args.site === 'fomo') {
      // The fixed token page's public center is bounded by the two account/
      // trade sidebars. Fail closed if a known private account label enters it.
      const safe = await page.evaluate(mint => {
        if (innerWidth !== 1440 || !document.getElementById(`thesis-trigger-token-page-thesis-${mint}:1399811149`) || !document.querySelector('[aria-label="Like comment"]')) return false;
        for (const node of document.querySelectorAll('span,p,button,div')) {
          if (node.children.length && node.tagName !== 'BUTTON') continue;
          const text = node.textContent?.trim() ?? '';
          if (!/^(?:your positions?\b|your holdings\b|total cash\b|cash$|available balance\b|wallet balance\b|deposit(?: more)?$|withdraw$)/i.test(text)) continue;
          const r = node.getBoundingClientRect();
          if (r.width && r.height && r.right > 360 && r.left < 1080 && r.bottom > 80 && r.top < innerHeight - 55 && getComputedStyle(node).visibility !== 'hidden') return false;
        }
        for (const node of document.querySelectorAll('input,textarea,[contenteditable="true"]')) node.style.setProperty('visibility','hidden','important');
        const covers = [['0','0','360px','100%'],['1080px','0','360px','100%'],['0','0','100%','80px'],['0','620px','100%','calc(100% - 620px)']];
        // Public holder/author position and PnL figures are also omitted. Keep
        // the native chart and comment text, cover each feed-card header and
        // the lower holdings table rather than relying on number formatting.
        for (const control of document.querySelectorAll('[aria-label="Like comment"]')) {
          if (control.closest('button')) continue;
          const header = control.parentElement?.parentElement?.firstElementChild;
          if (!header) continue;
          const r = header.getBoundingClientRect();
          if (r.width && r.height) covers.push([`${r.left}px`,`${r.top}px`,`${r.width}px`,`${r.height}px`]);
        }
        for (const [left,top,width,height] of covers) {
          const cover = document.createElement('div');
          Object.assign(cover.style,{position:'fixed',left,top,width,height,background:'#111',zIndex:'2147483647'}); document.body.append(cover);
        }
        return true;
      }, args.mint);
      if (safe) {
        screenshot = await page.screenshot({ type: 'png', fullPage: false });
        coverage.push('Native token-page viewport; account/trading sidebars, top bar, lower holdings table, comment-card position headers and input controls are masked. Capture is omitted if known private account labels appear in the public center. Dedicated unfunded test account only.');
      } else coverage.push('Screenshot omitted: public-center masking could not be verified.');
    } else {
      // Fresh logged-out context; additionally cover account/trade chrome.
      await page.evaluate(() => {
        for (const [left,top,width,height] of [['65%','0','35%','100%'],['0','0','100%','75px'],['0','calc(100% - 55px)','100%','55px']]) {
          const cover = document.createElement('div');
          Object.assign(cover.style,{position:'fixed',left,top,width,height,background:'#111',zIndex:'2147483647'});
          document.body.append(cover);
        }
      });
      screenshot = await page.screenshot({ type: 'png', fullPage: false });
      coverage.push('Logged-out native page capture; account/trading sidebar and header/footer are covered.');
    }
  }
  return { evidence, coverage, panel_found: selected, panel_error: panelError, scrolls, screenshot };
}

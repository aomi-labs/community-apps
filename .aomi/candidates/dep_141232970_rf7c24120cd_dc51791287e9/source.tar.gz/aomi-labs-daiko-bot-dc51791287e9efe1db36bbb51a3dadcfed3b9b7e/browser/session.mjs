import { fomoAuthState } from './contract.mjs';

// Authentication success and evidence extraction are separate outcomes. A
// refresh rotates credentials even when a later panel read or screenshot fails.
export async function persistFomoSession(storage, context, { refreshed, authenticated }) {
  if (!refreshed && !authenticated) return false;
  const state = fomoAuthState(await context.storageState({ indexedDB: true }));
  if (JSON.stringify(state) === JSON.stringify(await storage.get('state:fomo'))) return false;
  await storage.put({ 'state:fomo': state, 'state:fomo:updated_at': new Date().toISOString() });
  return true;
}

import type { Event } from "@aomi-labs/client";
import { describe, expect, it } from "vitest";

import { CampaignTrace } from "./campaign-trace.ts";

const message = (sequence: number, sender: string, content: string) =>
  ({ type: "message", sequence, sender, content }) as unknown as Event;
const error = (sequence: number, text: string) => ({ type: "error", sequence, message: text }) as unknown as Event;

describe("CampaignTrace", () => {
  it("flags a turn stopped at the execution limit as resumable", () => {
    const trace = new CampaignTrace([
      message(1, "user", "fuzz it"),
      message(2, "system", "execution_limit_reached: This agent reached its execution limit. Send another message to continue."),
    ]);
    expect(trace.resumable).toBe(true);
  });

  it("is not resumable once the user has continued, or after other errors", () => {
    expect(
      new CampaignTrace([
        message(1, "system", "execution_limit_reached: …"),
        message(2, "user", CampaignTrace.CONTINUE_PROMPT),
      ]).resumable,
    ).toBe(false);
    const capped = new CampaignTrace([error(3, "guest model input exceeds the runtime cap")]);
    expect(capped.resumable).toBe(false);
    expect(capped.errors).toEqual(["guest model input exceeds the runtime cap"]);
  });
});

use aomi_sdk::schemars::JsonSchema;
use aomi_sdk::*;
use serde::Deserialize;
use serde_json::{Value, json};

use crate::campaign::{FuzzCampaign, FuzzRoundArgs, FuzzStartArgs};
use crate::client::{ArcStudioFuzzerApp, AttackSurface, MapAttackSurfaceArgs, SourceArgs};

#[derive(Debug, Default, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct EmptyArgs {}

/// Written by hand: the derived schema for an empty struct omits
/// `properties`, which provider strict mode rejects for the whole tool list.
impl JsonSchema for EmptyArgs {
    fn schema_name() -> std::borrow::Cow<'static, str> {
        "EmptyArgs".into()
    }

    fn json_schema(_: &mut aomi_sdk::schemars::SchemaGenerator) -> aomi_sdk::schemars::Schema {
        aomi_sdk::schemars::json_schema!({
            "type": "object",
            "properties": {},
            "required": [],
            "additionalProperties": false
        })
    }
}

pub(crate) struct MapAttackSurface;

impl DynAomiTool for MapAttackSurface {
    type App = ArcStudioFuzzerApp;
    type Args = MapAttackSurfaceArgs;
    const NAME: &'static str = "arc_map_attack_surface";
    const DESCRIPTION: &'static str = "Map a compiled Arc contract's callable surface and source-level risk signals before attacking it. Call this first, either with artifact_url (preferred; the app downloads the source, ABI, and runtime bytecode itself) or with the complete source_code and contract. The app keeps the artifact for this session. Returns exact signatures, read-only observers, hypothesis seeds, and short source whole (longer source as source_lines, read with arc_source). It does not choose a fuzz corpus and never claims vulnerabilities.";

    fn run(app: &Self::App, args: Self::Args, ctx: DynToolCallCtx) -> Result<Value, String> {
        let artifact = args.artifact()?;
        let surface = AttackSurface::map(&artifact)?;
        let mut sessions = app.sessions();
        sessions.open(ctx.session_id.clone(), artifact);
        sessions.output(
            &ctx.session_id,
            serde_json::to_value(surface).map_err(|e| e.to_string())?,
        )
    }
}

pub(crate) struct Source;

impl DynAomiTool for Source {
    type App = ArcStudioFuzzerApp;
    type Args = SourceArgs;
    const NAME: &'static str = "arc_source";
    const DESCRIPTION: &'static str = "Read numbered lines of this session's contract source, at most 200 per call. Use it when arc_map_attack_surface returned source_lines without source_code.";

    fn run(app: &Self::App, args: Self::Args, ctx: DynToolCallCtx) -> Result<Value, String> {
        let mut sessions = app.sessions();
        sessions.restore(&ctx)?;
        sessions.get_mut(&ctx.session_id)?.source(args)
    }
}

pub(crate) struct FuzzStart;

impl DynAomiTool for FuzzStart {
    type App = ArcStudioFuzzerApp;
    type Args = FuzzStartArgs;
    const NAME: &'static str = "arc_fuzz_start";
    const DESCRIPTION: &'static str = "Create this session's fuzz campaign from an executable plan: chain_id plus hypothesis, actors, actions, invariants, max_depth, and max_executions at the top level. Validates the plan against the kept artifact and returns evm-sim setup operations (sim_set_code, null when the code already sits in the world: a live deployment or a harness install; sim_set_balance; sim_snapshot), the first replay batch, and compact progress.";

    fn run(app: &Self::App, args: Self::Args, ctx: DynToolCallCtx) -> Result<Value, String> {
        let mut sessions = app.sessions();
        sessions.restore(&ctx)?;
        let session = sessions.get_mut(&ctx.session_id)?;
        let mut campaign = FuzzCampaign::new(session.contract.clone(), args.clone())?;
        let result = campaign.start();
        session.campaign = Some(campaign);
        session.checkpoint.start = Some(args);
        session.checkpoint.rounds.clear();
        sessions.output(&ctx.session_id, result)
    }
}

pub(crate) struct FuzzRound;

impl DynAomiTool for FuzzRound {
    type App = ArcStudioFuzzerApp;
    type Args = FuzzRoundArgs;
    const NAME: &'static str = "arc_fuzz_round";
    const DESCRIPTION: &'static str = "Pass every compact trace from the last sim_replay_traces call unchanged. The app checks properties, deduplicates states, extends the breadth-first frontier, minimizes and reproduces violations, and returns the next replay batch (null when the campaign is complete or its budget is spent) plus compact progress; call arc_fuzz_report for full coverage. Optionally include a revised plan with the same actors; when nothing is pending (status budget_exhausted or complete), replay may be empty so the revised plan alone continues the campaign.";

    fn run(app: &Self::App, args: Self::Args, ctx: DynToolCallCtx) -> Result<Value, String> {
        let mut sessions = app.sessions();
        sessions.restore(&ctx)?;
        let session = sessions.get_mut(&ctx.session_id)?;
        let result = session
            .campaign
            .as_mut()
            .ok_or("no fuzz campaign for this session; call arc_fuzz_start first")?
            .round(args.clone())?;
        if session
            .checkpoint
            .rounds
            .last()
            .and_then(|round| serde_json::to_value(round).ok())
            != serde_json::to_value(&args).ok()
        {
            session.checkpoint.rounds.push(args);
        }
        sessions.output(&ctx.session_id, result)
    }
}

pub(crate) struct FuzzReport;

impl DynAomiTool for FuzzReport {
    type App = ArcStudioFuzzerApp;
    type Args = EmptyArgs;
    const NAME: &'static str = "arc_fuzz_report";
    const DESCRIPTION: &'static str = "Read the current campaign report: status, coverage, confirmed findings with their minimized reproductions, and unconfirmed violations. Includes next_batch so an interrupted turn can recover its exact pending recipe. Does not change the search or the simulation world.";

    fn run(app: &Self::App, _args: Self::Args, ctx: DynToolCallCtx) -> Result<Value, String> {
        let mut sessions = app.sessions();
        sessions.restore(&ctx)?;
        let report = sessions
            .get_mut(&ctx.session_id)?
            .campaign
            .as_ref()
            .ok_or("no fuzz campaign for this session")?
            .report();
        sessions.output(&ctx.session_id, report)
    }
}

pub(crate) struct FuzzClose;

impl DynAomiTool for FuzzClose {
    type App = ArcStudioFuzzerApp;
    type Args = EmptyArgs;
    const NAME: &'static str = "arc_fuzz_close";
    const DESCRIPTION: &'static str = "Delete this session's artifact and campaign state. Call sim_close separately to release the simulation world.";

    fn run(app: &Self::App, _args: Self::Args, ctx: DynToolCallCtx) -> Result<Value, String> {
        let closed = app.sessions().close(&ctx.session_id);
        Ok(json!({ "status": "closed", "had_session": closed, "__aomi_app_state": null }))
    }
}

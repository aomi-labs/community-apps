import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { createContext, StrictMode, useContext, useLayoutEffect, useRef, useState } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import type { Event } from "@aomi-labs/client";
import type { Campaign } from "@/lib/campaign";
import type { TargetData } from "@/app/actions";
import type { AomiAccount } from "@/lib/aomi-account";
import { loadTarget } from "@/app/actions";
import { FuzzPanel } from "./fuzz-panel";

const submissions = vi.fn<(threadId: string, text: string) => Promise<void>>();
const models = vi.fn<(threadId: string, model: string) => Promise<void>>();
const created = vi.fn();
const setUser = vi.fn();
let activeThread = "old-busy";
let nextThread = 0;
let turnState = "idle";
let events: Event[] = [];

function useRuntime(local = false) {
  const [currentThreadId, select] = useState(local ? "local" : "old-busy");
  const remote = useRef(new Set(["old-busy"]));
  const committed = useRef(currentThreadId);
  useLayoutEffect(() => {
    committed.current = currentThreadId;
    activeThread = currentThreadId;
  }, [currentThreadId]);
  return {
    currentThreadId,
    // Match SDK 0.7.5: selection uses React state and the returned ID is read
    // after a microtask. A caller awaiting this alone need not have committed.
    createThread: async () => {
      created();
      if (!remote.current.has(currentThreadId)) return currentThreadId;
      select(`campaign-${++nextThread}`);
      await Promise.resolve();
      return committed.current;
    },
    // Match the SDK's render-bound sender, rather than masking the bug with a
    // stable mock that always reads the latest thread.
    sendMessage: (text: string) => {
      remote.current.add(currentThreadId);
      return submissions(currentThreadId, text);
    },
    events,
    getMessages: () => [],
    isRunning: false,
    isSubmitting: false,
    turnState,
    setUser,
    cancelGeneration: vi.fn(),
  };
}
const Runtime = createContext<ReturnType<typeof useRuntime> | null>(null);
vi.mock("@aomi-labs/react", () => ({
  useAomiRuntime: () => {
    const value = useContext(Runtime);
    if (!value) throw new Error("Missing runtime");
    return value;
  },
  usePerThreadControl: () => ({
    actions: {
      getCurrentThreadControl: () => ({ model: "Claude Opus 5.5", modelMode: "manual" }),
      onModelSelect: (model: string) => models(activeThread, model),
    },
  }),
}));
vi.mock("@aomi-labs/widget-lib", () => ({ AomiFrame: () => null }));
vi.mock("@/app/actions", () => ({ requestFix: vi.fn(), loadTarget: vi.fn() }));

const target = {
  name: "LendingPool",
  sourcePath: "contracts/LendingPool.sol",
  source: "contract LendingPool {}",
  abi: [{ type: "function", name: "supply", stateMutability: "nonpayable" }],
  deployedBytecode: "0x6000",
  chainId: 5042002,
  deployment: { address: "0x0000000000000000000000000000000000000001", chainId: 5042002 },
  artifactUrl: "https://arc-studio-fuzz.vercel.app/api/artifacts/test",
  immutableReferences: [], protocol: [], installedArtifactUrl: undefined,
} satisfies TargetData;

const testAccount = {
  address: "0x0000000000000000000000000000000000000002",
  session: Object.assign(async () => "test-bearer", {
    required: true as const,
    revoke: async () => {},
    signOut: async () => {},
    dispose: () => {},
    subscribe: () => () => {},
  }),
  signOut: async () => {},
} satisfies AomiAccount;

function Harness({ signedIn = true, local = false, saved }: { signedIn?: boolean; local?: boolean; saved?: Campaign }) {
  const runtime = useRuntime(local);
  return (
    <Runtime.Provider value={runtime}>
      <output data-testid="active-thread">{runtime.currentThreadId}</output>
      <FuzzPanel
        saved={saved}
        appId="test-app"
        backendUrl="https://backend.example"
        account={signedIn ? testAccount : null}
        target={target}
        onRefresh={() => {}}
      />
    </Runtime.Provider>
  );
}

const seeds: string[] = [];
/** Threads whose model was pinned on the backend before their first message. */
const pins: string[] = [];
let seedGate: Promise<void>;

beforeEach(() => {
  vi.clearAllMocks();
  vi.mocked(loadTarget).mockResolvedValue({ ok: true, value: target });
  activeThread = "old-busy";
  nextThread = 0;
  turnState = "idle";
  events = [];
  seeds.length = 0;
  pins.length = 0;
  seedGate = Promise.resolve();
  submissions.mockImplementation(async (threadId) => {
    if (threadId === "old-busy") throw new Error("session busy");
  });
  models.mockResolvedValue(undefined);
  vi.stubGlobal(
    "fetch",
    vi.fn(async (input: URL, init?: RequestInit) => {
      if (input.pathname === "/api/thread/models") return Response.json(["Claude Opus 5.5"]);
      if (input.pathname === "/api/thread/model") {
        const headers = new Headers(init?.headers);
        expect(headers.get("X-Session-Id")).toBe(headers.get("X-Thread-Id"));
        expect(input.searchParams.get("rig")).toBe("Claude Opus 5.5");
        pins.push(headers.get("X-Thread-Id") ?? "missing");
        return Response.json({ success: true, rig: "opus-5.5" });
      }
      if (input.pathname === "/api/thread/sim/world") {
        const headers = new Headers(init?.headers);
        expect(headers.get("X-Session-Id")).toBe(headers.get("X-Thread-Id"));
        seeds.push(headers.get("X-Thread-Id") ?? "missing");
        await seedGate;
        return Response.json({ verified_code_checks: 1 });
      }
      throw new Error(`Unexpected request: ${input}`);
    }),
  );
  Element.prototype.scrollIntoView = vi.fn();
});

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

describe("campaign thread targeting", () => {
  it.each([true, false])(
    "sends initial and repeat runs to the visible fresh thread (signed in: %s)",
    async (signedIn) => {
      render(
        <StrictMode>
          <Harness signedIn={signedIn} />
        </StrictMode>,
      );
      for (const index of [1, 2]) {
        fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
        await waitFor(() => expect(submissions).toHaveBeenCalledTimes(index));
        const threadId = `campaign-${index}`;
        expect(screen.getByTestId("active-thread").textContent).toBe(threadId);
        expect(submissions.mock.calls[index - 1]?.[0]).toBe(threadId);
        expect(models.mock.calls[index - 1]).toEqual([threadId, "Claude Opus 5.5"]);
        if (signedIn) expect(seeds[index - 1]).toBe(threadId);
        if (signedIn) expect(pins[index - 1]).toBe(threadId);
        expect(screen.queryByText("session busy")).toBeNull();
        await waitFor(() => expect(screen.getByTestId("run-aomi-fuzz").hasAttribute("disabled")).toBe(false));
      }
      expect(created).toHaveBeenCalledTimes(2);
      if (!signedIn) expect(seeds).toEqual([]);
      if (!signedIn) expect(pins).toEqual([]);
    },
  );

  it("uses the initial unsent local thread when the SDK reuses it", async () => {
    render(<Harness local />);
    fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
    await waitFor(() => expect(submissions).toHaveBeenCalledTimes(1));
    expect(screen.getByTestId("active-thread").textContent).toBe("local");
    expect(submissions.mock.calls[0]?.[0]).toBe("local");
    expect(models.mock.calls[0]).toEqual(["local", "Claude Opus 5.5"]);
    expect(seeds).toEqual(["local"]);
  });

  it("disables duplicate starts and model changes while seeding is pending", async () => {
    const gate = Promise.withResolvers<void>();
    seedGate = gate.promise;
    render(<Harness />);
    const button = screen.getByTestId("run-aomi-fuzz");
    fireEvent.click(button);
    await waitFor(() => expect(seeds).toEqual(["campaign-1"]));
    expect(button.hasAttribute("disabled")).toBe(true);
    expect(screen.getByRole("combobox").hasAttribute("disabled")).toBe(true);
    fireEvent.click(button);
    expect(created).toHaveBeenCalledTimes(1);
    expect(submissions).not.toHaveBeenCalled();
    await act(async () => gate.resolve());
    await waitFor(() => expect(submissions).toHaveBeenCalledTimes(1));
    expect(submissions.mock.calls[0]?.[0]).toBe("campaign-1");
  });

  it("releases startup after a rejected send so the next campaign can retry", async () => {
    submissions.mockRejectedValueOnce(new Error("test submission failure"));
    render(<Harness />);
    fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
    await screen.findByText("test submission failure");
    expect(screen.getByTestId("run-aomi-fuzz").hasAttribute("disabled")).toBe(false);
    fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
    await waitFor(() => expect(submissions).toHaveBeenCalledTimes(2));
    expect(submissions.mock.calls[1]?.[0]).toBe("campaign-2");
    expect(screen.queryByText("test submission failure")).toBeNull();
  });
});


it("does not call a completed model turn a completed campaign without a report", async () => {
  const view = render(<Harness />);
  fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
  await waitFor(() => expect(submissions).toHaveBeenCalledTimes(1));
  turnState = "complete";
  view.rerender(<Harness />);
  expect(await screen.findByText("Turn ended · campaign incomplete")).toBeTruthy();
  expect(screen.queryByText("Campaign complete")).toBeNull();
});

const limitedTurn = (): Event[] => [
  { type: "error", message: "execution_limit_reached", event_id: "e1", sequence: 1, turn_id: "t1", occurred_at: 1 },
  { type: "turn_state_changed", state: "failed", event_id: "e2", sequence: 2, turn_id: "t1", occurred_at: 2 },
];
const savedRun = (status: string): Campaign => ({ id: "run", threadId: "local", target, status, resumes: 0, createdAt: 1 });

it("restoring a stopped campaign never sends an automatic continuation", () => {
  turnState = "failed";
  events = limitedTurn();
  render(<Harness local saved={savedRun("Stopped")} />);
  expect(submissions).not.toHaveBeenCalled();
});

it("late events do not send a second continuation for the same stopped turn", async () => {
  turnState = "failed";
  events = limitedTurn();
  const view = render(<Harness local saved={savedRun("Incomplete")} />);
  await waitFor(() => expect(submissions).toHaveBeenCalledTimes(1));
  events = [...events, { type: "title_changed", title: "Campaign", event_id: "e3", sequence: 3, turn_id: "t1", occurred_at: 3 }];
  view.rerender(<Harness local saved={savedRun("Incomplete")} />);
  expect(submissions).toHaveBeenCalledTimes(1);
});

it.each(["http", "network"])("does not submit a campaign when explicit world seeding fails (%s)", async (kind) => {
  const original = globalThis.fetch;
  let fail = true;
  vi.stubGlobal("fetch", vi.fn(async (input: URL, init?: RequestInit) => {
    if (fail && input.pathname === "/api/thread/sim/world") {
      if (kind === "network") throw new Error("network unavailable");
      return new Response("simulation setup unavailable", { status: 503 });
    }
    return original(input, init);
  }));
  render(<Harness />);
  fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
  await screen.findByText(/Could not seed the simulation world/);
  expect(submissions).not.toHaveBeenCalled();
  expect(screen.queryByText("Continue campaign")).toBeNull();
  expect(screen.getByTestId("run-aomi-fuzz").hasAttribute("disabled")).toBe(false);
  fail = false;
  fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
  await waitFor(() => expect(submissions).toHaveBeenCalledTimes(1));
  expect(submissions.mock.calls[0]?.[0]).toBe("campaign-1");
});

it("does not submit after Stop during pending seed", async () => {
  const gate = Promise.withResolvers<void>();
  seedGate = gate.promise;
  render(<Harness />);
  fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
  await waitFor(() => expect(seeds).toEqual(["campaign-1"]));
  fireEvent.click(screen.getByText("Stop execution"));
  await act(async () => gate.resolve());
  await waitFor(() => expect(screen.getByTestId("run-aomi-fuzz").hasAttribute("disabled")).toBe(false));
  expect(submissions).not.toHaveBeenCalled();
});

it("refreshes expired links at launch and rejects a changed build", async () => {
  vi.mocked(loadTarget).mockResolvedValueOnce({ ok: true, value: { ...target, artifactUrl: "https://arc-studio-fuzz.vercel.app/api/artifacts/fresh" } });
  render(<Harness />);
  fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
  await waitFor(() => expect(submissions).toHaveBeenCalledTimes(1));
  expect(submissions.mock.calls[0]?.[1]).toContain("/artifacts/fresh");
  vi.mocked(loadTarget).mockResolvedValueOnce({ ok: true, value: { ...target, deployedBytecode: "0x6001" } });
  fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
  await screen.findByText(/compiled target changed/);
  expect(submissions).toHaveBeenCalledTimes(1);
});

it("continues unfinished work after reproducing a first finding", async () => {
  turnState = "failed";
  const result = { campaign_id: "c", status: "exploring", findings: [{ property: "p", minimized_trace: [], balances: [], probes: [] }], executions: 12, round: 3, frontier_size: 8, corpus_size: 2, uncovered_writes: [], never_succeeded: [] };
  events = [{ type: "tool_complete", sequence: 0, tool_name: "arc_fuzz_round", id: "round", result: { progress: result } } as unknown as Event, ...limitedTurn()];
  render(<Harness local saved={savedRun("Incomplete")} />);
  await waitFor(() => expect(submissions).toHaveBeenCalledTimes(1));
  expect(submissions.mock.calls[0]?.[1]).toContain("arc_fuzz_report");
});

it("does not accept an older backend that ignores deployment code checks", async () => {
  const original = globalThis.fetch;
  vi.stubGlobal("fetch", vi.fn(async (input: URL, init?: RequestInit) => input.pathname === "/api/thread/sim/world" ? Response.json({}) : original(input, init)));
  render(<Harness />);
  fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
  await screen.findByText(/backend has not verified/);
  expect(submissions).not.toHaveBeenCalled();
});

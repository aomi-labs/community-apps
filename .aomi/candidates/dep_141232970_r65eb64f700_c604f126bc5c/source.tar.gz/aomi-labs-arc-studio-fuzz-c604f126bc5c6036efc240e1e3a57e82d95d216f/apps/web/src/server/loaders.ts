import { createServerFn } from "@tanstack/react-start";
import { setResponseHeader } from "@tanstack/react-start/server";
import { redirect } from "@tanstack/react-router";
import { z } from "zod";
import { StudioSession } from "./studio-session";

export const home = createServerFn().handler(async () => {
  setResponseHeader("cache-control", "private, no-store");
  const session = await StudioSession.current();
  const apps = await session
    ?.client()
    .listApps()
    .then((list) => list.sort((a, b) => b.timestamp.localeCompare(a.timestamp)))
    .catch(() => null);
  return { apps: apps ?? null, expired: Boolean(session), authorizeUrl: `${StudioSession.apiUrl}/cli-auth` };
});

export const workspace = createServerFn()
  .validator(z.object({ appId: z.string().uuid() }))
  .handler(async ({ data: { appId } }) => {
    setResponseHeader("cache-control", "private, no-store");
    const session = await StudioSession.current();
    if (!session) throw redirect({ to: "/" });
    const client = session.client();
    try {
      const [described, app] = await Promise.all([
        client.listApps().then((apps) => apps.find((app) => app.id === appId)),
        session.app(appId),
      ]);
      const [contracts, files] = await Promise.all([app.contracts(), app.files()]);
      return {
        appId,
        appName: described?.description || "Untitled app",
        studioUrl: app.webUrl,
        contracts,
        files: files.map((file) => file.path),
        error: null,
      };
    } catch (error) {
      return {
        appId,
        appName: "Unavailable app",
        studioUrl: client.webUrl(appId),
        contracts: [],
        files: [],
        error: error instanceof Error ? error.message : String(error),
      };
    }
  });

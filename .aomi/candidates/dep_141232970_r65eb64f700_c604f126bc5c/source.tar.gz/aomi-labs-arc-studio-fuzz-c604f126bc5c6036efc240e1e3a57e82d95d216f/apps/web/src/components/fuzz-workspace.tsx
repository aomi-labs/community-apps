"use client";

import { useQueryClient } from "@tanstack/react-query";

import { ArcStudioApp, type ContractSource } from "@aomi-labs/arc-studio-fuzz-core";
import { readCampaigns, saveCampaigns, type Campaign } from "@/lib/campaign";
import { AomiRuntimeProvider } from "@aomi-labs/react";
import {
  BrainCircuit,
  Check,
  ChevronLeft,
  CircleDashed,
  ExternalLink,
  File as FileIcon,
  FileCode2,
  Hammer,
  Loader2,
  LogOut,
  UserCheck,
  Wallet,
} from "lucide-react";
import { Link, useRouter } from "@tanstack/react-router";
import {
  type Dispatch,
  type ReactNode,
  type SetStateAction,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  useTransition,
} from "react";

import { loadTarget, refreshApp, requestBuild, type TargetData } from "@/app/actions";
import { Brand } from "@/components/brand";
import { AomiAccount, guestSession } from "@/lib/aomi-account";
import { COLLAPSED, FileTree } from "@/components/file-tree";
import { FuzzPanel } from "@/components/fuzz-panel";

// The Aomi portal (auth + proxy to the backend). Staging hosts arc-studio-fuzzer today.
const backendUrl = process.env.NEXT_PUBLIC_AOMI_BACKEND_URL ?? "https://chat-staging.aomi.dev";
const configuredApplicationId = Number(process.env.NEXT_PUBLIC_AOMI_APPLICATION_ID);
const applicationId =
  Number.isSafeInteger(configuredApplicationId) && configuredApplicationId > 0 ? configuredApplicationId : undefined;

const KEYWORDS =
  /\b(?:contract|interface|library|abstract|is|mapping|address|bool|string|bytes\d*|u?int\d*|public|private|internal|external|view|pure|payable|function|modifier|event|error|emit|returns?|require|revert|if|else|for|while|memory|storage|calldata|constructor|pragma|solidity|import|using|struct|enum|override|virtual|immutable|constant)\b/;

function highlight(line: string): ReactNode {
  if (line.trim().startsWith("//")) return <span className="text-ink-muted">{line}</span>;
  return line.split(new RegExp(`(${KEYWORDS.source})`, "g")).map((token, index) =>
    KEYWORDS.test(token) ? (
      <span key={index} className="text-accent-strong">
        {token}
      </span>
    ) : (
      token
    ),
  );
}

type TargetState =
  | { status: "idle" }
  | { status: "loading" }
  | { status: "ready"; target: TargetData }
  | { status: "missing-build"; error: string; buildUrl?: string }
  | { status: "error"; error: string };

export interface FuzzWorkspaceProps {
  appId: string;
  appName: string;
  studioUrl: string;
  contracts: ContractSource[];
  /** Paths Arc Studio listed in the sandbox; empty usually means it was still waking up. */
  files: string[];
}

export function FuzzWorkspace(props: FuzzWorkspaceProps) {
  const queries = useQueryClient();
  const [account, setAccount] = useState<AomiAccount | null>(null);
  const [identityReady, setIdentityReady] = useState(false);
  // Navigation is independent of the runtimes retained for each contract.
  const firstBuilt =
    props.contracts.find((file) => file.built && file.contracts.length > 0) ??
    props.contracts.find((file) => file.contracts.length > 0);
  const [selected, setSelected] = useState<Selection | null>(
    firstBuilt ? { path: firstBuilt.path, contract: firstBuilt.contracts[0] as string } : null,
  );
  const [opened, setOpened] = useState<OpenFile | null>(
    firstBuilt ? { path: firstBuilt.path, content: firstBuilt.source } : null,
  );
  const [target, setTarget] = useState<TargetState>({ status: "idle" });
  const [reloads, setReloads] = useState(0);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [activeCampaign, setActiveCampaign] = useState<string>();
  const [restored, setRestored] = useState<string>();
  const scope = JSON.stringify([backendUrl, props.appId, account?.address.toLowerCase() ?? "guest"]);

  useEffect(() => {
    if (!identityReady) return;
    setCampaigns([]);
    setActiveCampaign(undefined);
    // Listing saved campaigns must not renew an expired wallet session.
    // The runtime reconnects only when the visitor opens a campaign.
    setCampaigns(readCampaigns(scope).map((run) =>
      run.status === "Unavailable" ? { ...run, status: "Incomplete" } : run,
    ));
    setRestored(scope);
  }, [scope, identityReady, account]);

  useEffect(() => {
    if (restored === scope) saveCampaigns(scope, campaigns);
  }, [scope, restored, campaigns]);

  useEffect(() => {
    if (!selected) return;
    let cancelled = false;
    setTarget({ status: "loading" });
    void queries
      .fetchQuery({
        queryKey: ["target", props.appId, selected.path, selected.contract, reloads],
        queryFn: () =>
          loadTarget({ data: { appId: props.appId, sourcePath: selected.path, contract: selected.contract } }),
        staleTime: 60_000,
      })
      .then((result) => {
        if (cancelled) return;
        if (result.ok) {
          setTarget({ status: "ready", target: result.value });
        } else if (result.missingBuild) setTarget({ status: "missing-build", error: result.error });
        else setTarget({ status: "error", error: result.error });
      })
      .catch((error: unknown) => {
        if (!cancelled) setTarget({ status: "error", error: String(error) });
      });
    return () => {
      cancelled = true;
    };
  }, [props.appId, selected, reloads, queries]);

  useEffect(() => {
    void AomiAccount.resume(backendUrl)
      .then(setAccount)
      .finally(() => setIdentityReady(true));
  }, []);

  return (
    <Workspace
      {...props}
      account={account}
      onAccount={setAccount}
      selected={selected}
      onSelect={setSelected}
      opened={opened}
      onOpen={setOpened}
      target={target}
      campaigns={campaigns}
      activeCampaign={activeCampaign}
      onCampaign={setActiveCampaign}
      onCampaigns={setCampaigns}
      ready={restored === scope}
      onTarget={setTarget}
      onReload={() => setReloads((count) => count + 1)}
    />
  );
}

/** Header control for the Aomi account the campaigns run as. */
function AccountControl({
  account,
  onAccount,
}: {
  account: AomiAccount | null;
  onAccount: (account: AomiAccount | null) => void;
}) {
  const [pending, startPending] = useTransition();
  const [error, setError] = useState<string | null>(null);

  if (account) {
    return (
      <div className="flex items-center gap-2 rounded-pill border border-success/30 bg-success/8 px-3 py-1.5 text-[12px] text-success">
        <UserCheck className="size-3.5" />
        Aomi · {account.address.slice(0, 6)}…{account.address.slice(-4)}
        <button
          onClick={() =>
            startPending(async () => {
              await account.signOut();
              onAccount(null);
            })
          }
          className="ml-1 text-ink-muted hover:text-ink"
          aria-label="Sign out of Aomi"
          title="Sign out of Aomi"
        >
          <LogOut className="size-3.5" />
        </button>
      </div>
    );
  }
  return (
    <div className="flex items-center gap-2">
      {error && (
        <span className="max-w-64 truncate text-[12px] text-danger" title={error}>
          {error}
        </span>
      )}
      <button
        disabled={pending}
        onClick={() =>
          startPending(async () => {
            setError(null);
            try {
              onAccount(await AomiAccount.signIn(backendUrl));
            } catch (cause) {
              setError(cause instanceof Error ? cause.message : String(cause));
            }
          })
        }
        title="Sign in with your Ethereum wallet (one signature, no transaction). Signed-in campaigns are not limited by the guest input cap."
        className="flex items-center gap-1.5 rounded-pill bg-ink px-3.5 py-1.5 text-[12px] font-medium text-bg transition hover:bg-ink/85 disabled:opacity-70"
      >
        {pending ? <Loader2 className="size-3.5 animate-spin" /> : <Wallet className="size-3.5" />}
        Sign in to Aomi
      </button>
    </div>
  );
}

const LAYOUT_KEY = "arc-studio-fuzz:layout";
const LIMITS = { explorer: [180, 520], agent: [340, 760], activity: [10, 80] } as const;
// Side widths use pixels; activity height uses viewport height units.
const DEFAULT_LAYOUT = { explorer: 280, agent: 460, activity: 35 };
const MAX_VIEW_BYTES = 300_000;

type Layout = typeof DEFAULT_LAYOUT;
type OpenFile = { path: string; content?: string; error?: string; line?: number };
type Selection = { path: string; contract: string };

/** Drag a panel boundary; double-click restores its default size. */
function Divider({
  onDrag,
  onReset,
  horizontal = false,
}: {
  onDrag: (delta: number) => void;
  onReset: () => void;
  horizontal?: boolean;
}) {
  return (
    <div
      role="separator"
      aria-orientation={horizontal ? "horizontal" : "vertical"}
      aria-label={horizontal ? "Resize campaign activity" : "Resize side panel"}
      title="Drag to resize · double-click to reset"
      onDoubleClick={onReset}
      onPointerDown={(event) => {
        if (event.button !== 0) return;
        const handle = event.currentTarget;
        handle.setPointerCapture(event.pointerId);
        let last = horizontal ? event.clientY : event.clientX;
        const move = (e: PointerEvent) => {
          const position = horizontal ? e.clientY : e.clientX;
          onDrag(position - last);
          last = position;
        };
        const up = () => {
          handle.removeEventListener("pointermove", move);
          handle.removeEventListener("pointerup", up);
          handle.removeEventListener("lostpointercapture", up);
          document.body.style.removeProperty("cursor");
          document.body.style.removeProperty("user-select");
        };
        document.body.style.cursor = horizontal ? "row-resize" : "col-resize";
        document.body.style.userSelect = "none";
        handle.addEventListener("pointermove", move);
        handle.addEventListener("pointerup", up);
        handle.addEventListener("lostpointercapture", up);
      }}
      className={`group relative z-10 flex shrink-0 touch-none ${horizontal ? "-my-1 h-2 cursor-row-resize" : "-mx-1 w-2 cursor-col-resize"}`}
    >
      <div
        className={`bg-border transition group-hover:bg-accent group-active:bg-accent ${
          horizontal ? "my-auto h-px w-full group-hover:h-0.5" : "mx-auto h-full w-px group-hover:w-0.5"
        }`}
      />
    </div>
  );
}

function Workspace({
  appId,
  appName,
  studioUrl,
  contracts,
  files,
  account,
  onAccount,
  selected,
  onSelect: setSelected,
  opened,
  onOpen: setOpened,
  target,
  campaigns,
  activeCampaign,
  onCampaign,
  onCampaigns,
  ready,
  onTarget: setTarget,
  onReload,
}: FuzzWorkspaceProps & {
  account: AomiAccount | null;
  onAccount: (account: AomiAccount | null) => void;
  selected: Selection | null;
  onSelect: (selection: Selection | null) => void;
  opened: OpenFile | null;
  onOpen: Dispatch<SetStateAction<OpenFile | null>>;
  target: TargetState;
  campaigns: Campaign[];
  activeCampaign?: string;
  onCampaign: (id: string | undefined) => void;
  onCampaigns: Dispatch<SetStateAction<Campaign[]>>;
  ready: boolean;
  onTarget: (target: TargetState) => void;
  onReload: () => void;
}) {
  const router = useRouter();
  const [building, startBuild] = useTransition();
  const [layout, setLayout] = useState<Layout>(DEFAULT_LAYOUT);
  /** File reads by path, shared by hover-prefetch and clicks; cleared on refresh. */
  const reads = useRef(new Map<string, Promise<OpenFile>>());
  const [tabs, setTabs] = useState<string[]>([]);
  const [chosenTarget, setChosenTarget] = useState(false);
  const [activatedCampaigns, setActivatedCampaigns] = useState<Set<string>>(() => new Set());
  const sourceView = useRef<HTMLDivElement>(null);
  const scrolls = useRef(new Map<string, number>());
  useEffect(() => {
    if (opened) setTabs((current) => (current.includes(opened.path) ? current : [...current, opened.path]));
  }, [opened]);
  useLayoutEffect(() => {
    if (sourceView.current && opened)
      sourceView.current.scrollTop =
        opened.line !== undefined ? opened.line * 23 : (scrolls.current.get(opened.path) ?? 0);
  }, [opened?.path, opened?.line]);
  const fuzzable = contracts.filter((file) => file.contracts.length > 0);
  const scaffoldOnly = files.some((path) => /(^|\/)contracts\/(out|script)\//.test(path));

  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(LAYOUT_KEY) ?? "null") as Partial<Layout> | null;
      if (saved) setLayout((current) => ({ ...current, ...saved }));
    } catch {
      /* per-viewer convenience only */
    }
  }, []);

  function resize(panel: keyof Layout, delta: number) {
    setLayout((current) => {
      const [min, max] = LIMITS[panel];
      const next = { ...current, [panel]: Math.min(max, Math.max(min, current[panel] + delta)) };
      try {
        localStorage.setItem(LAYOUT_KEY, JSON.stringify(next));
      } catch {
        /* ignore */
      }
      return next;
    });
  }

  function read(path: string): Promise<OpenFile> {
    let pending = reads.current.get(path);
    if (!pending) {
      pending = fetch(`/api/apps/${appId}/file?path=${encodeURIComponent(path)}`).then(async (response) =>
        response.ok ? { path, content: await response.text() } : { path, error: await response.text() },
      );
      // Failed reads are retried on the next click.
      void pending.then((file) => file.error && reads.current.delete(path));
      reads.current.set(path, pending);
    }
    return pending;
  }

  // Warm the viewer: fetch the app's own files (not deps, build output, lockfiles
  // or secrets) in one batch, so most clicks never wait on Arc Studio.
  useEffect(() => {
    const known = new Set(contracts.map((file) => file.path));
    const project = files.filter(
      (path) =>
        !known.has(path) &&
        !reads.current.has(path) &&
        !ArcStudioApp.isSensitive(path) &&
        !ArcStudioApp.workspacePath(path)
          .split("/")
          .some((part) => COLLAPSED.has(part)) &&
        !/\.(lock|jsonl|png|jpe?g|gif|ico|woff2?|ttf)$/i.test(path),
    );
    if (project.length === 0) return;
    const batch = fetch(`/api/apps/${appId}/files`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ paths: project }),
    })
      .then((response): Promise<Record<string, string>> | Record<string, string> =>
        response.ok ? response.json() : {},
      )
      .catch((): Record<string, string> => ({}));
    for (const path of project.slice(0, 80)) {
      reads.current.set(
        path,
        batch.then((contents) => {
          if (path in contents) return { path, content: contents[path] as string };
          reads.current.delete(path);
          return read(path);
        }),
      );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- once per workspace load
  }, [appId, files]);

  function open(path: string) {
    const known = contracts.find((file) => file.path === path);
    if (known) {
      setOpened({ path, content: known.source });
      return;
    }
    setOpened({ path });
    void read(path).then((file) => setOpened((current) => (current?.path === path ? file : current)));
  }

  function choose(path: string, contract: string) {
    setChosenTarget(true);
    onCampaign(undefined);
    setSelected({ path, contract });
    open(path);
  }

  /** Re-read the workspace from Arc Studio (after a build or fix landed there). */
  function refresh() {
    reads.current.clear();
    void refreshApp({ data: { appId } }).then(() => {
      router.invalidate();
      onReload();
    });
  }

  useEffect(() => {
    if (
      !ready ||
      !chosenTarget ||
      target.status !== "ready" ||
      activeCampaign ||
      selected?.path !== target.target.sourcePath ||
      selected.contract !== target.target.name
    )
      return;
    const existing = campaigns.findLast(
      (run) => run.target.sourcePath === target.target.sourcePath && run.target.name === target.target.name,
    );
    if (existing) {
      setActivatedCampaigns((current) => new Set(current).add(existing.id));
      onCampaign(existing.id);
      return;
    }
    const run: Campaign = {
      id: crypto.randomUUID(),
      target: target.target,
      status: "Ready",
      resumes: 0,
      createdAt: Date.now(),
    };
    onCampaigns((current) => [...current, run]);
    setActivatedCampaigns((current) => new Set(current).add(run.id));
    onCampaign(run.id);
  }, [ready, target, selected, activeCampaign, campaigns, chosenTarget, onCampaign, onCampaigns]);

  function newCampaign(data: TargetData) {
    const run: Campaign = { id: crypto.randomUUID(), target: data, status: "Ready", resumes: 0, createdAt: Date.now() };
    onCampaigns((current) => [...current, run]);
    setActivatedCampaigns((current) => new Set(current).add(run.id));
    onCampaign(run.id);
  }

  const content = opened?.content ?? "";
  const truncated = content.length > MAX_VIEW_BYTES;
  const lines = (truncated ? content.slice(0, MAX_VIEW_BYTES) : content).split("\n");
  const solidity = opened?.path.endsWith(".sol") ?? false;

  return (
    <main className="flex h-screen flex-col overflow-hidden text-[13px]">
      <header className="flex h-14 shrink-0 items-center justify-between gap-4 border-b border-border bg-surface px-4">
        <div className="flex min-w-0 items-center gap-4">
          <Link
            to="/"
            className="rounded-pill p-1 text-ink-muted hover:bg-hover hover:text-ink"
            aria-label="Back to apps"
          >
            <ChevronLeft className="size-5" />
          </Link>
          <Brand />
          <div className="h-5 w-px bg-border" />
          <span className="truncate text-[14px] font-medium text-ink">{appName}</span>
        </div>
        <div className="flex shrink-0 items-center gap-3">
          <AccountControl account={account} onAccount={onAccount} />
          <div className="flex items-center gap-2 rounded-pill border border-accent/45 bg-accent/10 px-3 py-1.5 text-[12px] text-accent-strong">
            <span className="size-1.5 rounded-pill bg-accent" />
            Arc fork · {target.status === "ready" ? target.target.chainId : 5042}
            {target.status === "ready" && target.target.deployment && " · live deployment"}
          </div>
          <a
            href={studioUrl}
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1.5 rounded-pill border border-border px-3 py-1.5 text-[12px] font-medium text-ink transition hover:bg-hover"
          >
            Open in Arc Studio <ExternalLink className="size-3.5" />
          </a>
        </div>
      </header>

      <div className="flex min-h-0 flex-1">
        <aside style={{ width: layout.explorer }} className="flex shrink-0 flex-col overflow-hidden bg-surface">
          <div className="min-h-0 flex-1 overflow-auto">
            <h2 className="px-3 pb-2 pt-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-ink-muted">
              Fuzz targets
            </h2>
            {fuzzable.length === 0 ? (
              <div className="mx-3 mb-4 space-y-2 rounded-md border border-border bg-bg p-3 text-[12px] leading-5 text-ink">
                <p>
                  {files.length === 0
                    ? "Arc Studio returned an empty workspace. The app's sandbox may still be waking up."
                    : scaffoldOnly
                      ? "This app has Foundry scaffolding (forge-std, deploy scripts) but no contract of its own. It likely uses existing contracts such as USDC."
                      : "No Solidity contracts in this app yet."}
                </p>
                <p className="text-ink-muted">Ask Arc Studio to write a contract, then check again.</p>
                <button onClick={refresh} className="font-medium text-accent-strong hover:underline">
                  Check again
                </button>
              </div>
            ) : (
              <ul className="space-y-0.5 px-2 pb-4">
                {fuzzable.flatMap((file) =>
                  file.contracts.map((name) => {
                    const active = selected?.path === file.path && selected.contract === name;
                    return (
                      <li key={`${file.path}:${name}`}>
                        <button
                          onClick={() => choose(file.path, name)}
                          className={`flex w-full items-center gap-2 rounded-md px-2 py-2 text-left ${
                            active ? "bg-accent-subtle text-ink" : "text-ink hover:bg-hover"
                          }`}
                        >
                          <FileCode2 className="size-4 shrink-0 text-accent" />
                          <span className="min-w-0 flex-1">
                            <span className="block truncate font-medium">{name}</span>
                            <span className="block truncate text-[11px] text-ink-muted">
                              {ArcStudioApp.workspacePath(file.path)}
                            </span>
                          </span>
                          {file.built ? (
                            <span className="flex shrink-0 items-center gap-1 text-[11px] text-success">
                              <Check className="size-3.5" /> built
                            </span>
                          ) : (
                            <span className="flex shrink-0 items-center gap-1 text-[11px] text-ink-muted">
                              <CircleDashed className="size-3.5" /> not built
                            </span>
                          )}
                        </button>
                      </li>
                    );
                  }),
                )}
              </ul>
            )}

            <h2 className="border-t border-border px-3 pb-2 pt-4 text-[11px] font-semibold uppercase">Campaigns</h2>
            {campaigns
              .filter((run) => run.threadId)
              .map((run) => (
                <button
                  key={run.id}
                  onClick={() => {
                    setActivatedCampaigns((current) => new Set(current).add(run.id));
                    onCampaign(run.id);
                    setOpened({ path: run.target.sourcePath, content: run.target.source });
                  }}
                  className={`mx-2 block w-[calc(100%-1rem)] rounded-md px-2 py-2 text-left ${activeCampaign === run.id ? "bg-accent-subtle" : "hover:bg-hover"}`}
                >
                  <span className="block font-medium">{run.target.name}</span>
                  <span className="block text-xs text-ink-muted">
                    {run.status} · {new Date(run.createdAt).toLocaleTimeString()}
                  </span>
                </button>
              ))}
            <h2 className="flex items-center justify-between border-t border-border px-3 pb-2 pt-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-ink-muted">
              Files <span className="font-normal normal-case tracking-normal text-ink-muted/70">{files.length}</span>
            </h2>
            <FileTree files={files} openPath={opened?.path} onOpen={open} onPrefetch={(path) => void read(path)} />
          </div>
        </aside>

        <Divider
          onDrag={(dx) => resize("explorer", dx)}
          onReset={() => resize("explorer", DEFAULT_LAYOUT.explorer - layout.explorer)}
        />

        <section className="flex min-h-0 min-w-0 flex-1 flex-col bg-bg">
          <div
            role="tablist"
            aria-label="Source files"
            className="flex shrink-0 overflow-x-auto border-b border-border"
          >
            {tabs.map((path) => (
              <button
                key={path}
                role="tab"
                aria-selected={opened?.path === path}
                title={path}
                onClick={() => open(path)}
                className={`shrink-0 px-3 py-2 ${opened?.path === path ? "bg-accent-subtle" : "hover:bg-hover"}`}
              >
                {path.split("/").at(-1)}
              </button>
            ))}
          </div>
          <div className="flex h-11 shrink-0 items-center gap-2 border-b border-border bg-surface px-4 text-[13px] text-ink">
            {opened ? (
              <>
                {solidity ? (
                  <FileCode2 className="size-4 text-accent" />
                ) : (
                  <FileIcon className="size-4 text-ink-muted" />
                )}
                <span className="truncate">{ArcStudioApp.workspacePath(opened.path)}</span>
              </>
            ) : (
              <span className="text-ink-muted">Select a file to view it</span>
            )}
          </div>
          <div
            ref={sourceView}
            onScroll={() => {
              if (opened && sourceView.current) scrolls.current.set(opened.path, sourceView.current.scrollTop);
            }}
            className="min-h-0 flex-1 overflow-auto py-4 font-mono text-[13px] leading-[1.75]"
          >
            {opened && opened.content === undefined && !opened.error && (
              <p className="flex items-center gap-2 px-6 text-ink-muted">
                <Loader2 className="size-4 animate-spin" /> Reading from Arc Studio…
              </p>
            )}
            {opened?.error && <p className="px-6 text-danger">{opened.error}</p>}
            {opened?.content !== undefined &&
              lines.map((line, index) => (
                <div key={index} className={`flex min-h-[23px] ${opened.line === index ? "bg-accent-subtle" : ""}`}>
                  <span className="w-14 shrink-0 select-none pr-4 text-right text-ink-muted/60">{index + 1}</span>
                  <span className="whitespace-pre pr-6 text-ink">{solidity ? highlight(line) : line}</span>
                </div>
              ))}
            {truncated && (
              <p className="px-6 pt-2 text-ink-muted">
                Showing the first {MAX_VIEW_BYTES.toLocaleString()} characters of a large file.
              </p>
            )}
          </div>
          <Divider
            horizontal
            onDrag={(dy) => resize("activity", (-dy / window.innerHeight) * 100)}
            onReset={() => resize("activity", DEFAULT_LAYOUT.activity - layout.activity)}
          />
          <section
            aria-label="Campaign activity"
            style={{ height: `${layout.activity}vh`, maxHeight: "calc(100% - 9rem)" }}
            className="flex min-h-32 shrink-0 flex-col bg-surface"
          >
            <h2 className="border-b border-border px-3 py-2 text-xs font-semibold">
              Campaign activity ·{" "}
              {campaigns.find((run) => run.id === activeCampaign)?.target.name ?? "Select a campaign"}
            </h2>
            <div id="campaign-activity" className="flex min-h-0 flex-1 flex-col overflow-auto" />
          </section>
        </section>

        <Divider
          onDrag={(dx) => resize("agent", -dx)}
          onReset={() => resize("agent", DEFAULT_LAYOUT.agent - layout.agent)}
        />

        <aside style={{ width: layout.agent }} className="flex min-h-0 shrink-0 flex-col bg-surface">
          {/* Keep the runtime and continuation mounted even while another artifact loads. */}
          {campaigns.map((campaign) => {
            if (campaign.threadId && !activatedCampaigns.has(campaign.id)) return null;
            const visible = activeCampaign === campaign.id;
            if (campaign.status === "Unavailable")
              return visible ? (
                <div key={campaign.id} role="alert" className="p-4">
                  Saved campaign unavailable. Its thread may have expired or access could not be verified.
                  <button
                    className="block underline"
                    onClick={() => {
                      void loadTarget({
                        data: { appId, sourcePath: campaign.target.sourcePath, contract: campaign.target.name },
                      }).then((result) => {
                        if (result.ok) newCampaign(result.value);
                      });
                    }}
                  >
                    Prepare a new campaign
                  </button>
                </div>
              ) : null;
            return (
              <div key={campaign.id} hidden={!visible} className={visible ? "flex min-h-0 flex-1 flex-col" : "hidden"}>
                <CampaignRuntime campaign={campaign} account={account}>
                  <FuzzPanel
                    appId={appId}
                    backendUrl={backendUrl}
                    applicationId={applicationId}
                    account={account}
                    target={campaign.target}
                    saved={campaign}
                    onSource={(name: string, contract?: string | null) => {
                      if (contract && contract !== campaign.target.name) {
                        const file = contracts.find((file) => file.contracts.includes(contract));
                        if (file) void read(file.path).then(setOpened);
                        return;
                      }
                      const fn = name.split("(")[0];
                      const line = campaign.target.source
                        .split("\n")
                        .findIndex((text) => text.includes(`function ${fn}(`));
                      setOpened({
                        path: campaign.target.sourcePath,
                        content: campaign.target.source,
                        line: line >= 0 ? line : undefined,
                      });
                    }}
                    onChange={(update) =>
                      onCampaigns((current) =>
                        current.map((run) => (run.id === campaign.id ? { ...run, ...update } : run)),
                      )
                    }
                    onNew={() => {
                      void loadTarget({
                        data: { appId, sourcePath: campaign.target.sourcePath, contract: campaign.target.name },
                      }).then((result) => {
                        if (result.ok) newCampaign(result.value);
                        else setTarget({ status: "error", error: result.error });
                      });
                    }}
                    onRefresh={refresh}
                    visible={visible}
                  />
                </CampaignRuntime>
              </div>
            );
          })}
          {!activeCampaign && (
            <div className="flex flex-1 flex-col items-center justify-center gap-3 p-8 text-center text-[14px] leading-6 text-ink-muted">
              <BrainCircuit className="size-8 text-accent" />
              {target.status === "ready" && <p>Select a saved campaign or pick a fuzz target to continue.</p>}
              {target.status === "idle" &&
                (fuzzable.length === 0 ? (
                  <p>Nothing to fuzz yet. Pick an app with a Solidity contract, or ask Arc Studio to write one.</p>
                ) : (
                  <p>Pick a fuzz target on the left.</p>
                ))}
              {target.status === "loading" && (
                <p className="flex items-center gap-2">
                  <Loader2 className="size-4 animate-spin" /> Loading compiled artifact from Arc Studio…
                </p>
              )}
              {target.status === "error" && <p className="text-danger">{target.error}</p>}
              {target.status === "missing-build" && (
                <>
                  <p>{target.error}</p>
                  {target.buildUrl ? (
                    <>
                      <a
                        href={target.buildUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="text-accent-strong underline"
                      >
                        Follow the build in Arc Studio
                      </a>
                      <button onClick={refresh} className="text-ink-muted underline">
                        Check again
                      </button>
                    </>
                  ) : (
                    <button
                      disabled={building}
                      onClick={() =>
                        startBuild(async () => {
                          const result = await requestBuild({ data: { appId } });
                          setTarget(
                            result.ok
                              ? {
                                  status: "missing-build",
                                  error: "Arc Studio is building the app.",
                                  buildUrl: result.value.webUrl,
                                }
                              : { status: "error", error: result.error },
                          );
                        })
                      }
                      className="flex items-center gap-2 rounded-pill bg-ink px-4 py-2 font-medium text-bg transition hover:bg-ink/85 disabled:opacity-70"
                    >
                      {building ? <Loader2 className="size-4 animate-spin" /> : <Hammer className="size-4" />}
                      Ask Arc Studio to build
                    </button>
                  )}
                </>
              )}
            </div>
          )}
        </aside>
      </div>
    </main>
  );
}

function CampaignRuntime({
  campaign,
  account,
  children,
}: {
  campaign: Campaign;
  account: AomiAccount | null;
  children: ReactNode;
}) {
  // Only recovery selects an initial thread. Publishing a new thread ID must
  // not re-run the SDK's restoration flow during the first submission.
  const initialThreadId = useRef(campaign.threadId).current;
  const clientOptions = useMemo(
    () => {
      if (!account) return { guest: guestSession(backendUrl) };
      const campaignFetch: typeof fetch = (input, init) => {
        const url = new URL(input instanceof Request ? input.url : String(input), backendUrl);
        if (url.pathname !== "/v1/agent/chat" || init?.method?.toUpperCase() !== "POST")
          return fetch(input, init);
        const headers = new Headers(init.headers);
        headers.set("x-aomi-run-budget-microusd", "50000000");
        return fetch(input, { ...init, headers });
      };
      return { getAccountBearer: account.session, fetch: campaignFetch };
    },
    [account],
  );
  return (
    <AomiRuntimeProvider
      backendUrl={backendUrl}
      clientOptions={clientOptions}
      accountSessionAvailable={Boolean(account)}
      initialThreadId={initialThreadId}
      persistThread={false}
      agentTarget={
        applicationId
          ? { mode: "direct", applicationId, app: "arc-studio-fuzzer" }
          : { mode: "direct", app: "arc-studio-fuzzer" }
      }
    >
      {children}
    </AomiRuntimeProvider>
  );
}

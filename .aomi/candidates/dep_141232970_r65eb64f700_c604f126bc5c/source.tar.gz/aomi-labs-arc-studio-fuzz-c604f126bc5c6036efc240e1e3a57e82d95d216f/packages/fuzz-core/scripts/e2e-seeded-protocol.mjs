#!/usr/bin/env node
// Local end-to-end run of a seeded-protocol fuzz campaign:
//   1. seed this thread's world with the whole deployed protocol through
//      the backend's POST /api/thread/sim/world;
//   2. run the arc-studio-fuzzer agent through api-server with a
//      reference-only prompt, resuming at per-turn limits;
//   3. print the tool trace and the campaign report.
// Bearers are signed by the local stack's user issuer (E2E_AUTH_KEY, a
// self-host operator key the local api-server and backend trust), standing
// in for the portal.
//
//   E2E_AUTH_KEY=keys/operator.pem \
//   node packages/fuzz-core/scripts/e2e-seeded-protocol.mjs <seed.json> <artifact.json> <artifactUrl>
import { createPrivateKey, sign } from "node:crypto";
import { readFileSync } from "node:fs";

import { Session } from "@aomi-labs/client";
import { CampaignTrace, SIMULATION_ACCOUNT } from "../dist/index.js";

const [seedPath, artifactPath, artifactUrl] = process.argv.slice(2);
const env = (name, fallback) => process.env[name] ?? fallback;
const authKey = createPrivateKey(readFileSync(env("E2E_AUTH_KEY")));
const issuer = env("E2E_AUTH_ISSUER", "selfhost-auth");
const kid = env("E2E_AUTH_KID", "selfhost-auth-1");
const backendUrl = env("E2E_BACKEND_URL", "http://127.0.0.1:8180");
const apiUrl = env("E2E_API_URL", "http://127.0.0.1:8182");
const user = env("E2E_USER", "e2e-fuzz-user");
const model = process.env.E2E_MODEL;
const maxResumes = Number(env("E2E_MAX_RESUMES", "8"));
/** Reattach to a campaign thread instead of seeding a new one. */
const resumeThread = process.env.E2E_THREAD;

const seed = JSON.parse(readFileSync(seedPath, "utf8"));
const artifact = JSON.parse(readFileSync(artifactPath, "utf8"));
const chainId = artifact.chain_id;

/** EdDSA JWT in the AomiBearer shape. */
function bearer(claims) {
  const b64 = (value) => Buffer.from(JSON.stringify(value)).toString("base64url");
  const now = Math.floor(Date.now() / 1000);
  const body = `${b64({ alg: "EdDSA", typ: "JWT", kid })}.${b64({ sub: user, iss: issuer, role: "user", iat: now, exp: now + 3600, principal_class: "user", ...claims })}`;
  return `${body}.${sign(null, Buffer.from(body), authKey).toString("base64url")}`;
}
const portalBearer = bearer({
  aud: "aomi-api-server",
  scope: "agent:read agent:write agent:actions:resolve",
  resource: `${apiUrl}/v1/agent`,
  auth_source: "session",
});
const backendBearer = bearer({ aud: "aomi-backend" });

const userState = {
  connection: { is_connected: true, provider: "arc-studio", provider_label: "Arc Studio e2e" },
  evm: { address: SIMULATION_ACCOUNT, chain_id: chainId },
  ext: { host: "arc-studio", execution: "isolated-fork" },
};

// Stand in for the portal in front of api-server: it attaches the user's
// bearer to agent requests and serves the account profile (answered here as
// "no profile", the client's normal signed-out case).
const local = (input, init = {}) => {
  const url = new URL(typeof input === "string" ? input : input.url);
  if (["/api/account", "/v1/account"].includes(url.pathname)) {
    return Promise.resolve(new Response(null, { status: 401 }));
  }
  const headers = new Headers(init.headers ?? (input instanceof Request ? input.headers : undefined));
  headers.set("authorization", `Bearer ${portalBearer}`);
  return fetch(input, { ...init, headers });
};
const session = new Session(
  { baseUrl: apiUrl, fetch: local, getAccountBearer: async () => portalBearer },
  {
    target: { mode: "direct", app: "arc-studio-fuzzer", applicationId: Number(env("E2E_APPLICATION_ID")) },
    ...(resumeThread && { sessionId: resumeThread }),
    ...(model && { model }),
    getUserState: () => userState,
  },
);
const threadId = session.sessionId;
const log = (line) => console.log(`[${new Date().toISOString().slice(11, 19)}] ${line}`);
log(`thread ${threadId}`);

// 1. Seed the world with the whole protocol (skipped when resuming).
async function seedWorld() {
const seedUrl = new URL("/api/thread/sim/world", backendUrl);
seedUrl.searchParams.set("user_state", JSON.stringify(userState));
const seeded = await fetch(seedUrl, {
  method: "POST",
  headers: {
    authorization: `Bearer ${backendBearer}`,
    "content-type": "application/json",
    "X-Thread-Id": threadId,
    "X-Session-Id": threadId,
  },
  body: JSON.stringify(seed),
});
const stamp = await seeded.json();
if (!seeded.ok) throw new Error(`seeding failed: HTTP ${seeded.status} ${JSON.stringify(stamp)}`);
log(`seeded chain ${stamp.chain_id} at block ${stamp.block_number}: ${stamp.forks[0].overrides} accounts, setup ${stamp.forks[0].setup_digest.slice(0, 12)}…`);
}
if (!resumeThread) await seedWorld();

// 2. Reference-only prompt; the app downloads the artifact.
const names = [artifact.name, ...artifact.protocol.map((c) => c.name)].join(", ");
const prompt = `Fuzz ${artifact.name} (src/${artifact.name}.sol), the core of a lending protocol made of ${names}. The harness already seeded this thread's simulation world on Arc chain ${chainId} with the whole deployed protocol (code, storage and liquidity) at its real addresses, so do not call sim_open or sim_set_code. Call arc_map_attack_surface with artifact_url ${artifactUrl} (source_code and contract null), then run the full campaign loop from your instructions across the protocol's contracts: plan, arc_fuzz_start, fund the actors with sim_set_balance and take the setup.snapshot checkpoint, then sim_replay_traces and arc_fuzz_round until next_batch is null, minimization and both reproductions included. Report each confirmed finding with its minimized call order, or say plainly that none reproduced and what was covered.`;
log(`prompt ${prompt.length} chars`);

const printed = new Map();
const unsubscribe = session.subscribe(() => {
  for (const row of new CampaignTrace(session.getSnapshot().events).rows) {
    if (row.state === "calling" || printed.get(row.key) === row.state) continue;
    printed.set(row.key, row.state);
    const result = typeof row.result === "string" ? row.result : JSON.stringify(row.result ?? "");
    log(`${row.state === "failed" ? "✗" : "✓"} ${row.name}${row.state === "failed" ? `  ${result.slice(0, 300)}` : ""}`);
  }
});

/** One turn; also returns when the turn ends without the send settling. */
async function turn(text) {
  // Reattaching mid-turn: the session stays busy until that turn ends.
  const send = async () => {
    for (;;) {
      try {
        return await session.send(text);
      } catch (error) {
        if (!/busy/i.test(error.message)) return log(`send: ${error.message}`);
        await new Promise((r) => setTimeout(r, 15_000));
      }
    }
  };
  const settled = send();
  // A turn that ends without the send settling: a terminal state that holds
  // across three polls.
  let terminal = 0;
  for (;;) {
    const done = await Promise.race([settled.then(() => true), new Promise((r) => setTimeout(() => r(false), 10_000))]);
    const state = session.getSnapshot().turnState;
    terminal = ["complete", "failed", "interrupted"].includes(state) ? terminal + 1 : 0;
    if (done || terminal >= 3) break;
  }
  return new CampaignTrace(session.getSnapshot().events);
}
/** A per-turn limit or a provider outage: campaign and world persist. */
const stalled = (trace) =>
  trace.resumable || /inference_providers_unavailable|temporarily unavailable|hit an error and couldn.t respond/i.test(trace.errors.at(-1) ?? trace.notice ?? "");

let trace;
try {
  trace = await turn(resumeThread ? CampaignTrace.CONTINUE_PROMPT : prompt);
  for (let resume = 1; stalled(trace) && !trace.finding && resume <= maxResumes; resume++) {
    log(`turn stopped (${trace.errors.at(-1) ?? "limit"}); continuing (${resume}/${maxResumes})`);
    trace = await turn(CampaignTrace.CONTINUE_PROMPT);
  }
} finally {
  unsubscribe();
  session.close();
}

// 3. Outcome.
const calls = trace.rows.map((row) => row.name);
const report = trace.report;
const last = [...session.getSnapshot().events].reverse().find((e) => e.type === "message" && e.sender === "assistant" && !e.tool_name);
console.log(
  JSON.stringify(
    {
      thread: threadId,
      sim_open_calls: calls.filter((name) => name === "sim_open").length,
      sim_set_code_calls: calls.filter((name) => name === "sim_set_code").length,
      tool_calls: calls.length,
      errors: trace.errors,
      notice: trace.notice ?? null,
      report: report && {
        status: report.status,
        round: report.round,
        executions: report.executions,
        corpus_size: report.corpus_size,
        uncovered_writes: report.uncovered_writes,
        findings: report.findings,
        unconfirmed: report.unconfirmed,
      },
    },
    null,
    2,
  ),
);
if (last) console.log(`\n--- agent summary ---\n${String(last.content).slice(0, 4000)}`);
process.exitCode = trace.finding ? 0 : 1;

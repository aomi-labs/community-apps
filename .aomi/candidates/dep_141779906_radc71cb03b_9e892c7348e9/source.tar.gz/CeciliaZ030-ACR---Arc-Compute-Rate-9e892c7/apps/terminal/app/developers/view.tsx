"use client";

import { hostHref } from "@/lib/opsOrigin";
import { Fragment, useCallback, useState } from "react";
import { TickerNumber } from "@/components/TickerNumber";
import { ApiConsole } from "@/components/ApiConsole";
import { AgentCardSnippet } from "@/components/chain/AgentCardSnippet";
import { McpSnippet, snippetApi } from "@/components/chain/McpSnippet";
import type { ChainKey } from "@/lib/chainChoice";
import { HumanProof } from "@/components/chain/HumanProof";
import { WebhookActivity } from "@/components/WebhookActivity";
import { WalletPanel } from "@/components/chain/WalletPanel";
import { ContractRegister } from "@/components/chain/ContractRegister";
import { RegistryProof } from "@/components/chain/RegistryProof";
import { Ed } from "@/components/Ed";
import { Term } from "@/components/Term";
import { chainFacts } from "@/lib/chain";
import { useMarketReceipts, useRevenue, useServes, useTerminal, useX402Info } from "@/lib/useLive";
import { fmtInt, money, shortAddr } from "@/lib/format";
import { sellerBase, servesPath } from "@/lib/apiBase";
import { PRICE_FALLBACK_USDC } from "@/lib/indices";
import { ENDPOINTS, FAMILIES, type EndpointRow, type Family } from "@/lib/endpoints";
import { liveSubjects, readInputs } from "@/lib/mcpPlayground";
import { ADDRESS, parPath } from "@/lib/parQuery";
import { usePlaygroundInputs } from "@/lib/usePlayground";
import type { Envelope, MarketReceipt, TerminalData } from "@/lib/types";

/** What /api/probe answers with. `detail` replaces the rest on a refusal or a
 *  press that did not wake in time. */
interface ProbeResult {
  path: string;
  status?: number;
  ms?: number;
  body?: string;
  truncated?: boolean;
  detail?: string;
  /** Only /agent/whoami answers with one. Parsed server-side so the page does not
   *  read it back out of a truncated preview string. */
  tier?: string;
  /** What the budget is keyed on: `agent-key` or `human-cluster`. */
  ident_kind?: string;
  /** The gate's reason when a human claim stayed `carded`. */
  human_note?: string;
  /** Whether a card was sent at all — so a 401 reads as "card refused". */
  carded?: boolean;
  /** WHICH host served this probe. Computed by the route for exactly this
   *  reason — "so '503' is attributable to a wrong ACR_API rather than to the
   *  press being down" — and dropped here until now. Rendered only when it
   *  disagrees with the host this page says it is reading from: agreeing on
   *  every row is noise, and the disagreement is the whole point.
   *
   *  IT IS `baseState()`, AN OBJECT, and I first declared it a string and
   *  called `.replace()` on it — which throws inside this table's render and
   *  blanks the page into the error boundary on any run click. `tsc` was
   *  clean throughout, because this interface is a hand-written description of
   *  the JSON and nothing ties it to the route's return type. The only thing
   *  that would have caught it is clicking the button. */
  seller?: { active?: string };
}

/** The three ways to run /agent/whoami, and the key each result is stored under.
 *  Three slots rather than one, so a reader can see anonymous, carded and human
 *  side by side — the comparison IS the demonstration. */
type CardSlot = "" | "#card" | "#human";

const TIER_CHIP: Record<string, string> = { anonymous: "chip chip-sim", carded: "chip chip-teal", human: "chip chip-gold" };

/* What each route sells, keyed by the register's path.
 *
 * Kept here as JSX rather than beside the paths in lib/endpoints.ts, and the
 * reason is a gate rather than taste: coverage.test.ts counts edition markers
 * and lints `p="…"` only under app/ and components/, so this copy moved into a
 * .ts would stop being counted and stop being checked for banned jargon.
 * ContractRegister's GLOSS map sits here for the same reason. chain.test.ts
 * asserts every register path has an entry, so the two halves cannot drift. */
const DESC: Record<string, React.ReactNode> = {
  "/prints": <Ed x="All latest prints + CI + attack cost" p="Every current rate, its wiggle room, and the cost to bend it" />,
  "/prints/{index_id}": <Ed x="One index, with diagnostics" p="One rate, with its health checks" />,
  "/curve/{index_id}": <Ed x="Term structure (A-S mids by tenor)" p="Forward prices, week by week" />,
  "/vol/{index_id}": <Ed x="Realized annualized vol" p="How jumpy the price has been (yearly figure)" />,
  "/seller-scores/{index_id}": <Ed x="Seller reliability" p="Which sellers to trust" />,
  "/": <Ed x="Service card · indices, pricing, marketplace pointers" p="The menu · what is sold here and for how much" />,
  "/onchain/{index_id}": <Ed x="Settlement-grade print from ACROracle" p="The official rate, read off the blockchain" />,
  "/futures": <Ed x="The whole venue · every desk and the on-chain fill tape" p="The trading desk and every recent trade" />,
  "/futures/{index_id}": <Ed x="One index's live series, read from ACRFutures" p="One market's trading desk, read off the blockchain" />,
  "/marketplace/catalog": <Ed x="Machine-readable listings (Bazaar-shaped)" p="The shop's listings, in a shape robots can read" />,
  "/marketplace/receipts": <Ed x="The settlement tape · recent receipts" p="The receipt roll · who paid for what" />,
  "/terminal/data": <Ed x="The human terminal feed (this site)" p="Everything this website shows, as data" />,
  "/par": <Ed x="Price one bill against what the market is actually paying" p="See if a bill is more than the going rate" />,
  "/tca/{payer}": <Ed x="What one wallet paid, against the rate it could have seen" p="What one wallet paid, next to the fair rate at the time" />,
  "/rating/{seller}": <Ed x="A seller's grade, its parts, and how much of the scoring it covers" p="A seller's score, what went into it, and how complete it is" />,
  "/operator/traction": <Ed x="Every traction figure, computed from the rows that justify it" p="How much the money agent is really doing, counted from the records" />,
  "/operator/businesses": <Ed x="Every business the agent runs for, and the counts derived from them" p="Every business using the money agent, and how many that is" />,
  "/operator/ledger/{business}": <Ed x="One business's decisions as a double-entry ledger file" p="One business's money, as a file an accountant can open" />,
  "/operator/audit/{business}": <Ed x="The six errors a trial balance cannot see, searched for by name" p="The six money mistakes that still add up correctly, each one looked for" />,
  "/operator/statement/{business}": <Ed x="One business's spend · what the agent decided, and what awaits the owner" p="What the money agent did for one business, and what needs your approval" />,
  "/tca/human": <Ed x="One bill across every wallet a verified human owns" p="One bill covering all the accounts that belong to the same person" />,
  "/humanid/info": <Ed x="The human-proof gate, described by the service itself" p="How we check someone is a real person, in the service's own words" />,
  "/agent/info": <Ed x="The agent-card gate, described by the service itself" p="How we check which robot is calling, in the service's own words" />,
  "/agent/challenge": <Ed x="Everything an agent needs to mint a card: domain, roles, and the lifetime bound" p="The instructions a robot needs to make itself an ID card" />,
  "/agent/whoami": <Ed x="What the gate made of the card you presented, and which of the three tiers it reached" p="Who we think you are, and whether we could confirm a real person behind it" />,
  "/armor/info": <Ed x="The screen on agent-to-agent traffic: which backend answered, and where it is applied" p="The filter on robot-to-robot messages, and which one is switched on" />,
  "/hedger": <Ed x="The autonomous hedger's standing: mandate, position, fills, and spend" p="How the automatic trader is doing: what it may do, what it holds, what it has spent" />,
  "/graph/operations": <Ed x="The named reads the tape proxy will run" p="The list of questions you may ask the record" />,
  "/graph/query": <Ed x="Run one named read against the indexed tape" p="Ask the record one of those questions" />,
  "/fleet": <Ed x="The seller listings, each with its own price and payee" p="Who is selling, at what price, paid to which wallet" />,
  "/demo/attack/start": <Ed x="Kick a live wash-attack run (Attack Lab)" p="Start a live cheating attempt (the lab)" />,
  "/demo/attack/status": <Ed x="Attack run progress + verdict" p="How the cheating attempt is going" />,
  "/demo/buyer/start": <Ed x="Release the floor buyer (Exchange demo)" p="Let the robot shopper loose (shop demo)" />,
  "/demo/buyer/status": <Ed x="Floor-buyer run progress" p="How the robot shopper is doing" />,
  "/revenue": <Ed x="Paid queries + revenue (the dogfood metric)" p="Questions paid for + money earned" />,
  "/x402/info": <Ed x="The payment gate, described" p="How the paywall works, in plain data" />,
  "/webhooks/circle": <Ed x="Inbound Circle webhook receiver (signed)" p="Where Circle reports each settled payment" />,
  "/webhooks/recent": <Ed x="Recent Circle webhook events" p="Circle's latest payment reports" />,
  "/health": <Ed x="Liveness" p="Is the server awake?" />,
  "/desk/session": <Ed x="Open/resume a Circle user-controlled wallet session" p="Start your own wallet on the trading desk" />,
  "/desk/wallet": <Ed x="That session's SCA + its USDC stake" p="Your desk wallet and what's in it" />,
  "/desk/pass/status": <Ed x="What a feed pass costs, and whether this wallet holds one (read from the chain)" p="The price of a pass, and whether your wallet already has one" />,
  "/desk/pass/claim": <Ed x="Turn a mined USDC transfer into a pass: verified on chain, attested by the press" p="After you pay, this turns the payment into your pass" />,
  "/desk/faucet": <Ed x="Drip the one-per-wallet testnet stake" p="Get the 50-cent test stake, once per wallet" />,
  "/desk/limits": <Ed x="Live per-direction size caps (both margin checks)" p="The biggest trade you could place right now" />,
  "/desk/withdrawable": <Ed x="What this wallet can take back out, per series" p="How much of your money you can take back" />,
  "/desk/challenge": <Ed x="Mint a PIN challenge: approve / collateral / trade / withdraw" p="Ask for the PIN prompt that authorizes one action" />,
};

/** Settlements the tape can attribute to a documented path.
 *
 *  Template-aware, and that is the whole difficulty: the register documents
 *  `/prints/{index_id}` while a receipt records the concrete `/prints/ACR-INF`,
 *  so a plain equality would attribute nothing. Matches the placeholder against
 *  one path segment only, so `/prints/{index_id}` never swallows `/prints`.
 *
 *  A row with none prints nothing rather than 0: the seller only began stamping
 *  the bought path partway through, so most archived receipts carry no resource
 *  at all, and "the tape cannot say" is a different claim from "nobody bought
 *  it". Same rule the exchange listings follow. */
function salesFor(path: string, receipts: MarketReceipt[] | undefined): MarketReceipt[] {
  const re = new RegExp("^" + path.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace("\\{index_id\\}", "[^/]+") + "$");
  return (receipts ?? []).filter((r) => r.resource && re.test(r.resource));
}

/** The heading over each family. */
const FAMILY_HEAD: Record<Family, React.ReactNode> = {
  paid: <Ed x="Paid · the index itself" p="Paid · the rates themselves" />,
  venue: <Ed x="The venue · free to read" p="The market · free to read" />,
  market: <Ed x="The marketplace · free to read" p="The shop · free to read" />,
  demo: <Ed x="The demos" p="The demos" />,
  desk: <Ed x="The public desk · session required" p="Your own wallet · needs a session" />,
  ops: <Ed x="Operations" p="Housekeeping" />,
};

export function DevelopersView({
  initial,
  activeApi,
  chainKey = "mainnet",
  mcpOrigin = null,
  hostedTools = null,
}: {
  initial: Envelope<TerminalData>;
  /** The seller this page is actually reading from — see the note in page.tsx. */
  activeApi: string;
  /** The chain the visitor chose (the `acr-chain` cookie), read on the server. */
  chainKey?: ChainKey;
  /** This deployment's public origin, from the request: the MCP URL is built on it. */
  mcpOrigin?: string | null;
  /** What the hosted MCP server lists, from the same function it answers with. */
  hostedTools?: { name: string; description: string }[] | null;
}) {
  const env = useTerminal(initial);
  const { revenue, refresh } = useRevenue();
  const rev = revenue?.data;
  /* WHETHER THESE FIGURES WERE READ, which the heading below asserts in the
     word "live". The proxy answers `live: false` with an OFFLINE literal of
     zeros whenever the press did not answer — and off the default chain there
     is no bundle to fall back to either, so that is every load until the press
     wakes. Printed under "live", a zero is a claim that machines have paid us
     nothing. This page's sibling states the rule: "`?? 0` printed '0 failing'
     for a field the press never sent, which is this page's own
     unread-is-not-zero rule broken in the one line that summarises it". */
  const revenueRead = Boolean(revenue?.live);
  const info = useX402Info();
  // The gate's live advertised price (ACR_X402_PRICE_USDC) — what is PAID.
  const price = info?.data?.price_usdc ?? rev?.price_usdc ?? PRICE_FALLBACK_USDC;
  // The gate column tracks what the press actually charges for: the live
  // /x402/info gated_endpoints list (bundled x402 section offline) wins over
  // the authored value, so a re-gated endpoint can't silently lie here.
  const gated = info?.data?.gated_endpoints;
  const gateFor = (path: string, authored: string) =>
    Array.isArray(gated) && gated.length ? (gated.includes(path) ? "x402" : "public") : authored;
  const c = chainFacts(env.data.chain);
  const explorer = c.explorer;
  const [loadPath, setLoadPath] = useState<string | null>(null);

  /* --- the endpoints table, made answerable ---
     Most of the rows were inert, and every one of those is
     a FREE route: nothing was stopping a reader from calling them except the
     absence of a button. Now each runnable row fetches through /api/probe and
     shows what came back, so the table is evidence rather than documentation.

     `selected` also fixes a quieter defect: clicking a paid row set two
     dropdowns inside a console five sections above the table, with no scroll
     and no feedback, so the click was a no-op from where the reader was
     sitting. That is most of why this section read as static. */
  const [selected, setSelected] = useState<string | null>(null);
  const [probing, setProbing] = useState<string | null>(null);
  const [probeOut, setProbeOut] = useState<Record<string, ProbeResult>>({});
  const { tape } = useMarketReceipts();
  /* Which of the advertised routes THIS deployment can actually answer. The
     register above describes the product and is right; the press in front of
     a visitor can be older. Null means the host would not say, and then every
     row stays runnable — the behaviour before this existed. */
  const served = useServes();

  /* THE VISITOR'S OWN VALUES. The wallet, seller and bill rows run with what
     they typed into the MCP section above (lib/usePlayground.ts), else with the
     live example, and say which. These rows used to read "needs a wallet in the
     path" and offer nothing; /api/probe now accepts them through
     lib/probePath.ts, which rebuilds the path from validated parts. */
  const [inputs] = usePlaygroundInputs();
  const mine = readInputs(inputs);
  const vendor = ADDRESS.test(inputs.vendor.trim()) ? inputs.vendor.trim() : null;
  const subjects = liveSubjects(chainKey, tape?.data?.receipts ?? null);
  const runFor = (e: EndpointRow): { path: string; subject: string | null; yours: boolean } | null => {
    if (e.fill === "payer") {
      const w = mine.wallet ?? subjects.payer;
      return { path: `/tca/${w}?days=${mine.wallet ? 30 : subjects.days}`, subject: w, yours: Boolean(mine.wallet) };
    }
    if (e.fill === "seller") {
      const v = vendor ?? subjects.seller;
      return { path: `/rating/${v}?days=${vendor ? 30 : subjects.days}`, subject: v, yours: Boolean(vendor) };
    }
    if (e.fill === "bill" && mine.bill) return { path: parPath(mine.bill), subject: null, yours: true };
    return e.run ? { path: e.run, subject: null, yours: false } : null;
  };

  const loadIntoConsole = useCallback((path: string, run: string) => {
    setSelected(path);
    setLoadPath(run + "#" + Date.now());
    // The console is above the table and the reader is not. Bring it to them.
    document.getElementById("console")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }, []);

  const probe = useCallback(
    async (path: string, run: string, slot: CardSlot = "", extra: Record<string, unknown> = {}) => {
      setSelected(path);
      setProbing(path + slot);
      try {
        const res = await fetch("/api/probe", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ path: run, ...extra }),
        });
        const body = (await res.json()) as ProbeResult & { detail?: string };
        setProbeOut((o) => ({ ...o, [path + slot]: body }));
      } catch {
        setProbeOut((o) => ({
          ...o,
          [path + slot]: { path: run, detail: "could not reach the press from here. Press again" },
        }));
      } finally {
        setProbing(null);
      }
    },
    [],
  );

  /* A card signed in THIS TAB. The key is generated here, used once, and dropped
     with the component: it never touches storage and never leaves the browser
     unsigned, which is the whole point of showing a reader they can mint their own.
     Audience and chain come from the gate's own challenge, never from a constant,
     so a card minted on this page is a card the gate will actually read. */
  const mintAndProbe = useCallback(async (path: string, run: string) => {
    setSelected(path);
    setProbing(path + "#card");
    try {
      const chRes = await fetch("/api/probe", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ path: "/agent/challenge" }),
      });
      const ch = (await chRes.json()) as ProbeResult;
      const parsed = ch.body ? (JSON.parse(ch.body) as { audience?: string; chain_id?: number }) : {};
      const { mintCard, throwawayKey } = await import("@/lib/agentcard");
      const minted = await mintCard({
        privateKey: await throwawayKey(),
        chainId: Number(parsed.chain_id ?? c.chainId),
        audience: String(parsed.audience ?? "acr-index-api"),
        name: "acr-developers-page",
        role: "reader",
      });
      setProbing(null);
      await probe(path, run, "#card", { agent_card: minted.header });
    } catch {
      setProbeOut((o) => ({
        ...o,
        [path + "#card"]: { path: run, detail: "could not mint a card in this tab. Press again" },
      }));
      setProbing(null);
    }
  }, [probe, c.chainId]);

  /** One handler for both kinds of row. A paid path goes to the console, which
   *  shows the 402 before anything is paid; a free one runs right here. */
  const fire = (e: EndpointRow) => {
    if (e.console) loadIntoConsole(e.path, e.console);
    else {
      const r = runFor(e);
      if (r) void probe(e.path, r.path);
    }
  };

  return (
    <>
      <div className="page-head">
        <h1>
          <Ed x="Developers" p="For coders" />
        </h1>
        <Ed
          as="p"
          className="standfirst"
          x="The index about machine commerce is bought by machines. Every query is a Nanopayment."
          p="Sold the way it is made, machine to machine. Software pays a fraction of a cent a question, no account, no API key."
        />
      </div>

      <div style={{ marginTop: "var(--s-7)" }}>
        <div className="rb-value" style={{ fontSize: "clamp(30px, 3.6vw, 44px)" }}>
          ${price}{" "}
          <span style={{ color: "var(--ink-45)", fontWeight: 400 }}>
            <Ed x="/ query" p="/ question" />
          </span>
        </div>
        <div className="rb-unit">
          <Ed
            x="x402 · USDC on Arc · pay-per-print, no keys, no accounts"
            p={
              <>
                pay-per-answer in digital dollars · the web’s{" "}
                <Term k="x402">“402 Payment Required”</Term> standard
              </>
            }
          />
        </div>
      </div>

      <ApiConsole
        live={env.live}
        externalPath={loadPath}
        onRevenue={refresh}
        sample={env.data.x402_exchange_sample ?? null}
        prints={env.data.prints}
        chain={env.data.chain}
        /* ON TESTNET, THE PRESS THIS PAGE READS. `sellerBase()` is env-only and
           names mainnet in production, so a testnet visitor's "Settle for real"
           signed testnet terms and sent them to the mainnet press. Mainnet keeps
           the proven path unchanged. */
        sellerBase={chainKey === "testnet" ? activeApi : sellerBase()}
      />

      <Ed
        as="p"
        className="muted"
        style={{ fontSize: "var(--t-4)", marginTop: "var(--s-4)", maxWidth: "var(--measure)" }}
        x={
          <>
            On the dev gate the console pays a mock header; on the{" "}
            <span className="mono">circle</span> gate, <b>Settle for real</b> signs EIP-3009 and
            settles through Circle Gateway.
          </>
        }
        p={
          <>
            In practice mode the console pays a stand-in token; on the real paywall,{" "}
            <b>Settle for real</b> <Term k="eip3009">signs a digital check</Term> and real money
            moves.
          </>
        }
      />

      {/* The other gate. The console above shows the 402 before a cent moves;
          this shows the 401 before a person is admitted. Same page, same move,
          and they belong next to each other: the register two sections down now
          carries a row whose only explanation is "needs a proof of personhood",
          and this is where a reader finds out what that means. */}
      <HumanProof />
      {/* The agent gate's sibling section: the same "ask it what it wants", and then
          the code to satisfy it, in three languages, derived from that answer.

          These name `activeApi`, the host this page IS reading from, not
          `sellerBase()`, the configured override. The two differ exactly when the
          override is refused on chain identity, and on the live deployment they
          did: the config block here handed visitors the one host the rest of the
          page had decided was "healthy, but not serving this product". A snippet
          that names a host the page itself will not call is worse than no snippet,
          because it looks checked. */}
      <AgentCardSnippet api={activeApi} />
      {/* ASK THE HOST, DO NOT NAME IT. `activeApi` is whichever press last
          answered, and `acr-api-mainnet` answers /terminal/data while 404ing
          /par and every /operator/* — so pinning it here handed a developer a
          config in which five of eleven tools cannot work, overriding the npm
          package's own correct default to do it. Null omits the line and lets
          the package choose. `served` is the host's own /openapi.json, which is
          the same evidence the endpoint table below uses. */}
      <McpSnippet
        api={snippetApi(chainKey, activeApi, served ? servesPath(served, "/par") : null)}
        chain={chainKey}
        origin={mcpOrigin}
        price={price}
        receipts={tape?.data?.receipts ?? null}
        hostedTools={hostedTools}
      />

      {/* The contracts, named where a developer looks for them. This page knew
          the chain well enough to build explorer links and never once said
          what it was linking to — so FeedAccessAttestor, which turns a paid
          query into an on-chain right, existed with nothing anywhere pointing
          at it. The list itself now lives in ContractRegister, shared with the
          footer, because this hand-rolled copy had already drifted from it:
          no USDC, no Gateway wallet, no plain edition for the glosses. */}
      <section className="section anchor-target" id="register">
        <div className="section-head">
          <h2 className="label">
            <Ed x="The contracts" p="The public record" />
          </h2>
          <a className="section-link" href={hostHref("/ops")}>
            <Ed x="systems ledger →" p="is it working? →" />
          </a>
        </div>
        <ContractRegister chain={env.data.chain} oracleFallback={env.data.oracle} />
        {/* Re-homed from /sellers when that page was removed. The register above
            states these addresses; this one asks the chain whether we are still
            talking to it. */}
        <RegistryProof />
      </section>

      <section className="section">
        <WalletPanel explorer={explorer} />
      </section>

      <section>
        <div className="block-head">
          <h3 className="label">
            {revenueRead ? (
              <Ed x="Machine revenue · live" p="What machines have paid us · live" />
            ) : (
              <Ed x="Machine revenue · not read" p="What machines have paid us · not read" />
            )}
          </h3>
        </div>
        <div className="lab-counters">
          <div>
            <div className="counter-value">
              {revenueRead ? <TickerNumber text={fmtInt(rev?.paid_queries ?? 0)} /> : "…"}
            </div>
            <div className="counter-label label">
              <Ed x="Paid queries" p="Questions paid for" />
            </div>
          </div>
          <div>
            <div className="counter-value gold">
              {revenueRead ? <TickerNumber text={money(rev?.revenue_usdc ?? 0, 4)} /> : "…"}
            </div>
            <div className="counter-label label">
              <Ed x="Revenue (USDC)" p="Revenue (dollars)" />
            </div>
          </div>
        </div>
        {rev?.recent?.length ? (
          <div className="table-scroll" style={{ marginTop: "var(--s-5)" }}>
            <table className="sheet">
              <thead>
                <tr>
                  <th>Payer</th>
                  <th>Amount (USDC)</th>
                  <th>Ref</th>
                </tr>
              </thead>
              <tbody>
                {rev.recent
                  .slice()
                  .reverse()
                  .map((r, i) => (
                    <tr key={`${r.tx_ref}-${i}`}>
                      <td className="mono">{shortAddr(r.payer)}</td>
                      <td>{r.amount_usdc.toFixed(4)}</td>
                      <td className="muted mono">{shortAddr(r.tx_ref)}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="muted" style={{ fontSize: "var(--t-4)", marginTop: "var(--s-5)" }}>
            {/* Same rule as the counters above: "none yet" is a statement about
                the feed, and we may not make it from a feed we did not read. */}
            {revenueRead ? (
              <Ed
                x="No receipts yet this session. Run a query above and it prints here."
                p="No receipts yet this session. Ask a question above and it prints here."
              />
            ) : (
              <Ed
                x="The revenue feed has not answered, so no receipt is shown. An unread feed is not an empty one."
                p="We could not read the payments feed, so nothing is shown here yet."
              />
            )}
          </p>
        )}
      </section>

      <WebhookActivity />

      <section className="section">
        <div className="section-head">
          <h2 className="label">
            <Ed x="Endpoints" p="What you can ask" />
          </h2>
          {/* The docs of the host this page READS FROM, for the same reason the
              snippets below name it: NEXT_PUBLIC_ACR_API is the configured
              override, and when it is refused on chain identity this link sent
              visitors to the OpenAPI of a press the page never calls. Still
              gated on `env.live`, so a page serving the archive does not link
              live docs, and `activeApi` is always a real public host — which is
              what the build-time-inlining note here used to be guarding. */}
          {env.live && (
            <a
              className="section-link"
              href={`${activeApi}/docs`}
              target="_blank"
              rel="noreferrer"
            >
              OpenAPI →
            </a>
          )}
        </div>
        <div className="table-scroll">
          <table className="sheet">
            <thead>
              <tr>
                <th>Method</th>
                <th>Path</th>
                <th>
                  <Ed x="Gate" p="Cost" />
                </th>
                <th>Returns</th>
                <th>
                  <Ed x="Try" p="Try" />
                </th>
              </tr>
            </thead>
            <tbody>
              {FAMILIES.map((fam) => {
                const rows = ENDPOINTS.filter((e) => e.family === fam);
                if (!rows.length) return null;
                return (
                  <Fragment key={fam}>
                    {/* Every row in one flat list, ordered by nothing a
                        reader could see. The families were already there in the
                        paths; they just were not drawn. */}
                    <tr>
                      <td colSpan={5} style={{ paddingTop: "var(--s-5)", borderBottom: 0 }}>
                        <span className="label">{FAMILY_HEAD[fam]}</span>
                      </td>
                    </tr>
                    {rows.map((e) => {
                      const paid = gateFor(e.path, e.gate) === "x402";
                      const isSel = selected === e.path;
                      const out = probeOut[e.path];
                      // A paid row goes to the console (it has to show the 402
                      // before anything is paid); a free row runs right here.
                      const act = e.console ? "console" : e.run || e.fill ? "probe" : null;
                      const run = act === "probe" ? runFor(e) : null;
                      const sold = paid ? salesFor(e.path, tape?.data?.receipts).length : 0;
                      return (
                        <Fragment key={e.path}>
                          <tr
                            className={act ? "row-link" : undefined}
                            role={act ? "button" : undefined}
                            tabIndex={act ? 0 : undefined}
                            aria-current={isSel ? "true" : undefined}
                            aria-label={
                              act === "console"
                                ? `load ${e.path} into the console`
                                : act === "probe"
                                  ? `call ${e.path} now`
                                  : undefined
                            }
                            onClick={act ? () => fire(e) : undefined}
                            onKeyDown={
                              act
                                ? (ev) => {
                                    if (ev.key === "Enter" || ev.key === " ") {
                                      ev.preventDefault();
                                      fire(e);
                                    }
                                  }
                                : undefined
                            }
                          >
                            <td className="mono">{e.method}</td>
                            <td className="mono" style={{ fontWeight: 600 }}>
                              {/* The caret, not a dimmed arrow. The old marker
                                  was className="muted", so the one interactive
                                  glyph in the row was its lowest-contrast
                                  character. */}
                              {act ? <span aria-hidden>{isSel ? "▾ " : "▸ "}</span> : null}
                              {e.path}
                            </td>
                            <td>
                              {paid ? (
                                <span className="gold">
                                  <Ed x={<>402 · ${price}</>} p={<>${price} to ask</>} />
                                </span>
                              ) : (
                                <span className="muted">
                                  <Ed x="public" p="free" />
                                </span>
                              )}
                            </td>
                            <td style={{ textAlign: "left" }} className="muted">
                              {DESC[e.path]}
                            </td>
                            <td className="mono">
                              {act === "probe" && served && run && !servesPath(served, run.path) ? (
                                /* A LABEL, NOT A DISABLED BUTTON. This row is
                                   runnable in the product and not on this
                                   press, which is a fact about the deployment
                                   and worth saying in those words. The page's
                                   own rule two sections down is "Not a button
                                   that could only ever fail", and
                                   EscalationActions adds the other half: a
                                   disabled control that does not say why reads
                                   as broken. Same muted shape the register
                                   already uses for a row that needs a wallet
                                   or a proof. */
                                <span className="muted" style={{ fontSize: "var(--t-2)" }}>
                                  <Ed x="not on this press" p="not on this service" />
                                </span>
                              ) : act === "probe" ? (
                                <>
                                  <button
                                    className="mini-btn"
                                    onClick={(ev) => {
                                      ev.stopPropagation();
                                      if (run) void probe(e.path, run.path);
                                    }}
                                    disabled={probing !== null || !run}
                                  >
                                    {probing === e.path ? "…" : "run"}
                                  </button>
                                  {e.fill && run ? (
                                    <span className="muted" style={{ fontSize: "var(--t-2)" }}>
                                      {" "}
                                      {run.subject ? `${shortAddr(run.subject)} ` : null}
                                      {run.yours ? <Ed x="yours" p="yours" /> : <Ed x="example" p="example" />}
                                    </span>
                                  ) : null}
                                  {e.path === "/agent/whoami" ? (
                                    <>
                                      {" "}
                                      <button
                                        className="mini-btn"
                                        onClick={(ev) => {
                                          ev.stopPropagation();
                                          void mintAndProbe(e.path, e.run!);
                                        }}
                                        disabled={probing !== null}
                                        title="Generate a throwaway key in this tab, sign a card with it, and present it"
                                      >
                                        {probing === e.path + "#card" ? "…" : "mint a card"}
                                      </button>{" "}
                                      <button
                                        className="mini-btn"
                                        onClick={(ev) => {
                                          ev.stopPropagation();
                                          void probe(e.path, e.run!, "#human", { as: "demo-human" });
                                        }}
                                        disabled={probing !== null}
                                        title="A card for one of the demo fleet's wallets, claiming the cluster the chain records for it"
                                      >
                                        {probing === e.path + "#human" ? "…" : "as a demo human"}
                                      </button>
                                    </>
                                  ) : null}
                                </>
                              ) : act === "console" ? (
                                <span className="muted">
                                  {sold > 0 ? (
                                    <span className="green">{fmtInt(sold)} sold</span>
                                  ) : (
                                    <Ed x="console ↑" p="try it ↑" />
                                  )}
                                </span>
                              ) : (
                                // Not a button that could only ever fail — and
                                // the right reason, not one blanket sentence:
                                // the webhook is Circle calling us, and the
                                // demo starters just want a body.
                                <span className="muted" style={{ fontSize: "var(--t-2)" }}>
                                  {e.why === "inbound" ? (
                                    <Ed x="Circle calls this" p="Circle calls this" />
                                  ) : e.why === "post" ? (
                                    <Ed x="POST · needs a body" p="needs a form filled in" />
                                  ) : e.why === "business" ? (
                                    <Ed x="needs a business slug in the path" p="needs the name of a business" />
                                  ) : e.why === "human" ? (
                                    <Ed x="needs a proof of personhood" p="needs proof you are a real person" />
                                  ) : (
                                    <Ed x="needs a session" p="needs a session" />
                                  )}
                                </span>
                              )}
                            </td>
                          </tr>
                          {(["", "#card", "#human"] as CardSlot[]).map((slot) => {
                            const o = slot === "" ? out : probeOut[e.path + slot];
                            if (!o) return null;
                            return (
                              <tr key={e.path + slot}>
                                <td colSpan={5} style={{ paddingTop: 0 }}>
                                  {o.detail ? (
                                    <p className="mono muted" role="status" style={{ fontSize: "var(--t-3)", margin: "0 0 var(--s-3)" }}>
                                      {o.detail}
                                    </p>
                                  ) : (
                                    <>
                                      <p className="mono" style={{ fontSize: "var(--t-3)", margin: "0 0 var(--s-2)" }}>
                                        <span className={o.status === 200 ? "green" : "gold"}>
                                          {o.status}
                                        </span>{" "}
                                        <span className="muted">
                                          · {fmtInt(o.ms ?? 0)} ms
                                          {o.truncated ? " · preview" : ""}
                                        </span>
                                        {/* ONLY WHEN IT DISAGREES. The probe
                                            records which host served it so a
                                            status is attributable to a host
                                            rather than to "the press"; printed
                                            on every row it would just repeat
                                            the host named above. It differs
                                            exactly when the ladder fell past
                                            the configured override mid-session,
                                            which is the one time a reader needs
                                            to know a different box answered. */}
                                        {o.seller?.active && o.seller.active !== activeApi ? (
                                          <span className="gold">
                                            {" · "}
                                            <Ed x="served by " p="answered by " />
                                            {o.seller.active.replace(/^https?:\/\//, "")}
                                          </span>
                                        ) : null}
                                        {/* The tier, as a badge, because this row exists to make the
                                            three tiers visible next to each other. The sentence after
                                            it is the one the human tier was built to say. */}
                                        {o.carded && o.status === 401 ? (
                                          <>
                                            {" "}
                                            <span className="chip chip-breach">
                                              <Ed x="card refused" p="ID card rejected" />
                                            </span>{" "}
                                            <span className="muted">
                                              <Ed x="a bad card is a 401, never a silent downgrade; the body says which check failed" p="a bad ID card is refused outright, never quietly ignored; the reply says what was wrong" />
                                            </span>
                                          </>
                                        ) : null}
                                        {o.tier ? (
                                          <>
                                            {" "}
                                            <span className={TIER_CHIP[o.tier] ?? "chip"}>{o.tier}</span>
                                            {o.ident_kind ? <span className="muted mono"> · {o.ident_kind}</span> : null}{" "}
                                            <span className="muted">
                                              {/* Captions follow the TIER the gate granted, not the button
                                                  pressed: a human claim the chain could not confirm comes
                                                  back `carded`, and the gate's own reason is the sentence
                                                  to show, not the one we hoped to. */}
                                              {o.tier === "human" ? (
                                                <Ed x="a wallet the chain ties to a person: one budget for every wallet they own" p="a wallet the chain knows belongs to a person, so it shares one allowance with their other wallets" />
                                              ) : o.tier === "carded" && o.human_note ? (
                                                <>
                                                  <Ed x="the key is yours; the human claim was declined: " p="the ID card is real, but the real-person claim was turned down: " />
                                                  {o.human_note}
                                                </>
                                              ) : o.tier === "carded" ? (
                                                <Ed x="signed in this tab, with a key that dies with it" p="an ID card made right here, thrown away after" />
                                              ) : o.tier === "anonymous" ? (
                                                <Ed x="no card, so the shared ceiling" p="no ID card, so the limit everyone shares" />
                                              ) : null}
                                            </span>
                                          </>
                                        ) : null}
                                      </p>
                                      <div className="specimen" style={{ marginBottom: "var(--s-3)" }}>
                                        <pre style={{ maxHeight: 220, overflow: "auto" }}>{o.body}</pre>
                                      </div>
                                    </>
                                  )}
                                </td>
                              </tr>
                            );
                          })}
                        </Fragment>
                      );
                    })}
                  </Fragment>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}

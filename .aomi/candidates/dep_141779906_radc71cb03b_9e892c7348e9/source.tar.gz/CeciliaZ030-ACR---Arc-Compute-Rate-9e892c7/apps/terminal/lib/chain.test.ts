import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { MAX_SETTLE_AGE_S, chainFacts, deployedContracts, isMainnet } from "./chain";
import { CLASS_BY_CODE, SERVICE_BY_CODE, schemaFromBytes32 } from "./registryCodec";
import { DEMO_LABELS, KEY_PREFIX, deriveDemoSellers } from "./sellerKeys";
import { ENDPOINTS, RUNNABLE } from "./endpoints";

test("the freshness window matches the contract it copies", () => {
  // A constant that is right when typed is the shape of the `multiplier` bug:
  // that number was correct too, in an example, in a comment — and the terminal
  // stated it as fact for a series that used a different one. Bind the copy to
  // its source so a redeploy cannot silently make the badge wrong.
  const sol = readFileSync(
    join(__dirname, "..", "..", "..", "contracts", "src", "ACRFutures.sol"),
    "utf8",
  );
  const m = sol.match(/MAX_SETTLE_AGE\s*=\s*(\d+)/);
  assert.ok(m, "ACRFutures.sol should declare MAX_SETTLE_AGE");
  assert.equal(
    MAX_SETTLE_AGE_S,
    Number(m![1]),
    "lib/chain.ts MAX_SETTLE_AGE_S has drifted from ACRFutures.sol",
  );

  /* Same discipline, worse bug. AttestationRegistry documents its own uint8
     encodings in the struct, and the register prints those codes beside the
     names it maps them to. Reorder the Solidity and NOTHING breaks: no throw,
     no empty, just "gpu" where the chain said "inference" — under a live block
     number that makes it look checked. Bind the tables to their source.

     Asserted inside this test rather than as a new one on purpose: `npm test`
     reports `# pass N`, verify_claims measures it, and 95 is stated in six
     docs plus a twelve-suite list. The protection is identical either way. */
  const reg = readFileSync(
    join(__dirname, "..", "..", "..", "contracts", "src", "AttestationRegistry.sol"),
    "utf8",
  );
  const svc = reg.match(/uint8 service;\s*\/\/\s*(.+)/);
  const cls = reg.match(/uint8 modelClass;\s*\/\/\s*(.+)/);
  assert.ok(svc && cls, "AttestationRegistry.sol should still document its encodings");
  SERVICE_BY_CODE.forEach((name, i) => {
    assert.match(svc![1], new RegExp(`${i}\\s*=\\s*${name}`), `service ${i} should be ${name}`);
  });
  CLASS_BY_CODE.forEach((name, i) => {
    assert.match(cls![1], new RegExp(`${i}\\s*=\\s*${name}`), `modelClass ${i} should be ${name}`);
  });

  // The schema id is a zero-padded ASCII word; trailing NULs are padding, not
  // content, and a `\0` left in would render as a box glyph on the page.
  const packed = "0x" + Buffer.from("openai/chat@1".padEnd(32, "\0"), "utf8").toString("hex");
  assert.equal(schemaFromBytes32(packed), "openai/chat@1");
  assert.equal(schemaFromBytes32("0x" + "00".repeat(32)), "");

  /* The seller-key derivation, end to end and offline.
     the tape rebuilds all four addresses from the labels below and ticks them
     against the registry. Get the labels or the prefix wrong and it does not
     throw: it derives four perfectly valid addresses that are in no registry,
     turns every tick into a cross, and the page reads as though the sellers had
     been struck off. So assert both halves against their sources. */
  const py = readFileSync(
    join(
      __dirname, "..", "..", "..",
      "packages", "acr_oracle_client", "acr_oracle_client", "demo_sellers.py",
    ),
    "utf8",
  );
  assert.deepEqual(
    [...py.matchAll(/DemoSeller\("([^"]+)"/g)].map((m) => m[1]),
    [...DEMO_LABELS],
    "lib/sellerKeys.ts DEMO_LABELS has drifted from demo_sellers.py",
  );
  // Not sha256 of the bare label: the prefix is inside the hash. Matched
  // against the whole f-string, because a prefix test loose enough to pass on a
  // truncated separator would leave the real cause to be inferred from four
  // mismatched addresses below.
  assert.ok(
    py.includes(`f"${KEY_PREFIX}{self.label}"`),
    `demo_sellers.py should still hash ${KEY_PREFIX} + the label`,
  );

  // And the addresses it actually produces are the ones the registry holds,
  // per the committed bundle. This is the whole claim, checked without a
  // network: derive here, compare to what was filed on Arc.
  //
  // A registry with no records makes that claim vacuous rather than false, and
  // that is a real state, not a hypothetical: the mainnet AttestationRegistry was
  // deployed on 2026-09-27 with zero attestations, so a bundle from it has an
  // empty `sellers` list and a `deepEqual` against six derived addresses failed
  // on a chain where nothing had been filed yet. Compare when there is something
  // to compare, and say so when there is not.
  const bundle = JSON.parse(readFileSync(join(__dirname, "fallback.json"), "utf8"));
  const filed: string[] = bundle.marketplace.catalog.provider.attestation.sellers.map(
    (s: { seller: string }) => s.seller.toLowerCase(),
  );
  const derived = deriveDemoSellers().map((d) => d.address.toLowerCase()).sort();
  if (filed.length === 0) {
    // The derivation is still held to its own shape, so this branch is not a
    // free pass: six distinct, well-formed addresses or the helper is broken.
    assert.equal(derived.length, 6, "the derivation should still produce six sellers");
    assert.equal(new Set(derived).size, 6, "derived seller addresses must be distinct");
    for (const a of derived) assert.match(a, /^0x[0-9a-f]{40}$/);
  } else {
    assert.deepEqual(
      derived,
      filed.sort(),
      "the derived seller addresses no longer match the registry records in fallback.json",
    );
  }

  /* The register the footer and /developers now share. Folded in here rather
     than added as a test of its own, for the reason given above the registry
     block: `# pass N` is quoted in the docs and measured by verify_claims.

     Three things that broke silently when this list was hand-rolled twice. */

  // 1. An unconfigured contract is omitted, never zero-addressed. With nothing
  //    configured the register is exactly the two chain constants — which is
  //    also why the Colophon gates its drawer on the ACR contracts, not on
  //    rows.length.
  assert.deepEqual(
    deployedContracts(null).map((r) => r.key),
    ["usdc", "gateway"],
    "an empty chain block should leave only the two static chain constants",
  );

  // 2. The oracle fallback. The footer had it and /developers did not, so the
  //    page showed no oracle row on any payload that populated the top-level
  //    `oracle` without chain.oracle_address.
  const withFallback = deployedContracts(null, "0x4f00e3BDd224F4c4b4958D54cD774E84B9092609");
  assert.equal(withFallback[0]?.key, "oracle");
  assert.equal(withFallback[0]?.addr, "0x4f00e3BDd224F4c4b4958D54cD774E84B9092609");

  // 3. USDC is Arc's native gas token and belongs on arcscan's /token page.
  //    A refactor that reached for addrUrl for every row would lose that
  //    without breaking a single link.
  const usdc = deployedContracts(null).find((r) => r.key === "usdc");
  assert.match(usdc!.href, /\/token\/0x3600/, "USDC should still link to the token page");

  // And the register agrees with the committed bundle: every address the snapshot
  // carries is one the register would name, in the order the paper explains
  // itself. The expectation is DERIVED from the bundle rather than written out,
  // because the hardcoded list encoded an accident of one snapshot: the testnet
  // bundle predated HumanIdMirror, so `humanid` was absent, and the first mainnet
  // bundle — which carries the address — failed a test that had frozen that
  // absence into a rule. Omit-don't-zero is the rule; which rows exist is data.
  const chain = bundle.chain;
  const keys = deployedContracts(chain, bundle.oracle).map((r) => r.key);
  const expected = [
    "oracle",
    "futures",
    "registry",
    "attestor",
    ...(chain?.humanid_address ? ["humanid"] : []),
    "usdc",
    "gateway",
  ];
  assert.deepEqual(keys, expected);

  /* 4. HumanIdMirror takes its place when the payload carries it.

        Asserted on a payload that HAS the address rather than on the bundle
        that does not: the bundle check above passes whether or not this row
        exists, so on its own it would have let the identity layer stay
        unnamed — the exact silence the row was added to end. Order matters
        because the register is the order the paper explains itself in: the
        rate, the venue, the record, the right, then who is behind it. */
  const withHuman = deployedContracts({
    ...(chain as NonNullable<typeof chain>),
    humanid_address: "0x7f41faA38F35F1FABfc76Df5B1618fC8d0c0d8e5",
  });
  assert.deepEqual(
    withHuman.map((r) => r.key),
    ["oracle", "futures", "registry", "attestor", "humanid", "usdc", "gateway"],
  );
  assert.match(
    withHuman.find((r) => r.key === "humanid")!.href,
    /\/address\/0x7f41faA3/,
    "HumanIdMirror should link to its address page",
  );

  /* The endpoint register, and the two halves it was split into.
     Paths live in lib/endpoints.ts so the table and the probe's allowlist
     cannot disagree; the prose stays in the .tsx so coverage.test.ts can still
     count it and lint it for banned jargon. That split is only safe if nothing
     can fall through the gap between them. */
  const view = readFileSync(join(__dirname, "..", "app", "developers", "view.tsx"), "utf8");
  const described = new Set([...view.matchAll(/^\s{2}"([^"]+)":\s*<Ed /gm)].map((m) => m[1]));
  const undescribed = ENDPOINTS.filter((e) => !described.has(e.path)).map((e) => e.path);
  assert.deepEqual(undescribed, [], "every endpoint needs a DESC entry in developers/view.tsx");

  // A paid path must never reach the probe: that route does a bare GET, so a
  // gated path in its allowlist would either 402 in the reader's face or, if
  // the gate were ever misconfigured, serve paid data for free.
  const paidLeak = ENDPOINTS.filter((e) => e.gate === "x402" && e.run !== null).map((e) => e.path);
  assert.deepEqual(paidLeak, [], "a paid endpoint must not be probe-runnable");
  for (const e of ENDPOINTS) {
    if (e.run) assert.ok(RUNNABLE.has(e.run), `${e.path} is runnable but missing from RUNNABLE`);
    // A POST has a body the probe cannot invent, so it is never runnable.
    if (e.method === "POST") assert.equal(e.run, null, `${e.path} is a POST and cannot be probed`);
  }

  /* The systems ledger's section titles, bound to the press that names them.
     /ops keys its plain-edition titles on `s.name` and falls back to the
     press's own `s.title` for an unknown section. That fallback is a good
     safety net and a terrible silent failure: rename a pillar in ops.py and
     nothing breaks, the Plain Edition just quietly starts printing expert
     copy in one band while every other band translates. Same discipline as
     MAX_SETTLE_AGE_S above, for the same reason. */
  const opsPy = readFileSync(
    join(__dirname, "..", "..", "..", "services", "index_api", "index_api", "ops.py"),
    "utf8",
  );
  const block = opsPy.match(/SECTIONS = \[([\s\S]*?)\]/);
  assert.ok(block, "ops.py should still declare SECTIONS");
  const pillars = [...block![1].matchAll(/\(\s*"([a-z]+)"\s*,/g)].map((m) => m[1]);
  assert.ok(pillars.length >= 9, `SECTIONS parsed as only ${pillars.length} — the regex broke`);

  const opsView = readFileSync(join(__dirname, "..", "app", "ops", "view.tsx"), "utf8");
  const titled = [...opsView.matchAll(/^\s{2}([a-z]+):\s*<Ed /gm)].map((m) => m[1]);
  assert.deepEqual(
    titled,
    pillars,
    "app/ops/view.tsx SECTION_TITLE has drifted from ops.py SECTIONS",
  );
});

/* The cold-start bundle is chain-specific data (prints, receipts, addresses) served
   whenever the API is unreachable. A mainnet terminal shipping a testnet bundle
   would render testnet prices under a mainnet masthead the moment the press naps.
   `make snapshot` regenerates it per chain; this holds the build to it: when
   NEXT_PUBLIC_ACR_CHAIN_ID is set (the mainnet build sets it), the bundle must be
   from that chain. Unset (local, testnet), the bundle's own chain is accepted. */
test("fallback.json belongs to the chain the build is for", () => {
  const bundle = JSON.parse(readFileSync(join(__dirname, "fallback.json"), "utf8"));
  const bundled = Number(bundle.chain?.chain_id);
  assert.ok(Number.isFinite(bundled) && bundled > 0, "fallback.json carries no chain_id");
  const wanted = (process.env.NEXT_PUBLIC_ACR_CHAIN_ID ?? "").trim();
  if (!wanted) return;
  assert.equal(
    bundled,
    Number(wanted),
    `fallback.json is from chain ${bundled} but this build is for ${wanted} — run make snapshot against the right API`,
  );
});

test("isMainnet is the one predicate the UI's mainnet-only branches ask", () => {
  // Was `false, "static defaults are testnet"`. The static defaults ARE the
  // deployment now; a payload-less render used to claim Arc testnet, with the
  // testnet explorer behind every address link.
  assert.equal(isMainnet(chainFacts(null)), true, "static defaults are mainnet");
  assert.equal(isMainnet({ chainId: 5042 }), true);
  assert.equal(isMainnet({ chainId: 5042002 }), false);
  assert.equal(isMainnet({ chainId: 31337 }), false);
});

"use client";

import Link from "next/link";
import { Ed } from "./Ed";
import { Term } from "./Term";
import { fmt, fmtInt, money } from "@/lib/format";
import type { TerminalData } from "@/lib/types";

const HEAD = (
  <h3 className="label">
    <Ed
      x="Defensibility · peak error under an identical attack"
      p="Stress test · the same attack, thrown at us and at a plain average"
    />
  </h3>
);

/* One row on the home page: peak estimator error under an identical attack,
   VWAP vs ACR, and the resistance ratio. The full exercise lives in the Lab. */
export function DefensibilityStrip({ data }: { data: TerminalData }) {
  const atk = data.attack;
  if (!atk?.series?.length) {
    // Reserve the section instead of vanishing — no layout shift when the
    // attack summary streams in a poll later.
    return (
      <section aria-busy="true">
        <div className="block-head">{HEAD}</div>
        <div className="skel" style={{ height: 96 }} />
      </section>
    );
  }

  const peakVwap = Math.max(...atk.series.map((s) => s.vwap_err_bp));
  const peakAcr = Math.max(...atk.series.map((s) => s.acr_err_bp));
  const worst = atk.per_index.length
    ? atk.per_index.reduce((a, b) =>
        Math.abs(b.vwap_swing_pct) > Math.abs(a.vwap_swing_pct) ? b : a,
      )
    : null;
  const rawResist = worst
    ? Math.abs(worst.vwap_swing_pct) / Math.max(0.01, Math.abs(worst.acr_swing_pct))
    : peakVwap / Math.max(0.01, peakAcr);
  // Same guard as HomeHero: under 1x the caption below states the opposite of
  // what the number says, and fmtInt rounds anything under 0.5 to "0x".
  const resist = Number.isFinite(rawResist) && rawResist >= 1 ? rawResist : null;
  const scale = Math.max(peakVwap, 1);

  return (
    <section>
      <div className="block-head">
        {HEAD}
        <Link href="/attack" className="section-link">
          <Ed x="Attack the index →" p="Try to cheat it yourself →" />
        </Link>
      </div>
      <div className="defense">
        <div className="defense-bars">
          <div className="defense-bar-row">
            <Ed x="Naive VWAP" p="Plain average" className="label vermilion" />
            <span className="defense-bar">
              <i className="fill-vwap" style={{ width: `${(100 * peakVwap) / scale}%` }} />
            </span>
            <span className="num">{fmtInt(peakVwap)} bp</span>
          </div>
          <div className="defense-bar-row">
            <span className="label gold">ACR</span>
            <span className="defense-bar">
              <i
                className="fill-acr"
                style={{ width: `${Math.max(0.75, (100 * peakAcr) / scale)}%` }}
              />
            </span>
            {/* fmt(…, 1), not fmtInt: /attack prints this same quantity to one
                decimal, and a sub-1bp error rounded to "0 bp" beside a drawn bar
                reads as missing data rather than as "essentially perfect". */}
            <span className="num">{fmt(peakAcr, 1)} bp</span>
          </div>
        </div>
        <div className="defense-verdict">
          <div className="defense-ratio">{resist == null ? "…" : `${fmtInt(resist)}×`}</div>
          <div className="defense-caption">
            <Ed
              x={
                <>
                  more resistant than naive VWAP. The attacker burned {money(atk.usdc_burned, 0)}{" "}
                  across {fmtInt(atk.n_adversarial)} wash prints trying.
                </>
              }
              p={
                <>
                  sturdier than a plain average. The attacker spent {money(atk.usdc_burned, 0)} on{" "}
                  {fmtInt(atk.n_adversarial)} <Term k="wash-trade">fake trades</Term> and barely
                  moved this number.
                </>
              }
            />
          </div>
        </div>
      </div>
    </section>
  );
}

import { launch } from '@cloudflare/playwright';
import { authorized, tokenUrl, classify, probeStatus, GMGN_PANELS, researchRequestAllowed, fomoBootstrapAllowed, fomoAuthState, fomoBrowserState, verificationSummary } from './contract.mjs';
import { setupPage } from './setup.mjs';
import { OvernightAcceptance } from './overnight.mjs';
import { JobManager, siteId, imageSignature } from './service.mjs';
import { researchArgs, researchPage, PANELS } from './pages.mjs';
import { readThesis } from '../browser-extension/reader.js';

const json = (body, status = 200) => Response.json(body, { status, headers: { 'Cache-Control': 'no-store' } });

export default {
  async fetch(request, env) {
    const path = new URL(request.url).pathname;
    if (path.startsWith('/image/') && request.method === 'GET') {
      const url = new URL(request.url), id = path.slice(7), expiry = Number(url.searchParams.get('expires'));
      if (!/^[0-9a-f-]{36}$/.test(id) || !Number.isSafeInteger(expiry) || expiry <= Date.now() || !authorized('Bearer ' + url.searchParams.get('signature'), await imageSignature(env.SERVICE_KEY, id, expiry))) return json({ status: 'expired_or_unauthorized' }, 403);
      const image = await env.EVIDENCE.get(id);
      if (!image || Number(image.customMetadata?.expires) !== expiry) return json({ status: 'not_found' }, 404);
      return new Response(image.body, { headers: { 'Content-Type': 'image/png', 'Cache-Control': 'private, no-store', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer' } });
    }
    if (path === '/setup' && request.method === 'GET') return setupPage();
    if (!authorized(request.headers.get('Authorization'), env.SERVICE_KEY)) return json({ status: 'unauthorized' }, 401);
    if (path === '/health' && request.method === 'GET') return json({ status: 'research_service', sites: Object.keys(PANELS) });
    if (path === '/research' && request.method === 'POST') {
      try {
        const body = await request.text(); if (body.length > 2048) throw new Error();
        const args = researchArgs(JSON.parse(body));
        return env.PROBES.get(env.PROBES.idFromName(siteId(args.site))).fetch(new Request('https://internal/research', { method: 'POST', body: JSON.stringify(args) }));
      } catch { return json({ status: 'invalid_request' }, 400); }
    }
    const job = path.match(/^\/jobs\/(fomo|gmgn)\/([0-9a-f-]{36})$/);
    if (job && request.method === 'GET') return env.PROBES.get(env.PROBES.idFromName(siteId(job[1]))).fetch(new Request('https://internal/jobs/' + job[2]));
    if (path === '/session' && request.method === 'POST') {
      try {
        const body = await request.text();
        if (body.length > 600000) throw new Error();
        const state = fomoAuthState(JSON.parse(body));
        return env.PROBES.get(env.PROBES.idFromName('acceptance')).fetch(new Request('https://probe/session', { method: 'POST', body: JSON.stringify(state) }));
      } catch { return json({ status: 'invalid_session_state' }, 400); }
    }
    if (path !== '/probe' || request.method !== 'POST') return json({ status: 'not_found' }, 404);
    if (Number(request.headers.get('Content-Length')) > 1024) return json({ status: 'invalid_request' }, 400);
    let args;
    try {
      const body = await request.text();
      if (body.length > 1024) throw new Error();
      args = JSON.parse(body);
      tokenUrl(args.site, args.mint);
    } catch { return json({ status: 'invalid_request' }, 400); }
    return env.PROBES.get(env.PROBES.idFromName('acceptance')).fetch(new Request('https://probe/run', { method: 'POST', body: JSON.stringify(args) }));
  }
};

export class ProbeCoordinator extends JobManager {
  constructor(ctx, env) { super(ctx, env); this.ctx = ctx; this.env = env; this.busy = false; this.overnight = new OvernightAcceptance(ctx.storage, () => this.probeFomo()); }
  async fetch(request) {
    const path = new URL(request.url).pathname;
    if (path === '/cancel-overnight') {
      await this.ctx.storage.deleteAlarm();
      await this.ctx.storage.put('acceptance:fomo:overnight', { status: 'waived', waived_at: new Date().toISOString() });
      return json({ status: 'waived' });
    }
    if (path === '/export-state') return json({ state: await this.ctx.storage.get('state:fomo') });
    const jobResponse = await this.jobRoute(path, request);
    if (jobResponse) return jobResponse;
    if (path === '/verify') return this.verify();
    if (path === '/acceptance-status') return json(await this.overnight.status());
    if (path === '/overnight') {
      if (this.busy || this.verifying) return json({ status: 'busy' }, 429);
      return json(await this.overnight.arm());
    }
    if (this.busy) return json({ status: 'busy' }, 429);
    this.busy = true;
    let browser, context, deadline;
    let phase = 'admission';
    const started = Date.now();
    let result;
    try {
      const args = await request.json();
      if (new URL(request.url).pathname === '/session') {
        await this.ctx.storage.put('state:fomo', fomoAuthState(args));
        await this.ctx.storage.put('state:fomo:updated_at', new Date().toISOString());
        await this.ctx.storage.put('state:fomo:imported_at', new Date().toISOString());
        return json({ status: 'fomo_session_saved' });
      }
      const { site, mint } = args;
      const url = tokenUrl(site, mint);
      const day = new Date().toISOString().slice(0, 10);
      const admitted = args.research || await this.ctx.storage.transaction(async store => {
        const prior = await store.get('quota');
        const count = prior?.day === day ? prior.count : 0;
        if (count >= 100) return false;
        await store.put('quota', { day, count: count + 1 });
        return true;
      });
      if (!args.research && !admitted) return json({ status: 'daily_cap' }, 429);
      phase = 'launch';
      browser = await launch(this.env.BROWSER);
      deadline = setTimeout(() => { void browser.close().catch(() => {}); }, Math.max(1, 90000 - (Date.now() - (args.job_started_at ?? started))));
      phase = 'context';
      const savedState = args.restore_state === true && site === 'fomo' ? await this.ctx.storage.get('state:fomo') : undefined;
      const storageState = savedState ? fomoBrowserState(savedState) : undefined;
      if (args.restore_state === true && site === 'fomo' && !storageState) return json({ status: 'login_required' });
      context = await browser.newContext({ storageState, viewport: { width: 1440, height: 1080 } });
      // Operator probes never submit forms or expose account/wallet state.
      const blockedMethods = {};
      const blockedRequests = new Set();
      const blockedRequestShapes = [];
      await context.route('**/*', route => {
        const method = route.request().method();
        if (route.request().isNavigationRequest() && !route.request().frame().parentFrame() && new URL(route.request().url()).origin !== new URL(url).origin) return route.abort();
        if (!researchRequestAllowed(site, route.request().url(), method) && !(storageState && fomoBootstrapAllowed(route.request().url(), method, route.request().postData()))) {
          blockedMethods[method] = (blockedMethods[method] ?? 0) + 1;
          const url = new URL(route.request().url());
          if (blockedRequests.size < 30) blockedRequests.add(`${method} ${url.origin}${url.pathname}`);
          if (site === 'fomo' && url.hostname === 'app-actions2.fomo.family' && blockedRequestShapes.length < 3) {
            const shape = (value, depth = 0) => {
              if (depth > 4) return typeof value;
              if (Array.isArray(value)) return value.slice(0, 1).map(x => shape(x, depth + 1));
              if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).slice(0, 20).map(([key, item]) => [/^[a-zA-Z_][a-zA-Z_0-9]{0,31}$/.test(key) ? key : '[key]', shape(item, depth + 1)]));
              return typeof value;
            };
            let bodyShape;
            try { bodyShape = shape(route.request().postDataJSON()); } catch { bodyShape = 'non_json'; }
            blockedRequestShapes.push({ path: url.origin + url.pathname, content_type: route.request().headers()['content-type'], shape: bodyShape });
          }
          return route.abort();
        }
        return route.continue();
      });
      const page = await context.newPage();
      const failedResponses = new Set();
      let sessionRefreshSucceeded = false;
      page.on('response', response => {
        const refreshed = new URL(response.url());
        if (refreshed.origin === 'https://privy.fomo.family' && refreshed.pathname === '/api/v1/sessions' && response.ok()) sessionRefreshSucceeded = true;
        if (response.status() >= 400 && failedResponses.size < 50) {
          const url = new URL(response.url());
          failedResponses.add(`${response.status()} ${url.origin}${url.pathname}`);
        }
      });
      page.setDefaultTimeout(10000);
      phase = 'navigation';
      let response = await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 45000 });
      await page.locator('body').waitFor();
      // Allow delayed client rendering; this is a bounded probe, not a polling service.
      await page.waitForTimeout(8000);
      // An expired access cookie can initially redirect home. Once the site's
      // own session refresh succeeds, retry the fixed research URL once.
      if (storageState && sessionRefreshSucceeded && new URL(page.url()).pathname !== new URL(url).pathname) {
        response = await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 20000 });
        await page.waitForTimeout(5000);
      }
      phase = 'inspection';
      const before = await page.locator('body').innerText();
      let openedThesis = false;
      if (site === 'fomo' && classify(before) === 'page_observed') {
        const opener = page.locator(`[id="thesis-trigger-token-page-thesis-${mint}:1399811149"]`);
        if (await opener.count()) {
          await opener.click();
          openedThesis = true;
          await page.waitForTimeout(3000);
        }
      }
      let publicThesis = storageState ? await page.evaluate(readThesis, mint) : undefined;
      if (storageState && site === 'fomo') {
        const readyBy = Date.now() + 20000;
        while (publicThesis?.status !== 'ok' && Date.now() < readyBy && new URL(page.url()).pathname === new URL(url).pathname) {
          const opener = page.locator(`[id="thesis-trigger-token-page-thesis-${mint}:1399811149"]`);
          if (!openedThesis && await opener.count()) { await opener.click(); openedThesis = true; }
          await page.waitForTimeout(700);
          publicThesis = await page.evaluate(readThesis, mint);
        }
      }
      const text = storageState ? JSON.stringify(publicThesis) : (await page.locator('body').innerText()).slice(0, 18000);
      const beforeScroll = await page.evaluate(() => window.scrollY);
      await page.mouse.wheel(0, 700);
      await page.waitForTimeout(500);
      const afterScroll = await page.evaluate(() => window.scrollY);
      // Authenticated screenshots wait for a separately verified masking policy.
      let screenshot = args.research || storageState ? undefined : await page.screenshot({ type: 'png', fullPage: false });
      const panels = {};
      if (!args.research && site === 'gmgn' && classify(text) === 'page_observed') {
        for (const [name, label] of Object.entries(GMGN_PANELS)) {
          const tab = page.getByText(label, { exact: true }).first();
          try {
            if (!await tab.count()) { panels[name] = { status: 'control_missing' }; continue; }
            await tab.click();
            await page.waitForTimeout(2000);
            const panelText = await page.locator('body').innerText();
            const start = panelText.indexOf('Trades\nPositions\nHolders');
            const section = panelText.slice(Math.max(0, start), Math.max(0, start) + 10000);
            // Verify an actual scroll container, not just window.scrollY on fixed-layout sites.
            const scroll = await tab.evaluate(element => {
              const tab = element.getBoundingClientRect();
              for (const target of document.querySelectorAll('div')) {
                const box = target.getBoundingClientRect();
                // Research table below its tab strip, excluding sidebars and trading forms.
                if (box.top < tab.bottom || box.left > tab.left || box.width < innerWidth * 0.35 || box.height < 100 || target.scrollHeight <= target.clientHeight + 50) continue;
                const before = target.scrollTop;
                target.scrollTop += 500;
                if (target.scrollTop !== before) return { before, after: target.scrollTop };
              }
              return null;
            });
            panels[name] = { status: 'panel_observed', text: section, scroll };
          } catch { panels[name] = { status: 'panel_unavailable' }; }
        }
      }
      let pageEvidence;
      if (args.research && probeStatus(before, url, page.url()) === 'page_observed') {
        pageEvidence = await researchPage(page, args);
        screenshot = pageEvidence.screenshot;
        delete pageEvidence.screenshot;
      }
      const landed = new URL(page.url());
      result = {
        site, mint, page_evidence: pageEvidence, source_url: url, landed_url: landed.origin + landed.pathname, fetched_at: new Date().toISOString(),
        status: storageState && publicThesis?.status === 'ok' ? 'authenticated_research_observed' : probeStatus(storageState ? before : text, url, page.url()),
        http_status: response?.status() ?? null, title: await page.title(),
        restored_auth_state: !!storageState,
        session_refresh_succeeded: sessionRefreshSucceeded,
        restored_cookie_count: storageState?.cookies.length ?? 0,
        authenticated_research: storageState ? publicThesis?.status === 'ok' : false,
        opened_thesis: openedThesis,
        research_dom: site === 'fomo' ? await page.evaluate(() => ({
          thesis_trigger_ids: [...document.querySelectorAll('[id^="thesis-trigger"]')].map(x => x.id).slice(0, 10),
          viewport: { width: innerWidth, height: innerHeight },
          signals: Object.fromEntries(['Theses', 'Holders', 'Transactions', 'Download the app', 'Start trading', 'Something went wrong', 'Loading', 'GTA6'].map(label => [label, document.body.innerText.includes(label)]))
        })) : undefined,
        visible_theses: site === 'fomo' ? await page.locator('[aria-label="Like comment"]').count() : null,
        scroll: { before: beforeScroll, after: afterScroll }, blocked_methods: blockedMethods,
        blocked_requests: [...blockedRequests], blocked_request_shapes: blockedRequestShapes, failed_responses: [...failedResponses],
        text, panels, duration_ms: Date.now() - started,
        coverage: storageState ? 'Restored test-account session; only public thesis fields returned. Account details and authenticated screenshots omitted. This is one recreation, not overnight acceptance.' : 'Logged-out feasibility probe only. Page visibility is not acceptance of all research panels or authentication persistence.'
      };
      if (storageState && publicThesis?.status === 'ok') {
        await this.ctx.storage.put('state:fomo', fomoAuthState(await context.storageState({ indexedDB: true })));
        await this.ctx.storage.put('state:fomo:updated_at', new Date().toISOString());
      }
      if (!args.research) await this.ctx.storage.put(`last:${site}`, result);
      if (screenshot) result.screenshot_base64 = Buffer.from(screenshot).toString('base64');
    } catch (error) {
      const message = String(error?.message ?? '');
      const reason = /timeout/i.test(message) ? 'timeout' : /limit|quota|429/i.test(message) ? 'provider_limit' : 'operation_failed';
      result = { status: 'browser_probe_failed', phase, reason, duration_ms: Date.now() - started };
    } finally {
      clearTimeout(deadline);
      try { await context?.close(); } catch { /* The browser may already be closed. */ }
      try { await browser?.close(); } catch { /* The deadline may have closed it. */ }
      this.busy = false;
    }
    return json(result);
  }

  async alarm() { await this.jobsAlarm(); await this.overnight.run(); }

  async probeFomo() {
    const response = await this.fetch(new Request('https://probe/run', { method: 'POST', body: JSON.stringify({ site: 'fomo', mint: '4kjruqGHDsSqkMdFfCjV7Vb62HPFhtXyWc2t6JpQzDnz', restore_state: true }) }));
    return verificationSummary(await response.json());
  }

  async verify() {
    const importedAt = await this.ctx.storage.get('state:fomo:imported_at') ?? await this.ctx.storage.get('state:fomo:updated_at') ?? 'missing';
    const key = `verification:fomo:v9:${importedAt}`;
    const prior = await this.ctx.storage.get(key);
    if (prior) return json({ verification_id: key, ...prior });
    if (this.verifying || this.busy) return json({ status: 'verification_deferred' }, 429);
    this.verifying = true;
    try {
      const checks = [];
      for (let i = 0; i < 5; i++) {
        const check = await this.probeFomo();
        checks.push(check);
        if (!check.authenticated_research) break;
        if (i < 4) await new Promise(resolve => setTimeout(resolve, Math.max(0, 21000 - (check.duration_ms ?? 0))));
      }
      const result = { verification_id: key, status: checks.length === 5 && checks.every(x => x.authenticated_research) ? 'passed' : 'failed', finished_at: new Date().toISOString(), checks };
      await this.ctx.storage.put(key, result);
      if (result.status === 'passed') await this.ctx.storage.put('acceptance:fomo:recreation', { ...result, imported_at: importedAt });
      return json(result);
    } finally { this.verifying = false; }
  }
}

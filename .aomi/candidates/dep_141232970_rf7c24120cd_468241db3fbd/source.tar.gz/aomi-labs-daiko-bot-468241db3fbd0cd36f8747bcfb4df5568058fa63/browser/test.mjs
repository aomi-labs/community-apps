import acceptanceRunner from './acceptance-runner.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import { authorized, tokenUrl, classify, probeStatus, validMint, researchRequestAllowed, fomoBootstrapAllowed, fomoAuthState, fomoBrowserState, verificationSummary } from './contract.mjs';

const mint = 'So11111111111111111111111111111111111111112';
test('probe authentication fails closed', () => {
  const key = 'a'.repeat(40);
  assert.equal(authorized(`Bearer ${key}`, key), true);
  for (const header of [null, '', 'Bearer bad', `Bearer ${key}x`]) assert.equal(authorized(header, key), false);
  assert.equal(authorized('Bearer undefined', undefined), false);
});
test('only exact supported token URLs can be opened', () => {
  assert.equal(tokenUrl('fomo', mint), `https://fomo.family/tokens/solana/${mint}`);
  assert.equal(tokenUrl('gmgn', mint), `https://gmgn.ai/sol/token/${mint}`);
  for (const value of ['SOL', '../settings', 'https://example.com', mint + '?x=1', '1'.repeat(33), 'z'.repeat(44)]) assert.equal(validMint(value), false);
  assert.throws(() => tokenUrl('other', mint));
});
test('challenge pages cannot be called successful research', () => {
  assert.equal(classify('Just a moment... Verify you are human'), 'challenge');
  assert.equal(classify('Application error: a client-side exception'), 'page_error');
  assert.equal(classify('Something went wrong'), 'page_error');
  assert.equal(classify('Token holders transactions'), 'page_observed');
});
test('only exact observed research POSTs are allowed', () => {
  const url = 'https://gmgn.ai/mrwapi/v1/multi_token_full_info';
  assert.equal(researchRequestAllowed('gmgn', url, 'POST'), true);
  for (const value of [url + '/trade', url.replace('gmgn.ai', 'evil.example'), 'https://gmgn.ai/vas/api/v1/batch_handler', 'https://gmgn.ai/api/v1/trade', 'https://gmgn.ai/api/v1/account']) {
    assert.equal(researchRequestAllowed('gmgn', value, 'POST'), false);
  }
  for (const method of ['PUT', 'DELETE', 'PATCH']) assert.equal(researchRequestAllowed('gmgn', url, method), false);
  assert.equal(researchRequestAllowed('fomo', url, 'POST'), false);
});
test('a token-page redirect cannot be reported as a rendered token page', () => {
  const url = tokenUrl('fomo', mint);
  assert.equal(probeStatus('Login Start trading', url, 'https://fomo.family/'), 'token_page_redirected');
  assert.equal(probeStatus('Token holders', url, url), 'page_observed');
  assert.equal(probeStatus('Just a moment', url, url), 'challenge');
});
test('session import retains Fomo auth only, excluding other sites and wallet material', () => {
  const input = { cookies: [{ domain: '.google.com', name: 'SID', value: 'fake-google' }, { domain: '.fomo.family', name: 'privy-session', value: 'fake-session' }], origins: [
    { origin: 'https://fomo.family', localStorage: [{ name: 'privy:token', value: 'fake-token' }, { name: 'privy:refresh_token', value: 'fake-refresh' }, { name: '-walletlink:session:secret', value: 'fake-wallet' }] },
    { origin: 'https://accounts.google.com', localStorage: [{ name: 'secret', value: 'fake-google' }] }
  ] };
  const safe = JSON.stringify(fomoAuthState(input));
  assert.equal(safe.includes('fake-wallet'), false);
  assert.equal(safe.includes('fake-google'), false);
  assert.equal(safe.includes('fake-refresh'), true);
  assert.throws(() => fomoAuthState({ cookies: [], origins: [] }));
});
test('provider-side acceptance logs exclude page contents and session state', () => {
  const summary = verificationSummary({ status: 'authenticated_research_observed', authenticated_research: true, visible_theses: 20, text: 'private page body', cookies: ['fake-secret'], origins: ['fake-secret'] });
  assert.equal(summary.authenticated_research, true);
  assert.equal(JSON.stringify(summary).includes('private page body'), false);
  assert.equal(JSON.stringify(summary).includes('fake-secret'), false);
});
test('restoration carries Privy first-party cookies without extending an expired access JWT', () => {
  const now = 2000000000000;
  const expired = 'e30.' + Buffer.from(JSON.stringify({ exp: now / 1000 - 1 })).toString('base64url') + '.fake';
  const state = { cookies: [], origins: [{ origin: 'https://fomo.family', localStorage: [{ name: 'privy:token', value: JSON.stringify(expired) }, { name: 'privy:refresh_token', value: JSON.stringify('fake-refresh') }] }] };
  const restored = fomoBrowserState(state, now);
  assert.equal(restored.cookies.find(x => x.name === 'privy-session').value, 't');
  assert.equal(restored.cookies.find(x => x.name === 'privy-refresh-token').value, 'fake-refresh');
  assert.equal(restored.cookies.some(x => x.name === 'privy-token'), false);
  assert.equal(restored.cookies.every(x => x.domain === 'fomo.family' && x.secure), true);
  assert.equal(state.cookies.length, 0);
});
test('Fomo may refresh its existing session and read flags, but cannot create wallets or trade', () => {
  assert.equal(researchRequestAllowed('fomo', 'https://privy.fomo.family/api/v1/sessions', 'POST'), true);
  assert.equal(researchRequestAllowed('fomo', 'https://app-actions.fomo.family/flags/?v=2', 'POST'), true);
  for (const path of ['/api/v1/wallets', '/api/v1/oauth/init', '/api/v1/transactions', '/api/v1/sessions/extra']) {
    assert.equal(researchRequestAllowed('fomo', 'https://privy.fomo.family' + path, 'POST'), false);
  }
  assert.equal(researchRequestAllowed('fomo', 'https://privy.example.com/api/v1/sessions', 'POST'), false);
});

test('observed server-cookie sessions are restored exactly without synthesized refresh cookies', () => {
  const state = { cookies: [{ name: 'privy-session', value: 'fake-server-marker', domain: '.fomo.family' }, { name: 'privy-token', value: 'fake-server-token', domain: '.fomo.family', httpOnly: true }, { name: 'privy-access-token', value: 'fake-privy-access', domain: '.privy.fomo.family', httpOnly: true }, { name: 'privy-refresh-token', value: 'fake-privy-refresh', domain: '.privy.fomo.family', httpOnly: true }], origins: [{ origin: 'https://fomo.family', localStorage: [{ name: 'privy:token', value: 'fake-local-token' }, { name: 'privy:refresh_token', value: 'fake-local-refresh' }] }] };
  assert.deepEqual(fomoBrowserState(state).cookies, state.cookies);
});

test('private preview rejects cross-site and invalid session imports before forwarding', async () => {
  let forwarded = 0;
  const env = { PROBES: { idFromName: x => x, get: () => ({ fetch: () => { forwarded++; return Response.json({ status: 'unexpected' }); } }) } };
  const request = (site, body) => new Request('http://127.0.0.1:18789/session', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Sec-Fetch-Site': site }, body });
  assert.equal((await acceptanceRunner.fetch(request('cross-site', '{}'), env)).status, 404);
  const invalid = await acceptanceRunner.fetch(request('same-origin', '{}'), env);
  assert.equal(invalid.status, 400);
  assert.deepEqual(await invalid.json(), { status: 'invalid_session_state' });
  assert.equal(forwarded, 0);
});

test('approved Fomo bootstrap accepts only the exact two-address account initializer', () => {
  const url = 'https://prod-api.fomo.family/v2/users';
  const body = JSON.stringify({ address: mint, evmAddress: '0x' + '1'.repeat(40) });
  assert.equal(fomoBootstrapAllowed(url, 'POST', body), true);
  assert.equal(researchRequestAllowed('fomo', url, 'POST'), false);
  for (const path of [url + '/pushToken', url + '?action=trade', url.replace('prod-api.fomo.family', 'evil.example')]) assert.equal(fomoBootstrapAllowed(path, 'POST', body), false);
  for (const invalid of [null, '{}', 'invalid', JSON.stringify({ address: mint, evmAddress: 'invalid' }), JSON.stringify({ address: mint, evmAddress: '0x' + '1'.repeat(40), withdraw: true })]) assert.equal(fomoBootstrapAllowed(url, 'POST', invalid), false);
  for (const method of ['GET', 'PUT', 'PATCH', 'DELETE']) assert.equal(fomoBootstrapAllowed(url, method, body), false);
});
test('Fomo token-read POSTs stay separate from account and trading routes', () => {
  for (const path of ['filterTokens', 'filterTokensSearch', 'tokenDetails', 'tokenWarnings', 'getBars', 'getTokenPrices']) assert.equal(researchRequestAllowed('fomo', 'https://prod-api.fomo.family/proxy/' + path, 'POST'), true);
  for (const path of ['/proxy/trade', '/proxy/batch', '/v2/users', '/v1/builder-fee/approve', '/v1/account/abstraction']) assert.equal(researchRequestAllowed('fomo', 'https://prod-api.fomo.family' + path, 'POST'), false);
});

async function overnightFixture(probe) {
  const { OvernightAcceptance, OVERNIGHT_IDLE_MS } = await import('./overnight.mjs');
  const records = new Map([
    ['state:fomo:imported_at', 'import-1'], ['state:fomo:updated_at', 'read-1'],
    ['acceptance:fomo:recreation', { status: 'passed', imported_at: 'import-1', checks: Array.from({ length: 5 }, () => ({ authenticated_research: true })) }]
  ]);
  let now = 1000000, alarm = null, calls = 0;
  const storage = { get: async key => records.get(key), put: async (key, value) => records.set(key, structuredClone(value)), setAlarm: async value => { alarm = value; }, getAlarm: async () => alarm };
  const acceptance = new OvernightAcceptance(storage, async () => { calls++; return probe ? await probe() : { authenticated_research: true, visible_theses: 20 }; }, () => now);
  return { acceptance, records, advance: duration => { now += duration; }, calls: () => calls, idle: OVERNIGHT_IDLE_MS };
}
test('overnight acceptance waits a real interval and does not postpone an already armed check', async () => {
  const f = await overnightFixture();
  const initial = await f.acceptance.arm();
  assert.equal(initial.due_at - initial.idle_from, f.idle);
  assert.equal(initial.alarm_at, initial.due_at);
  f.advance(1000);
  assert.equal((await f.acceptance.arm()).due_at, initial.due_at);
  await f.acceptance.run();
  assert.equal(f.calls(), 0);
  f.advance(f.idle);
  await f.acceptance.run();
  const result = await f.acceptance.status();
  assert.equal(result.status, 'passed');
  assert.ok(result.idle_ms >= f.idle);
  await f.acceptance.run();
  assert.equal(f.calls(), 1);
});
test('changed session state invalidates idle proof without launching a browser', async () => {
  const f = await overnightFixture();
  await f.acceptance.arm();
  f.records.set('state:fomo:updated_at', 'another-read');
  f.advance(f.idle);
  await f.acceptance.run();
  assert.equal((await f.acceptance.status()).status, 'idle_invalidated');
  assert.equal(f.calls(), 0);
});
test('overnight acceptance refuses missing or superseded recreation proof', async () => {
  const f = await overnightFixture();
  f.records.set('state:fomo:imported_at', 'new-login');
  assert.equal((await f.acceptance.arm()).status, 'prerequisite_missing');
  assert.equal((await f.acceptance.status()).alarm_at, null);
  assert.equal(f.calls(), 0);
});

test('an overnight probe failure is recorded without leaking errors or retrying login', async () => {
  const f = await overnightFixture(async () => { throw new Error('fake-secret-page-or-session'); });
  await f.acceptance.arm();
  f.advance(f.idle);
  await f.acceptance.run();
  const result = await f.acceptance.status();
  assert.equal(result.status, 'failed');
  assert.equal(result.reason, 'probe_failed');
  assert.equal(JSON.stringify(result).includes('fake-secret'), false);
  await f.acceptance.run();
  assert.equal(f.calls(), 1);
});

test('research jobs reject arbitrary controls and unbounded pages', async () => {
  const { researchArgs } = await import('./pages.mjs');
  assert.equal(researchArgs({ site: 'gmgn', mint, panel: 'holders', page: 2 }).page, 2);
  for (const value of [{ site: 'gmgn', mint, panel: 'buy' }, { site: 'fomo', mint, panel: 'withdraw' }, { site: 'fomo', mint, page: 3 }, { site: 'gmgn', mint, page: -1 }, { site: 'gmgn', mint, screenshot: 'yes' }]) assert.throws(() => researchArgs(value));
});
test('screenshot delivery signatures are bound to one object and expiry', async () => {
  const { imageSignature, siteId } = await import('./service.mjs');
  const key = 'fake-service-key-for-tests-only';
  assert.notEqual(await imageSignature(key, 'image-1', 123), await imageSignature(key, 'image-2', 123));
  assert.notEqual(await imageSignature(key, 'image-1', 123), await imageSignature(key, 'image-1', 124));
  assert.notEqual(siteId('fomo'), siteId('gmgn'));
});
test('shared quota admits 100 fresh jobs across site callers, then stops', async () => {
  const { JobManager } = await import('./service.mjs');
  const data = new Map();
  const storage = { get: async key => data.get(key), put: async (key,value) => data.set(key,value) };
  storage.transaction = async fn => fn(storage);
  const service = new JobManager({ storage }, {});
  for (let i = 0; i < 100; i++) assert.equal((await (await service.jobRoute('/quota')).json()).admitted, true);
  assert.equal((await (await service.jobRoute('/quota')).json()).admitted, false);
});

async function jobsFixture(raw) {
  const { JobManager } = await import('./service.mjs');
  const records = new Map(), waits = [];
  let admitted = 0;
  const storage = { get: async k => records.get(k), put: async (k,v) => { if (typeof k === 'object') for (const [name,value] of Object.entries(k)) records.set(name,value); else records.set(k,v); }, delete: async k => records.delete(k), setAlarm: async () => {}, list: async ({prefix}) => new Map([...records].filter(([k]) => k.startsWith(prefix))) };
  const ctx = { storage, waitUntil: promise => waits.push(promise) };
  class Jobs extends JobManager { async fetch() { return Response.json(raw); } }
  const manager = new Jobs(ctx, { PROBES: { idFromName:x=>x, get:()=>({fetch:async()=>{admitted++;return Response.json({admitted:true});}}) } });
  return { manager, records, waits, admissions:()=>admitted };
}
test('pending hosted jobs resume and a cached read keeps its original fetch timestamp', async () => {
  const { tokenUrl } = await import('./contract.mjs');
  const at = '2026-11-08T00:00:00Z';
  const f = await jobsFixture({ status:'page_observed', source_url:tokenUrl('gmgn',mint), fetched_at:at, page_evidence:{ evidence:{text:'public research'},coverage:['sampled rows'],panel_found:true } });
  const request = () => new Request('https://internal/research',{method:'POST',body:JSON.stringify({site:'gmgn',mint,panel:'holders'})});
  const pending = await (await f.manager.jobRoute('/research',request())).json();
  assert.equal(pending.status,'pending');
  await Promise.all(f.waits);
  const completed = await (await f.manager.jobRoute('/jobs/'+pending.job_id)).json();
  assert.equal(completed.status,'ok');assert.equal(completed.fetched_at,at);
  const cached = await (await f.manager.jobRoute('/research',request())).json();
  assert.equal(cached.cached,true);assert.equal(cached.fetched_at,at);assert.equal(f.admissions(),1);
});
test('the watchdog turns an interrupted job into explicit missing coverage without retrying it', async () => {
  const f = await jobsFixture({});
  f.records.set('active-job','stalled');f.records.set('job:stalled',{id:'stalled',status:'pending',created_at:Date.now(),args:{site:'gmgn',mint}});
  await f.manager.jobsAlarm();
  const result = await (await f.manager.jobRoute('/jobs/stalled')).json();
  assert.equal(result.status,'interrupted');assert.equal(f.records.has('active-job'),false);assert.equal(f.admissions(),0);
});

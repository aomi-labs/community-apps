# Hosted browser migration

Approved direction: API-first research, with separate Fomo and GMGN token-page
skills backed by a Cloudflare-hosted browser. The current Chrome extension and
live Daiko app stay in place until the replacement passes acceptance.

## Delivery order and gates

1. Deploy the isolated Browser Run probe. Test logged-out token pages, public
   research controls, scrolling, and screenshots independently for each site.
2. If a site requires login, provision an unfunded test account during operator
   setup. Save supported cookies/localStorage/IndexedDB in private Durable Object
   storage, with no custom encryption layer. Prove five browser recreations,
   Worker redeployment, and overnight idle. User requests never initiate login.
3. For sites that pass, add SDK 7 app-scoped `daiko/fomo-page-skill` and
   `daiko/gmgn-page-skill`. Prefer direct API tools for sufficient evidence; use
   the page skill for UI-only/incomplete evidence or explicit screenshot requests.
   Preserve `daiko_thesis`; do not adopt the old relay's captured private bearer.
4. Implement the research service with site/account serialization, automatic
   saved-state restoration, five-minute evidence cache, 100 fresh jobs/day,
   30 actions/90 seconds per job, asynchronous status, and browser cleanup.
   Allow only named research controls and verified read requests. Store masked
   requested screenshots in private R2 with authenticated delivery and 24-hour
   expiry. No trading/account changes, arbitrary selectors or JavaScript input.
5. Run Rust and browser checks, build the immutable staging app, verify skill
   registration, activate it, and prove real Telegram API-only, Fomo, GMGN and
   screenshot flows in the existing private acceptance group. Record source and
   deployment provenance and retain the original bridge as rollback until both
   sites pass.

If hosted access fails, stop that site's cutover and report the evidence. Do not
silently switch providers. A persistent hosted Chrome profile with fixed egress
is the preferred follow-up architecture, not an implicitly authorized fallback
deployment. Production and shared Aomi routes are outside this migration.

## Candidate deployment — 2026-11-07

- Worker: `daiko-browser-candidate`, workers.dev only; no DNS or shared routes.
- URL: `https://daiko-browser-candidate.h16n.workers.dev`.
- Current candidate version, including scoped cookie restoration and session refresh:
  `0a3dd6c4-0028-4b40-a0df-5a9a87d2489d`.
  The preceding successful five-browser check used
  `4e79ccbe-c66c-484c-8377-122c6b9f96a7`.
- Bindings: Browser Run `BROWSER`, SQLite Durable Object `PROBES`.
- Separate configuration/key: **Aomi Dev / Daiko hosted browser** in 1Password.
- Scope: operator-only acceptance probes, logged out by default with optional
  scoped Fomo auth restoration, **not** the research service
  and **not** a live-bot cutover. The app and original bridge are unchanged.
- Reproduction: [browser instructions](../browser/README.md).

## Evidence and outstanding acceptance

Representative mint: `4kjruqGHDsSqkMdFfCjV7Vb62HPFhtXyWc2t6JpQzDnz`
(GTA6, independently resolved through DEX Screener).

**Fomo:** a fresh logged-out browser received HTTP 200 but redirected the token
URL to `https://fomo.family/`. Its rendered content was the marketing homepage
with Login / Start trading, not the token page. There were zero visible thesis
controls or rows. No challenge was observed. This is not a passed research gate;
it is consistent with authentication being required. This initial probe imported
no saved session. The Aomi Dev vault contains relay configuration, and the Employee
vault's Fomo login item has no credential values. Operator test-account selection
was initially pending before hosted authentication or restoration could be tested.

The user subsequently authorized using the existing test account. Its signed-in
Chrome session opened the actual token page and thesis feed. Operator setup
transferred only four observed Fomo Privy authentication entries into private
Durable Object storage through the masked `/setup` form; the UI confirmed
`fomo_session_saved`. No Google session, wallet-connection secrets, full browser
profile, or IndexedDB contents were copied. The setup form resets its masked
fields on success and returns no credential values. Authenticated probes now
restore that state into fresh browsers, return only the existing public thesis
extraction, omit screenshots/account text, and retain filtered updated auth
state only after a successful read.

**Fomo restoration failed on 2026-11-07 at 18:29 UTC.** Local 1Password CLI
access continued returning `promptError` after Touch ID approval. A development-only
Wrangler remote preview runner reached the existing private coordinator using
Cloudflare OAuth instead, so credential-tool failure no longer prevented the test.
The first restoration had no cookies and redirected without refreshing. Recreating
Privy's first-party cookie representation from the saved auth entries made the
browser attempt its normal refresh. After allowing the exact
`POST https://privy.fomo.family/api/v1/sessions` endpoint, that request returned
HTTP 401 and the page redirected home with zero theses (13.0 seconds). Analytics
remained blocked. The saved access token was already expired; this proves that
this saved credential did not recover the session, not that Cloudflare is
categorically incompatible with Fomo. Failed probes did not overwrite stored auth.

Cookie representation follows `@privy-io/js-sdk-core@0.79.4`'s
`storeRefreshTokenForUser` and `storeCustomerAccessTokenForUser`: session marker,
refresh cookie, and an access cookie only while the JWT is unexpired. No access
expiry is extended. Fomo's exact feature-flag POST is also allowed; wallet,
trading, OAuth-initiation and analytics POSTs remain blocked.

Native Chrome control then reported `cgWindowNotFound`, preventing a fresh
operator-session setup through the available native UI. A fresh setup followed by
five successful recreations, redeployment read, expiry recovery and overnight idle
is still required. Do not enable the Fomo page skill or cut over the bot on this
result. No login handoff was added to on-demand tools. The temporary acceptance
Cron was removed (`crons: []`); no recurring test or overnight test is scheduled.

**Fresh setup on 2026-11-08:** native Chrome became reachable and the user
provided a renewed signed-in test account. Importing local storage alone still
returned 401. Inspecting the actual cookie scope revealed that Fomo uses
server-cookie authentication: `privy-token` and a non-generic `privy-session` on
`.fomo.family`, plus HttpOnly `privy-access-token` and `privy-refresh-token` on
`.privy.fomo.family`. The original export omitted the authentication subdomain.
The candidate now preserves these four scoped cookies exactly and does not add
a generic refresh cookie when an observed session cookie exists. Other origins
and wallet state remain excluded.

With the complete cookie set, the hosted browser stayed on the token page and
reported no HTTP errors, including no refresh 401. Public thesis extraction was
still empty. This is progress on authentication, not a passed research gate.
Additional POST calls were blocked, including `app-actions2.fomo.family/`; those
need operation-level inspection before any research allowance. The current
probe records only JSON field/type structure for that blocked endpoint, never
request values. Five successful research recreations and overnight persistence
remain pending. The operator preview now accepts masked cookies separately and
uses Cloudflare OAuth to reach the existing private coordinator without exporting
the service key. Verification caching is tied to operator import time so a fresh
setup cannot reuse an older failed verdict.

Further inspection at 12:09 UTC found the token route showing **Something went
wrong**, with no thesis controls or token identity. Fomo's public
`token-v2-JsVzCtTi.js` frontend confirms that startup calls
`POST https://prod-api.fomo.family/v2/users` with the authenticated account's
`address` and `evmAddress`. It labels this operation user registration and treats
a blocked call as an account-loading error. This is not a verified read POST,
so it remains denied. A separate source-browser token tab displayed the expected
thesis trigger and 31 public comment controls. The current evidence therefore
identifies a policy/initialization blocker after session restoration, rather than
a demonstrated Cloudflare challenge. The user subsequently approved this exact existing-test-account initializer.
It is now a separate bootstrap exception, enabled only when restoring saved
Fomo state, with a body restricted to the observed Solana/EVM address pair.
It is not exposed as a model operation; other account and wallet POSTs remain
blocked. The opaque `app-actions2` POSTs were not
allowlisted either. Browser recreation, redeployment acceptance and overnight
acceptance were still unproven at that point. The subsequent acceptance results
and overnight schedule follow below.

**GMGN:** initially rendered live trades, holder counts, and public risk data
without a login or challenge, but identity/market data and the chart were missing.
Network inspection found that the probe's GET-only policy blocked legitimate
token-info POSTs. Allowing only four exact GMGN token/price read POST endpoints
restored GTA6's identity, market cap, price, liquidity, supply, and rendered chart.
Five consecutive fresh browser instances loaded the correct token page and all
four public research controls: holders, top traders, early buyers and Dev Token.
Scrolling from 0 to 500 was observed in top-trader, early-buyer and developer-token
tables on every final probe. Holder-table scrolling was not demonstrated. There
were no HTTP error responses or challenges in these five runs. This establishes
logged-out access/recreation, not an authenticated login-restoration test or
complete extraction/pagination acceptance. Embedded third-party holder maps and
other non-allowlisted POST features remain outside the probe's demonstrated
coverage; neither a populated HTML shell nor a first table is full acceptance.
Generic batch handlers, analytics, account and trading POSTs remain blocked.

Screenshots and raw logged-out probe output are local operator evidence under
`/tmp/daiko-browser-evidence/`; they are not stored in R2, published, or sent to
Telegram. The repository records only this curated acceptance summary.

Fomo passed its initial five-recreation authenticated research check on
2026-11-08 at 12:26:43 UTC. Every browser opened the public thesis feed and
returned the existing structured extraction; 59 like-controls were rendered
across the holder/feed views, not 59 unique extracted comments. The extraction
remains bounded to 20 public comments. Durations were 15.2–21.3 seconds, with
no HTTP errors or challenges. Trade/RPC, engagement writes, analytics, friends
and the new chart endpoint remained blocked. Full token-page/chart coverage is
therefore not yet accepted.

A second five-browser check passed after redeployment on 2026-11-08 at
12:29:47 UTC, on Worker `0a3dd6c4-0028-4b40-a0df-5a9a87d2489d`. Each read
observed a successful Privy session refresh and returned authenticated research,
with no HTTP errors; durations were 14.3–16.2 seconds. This proves that
redeployment retained usable saved state. It does not prove overnight expiry
recovery. The candidate now retries the fixed token URL once if an initial
redirect was followed by a successful site-managed session refresh.

The private coordinator confirmed a single Durable Object alarm at
**2026-11-09 00:30:27.795 UTC**, after 12 hours of untouched stored state. Its
status was read back as `pending`, with the provider alarm timestamp matching
the requested deadline. Another successful read or operator import invalidates
the idle proof. The alarm runs one fresh browser, closes it, and stores only a
safe verdict; there is no recurring Cron, warm browser, interactive login, or
automatic login retry. No further fresh probes should run before that deadline.
A continuation bound to the current conversation is scheduled for
**2026-11-09 00:32:45.712 UTC** to inspect the result and continue the approved
plan. It must disable itself at the start of its first run. Its task ID is
`scheduled-task:command:mcp:95d39d02-23b6-4e20-b982-0972a4bc5241:schedule-task:daiko-fomo-overnight-2026-11-08`.

Overnight login proof, complete research jobs, app page skills, new app
build/activation, and Telegram cutover have not been accepted yet. Those steps remain gated, not implicitly passed
by deployment of the probe.

Validation completed for the probe: seventeen Node contract/acceptance tests, Worker dry-run
bundle, Python syntax checks, and deployed HTTP checks for authenticated health
(200), missing authorization (401), invalid site/mint (400), and wrong method
(404). Rust formatting, clippy with warnings denied, and all seven Rust tests passed.
App activation remains deferred because the site gates have not passed. The existing workflow now also tests and
bundles the candidate browser package; its staging app-deploy branch condition
is unchanged.

## Activation work — 2026-11-08

Cecilia explicitly waived the overnight gate and requested activation now.
The scheduled conversation continuation is disabled; the operator alarm will be
marked waived by the new service before activation. This is a waiver, not a
successful overnight result.

The candidate now implements authenticated pending jobs, per-site coordinators,
a shared 100-fresh-jobs/day budget, a five-minute success cache preserving fetch
timestamps, and bounded named-panel/scroll requests. Fomo's existing four-cookie
test session is copied internally from acceptance storage on first use. Login
handoffs are never initiated by user calls. A watchdog records interrupted jobs.

The existing authenticated bridge URL/key act as a gateway to the separate
hosted service through an external Durable Object binding. This reuses the
already-provisioned application credential; it does not introduce the captured
private Fomo bearer as an API. Original extension routes remain available for
rollback. New SDK 7 skills own `daiko_fomo_page` and `daiko_gmgn_page`; direct APIs
remain first when sufficient. `daiko_thesis` uses the hosted gateway after app
activation.

Screenshot delivery requires private R2, signed object-specific URLs and enforced
24-hour expiry. Cloudflare currently requires account-level R2 activation; that
checkout is pending the explicit billing/terms decision. Fomo captures cover the account/trading sidebars, header/footer and inputs,
with fail-closed checks for private account labels in the public center. GMGN uses
a fresh logged-out context with account/trading chrome covered. These are native
viewport captures, not an assertion of complete or unmasked page coverage.

Fomo still returns public comments rather than complete holders/chart data.
GMGN returns bounded rendered tables. Missing panels and non-advancing scrolls
are coverage limitations. Build/activation and real bot acceptance must be
recorded separately below; source code is not proof of a live integration.

Rollback: original app release `apps-141232970-rf7c24120cd-daiko-e31873b51005`;
bridge Worker `0bcb385b-235c-4c32-bdb7-7ef55a12ee78`;
browser candidate before integration `0a3dd6c4-0028-4b40-a0df-5a9a87d2489d`.

Hosted service checks on 2026-11-08: both Fomo thesis and GMGN holder jobs
completed through the new per-site job path. Repeating each returned `cached:true`
with the exact original fetch timestamp. The operator overnight alarm is now
`waived`, not pending. The read service currently runs without its R2 binding
while the account-level R2 subscription confirmation is pending; image delivery
explicitly reports unavailable in that state. The authenticated bridge gateway
was deployed as Worker `af5aa94c-4057-452f-aa45-81b8eb8e1869`; its legacy routes
remain present. Masked native captures were generated for inspection locally.

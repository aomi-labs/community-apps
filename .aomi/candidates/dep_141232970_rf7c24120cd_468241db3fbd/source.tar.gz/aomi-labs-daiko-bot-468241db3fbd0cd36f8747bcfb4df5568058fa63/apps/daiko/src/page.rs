use crate::client::{DaikoApp, key, mint, unavailable};
use aomi_sdk::{DynAomiTool, DynToolCallCtx};
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use std::time::{Duration, Instant};
#[derive(Deserialize, Serialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct PageArgs {
    /// Exact Solana mint from the user or token API.
    pub mint: String,
    /// Fomo: overview, thesis, holders. GMGN: overview, trades, holders, top_traders, early_buyers, dev_token.
    pub panel: Option<String>,
    /// Bounded rendered page: 0, 1 or 2. A missing scroll container is reported as limited coverage.
    #[serde(default)]
    pub page: u8,
    /// Request a native screenshot with account/position areas masked. Captures may be partial or omitted.
    #[serde(default)]
    pub screenshot: bool,
    /// Resume the same site's pending job. Preserve the mint and job id exactly.
    pub job_id: Option<String>,
}
pub fn hosted(ctx: &DynToolCallCtx, site: &str, args: PageArgs) -> Result<Value, String> {
    mint(&args.mint)?;
    if args.page > 2 {
        return Err("Page must be 0, 1 or 2".into());
    }
    let configured = key(ctx, "BROWSER_URL")
        .zip(key(ctx, "BROWSER_KEY"))
        .or_else(|| key(ctx, "FOMO_RELAY_URL").zip(key(ctx, "FOMO_RELAY_KEY")));
    let Some((base, secret)) = configured else {
        return Ok(unavailable(site, "not_configured"));
    };
    let url = reqwest::Url::parse(&base).map_err(|_| "Invalid browser service configuration")?;
    if url.scheme() != "https"
        || url.host_str().is_none()
        || !url.username().is_empty()
        || url.password().is_some()
    {
        return Err("Invalid browser service configuration".into());
    }
    let client = reqwest::blocking::Client::builder()
        .timeout(Duration::from_secs(8))
        .connect_timeout(Duration::from_secs(4))
        .redirect(reqwest::redirect::Policy::none())
        .build()
        .map_err(|_| "Browser client unavailable")?;
    let endpoint = base.trim_end_matches('/');
    let read_job = |id: &str| -> Result<Value, String> {
        if id.len() != 36 || !id.chars().all(|c| c.is_ascii_hexdigit() || c == '-') {
            return Err("Invalid browser job id".into());
        }
        client
            .get(format!("{endpoint}/jobs/{site}/{id}"))
            .bearer_auth(&secret)
            .send()
            .and_then(|r| r.error_for_status())
            .and_then(|r| r.json())
            .map_err(|_| "Browser job status unavailable".into())
    };
    let mut result: Value = if let Some(id) = args.job_id.as_deref() {
        read_job(id)?
    } else {
        match client.post(format!("{endpoint}/research")).bearer_auth(&secret).json(&json!({"site":site,"mint":args.mint,"panel":args.panel,"page":args.page,"screenshot":args.screenshot})).send().and_then(|r| r.error_for_status()).and_then(|r| r.json()) {
            Ok(v) => v, Err(_) => return Ok(unavailable(site, "unavailable")),
        }
    };
    let started = Instant::now();
    while result["status"] == "pending" && started.elapsed() < Duration::from_secs(20) {
        let Some(id) = result["job_id"].as_str().map(str::to_owned) else {
            break;
        };
        std::thread::sleep(Duration::from_secs(2));
        result = read_job(&id)?;
    }
    if result
        .get("mint")
        .and_then(Value::as_str)
        .is_some_and(|m| m != args.mint)
    {
        return Err("Browser evidence mint mismatch".into());
    }
    Ok(result)
}
macro_rules! page_tool {
    ($tool:ident,$name:literal,$site:literal,$description:literal) => {
        pub struct $tool;
        impl DynAomiTool for $tool {
            type App = DaikoApp;
            type Args = PageArgs;
            const NAME: &'static str = $name;
            const DESCRIPTION: &'static str = $description;
            fn run(_: &DaikoApp, args: PageArgs, ctx: DynToolCallCtx) -> Result<Value, String> {
                hosted(&ctx, $site, args)
            }
        }
    };
}
page_tool!(
    FomoPage,
    "daiko_fomo_page",
    "fomo",
    "Read Fomo's token-page public research, bounded rendered pages, masked screenshots, or pending-job status. Use the fomo-page-skill; APIs first when sufficient. Never trade or change accounts. Return missing coverage honestly."
);
page_tool!(
    GmgnPage,
    "daiko_gmgn_page",
    "gmgn",
    "Read GMGN's token-page research tables, bounded rendered pages, masked screenshots, or pending-job status. Use the gmgn-page-skill for UI-only evidence or screenshots. Never trade or change accounts."
);

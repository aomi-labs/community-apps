import { keccak_256 } from "@noble/hashes/sha3";
import { bytesToHex, utf8ToBytes } from "@noble/hashes/utils";

import type { SandboxFile, StudioClient } from "@aomi-labs/arc-studio-cli/client";

import { ARC_MAINNET_CHAIN_ID, ARC_TESTNET_CHAIN_ID, type Deployment, FuzzTarget } from "./fuzz-target.ts";
import type { FuzzCampaignReport } from "./report.ts";

interface CompilerMetadata {
  settings?: { compilationTarget?: Record<string, string> };
  sources?: Record<string, { keccak256?: string }>;
}

interface DeploymentSource {
  address: string;
  path: string;
}

export interface ContractSource {
  /** Workspace path, e.g. `contracts/Vault.sol`. */
  path: string;
  source: string;
  /** Concrete (non-abstract) contracts declared in the file. */
  contracts: string[];
  /** Whether a Foundry artifact exists for every declared contract. */
  built: boolean;
}

/**
 * A sibling of the target, deployed on the same Arc chain, as the fuzzer app's
 * artifact lists it: the agent can then call it by name inside the forked world.
 */
export interface ProtocolContract {
  name: string;
  address: string;
  /** The compiler's JSON ABI array, encoded as a JSON string. */
  abi: string;
}

/** Raised when a contract has no compiled artifact in the app workspace yet. */
export class MissingBuildError extends Error {
  constructor(readonly sourcePath: string, readonly contract: string) {
    super(
      `No compiled artifact for ${contract} (${sourcePath}). Build the app in Arc Studio, or ask it to run \`forge build\`.`,
    );
    this.name = "MissingBuildError";
  }
}

/**
 * One of the user's Arc Studio apps, seen through its live sandbox workspace
 * (a Vite + Foundry project; Solidity may sit at the root or in a subfolder).
 */
export class ArcStudioApp {
  static #metadata(artifact: unknown): CompilerMetadata | undefined {
    const json = artifact as { metadata?: unknown; rawMetadata?: string };
    const value = json.metadata ?? json.rawMetadata;
    return typeof value === "string" ? JSON.parse(value) : value as CompilerMetadata | undefined;
  }

  #files: SandboxFile[] | undefined;
  #contracts: Promise<ContractSource[]> | undefined;
  private deploymentSources?: Promise<DeploymentSource[]>;

  private constructor(
    readonly client: StudioClient,
    readonly appId: string,
    readonly sandboxId: string,
  ) {}

  static async open(client: StudioClient, appId: string): Promise<ArcStudioApp> {
    const { sandboxId } = await client.getSandbox(appId);
    if (!sandboxId) {
      throw new Error(
        `App ${appId} has no live sandbox. Open it in Arc Studio (or run one turn) to wake it, then retry.`,
      );
    }
    return new ArcStudioApp(client, appId, sandboxId);
  }

  /** A sandbox path as the builder knows it: `/home/user/app/contracts/V.sol` → `contracts/V.sol`. */
  static workspacePath(path: string): string {
    return path.replace(/^\/home\/user\/app\//, "");
  }

  /** Credential-shaped files (same policy as the CLI's --file guard); never read or shown. */
  static isSensitive(path: string): boolean {
    const name = path.split("/").at(-1)?.toLowerCase() ?? "";
    return /^\.env/.test(name) || name === ".npmrc" || /\.(pem|key|p12|pfx|keystore)$/.test(name) || name.startsWith("id_rsa");
  }

  /** Reads one workspace file the sandbox listed, refusing credential-shaped files. */
  async readFile(path: string): Promise<string> {
    if (ArcStudioApp.isSensitive(path)) throw new Error(`${ArcStudioApp.workspacePath(path)} may hold secrets and is not shown.`);
    if (!(await this.files()).some((f) => f.path === path)) throw new Error(`${path} is not in this app's workspace.`);
    return (await this.read([path])).get(path) ?? "";
  }

  /** Reads many listed files in one batch, silently skipping credential files and unlisted paths. */
  async readFiles(paths: string[]): Promise<Map<string, string>> {
    const listed = new Set((await this.files()).map((f) => f.path));
    const wanted = paths.filter((p) => listed.has(p) && !ArcStudioApp.isSensitive(p));
    return wanted.length ? this.read(wanted) : new Map();
  }

  get webUrl(): string {
    return this.client.webUrl(this.appId);
  }

  async files(): Promise<SandboxFile[]> {
    this.#files ??= await this.client.listSandboxFiles(this.sandboxId);
    return this.#files;
  }

  /** Reads workspace files as text; throws on the first file the sandbox could not return. */
  async read(paths: string[]): Promise<Map<string, string>> {
    const out = new Map<string, string>();
    for (const file of await this.client.batchReadFiles(this.sandboxId, paths)) {
      if (file.content === undefined) {
        throw new Error(`Could not read ${file.path}: ${file.error ?? "no content"}`);
      }
      out.set(file.path, file.content);
    }
    return out;
  }

  /**
   * Path of the Foundry artifact for `contract` declared in `sourcePath`, wherever
   * the Foundry project sits (root or a subfolder like `onchain/`).
   */
  async artifactPath(sourcePath: string, contract: string): Promise<string | undefined> {
    const suffix = `/${sourcePath.split("/").at(-1)}/${contract}.json`;
    const files = await this.files();
    const matches = files.map((f) => f.path).filter((p) => p.endsWith(suffix) && !p.includes("node_modules/"));
    if (matches.length === 0) return undefined;
    const roots = files.map((f) => f.path).filter((path) => path.endsWith("foundry.toml"))
      .map((path) => path.slice(0, -"foundry.toml".length)).sort((a, b) => b.length - a.length);
    const projectRoot = (path: string) => roots.find((root) => path.startsWith(root));
    const root = projectRoot(sourcePath);
    const local = root === undefined ? matches : matches.filter((path) => projectRoot(path) === root);
    // Another project's build (e.g. an unbuilt export copy) is not this source's artifact.
    if (local.length === 0) return undefined;
    // Metadata disambiguates duplicate basenames within one build project.
    const artifacts = await this.read(local);
    const identified = local.filter((path) => {
      const artifact = JSON.parse(artifacts.get(path) ?? "null");
      const metadata = ArcStudioApp.#metadata(artifact);
      return Object.keys(metadata?.settings?.compilationTarget ?? {}).some((file) =>
        ArcStudioApp.workspacePath(sourcePath) === `${ArcStudioApp.workspacePath(root ?? "")}${file}`);
    });
    if (identified.length === 1) return identified[0];
    if (local.length === 1) {
      const artifact = JSON.parse(artifacts.get(local[0]!) ?? "null");
      const metadata = ArcStudioApp.#metadata(artifact);
      if (!metadata?.settings?.compilationTarget) return local[0];
    }
    throw new Error(`Ambiguous compiled artifact for ${sourcePath}:${contract}. Rebuild this Foundry project with source metadata.`);
  }

  /** The app's own Solidity files and their contracts; read once per ArcStudioApp. */
  contracts(): Promise<ContractSource[]> {
    this.#contracts ??= this.#scanContracts();
    return this.#contracts;
  }

  async #scanContracts(): Promise<ContractSource[]> {
    const solidity = (await this.files())
      .map((f) => f.path)
      .filter(
        (p) =>
          p.endsWith(".sol") &&
          !/\.(t|s)\.sol$/.test(p) &&
          !/(^|\/)(lib|node_modules|test|tests|script|out|cache|broadcast|context)\//.test(p),
      )
      .sort();
    if (solidity.length === 0) return [];
    const sources = await this.read(solidity);
    const contracts = solidity.map((path) => {
      const source = sources.get(path) ?? "";
      const declared = [
        ...source.matchAll(/^\s*(abstract\s+)?contract\s+(\w+)/gm),
      ]
        .filter((m) => !m[1])
        .map((m) => m[2] as string);
      return { path, source, contracts: declared };
    });
    return Promise.all(
      contracts.map(async (file) => ({
        ...file,
        built:
          file.contracts.length > 0 &&
          (await Promise.all(file.contracts.map((name) => this.artifactPath(file.path, name)))).every(Boolean),
      })),
    );
  }

  /**
   * Loads a contract's Foundry artifact plus its source. Relative imports inside
   * the workspace are inlined (with path headers) so the agent sees the code it
   * is attacking; library dependencies under `lib/` or `node_modules/` are not.
   */
  async target(sourcePath: string, contract: string, chainId?: number): Promise<FuzzTarget> {
    const artifactPath = await this.artifactPath(sourcePath, contract);
    if (!artifactPath) {
      throw new MissingBuildError(sourcePath, contract);
    }
    const artifact = JSON.parse((await this.read([artifactPath])).get(artifactPath) ?? "null");

    const known = new Set((await this.files()).map((f) => f.path));
    const seen = new Map<string, string>();
    let frontier = [sourcePath];
    while (frontier.length > 0) {
      const batch = await this.read(frontier);
      frontier = [];
      for (const [path, text] of batch) {
        seen.set(path, text);
        for (const match of text.matchAll(/^\s*import\s+(?:[^"']*from\s+)?["'](\.{1,2}\/[^"']+)["']/gm)) {
          // Arc Studio lists absolute sandbox paths (/home/user/app/...); keep the caller's form.
          const absolute = path.startsWith("/");
          const pathname = new URL(match[1] as string, `file://${absolute ? "" : "/"}${path}`).pathname;
          const resolved = absolute ? pathname : pathname.slice(1);
          if (known.has(resolved) && !seen.has(resolved) && !frontier.includes(resolved)) {
            frontier.push(resolved);
          }
        }
      }
    }
    const metadata = ArcStudioApp.#metadata(artifact);
    for (const [path, text] of seen) {
      const compiled = Object.entries(metadata?.sources ?? {})
        .filter(([file]) => ArcStudioApp.workspacePath(path).endsWith(file))
        .sort(([a], [b]) => b.length - a.length)[0]?.[1];
      if (compiled?.keccak256 && compiled.keccak256.toLowerCase() !== `0x${bytesToHex(keccak_256(utf8ToBytes(text)))}`) {
        throw new Error(`${path} changed since compilation. Run forge build before preparing the campaign.`);
      }
    }
    const source =
      seen.size === 1
        ? (seen.get(sourcePath) as string)
        : [...seen].map(([path, text]) => `// ==== ${path} ====\n${text}`).join("\n\n");

    return FuzzTarget.fromFoundryArtifact(contract, sourcePath, source, artifact, chainId, await this.deployment(contract, sourcePath));
  }

  /**
   * The Arc chain for an Arc Studio deployment's network label, or undefined
   * for other chains (Arc Studio also deploys to Base, Arbitrum, …), which the
   * fuzzer's Arc fork cannot reach.
   */
  static arcChainId(network: string, explorerUrl?: string): number | undefined {
    const label = `${network} ${explorerUrl ?? ""}`.toLowerCase();
    if (/5042002|arc[\s_-]*testnet|testnet\.arcscan/.test(label)) return ARC_TESTNET_CHAIN_ID;
    if (/\b5042\b|arc[\s_-]*mainnet|^arc\b|\barcscan\.app/.test(label)) return ARC_MAINNET_CHAIN_ID;
    return undefined;
  }

  /** Arc Studio records which source was copied into its deployment project. */
  private async readDeploymentSources(): Promise<DeploymentSource[]> {
    const paths = (await this.files()).map((file) => file.path)
      .filter((path) => /(?:^|\/)contract-metadata\/[^/]+\.json$/.test(path));
    const sources: DeploymentSource[] = [];
    for (const content of (await this.read(paths)).values()) {
      const metadata = JSON.parse(content) as {
        contract_code_path?: string;
        contractAddress?: string;
        contract_deployments?: Array<{ address?: string }>;
      };
      if (!metadata.contract_code_path) continue;
      const source = ArcStudioApp.workspacePath(metadata.contract_code_path);
      for (const address of [metadata.contractAddress, ...(metadata.contract_deployments ?? []).map((d) => d.address)]) {
        if (!address) continue;
        sources.push({ address: address.toLowerCase(), path: source });
      }
    }
    return sources;
  }

  /** The latest Arc deployment belonging to the selected source, when known. */
  async deployment(contract: string, sourcePath: string): Promise<Deployment | undefined> {
    const deployments = await this.client.listDeployments(this.appId);
    const candidates = deployments.flatMap(({ contract: name, address, network, explorerUrl, deployedAt }) => {
      if (name !== contract && name.split(/[:/]/).at(-1) !== contract) return [];
      const chainId = ArcStudioApp.arcChainId(network, explorerUrl);
      if (chainId === undefined || !/^0x[0-9a-fA-F]{40}$/.test(address)) return [];
      return [{ contract: name, address, chainId, at: deployedAt ?? "" }];
    }).sort((a, b) => b.at.localeCompare(a.at));
    if (candidates.length === 0) return undefined;

    const sources = await (this.deploymentSources ??= this.readDeploymentSources());
    const selected = ArcStudioApp.workspacePath(sourcePath);
    let duplicate: boolean | undefined;
    for (const candidate of candidates) {
      // Fully qualified API names identify a source without metadata.
      const separator = candidate.contract.lastIndexOf(":");
      const address = candidate.address.toLowerCase();
      const paths = separator > 0
        ? [ArcStudioApp.workspacePath(candidate.contract.slice(0, separator))]
        : sources.filter((source) => source.address === address).map((source) => source.path);
      if (paths.length > 0 && !paths.includes(selected)) continue;
      if (paths.length === 0) {
        duplicate ??= (await this.contracts()).filter((file) => file.contracts.includes(contract)).length > 1;
        if (duplicate) {
          throw new Error(`Ambiguous Arc deployment for ${sourcePath}:${contract}. Refresh the deployment source metadata in Arc Studio before preparing a campaign.`);
        }
      }
      return { address: candidate.address, chainId: candidate.chainId };
    }
    return undefined;
  }

  /**
   * The rest of the protocol around `target`: every other built contract in
   * the app with an Arc deployment on `chainId`, with its ABI. A fork of that
   * chain holds them at those addresses, so a bug that needs several
   * contracts (an oracle read from an AMM, say) is reachable.
   */
  async protocol(target: string, chainId: number): Promise<ProtocolContract[]> {
    // Resolve each source before deduplicating: the first copy may be undeployed.
    const seen = new Set<string>([target]);
    const siblings = (await this.contracts())
      .filter((file) => file.built)
      .flatMap((file) => file.contracts.map((name) => ({ name, path: file.path })))
      .filter((sibling) => sibling.name !== target);
    const found = await Promise.all(
      siblings.map(async ({ name, path }) => {
        const deployment = await this.deployment(name, path);
        if (!deployment || deployment.chainId !== chainId) return undefined;
        const artifactPath = await this.artifactPath(path, name);
        if (!artifactPath) return undefined;
        const artifact = JSON.parse((await this.read([artifactPath])).get(artifactPath) ?? "null");
        return { name, address: deployment.address, abi: JSON.stringify(artifact?.abi ?? []) };
      }),
    );
    return found.filter((contract): contract is ProtocolContract => {
      if (!contract || seen.has(contract.name)) return false;
      seen.add(contract.name);
      return true;
    });
  }

  /** Asks the Arc Studio agent to compile the app so `out/` artifacts exist. */
  async requestBuild(): Promise<{ threadId: string; webUrl: string }> {
    const { threadId } = await this.client.chatDetached({
      appId: this.appId,
      messages: [
        {
          role: "user",
          content:
            "Run `forge build` for this app's contracts and fix any compile errors. Do not change contract behavior or deploy anything.",
        },
      ],
    });
    return { threadId, webUrl: this.webUrl };
  }

  /**
   * Hands verified findings back to the Arc Studio agent as a fix request on a
   * new thread in the same app. Only confirmed findings are sent;
   * unconfirmed violations stay in the report.
   */
  async requestFix(
    target: FuzzTarget,
    report: FuzzCampaignReport,
  ): Promise<{ threadId: string; webUrl: string }> {
    const findings = report.findings;
    if (findings.length === 0) {
      throw new Error("The campaign has no reproduced findings to fix.");
    }
    const described = findings
      .map((finding, index) => {
        const steps = finding.minimized_trace
          .map(
            (call, step) =>
              `   ${step + 1}. ${call.actor} calls ${call.contract ? `${call.contract}.` : ""}${call.function}` +
              (call.arguments.length ? ` with (${call.arguments.join(", ")})` : "") +
              (call.value !== "0" ? `, sending ${call.value} wei of native USDC` : ""),
          )
          .join("\n");
        return `${index + 1}. Property violated: ${finding.property}\n   Minimized reproduction (replayed twice on a held Arc fork):\n${steps}`;
      })
      .join("\n\n");
    const { threadId } = await this.client.chatDetached({
      appId: this.appId,
      messages: [
        {
          role: "user",
          content: `Aomi's stateful fuzzer found ${findings.length === 1 ? "a verified vulnerability" : `${findings.length} verified vulnerabilities`} in ${target.name} (${target.sourcePath}).

${described}

Fix the affected protocol source files (the selected entrypoint is ${target.sourcePath}) so each sequence above can no longer violate its property. Keep the public ABI unless a signature change is required for the fix, and explain any such change. Then run \`forge build\` so the artifacts are current. Do not deploy.

Campaign ${report.campaign_id}: ${report.executions} executions over ${report.round} rounds.`,
        },
      ],
    });
    return { threadId, webUrl: this.webUrl };
  }
}

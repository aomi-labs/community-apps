import { redact } from "./campaign-record.ts";
import { statusLabel } from "./campaign-state.ts";
import type { CampaignRecord } from "./campaign-record.ts";
import type { FuzzCall, FuzzFinding } from "./report.ts";

const ARC_EXPLORER: Record<number, string> = {
  5042: "https://explorer.arc.network",
  5_042_002: "https://testnet.explorer.arc.network",
};

function escape(value: unknown): string {
  return redact(String(value ?? ""))
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function call(step: FuzzCall): string {
  const target = step.contract ? `${step.contract}.` : "";
  const value = step.value && step.value !== "0" ? ` {value: ${step.value}}` : "";
  return `${step.actor} → ${target}${step.function}(${step.arguments.join(", ")})${value}`;
}

function formatUnits(value: string): string {
  try {
    const atomic = BigInt(value);
    const whole = atomic / 10n ** 18n;
    const fraction = ((atomic < 0n ? -atomic : atomic) % 10n ** 18n).toString().padStart(18, "0").replace(/0+$/, "");
    return fraction ? `${whole}.${fraction.slice(0, 6)}` : whole.toString();
  } catch {
    return value;
  }
}

function delta(before: string, after: string): string {
  try {
    const change = BigInt(after) - BigInt(before);
    const sign = change > 0n ? "+" : change < 0n ? "−" : "";
    return `${sign}${formatUnits((change < 0n ? -change : change).toString())}`;
  } catch {
    return "?";
  }
}

function finding(item: FuzzFinding, index: number): string {
  const steps = item.steps
    .map(
      (step, i) =>
        `<tr><td>${i + 1}</td><td>${escape(step.actor)}</td><td><code>${escape(step.function)}</code></td><td class="s-${escape(step.status)}">${escape(step.status)}</td></tr>`,
    )
    .join("");
  const trace = item.minimized_trace.map((step) => `<li><code>${escape(call(step))}</code></li>`).join("");
  const balances = item.balances
    .filter((balance) => balance.before !== balance.after)
    .map(
      (balance) =>
        `<tr><td><code>${escape(balance.address)}</code></td><td>${escape(formatUnits(balance.before))}</td><td>${escape(formatUnits(balance.after))}</td><td>${escape(delta(balance.before, balance.after))}</td></tr>`,
    )
    .join("");
  const probes = item.probes
    .map(
      (probe) =>
        `<tr><td>${escape(probe.label)}</td><td>${escape(probe.status)}</td><td><code>${escape(probe.return_data ?? "")}</code></td></tr>`,
    )
    .join("");
  return `<section class="finding">
<h3>Finding ${index + 1}: ${escape(item.property)}</h3>
<p class="meta">Minimized to ${item.minimized_trace.length} call${item.minimized_trace.length === 1 ? "" : "s"} · reproduced ${item.reproductions}× from the baseline snapshot</p>
<h4>Minimized call order</h4>
<ol>${trace}</ol>
<h4>Replay</h4>
<table><thead><tr><th>#</th><th>Actor</th><th>Function</th><th>Status</th></tr></thead><tbody>${steps}</tbody></table>
${balances ? `<h4>Balance changes (native USDC)</h4><table><thead><tr><th>Address</th><th>Before</th><th>After</th><th>Change</th></tr></thead><tbody>${balances}</tbody></table>` : ""}
${probes ? `<h4>Probes after the trace</h4><table><thead><tr><th>Probe</th><th>Status</th><th>Returned</th></tr></thead><tbody>${probes}</tbody></table>` : ""}
</section>`;
}

/**
 * A self-contained HTML report of one campaign: target, status at close,
 * findings with minimized traces and balance deltas, rejected violations,
 * untested actions and the fix verdict. It names no session, thread or
 * signed link, so it can be shared as evidence as it is.
 */
export function renderCampaignReport(record: CampaignRecord): string {
  const { state, target } = record;
  const report = state.report;
  const chain = target.deployment?.chainId ?? target.chainId;
  const explorer = ARC_EXPLORER[chain];
  const address = target.deployment?.address;
  const status = statusLabel(state.status);
  const verdict = report?.fix_verdict;
  const when = new Date(record.updatedAt).toISOString().replace("T", " ").slice(0, 16) + " UTC";
  const rejected = state.rejected
    .map(
      (item) =>
        `<li><strong>${escape(item.property)}</strong>: ${escape(item.reason)}<ol>${item.trace.map((step) => `<li><code>${escape(call(step))}</code></li>`).join("")}</ol></li>`,
    )
    .join("");
  const limitations = (report?.limitations ?? []).map((text) => `<li>${escape(text)}</li>`).join("");
  const covered = (report?.covered_writes ?? []).map((fn) => `<code>${escape(fn)}</code>`).join(", ") || "none";
  const uncovered = (report?.uncovered_writes ?? []).map((fn) => `<code>${escape(fn)}</code>`).join(", ") || "none";
  const notTested = state.notTested.map((label) => `<li>${escape(label)}</li>`).join("");

  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Fuzz report: ${escape(target.name)}</title>
<style>
:root{--ink:#1a1a1a;--muted:#5c5c5c;--bg:#fff;--line:#e3e3e3;--danger:#b42318;--ok:#067647;--warn:#b54708;color-scheme:light dark}
@media(prefers-color-scheme:dark){:root{--ink:#ececec;--muted:#a3a3a3;--bg:#121212;--line:#2a2a2a;--danger:#f97066;--ok:#47cd89;--warn:#f79009}}
body{margin:0;padding:24px 16px;font:15px/1.5 system-ui,-apple-system,Segoe UI,sans-serif;color:var(--ink);background:var(--bg)}
main{max-width:880px;margin:0 auto}
h1{font-size:22px;margin:0 0 4px}h2{font-size:17px;margin:32px 0 8px;border-top:1px solid var(--line);padding-top:16px}
h3{font-size:15px;margin:20px 0 4px}h4{font-size:12px;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);margin:14px 0 4px}
.meta{color:var(--muted);margin:0 0 8px;font-size:13px}
dl{display:grid;grid-template-columns:max-content 1fr;gap:4px 16px;margin:12px 0;font-size:14px}dt{color:var(--muted)}dd{margin:0;overflow-wrap:anywhere}
table{border-collapse:collapse;width:100%;font-size:13px}th,td{text-align:left;padding:5px 8px;border-bottom:1px solid var(--line);vertical-align:top}th{color:var(--muted);font-weight:500}
code{font:12.5px/1.4 ui-monospace,SFMono-Regular,Menlo,monospace;overflow-wrap:anywhere}
.badge{display:inline-block;padding:2px 10px;border-radius:999px;border:1px solid var(--line);font-size:13px}
.badge.danger{color:var(--danger);border-color:currentColor}.badge.ok{color:var(--ok);border-color:currentColor}.badge.warn{color:var(--warn);border-color:currentColor}
.s-succeeded{color:var(--ok)}.s-reverted,.s-failed,.s-engine_error{color:var(--danger)}
.finding{margin:16px 0;padding:12px 16px;border:1px solid var(--line);border-radius:10px}
ol,ul{padding-left:22px}li{margin:2px 0}
footer{margin-top:40px;color:var(--muted);font-size:12px}
</style>
</head>
<body><main>
<h1>Fuzz report: ${escape(target.name)}</h1>
<p class="meta">${escape(target.sourcePath)} · Arc ${chain === 5042 ? "mainnet" : "testnet"} (chain ${chain}) · ${when}</p>
<p><span class="badge ${state.findings.length > 0 ? "danger" : state.status === "complete" ? "ok" : "warn"}">${escape(status)}</span>
${record.blind === true ? ' <span class="badge">blind mode: source comments hidden from the agent</span>' : record.blind === false ? ' <span class="badge">sighted mode: the agent read the source comments</span>' : ""}
${verdict ? ` <span class="badge ${verdict.verdict === "blocked" ? "ok" : verdict.verdict === "still_reproduces" ? "danger" : "warn"}">fix verdict: ${escape(verdict.verdict.replace("_", " "))}</span>` : ""}</p>
<dl>
<dt>Target</dt><dd>${address ? `<code>${escape(address)}</code>${explorer ? ` · <a href="${escape(`${explorer}/address/${address}`)}">explorer</a>` : ""}` : "runtime bytecode installed on a fresh address (no constructor ran)"}</dd>
${target.protocol && target.protocol.length > 0 ? `<dt>Protocol</dt><dd>${target.protocol.map((c) => `${escape(c.name)} <code>${escape(c.address)}</code>`).join(", ")}</dd>` : ""}
<dt>Hypothesis</dt><dd>${escape(report?.hypothesis ?? "—")}</dd>
<dt>Engine status</dt><dd>${escape(report?.status ?? "no report")}</dd>
<dt>Executions</dt><dd>${state.executions} of ${state.budget} budgeted · ${report?.round ?? 0} rounds · ${report?.inconclusive_traces ?? 0} inconclusive</dd>
<dt>Findings</dt><dd>${state.findings.length} confirmed · ${state.rejected.length} rejected</dd>
${record.cost ? `<dt>Cost</dt><dd>about ${Math.round(record.cost.microusd / 10_000).toLocaleString("en-US")} credits</dd>` : ""}
</dl>
<h2>Confirmed findings</h2>
${state.findings.length > 0 ? state.findings.map(finding).join("\n") : `<p>No exploit reproduced in the tested hypotheses.</p>`}
<h2>Rejected violations</h2>
${rejected ? `<ul>${rejected}</ul>` : "<p>None.</p>"}
${verdict ? `<h2>Fix verdict</h2><p>${verdict.verdict === "blocked" ? "Every earlier finding's trace ran on this target without violating a property." : verdict.verdict === "still_reproduces" ? "At least one earlier finding still reproduces on this target." : "At least one earlier finding could not be replayed to a conclusion on this target."}</p><table><thead><tr><th>Earlier finding</th><th>On this target</th><th>Detail</th></tr></thead><tbody>${verdict.replayed.map((r) => `<tr><td>${escape(r.property)}</td><td>${escape(r.outcome)}</td><td>${escape(r.detail ?? "")}</td></tr>`).join("")}</tbody></table>` : ""}
<h2>Coverage</h2>
<dl>
<dt>Covered writes</dt><dd>${covered}</dd>
<dt>Uncovered writes</dt><dd>${uncovered}</dd>
<dt>Not tested</dt><dd>${notTested ? `actions that never succeeded, so paths through them were not exercised:<ul>${notTested}</ul>` : "every planned action succeeded at least once"}</dd>
</dl>
${limitations ? `<h2>Limitations</h2><ul>${limitations}</ul>` : ""}
<footer>Generated by the Aomi agentic fuzzer from the campaign's event ledger. ${state.status === "complete" && (!verdict || verdict.verdict === "blocked") ? "A completed budget is evidence for the tested properties, not proof of contract safety." : "The campaign did not reach a complete budget; untested surfaces remain."}</footer>
</main></body></html>`;
}

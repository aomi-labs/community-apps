// Wire types for the report the Aomi `arc-studio-fuzzer` app returns from
// arc_fuzz_start / arc_fuzz_round / arc_fuzz_report. Mirrors
// apps/arc-studio-fuzzer/src/campaign.rs in this repository.

export interface FuzzCall {
  label: string;
  actor: string;
  contract?: string | null;
  function: string;
  arguments: string[];
  value: string;
}

export type ReplayStatus = "succeeded" | "reverted" | "halted" | "failed" | "engine_error";

export interface FindingStep {
  label: string;
  actor: string;
  function: string;
  status: ReplayStatus;
}

export interface BalanceChange {
  address: string;
  before: string;
  after: string;
}

export interface ProbeResult {
  label: string;
  status: ReplayStatus;
  return_data: string | null;
}

/** A violation minimized and reproduced twice from the baseline. */
export interface FuzzFinding {
  property: string;
  minimized_trace: FuzzCall[];
  steps: FindingStep[];
  balances: BalanceChange[];
  probes: ProbeResult[];
  reproductions: number;
}

/** A violation that did not reproduce; never a finding. */
export interface UnconfirmedViolation {
  property: string;
  trace: FuzzCall[];
  reason: string;
}

export interface FuzzCampaignReport {
  campaign_id: string;
  hypothesis: string;
  status: "exploring" | "confirming" | "budget_exhausted" | "complete";
  round: number;
  executions: number;
  max_executions: number;
  inconclusive_traces: number;
  corpus_size: number;
  frontier_size: number;
  covered_writes: string[];
  uncovered_writes: string[];
  behavior_coverage: string[];
  /** Action labels that ran but never succeeded: paths through them were not tested. */
  never_succeeded?: string[];
  /** What the engine changed on its own, such as resizing a stuck action. */
  engine_actions?: string[];
  findings: FuzzFinding[];
  unconfirmed: UnconfirmedViolation[];
  limitations: string[];
  /** The verdict on a patched target, when the plan replayed earlier findings first. */
  fix_verdict?: FixVerdict | null;
  /** The pending replay recipe, so an interrupted turn can recover. */
  next_batch?: unknown;
}

/** A finding from an earlier campaign, as a plan hands it to the engine. */
export interface PriorFinding {
  property: string;
  trace: FuzzCall[];
}

/**
 * Whether earlier findings still reproduce on a patched target. The engine
 * replays each prior finding before it searches; `blocked` only once every
 * trace ran cleanly without a violation, `still_reproduces` as soon as one
 * violated a property again.
 */
export interface FixVerdict {
  verdict: "blocked" | "still_reproduces" | "inconclusive";
  replayed: Array<{
    property: string;
    trace: FuzzCall[];
    outcome: "pending" | "blocked" | "reproduced" | "inconclusive";
    /** Why: the statuses it produced, the property it still violates, or the host error. */
    detail: string | null;
  }>;
}

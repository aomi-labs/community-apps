import type { Event } from "@aomi-labs/client";
import { describe, expect, it } from "vitest";

import { compactEvents, recordState, redact, type CampaignRecord } from "./campaign-record.ts";
import { renderCampaignReport } from "./report-html.ts";
import type { FuzzCampaignReport } from "./report.ts";

const SIGNED = "https://arc-studio-fuzz.vercel.app/api/artifacts/abc.def.ghi";

const withdraw = { label: "withdraw", actor: "attacker", contract: null, function: "withdrawSupply(uint256)", arguments: ["10"], value: "0" };
const report: FuzzCampaignReport = {
  campaign_id: "0xebdc",
  hypothesis: "a supplier's balance can be withdrawn by anyone",
  status: "confirming",
  round: 12,
  executions: 60,
  max_executions: 64,
  inconclusive_traces: 0,
  corpus_size: 20,
  frontier_size: 3,
  covered_writes: ["supply(uint256)", "withdrawSupply(uint256)"],
  uncovered_writes: ["repay(uint256)"],
  behavior_coverage: [],
  never_succeeded: ["repay"],
  findings: [
    {
      property: "unauthorized withdrawal",
      minimized_trace: [{ ...withdraw, actor: "victim", function: "supply(uint256)", label: "supply" }, withdraw],
      steps: [
        { label: "supply", actor: "victim", function: "supply(uint256)", status: "succeeded" },
        { label: "withdraw", actor: "attacker", function: "withdrawSupply(uint256)", status: "succeeded" },
      ],
      balances: [{ address: "0x00000000000000000000000000000000000000a1", before: "10000000000000000000", after: "20000000000000000000" }],
      probes: [{ label: "attacker supplied", status: "succeeded", return_data: "0x0" }],
      reproductions: 2,
    },
    {
      property: "untracked borrow",
      minimized_trace: [withdraw],
      steps: [{ label: "withdraw", actor: "attacker", function: "withdrawSupply(uint256)", status: "succeeded" }],
      balances: [],
      probes: [],
      reproductions: 2,
    },
  ],
  unconfirmed: [{ property: "collateral theft", trace: [withdraw], reason: "violation did not reproduce from the baseline" }],
  limitations: ["Coverage measures writable entrypoints, not opcodes."],
};

const record = (): CampaignRecord => {
  const events = [
    { type: "message", sequence: 1, sender: "user", content: `Fuzz it with artifact_url ${SIGNED}`, turn_id: "t1" },
    { type: "tool_update", sequence: 2, id: "c1", turn_id: "t1", tool_name: "arc-studio-fuzzer::arc_fuzz_round", result: undefined },
    { type: "tool_complete", sequence: 3, id: "c1", turn_id: "t1", tool_name: "arc-studio-fuzzer::arc_fuzz_round", result: JSON.stringify({ progress: report }) },
    { type: "turn_state_changed", sequence: 4, state: "failed", turn_id: "t1" },
  ] as unknown as Event[];
  const local = { started: true, turnState: "failed", signedIn: true };
  const compact = compactEvents(events);
  return {
    id: "run-1",
    appId: "app-1",
    target: { name: "LabLendingMarket", sourcePath: "contracts/LabLendingMarket.sol", chainId: 5042002, deployment: { address: "0xb4c00fc759aeff83f693f7c24420771d84e65a77", chainId: 5042002 } },
    threadId: "thread-secret-id",
    local,
    events: compact,
    state: recordState({ events: compact, local }),
    blind: false,
    createdAt: 1_761_600_000_000,
    updatedAt: 1_761_603_600_000,
  };
};

describe("campaign records", () => {
  it("drops streaming partials that a completion superseded and redacts signed links", () => {
    const events = record().events;
    expect(events.map((event) => event.type)).toEqual(["message", "tool_complete", "turn_state_changed"]);
    expect(JSON.stringify(events)).not.toContain("/api/artifacts/");
    expect(redact(`see ${SIGNED} and https://x.supabase.co/storage/v1/object/sign/arc-snapshots/a.json?token=t`)).toBe(
      "see <artifact link> and <artifact link>",
    );
  });

  it("renders two confirmed and one rejected finding without any session identifier", () => {
    const html = renderCampaignReport(record());
    expect(html).toContain("Finding 1: unauthorized withdrawal");
    expect(html).toContain("Finding 2: untracked borrow");
    expect(html).toContain("collateral theft");
    expect(html).toContain("violation did not reproduce");
    expect(html).toContain("+10");
    expect(html).toContain("60 of 64 budgeted");
    expect(html).toContain("<li>repay</li>");
    expect(html).toContain("sighted mode");
    expect(html).not.toContain("thread-secret-id");
    expect(html).not.toContain("/api/artifacts/");
    expect(html).toContain("testnet.explorer.arc.network/address/0xb4c0");
  });

  it("escapes report text and shows the fix verdict when the engine gave one", () => {
    const run = record();
    run.state = {
      ...run.state,
      report: {
        ...report,
        hypothesis: "<script>alert(1)</script>",
        status: "complete",
        fix_verdict: { verdict: "blocked", replayed: [{ property: "unauthorized withdrawal", trace: [], outcome: "blocked", detail: "statuses: succeeded, reverted" }] },
      },
      findings: [],
      rejected: [],
      status: "complete",
    };
    const html = renderCampaignReport(run);
    expect(html).not.toContain("<script>");
    expect(html).toContain("&lt;script&gt;");
    expect(html).toContain("fix verdict: blocked");
    expect(html).toContain("No exploit reproduced in the tested hypotheses.");
  });
});

import type { Event } from "@aomi-labs/client";

import { campaignState, type CampaignState, type LocalInput } from "./campaign-state.ts";

/** What a stored campaign says about its target; enough for a report. */
export interface RecordTarget {
  name: string;
  sourcePath: string;
  chainId: number;
  deployment?: { address: string; chainId: number } | null;
  protocol?: Array<{ name: string; address: string }> | null;
}

/**
 * A campaign as the server keeps it: the thread's events and the reduced
 * state, written as the run goes, so losing the tab or the credit balance
 * never loses the run. Never carries session secrets or signed links.
 */
export interface CampaignRecord {
  id: string;
  appId: string;
  target: RecordTarget;
  threadId?: string;
  /** The host's view used to reduce `state`, kept so a reload reduces the same way. */
  local: LocalInput;
  events: Event[];
  state: CampaignState;
  /** The agent could not read source comments (Phase 5 blind mode). */
  blind?: boolean;
  /** Credits the run consumed, when the account's balance was read at both ends. */
  cost?: { microusd: number; executions: number } | null;
  /** Credits the run was allowed to spend. */
  maxCredits?: number;
  createdAt: number;
  updatedAt: number;
}

/** Events the reducer needs; streaming partials are superseded by their completion. */
export function compactEvents(events: readonly Event[]): Event[] {
  const kept: Event[] = [];
  const completed = new Set<string>();
  for (const event of [...events].reverse()) {
    if (event.type === "tool_update") {
      const id = (event as { call_id?: string; id?: string }).call_id ?? (event as { id?: string }).id;
      if (id && completed.has(id)) continue;
    }
    if (event.type === "tool_complete") {
      const id = (event as { call_id?: string; id?: string }).call_id ?? (event as { id?: string }).id;
      if (id) completed.add(id);
    }
    kept.push(event);
  }
  return kept.reverse().map(redactEvent);
}

const SIGNED_LINK = /https?:\/\/[^\s"'<>]+\/api\/artifacts\/[^\s"'<>]+|https?:\/\/[^\s"'<>]+\/storage\/v1\/object\/sign\/[^\s"'<>]+/g;

/** Signed artifact links out of any text that will be stored or shown. */
export function redact(text: string): string {
  return text.replace(SIGNED_LINK, "<artifact link>");
}

function redactValue<T>(value: T): T {
  if (typeof value === "string") return redact(value) as T;
  if (Array.isArray(value)) return value.map(redactValue) as T;
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, redactValue(item)])) as T;
  }
  return value;
}

/** The same event with signed links removed from its text and arguments. */
export function redactEvent(event: Event): Event {
  return redactValue(event);
}

/** Reduce a record's events with the host facts it was saved with. */
export function recordState(record: Pick<CampaignRecord, "events" | "local">): CampaignState {
  return campaignState(record.events, record.local);
}

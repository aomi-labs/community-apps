import { describe, expect, it } from "vitest";

import { stripComments } from "./blind.ts";

describe("stripComments", () => {
  it("removes line, block and NatSpec comments and keeps every line", () => {
    const source = [
      "// SPDX-License-Identifier: MIT",
      "/// @notice INTENTIONAL VULNERABILITY: anyone can withdraw",
      "contract Vault {",
      "    /** @dev missing owner check */",
      "    function withdraw(uint256 amount) external { // no auth",
      "        /* multi",
      "           line */ payable(msg.sender).transfer(amount);",
      "    }",
      "}",
    ].join("\n");
    const stripped = stripComments(source);
    expect(stripped.split("\n")).toHaveLength(9);
    expect(stripped).not.toMatch(/INTENTIONAL|SPDX|owner check|no auth|multi/);
    expect(stripped.split("\n")[4]).toBe("    function withdraw(uint256 amount) external {");
    expect(stripped.split("\n")[6]).toBe(" payable(msg.sender).transfer(amount);");
  });

  it("keeps comment markers inside string literals", () => {
    const source = `string constant URL = "https://example.com/*not a comment*/"; // gone\nbytes1 c = '/'; string s = "a \\" // b";`;
    expect(stripComments(source)).toBe(
      `string constant URL = "https://example.com/*not a comment*/";\nbytes1 c = '/'; string s = "a \\" // b";`,
    );
  });
});

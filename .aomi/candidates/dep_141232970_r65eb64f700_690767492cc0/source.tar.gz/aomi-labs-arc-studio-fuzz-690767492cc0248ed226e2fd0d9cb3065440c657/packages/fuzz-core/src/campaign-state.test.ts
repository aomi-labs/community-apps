import type { Event } from "@aomi-labs/client";
import { describe, expect, it } from "vitest";

import { CampaignTrace } from "./campaign-trace.ts";
import { FINISH_PROMPT, MAX_RESUMES, campaignState, statusLabel } from "./campaign-state.ts";
import type { FuzzCampaignReport } from "./report.ts";

let sequence = 0;
const message = (sender: string, content: string) =>
  ({ type: "message", sequence: ++sequence, sender, content, turn_id: "t1" }) as unknown as Event;
const turn = (state: string) =>
  ({ type: "turn_state_changed", sequence: ++sequence, state, turn_id: "t1" }) as unknown as Event;
const tool = (name: string, result: unknown) =>
  ({
    type: "tool_complete",
    sequence: ++sequence,
    id: `call-${sequence}`,
    turn_id: "t1",
    tool_name: `arc-studio-fuzzer::${name}`,
    result: JSON.stringify(result),
  }) as unknown as Event;

const finding = {
  property: "unauthorized withdrawal",
  minimized_trace: [],
  steps: [{ label: "withdraw", actor: "attacker", function: "withdrawSupply(uint256)", status: "succeeded" as const }],
  balances: [],
  probes: [],
  reproductions: 2,
};
const report = (overrides: Partial<FuzzCampaignReport>): FuzzCampaignReport => ({
  campaign_id: "0xebdc",
  hypothesis: "supplier accounting",
  status: "exploring",
  round: 1,
  executions: 8,
  max_executions: 64,
  inconclusive_traces: 0,
  corpus_size: 4,
  frontier_size: 12,
  covered_writes: ["supply(uint256)"],
  uncovered_writes: ["borrow(uint256)"],
  behavior_coverage: [],
  findings: [],
  unconfirmed: [],
  limitations: [],
  ...overrides,
});

/** The 27 Oct Arc Lending Lab CLI run: two confirmed findings, one rejected, turn failed mid-confirmation. */
const lendingLabRun = (): Event[] => {
  sequence = 0;
  return [
    message("user", "Fuzz LabLendingMarket"),
    turn("processing"),
    tool("arc_fuzz_start", { campaign_id: "0xebdc", progress: report({ status: "exploring", findings: [] }) }),
    tool("arc_fuzz_round", {
      progress: report({
        status: "confirming",
        round: 12,
        executions: 60,
        findings: [finding, { ...finding, property: "untracked borrow" }],
        unconfirmed: [{ property: "collateral theft", trace: [], reason: "violation did not reproduce from the baseline" }],
        never_succeeded: ["repay"],
      }),
    }),
    turn("failed"),
  ];
};

describe("campaignState", () => {
  it("is ready before a run and preparing while the fork is set up", () => {
    expect(campaignState([], { started: false }).status).toBe("ready");
    expect(campaignState([], { started: false, preparing: true }).status).toBe("preparing");
    expect(statusLabel("preparing")).toBe("Preparing fork");
  });

  it("reads the 27 Oct Lending Lab run: findings, a rejected violation and untested actions", () => {
    const state = campaignState(lendingLabRun(), { started: true, turnState: "failed", signedIn: true });
    expect(state.status).toBe("finding");
    expect(state.findings.map((f) => f.property)).toEqual(["unauthorized withdrawal", "untracked borrow"]);
    expect(state.rejected.map((r) => r.property)).toEqual(["collateral theft"]);
    expect(state.notTested).toEqual(["repay"]);
    expect(state.fixVerdict).toBeNull();
    expect(state.executions).toBe(60);
    expect(state.budget).toBe(64);
    expect(state.terminal).toBe(true);
    expect(state.busy).toBe(false);
  });

  it("asks for the finish turn when the model stopped with the engine still confirming", () => {
    const events = lendingLabRun();
    events[events.length - 1] = turn("complete");
    const state = campaignState(events, { started: true, turnState: "complete", signedIn: true });
    expect(state.next).toEqual({ kind: "finish", prompt: FINISH_PROMPT, resumes: 0 });
    expect(state.status).toBe("finding");
  });

  it("does not finish a guest run, a stopped run, or past the resume limit", () => {
    const events = lendingLabRun();
    events[events.length - 1] = turn("complete");
    expect(campaignState(events, { started: true, turnState: "complete", signedIn: false }).next.kind).toBe("none");
    expect(campaignState(events, { started: true, turnState: "complete", stopped: true }).next.kind).toBe("none");
    expect(
      campaignState(events, { started: true, turnState: "complete", resumes: MAX_RESUMES, signedIn: true }).next.kind,
    ).toBe("none");
  });

  it("continues after a resumable runtime limit and reports incomplete otherwise", () => {
    sequence = 0;
    const events = [
      message("user", "Fuzz it"),
      tool("arc_fuzz_start", { campaign_id: "c1", progress: report({}) }),
      message("notice", "This run reached its execution limit. Send another message to continue."),
      turn("failed"),
    ];
    const state = campaignState(events, { started: true, turnState: "failed", resumes: 2 });
    expect(state.status).toBe("incomplete");
    expect(state.next).toEqual({ kind: "continue", prompt: CampaignTrace.CONTINUE_PROMPT, resumes: 2 });
  });

  it("fails with the backend's reason when a turn dies without a resumable notice", () => {
    sequence = 0;
    const events = [
      message("user", "Fuzz it"),
      { type: "error", sequence: ++sequence, message: "model provider unavailable" } as unknown as Event,
      turn("failed"),
    ];
    const state = campaignState(events, { started: true, turnState: "failed" });
    expect(state.status).toBe("failed");
    expect(state.error).toBe("model provider unavailable");
    expect(state.next.kind).toBe("none");
  });

  it("waits for credits instead of continuing", () => {
    const events = lendingLabRun();
    const state = campaignState(events, { started: true, turnState: "failed", paymentRequired: true });
    expect(state.status).toBe("payment_required");
    expect(state.next).toEqual({ kind: "wait_for_credits" });
  });

  it("is complete only on the engine's terminal report, and budget-limited on its budget stop", () => {
    sequence = 0;
    const done = [tool("arc_fuzz_report", report({ status: "complete", executions: 64 })), turn("complete")];
    expect(campaignState(done, { started: true, turnState: "complete" }).status).toBe("complete");
    sequence = 0;
    const spent = [tool("arc_fuzz_round", { progress: report({ status: "budget_exhausted" }) }), turn("complete")];
    const state = campaignState(spent, { started: true, turnState: "complete", signedIn: true });
    expect(state.status).toBe("budget_exhausted");
    expect(state.next.kind).toBe("none");
  });

  it("reflects the host's own transitions: running, stopping, stopped, unavailable", () => {
    expect(campaignState([], { started: true, running: true }).status).toBe("running");
    expect(campaignState([], { started: true, running: true, stopped: true }).status).toBe("stopping");
    expect(campaignState([], { started: true, stopped: true, turnState: "interrupted" }).status).toBe("stopped");
    expect(campaignState([], { started: true, threadUnavailable: true }).status).toBe("thread_unavailable");
    expect(campaignState([], { started: true, failure: "seed failed" })).toMatchObject({
      status: "failed",
      error: "seed failed",
    });
  });
});

/**
 * Solidity source with every comment removed: `//` and `/* *\/` comments,
 * NatSpec (`///`, `/** *\/`) included. String and hex literals are kept as
 * written, and every newline stays, so line numbers still match the original.
 *
 * A blind campaign gets this source, so a planted "INTENTIONAL VULNERABILITY"
 * note or a NatSpec hint cannot tell the agent where to look.
 */
export function stripComments(source: string): string {
  let out = "";
  let i = 0;
  while (i < source.length) {
    const char = source[i]!;
    const next = source[i + 1];
    if (char === '"' || char === "'") {
      // A string literal, escapes included; it ends at its quote or the line.
      let j = i + 1;
      while (j < source.length && source[j] !== char && source[j] !== "\n") j += source[j] === "\\" ? 2 : 1;
      out += source.slice(i, j + 1);
      i = j + 1;
    } else if (char === "/" && next === "/") {
      while (i < source.length && source[i] !== "\n") i++;
    } else if (char === "/" && next === "*") {
      const end = source.indexOf("*/", i + 2);
      const stop = end < 0 ? source.length : end + 2;
      out += source.slice(i, stop).replace(/[^\n]/g, "");
      i = stop;
    } else {
      out += char;
      i++;
    }
  }
  // Lines left holding only whitespace by a removed comment become empty.
  return out.replace(/[ \t]+$/gm, "");
}

import type { Event } from "@aomi-labs/client";

import { CampaignTrace } from "./campaign-trace.ts";
import type { FixVerdict, FuzzCampaignReport, FuzzFinding, UnconfirmedViolation } from "./report.ts";

/** What a campaign is doing, decided in one place for the web app and the CLI. */
export type CampaignStatus =
  | "ready"
  | "preparing"
  | "running"
  | "stopping"
  | "stopped"
  | "finding"
  | "complete"
  | "budget_exhausted"
  | "incomplete"
  | "failed"
  | "payment_required"
  | "thread_unavailable";

/** The one thing the host should do next; `none` means wait for the user. */
export type NextAction =
  | { kind: "none" }
  /** The runtime stopped the turn at a resumable limit: send the continuation. */
  | { kind: "continue"; prompt: string; resumes: number }
  /**
   * The turn ended with the engine still holding queued or unconfirmed work:
   * send the finish prompt so the model drains it and writes the report.
   */
  | { kind: "finish"; prompt: string; resumes: number }
  | { kind: "wait_for_credits" };

/** Facts only the host knows: the runtime's turn state and the user's clicks. */
export interface LocalInput {
  /** A campaign message was sent (or restored) on this thread. */
  started: boolean;
  /** The launch sequence (fork, model pin, world seed) is still running. */
  preparing?: boolean;
  /** The user pressed Stop. */
  stopped?: boolean;
  /** The runtime is submitting or processing a turn. */
  running?: boolean;
  turnState?: string | null;
  /** The saved thread is not the runtime's current thread. */
  threadUnavailable?: boolean;
  /** A launch or send failed locally. */
  failure?: string | null;
  /** The backend refused the last turn for lack of credits. */
  paymentRequired?: boolean;
  /** Automatic continuations sent so far in this run. */
  resumes?: number;
  /** A guest session is capped; its stops are not retried. */
  signedIn?: boolean;
}

export interface CampaignState {
  status: CampaignStatus;
  report: FuzzCampaignReport | null;
  findings: FuzzFinding[];
  /** Violations the engine could not reproduce, never findings. */
  rejected: UnconfirmedViolation[];
  executions: number;
  budget: number;
  /** Action labels that ran but never succeeded: their paths were not tested. */
  notTested: string[];
  /** Whether earlier findings still reproduce, when the plan replayed any. */
  fixVerdict: FixVerdict | null;
  next: NextAction;
  /** Why the campaign stopped short, when it did. */
  error: string | null;
  /** The host is busy: launching, or the runtime is processing a turn. */
  busy: boolean;
  /** The run has ended, one way or another. */
  terminal: boolean;
}

/** Automatic continuations per run, so a looping limit cannot spend forever. */
export const MAX_RESUMES = 6;

/**
 * Message that drains a campaign the model left open: no new hypotheses,
 * only the engine's pending work and the report.
 */
export const FINISH_PROMPT =
  "Finish the existing fuzz campaign without starting a new one and without revising the plan. Call arc_fuzz_report; if it returns a next_batch, execute that exact batch with sim_replay_traces and pass the traces to arc_fuzz_round, and repeat until next_batch is null. Then call arc_fuzz_report once more and write the final report from it: each confirmed finding with its minimized call order, the unconfirmed violations, the never_succeeded actions as untested, and the status at close.";

export const STATUS_LABELS: Record<CampaignStatus, string> = {
  ready: "Ready",
  preparing: "Preparing fork",
  running: "Running",
  stopping: "Stopping",
  stopped: "Stopped",
  finding: "Finding reproduced",
  complete: "Complete",
  budget_exhausted: "Budget exhausted",
  incomplete: "Incomplete",
  failed: "Failed",
  payment_required: "Needs credits",
  thread_unavailable: "Thread unavailable",
};

/** The status strip's text for a status. */
export function statusLabel(status: CampaignStatus): string {
  return STATUS_LABELS[status];
}

/**
 * The campaign's state from its thread's events plus what the host knows.
 * Pure: the same inputs always give the same state, so the web panel, a
 * server-side store and a CLI agree on what a campaign is doing.
 */
export function campaignState(events: readonly Event[] | CampaignTrace, local: LocalInput): CampaignState {
  const trace = events instanceof CampaignTrace ? events : new CampaignTrace(events);
  const report = trace.report;
  const finding = report?.findings[0];
  const resumes = local.resumes ?? 0;
  const turnState = local.turnState ?? null;
  const started = local.started;
  const busy = Boolean(local.preparing) || (started && (Boolean(local.running) || turnState === "processing"));
  const turnEnded = started && !busy && turnState !== null && turnState !== "processing";
  const turnFailed = turnEnded && (turnState === "failed" || turnState === "interrupted");
  const reportOpen = report !== null && (report.status === "exploring" || report.status === "confirming");

  let status: CampaignStatus;
  let error: string | null = null;
  if (local.threadUnavailable) status = "thread_unavailable";
  else if (local.failure) {
    status = "failed";
    error = local.failure;
  } else if (local.paymentRequired) status = "payment_required";
  else if (local.preparing) status = "preparing";
  else if (local.stopped && busy) status = "stopping";
  else if (busy) status = "running";
  else if (local.stopped) status = "stopped";
  else if (finding) status = "finding";
  else if (report?.status === "complete") status = "complete";
  else if (turnState === "interrupted") status = "stopped";
  else if (turnFailed && !trace.resumable) {
    status = "failed";
    error =
      trace.errors.at(-1) ??
      trace.notice ??
      (local.signedIn === false
        ? "The guest session hit Aomi's per-call input cap. Sign in to Aomi and run again for a complete campaign."
        : `The agent's turn ended (${turnState}) before the campaign finished.`);
  } else if (turnEnded && report?.status === "budget_exhausted") status = "budget_exhausted";
  else if (started) status = "incomplete";
  else status = "ready";

  const terminal =
    status === "complete" ||
    status === "finding" ||
    status === "stopped" ||
    status === "failed" ||
    status === "thread_unavailable";

  let next: NextAction = { kind: "none" };
  const mayResume = started && !busy && !local.stopped && !local.threadUnavailable && !local.failure && resumes < MAX_RESUMES;
  if (local.paymentRequired) next = { kind: "wait_for_credits" };
  else if (mayResume && turnEnded && trace.resumable && report?.status !== "complete") {
    next = { kind: "continue", prompt: trace.continuationPrompt, resumes };
  } else if (mayResume && turnEnded && !turnFailed && reportOpen && local.signedIn !== false) {
    // The model stopped talking with the engine still holding work. The
    // engine cannot run the world itself, so a short, plan-free turn drains it.
    next = { kind: "finish", prompt: FINISH_PROMPT, resumes };
  }

  return {
    status,
    report,
    findings: report?.findings ?? [],
    rejected: report?.unconfirmed ?? [],
    executions: report?.executions ?? 0,
    budget: report?.max_executions ?? 0,
    notTested: notTested(report),
    fixVerdict: report?.fix_verdict ?? null,
    next,
    error,
    busy,
    terminal,
  };
}

/** Action labels the engine reports as never having succeeded. */
export function notTested(report: FuzzCampaignReport | null): string[] {
  return report?.never_succeeded ?? [];
}

# Handoff: Arc Studio fuzzer (as of 2026-10-09, with PR #6)

Read `docs/how-the-fuzzer-works.md` first for the architecture. This page is the **current state and what to do next**. Owner/reviewer is Cecilia: she reviews and merges every PR and runs Project deploys. You ship changes as PRs; never merge them yourself.

## Where things live

| Thing | Location | State |
|---|---|---|
| Repo | `github.com/aomi-labs/arc-studio-fuzz` (private), local `~/Code/arc-studio-fuzz` | `main` = `256a4cc` (#1–#5, #7–#12 merged). **#6 open** (these docs). |
| Web | Cloudflare Worker `arc-studio-fuzz` (`apps/web/wrangler.jsonc`), https://fuzzer.aomi.dev | Auto-deployed on push to `main` by `.github/workflows/deploy-web.yml`. Secrets: `SESSION_SECRET`, `SUPABASE_SNAPSHOT_SERVICE_ROLE_KEY`. Server vars in `wrangler.jsonc`, public client values in `apps/web/.env.production`. |
| Aomi app | `apps/arc-studio-fuzzer`, an Aomi Build Project (`.aomi/config.json`, community platform) | **Live on staging**: release `apps-141232970-r65eb64f700-arc-studio-fuzzer-e5fb9381faec` (the #8 merge), applicationId **2937813**. Not registered on production (`chat.aomi.dev`). Deploy it from the Aomi Build UI (see gotcha 1). |
| Backend | `aomi-labs/product-mono` (`evm-sim`, runtime) | The sim commands (#1248), per-world arc-anvil (#1250), the sim stack (#1252–#1257) and the CLI activation fix (#1267) are all merged and deployed to staging. |

## Verify the stack in 2 minutes

```js
// node, from packages/fuzz-core (has @aomi-labs/client)
import { AomiClient, Session } from "@aomi-labs/client";
const base = "https://chat-staging.aomi.dev";
const app = (await new AomiClient({ baseUrl: base }).getApps()).find(a => a.name === "arc-studio-fuzzer");
console.log(app.appReleaseTag, app.artifactStatus);           // expect …e5fb9381faec ready
const s = new Session({ baseUrl: base }, { target: { mode: "direct", app: "arc-studio-fuzzer", applicationId: 2937813 }, model: "Claude Sonnet 5" });
await s.send("Do not call any tools. Reply with only the exact top-level parameter names of the arc_map_attack_surface tool schema, comma-separated.");
// expect: artifact_url, contract, source_code
```

Local dev: `node scripts/mock-arc-studio.mjs` (add `MOCK_LATENCY_MS=400` to simulate the network). Then `pnpm dev` (:3100). A second server against the mock: `ARC_STUDIO_API_URL=http://localhost:4100 NEXT_DIST_DIR=.next-mock pnpm --filter @aomi-labs/arc-studio-fuzz-web exec next dev --port 3101`. The mock token is in the script. Tests: `pnpm --filter @aomi-labs/arc-studio-fuzz-core test` (11) and `cargo test --manifest-path apps/arc-studio-fuzzer/Cargo.toml` (17). CI-equivalent for the app: `cargo fmt` plus `cargo clippy --lib -- -Dwarnings`.

## Where the e2e run stands

A signed-in run on Cecilia's real `LendingPool` gets through `arc_map_attack_surface` (via `artifact_url`) and `sim_open`. Plan validation reports every error at once (#8), and the web resumes after execution and active-work limits (#12). There's no verified finding on a real contract yet. PR #6 adds **live-deployment fuzzing** (below), which is what makes contracts like `LendingPool` meaningful. That needs a staging app deploy, then a web deploy, in that order.

## What PR #6 adds (once deployed)

- **Fuzzing the live deployment:** the website looks up the contract's latest Arc deployment through Arc Studio's `/api/deployments`, mapping `Arc Testnet` to 5042002 and `Arc` to 5042 and ignoring other chains. The deployment travels in the artifact link. The app targets that address on that chain, `setup.set_code` is null, and the constructor limitation becomes a live-state note. Actors can set `address` to act as an existing account, e.g. the real `owner()` read with `sim_call`. Arc testnet forks on staging were checked: `sim_open` 5042002 pinned block 66,251,573.
- **Smaller history:** replay calls and probes are labelled `a<N>`/`p<N>` (findings map them back to prose). `arc_fuzz_start` and `arc_fuzz_round` return compact `progress`; `arc_fuzz_report` returns everything.
- **Failure reasons:** the panel shows the runtime's notice for a failed turn. With product-mono's typed guest input limit, guests see "…Sign in to an Aomi account to continue…" instead of "couldn't respond".

## Next tasks, in order

1. **Deploy and verify PR #6.** Deploy the app to staging (Aomi Build UI, or the CLI now that #1267 is in), check `getApps` and the param probe, then deploy the web. Run one campaign on a contract Arc Studio has **deployed to Arc**.
2. **Merge the product-mono typed guest-limit PR,** then a backend deploy.
3. **Run the constructor for contracts that were never deployed** (option B: chosen args plus mock tokens and oracle), if builders fuzz before deploying.
4. **Arc Studio web sign-in (external):** ask Circle to allow our origin as a `/cli-auth` redirect.
5. **Seeded worlds (phase 3, `claude/seeded-world`):** needs product-mono #1309 on staging, then an app deploy and a web deploy. Verify with a signed-in run: the trace should show "World seeded by the harness", no `sim_open` and no `sim_set_code`. Until then the web falls back to the old flow on its own.

## Gotchas (each cost us time)

1. **Verify a deploy on staging itself, not just the deploy log.** Use `getApps` **and** the param probe. Before product-mono #1267, CLI deploys built but never activated, so staging kept serving the old release.
2. **Use the portal, not the API host.** `chat-staging.aomi.dev` issues guest and SIWE sessions. `api-staging.aomi.dev` has no auth routes, so sign-in 404s. Your shell may export `AOMI_BACKEND_URL=api-staging…` for other tools. The CLI uses `ARC_STUDIO_FUZZ_AOMI_URL` / `ARC_STUDIO_FUZZ_APPLICATION_ID` to avoid clashing with it.
3. **Hard limits:**
   - Chat messages are capped at 32,000 chars, hence artifact-by-link. The CLI can't mint links, so it only handles small contracts.
   - **Guest** model calls are capped at 64 KB of input. Sign in with SIWE.
   - 32 model calls per turn (`execution_limit_reached`). The client auto-continues up to 6×.
   - `sim_open` needs a "connected" address in user state. Use the placeholder `SIMULATION_ACCOUNT`.
4. **The artifact link is security-sensitive.** The app accepts https from the exact host `fuzzer.aomi.dev` only, with no userinfo or port, no redirects and a 4 MB bounded read. A host pattern would be squattable. The ticket is AES-GCM with a key separate from the session cookie's. Keep both properties.
5. **Generated files.** Next rewrites `apps/web/next-env.d.ts` and `tsconfig.json` when you use `NEXT_DIST_DIR`. Don't commit those changes. `packages/arc-studio-cli/dist/` **is source** (vendored from npm). Never gitignore it.
6. **Report format** follows the app (`findings` reproduced twice, `unconfirmed`, `status`). `packages/fuzz-core/src/report.ts` mirrors `campaign.rs`; change both together.

## People and sessions

- **Cecilia:** product owner. Reviews and merges, runs Project deploys and wallet sign-in. Never paste or handle her Arc Studio token or wallet.
- **Backend work** (`evm-sim`, runtime, staging logs) went through a separate session. Read root causes in staging-2 logs: `aomi_evm::simulate`, `aomi_runtime::thread`.

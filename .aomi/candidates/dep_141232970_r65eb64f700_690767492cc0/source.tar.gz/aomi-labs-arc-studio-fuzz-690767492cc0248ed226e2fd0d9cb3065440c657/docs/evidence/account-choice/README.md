# Account-choice browser acceptance — 2026-10-25

Chrome tested the real Fuzzer AomiAccount implementation and real local Portal,
Better Auth, disposable PostgreSQL, PKCE, DPoP and signed canonical-account claims.
The execution upstream is a fixture that verifies BFF assertions. No production
accounts, secrets, payments or merges were used.

| Flow | Observed result | Evidence |
|---|---|---|
| Cecilia → Continue as B | Fuzzer adopts B; Agent request HTTP 200; upstream principal B | [chooser](mismatch.png), [result](continue-b.png) |
| Portal B → Use Cecilia | Portal switches; consent completes; Fuzzer Cecilia; Agent HTTP 200 | [result](switch-cecilia.png) |
| Portal signed out | Incoming Cecilia creates Portal session; grant and Agent HTTP 200 | [prompt](portal-signed-out.png), [result](signed-out-completed.png) |
| Same account | Single account option; grant completes | [prompt](same-account.png) |
| Fuzzer signed out, Portal B | OAuth without widget bearer; Fuzzer adopts B; Agent HTTP 200 | [result](fuzzer-signed-out.png) |
| Cancel | Popup closes; original Cecilia remains selected | [result](canceled.png) |
| Portal changes after preview | Stale confirmation rejected; no new grant | [rejection](stale-session.png) |

[Redacted principal records](principals.json) verify both owners reached the
upstream through OAuth-authenticated BFF forwarding.

Browser testing caught and fixed: offline_access rejected by bootstrap policy;
native fetch called with an invalid receiver; internal Next host used for public
DPoP proof verification. Public URL binding now uses configured origin, never
caller-supplied forwarded host headers.

Automated checks include Fuzzer's 64 tests/15 files, type check and production
build with candidate packages; campaign isolation/no-auto-retry; Portal binding,
revocation/replay and session race; SDK signed identity/refresh validation;
bounded setup-route scopes; public DPoP URL; checkout account guard; candidate
SDK consumer compatibility builds.

## Scope and release gates

This is authentication E2E, not deployed Arc campaign or payment E2E. The local
host uses the production account module; workspace isolation has component tests.
Account/credit navigation is implemented, but full Portal checkout destination
was not visually accepted because browser automation stalled in the full shell.
No payment completion is claimed.

The Fuzzer PR remains draft until the dependent SDK/React/widget versions are
published, its lockfile is refreshed and a clean frozen install passes. Register
the exact managed Fuzzer origin/callback and run the matrix on the deployed
Fuzzer, including a real Arc campaign and visual account/checkout checks.
No merge, deployment or package publication was performed.

## Tested source revisions

- Portal/SDK: `ce19c11e509050f964b7df707111b167a77219c3` (aomi PR 775).
- Fuzzer: `a13d6bd183aceb419ada867497a7426cda625e25` (Fuzzer PR 47).
- The following documentation-only commit records these revisions; application code is unchanged.
- Focused Portal run: 229 tests across four files passed.

# Fuzzer credit checkout verification

Code revision: b301f43a170f596edcc479fc62dcb41df3e4d79b (PR #46).

## Automated Fuzzer recovery

63 unit tests, TypeScript, production build, and all four Playwright tests passed.
`apps/web/e2e/credits.spec.ts` drives the rendered Fuzzer: HTTP 402, no BYOK form,
checkout popup at the configured portal, no automatic resend, another rejected
retry, then the same campaign/session request accepted. Checkout and credit
availability are fixtures in this test, not provider settlement evidence.

## Staging checkout follow-up

Opened `https://chat-staging.aomi.dev/?topup=credits` in the signed-in browser.
Stripe Elements advertised `keyMode=test` for the company sandbox. Selected
500 credits ($5) and submitted Stripe's 4242 test card. Checkout reported
“500 credits added. Your balance is up to date.” Usage subsequently displayed
3,100 purchased credits ($31) and a card-payment activity entry of +500 credits.
The initial account-menu number was monthly allowance, not purchased balance;
therefore it is not evidence of the purchased-balance delta.

Screenshot: [staging success](staging-credits-added.png).

This is observed UI confirmation, not independent webhook/provider/ledger
reconciliation. The account had remaining monthly allowance. A single live
Fuzzer exhaustion → payment → retry run has not been demonstrated, and no
account balance was modified to force exhaustion. PR remains unmerged; no
Fuzzer deployment was performed.

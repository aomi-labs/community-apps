# Fuzzer account choice

The Fuzzer signs in through Aomi's Portal. Existing wallet sessions may hand off
through the shared bootstrap account chooser. Choosing the app account switches
the Portal session; choosing the Portal account changes the Fuzzer's authenticated
principal. No account merge, credit transfer or automatic campaign retry occurs.

Campaign storage and runtime state are scoped to the verified canonical account.
The connected wallet is not an OAuth identity. Existing wallet-keyed browser
history is preserved on disk but is not automatically reassigned to an account.
OAuth grants and non-exportable DPoP keys are retained together in IndexedDB.
A tab-scoped sessionStorage pointer selects the session to restore. Reload refreshes
and verifies its canonical account without opening windows or signing wallet messages.
Expired/revoked sessions require explicit sign-in. Sign-out clears the stored grant.
A connected paying wallet never selects the credit owner.
Background requests cannot open new authorization windows.

## Release dependency

Portal aomi-labs/aomi#775 is merged. Client 0.11.2, React 0.9.0 and widget
4.0.2 are published from `packages-v4.0.2` (Portal commit
`3226385237807d55aa170e04840e865427378e56`). The regenerated lockfile passes
a clean frozen registry install, type checks, 103 tests and production build.
It removes stale optional Privy/Para dependencies retained by the old lockfile.
Exact-version release-age exceptions cover only these explicitly approved releases.
No production fallback to wallet identity is allowed if OAuth configuration is missing.

Register a managed public `partner_widget` client for each environment:

- Exact redirect URI: `<Fuzzer origin>/auth/aomi`.
- Agent resource: `<Portal origin>/v1/agent`, scopes `agent:read agent:write agent:actions:resolve offline_access`.
- Account resource: `<Portal origin>/v1/account`, scopes `account:credits:read account:credits:fund payments:submit offline_access`.
- Authorization-code + refresh-token grants, PKCE S256 and DPoP required.
- Set its public ID in `NEXT_PUBLIC_AOMI_OAUTH_CLIENT_ID`.
- Do not put a client secret into browser configuration.

`/api/thread/model` and `/api/thread/sim/world` use the same selected Agent grant
as campaign calls; the Portal checks Agent write permission for these routes.
The header reuses the shared account menu. Manage account/credits opens Portal;
`+ Add credits` mounts the shared Card/USDC checkout in Fuzzer with the selected
account's authenticated transport. Successful funding refreshes the header balance,
without retrying a campaign. Switching accounts closes the old checkout.
Register the Fuzzer HTTPS domain in the company Stripe account for express-payment
eligibility; Apple Pay availability still depends on device/browser support.

Matching canonical Portal/widget accounts continue automatically. Different wallet
and Portal accounts retain the explicit chooser. If an existing OAuth Fuzzer session
and a newly authorized Portal session differ, Fuzzer refuses the switch and tells the
visitor to explicitly sign out before choosing another account.

## Browser acceptance

`apps/web/tests/account-choice.html` exercises the real account implementation
against a disposable local Portal. It requires a loopback-only fixture signer
and a managed local client; it must never run against production. Evidence must
include selected canonical IDs and successful authenticated requests, without
cookies, codes, bearers or signing material.

Required cases: same account; Portal signed out; choose app account from mismatch;
continue as Portal account; cancel; stale session; and campaign/cache isolation.

//! One session's fuzz campaign: a bounded breadth-first search over call
//! sequences, run on the host's `evm-sim` world. The app owns the search
//! (frontier, state deduplication, property checks, minimization and the
//! two-reproduction rule); the host only executes the batches it emits.

use std::collections::{BTreeMap, BTreeSet, HashMap, VecDeque};
use std::str::FromStr;

use alloy_primitives::{Address, B256, Bytes, U256, keccak256};
use aomi_sdk::schemars::JsonSchema;
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};

use crate::abi::{ContractAbi, Targets};
use crate::plan::{FuzzCall, FuzzContract, FuzzPlan, PreparedCall, PreparedPlan};
use crate::replay::{
    BASELINE, CompactTrace, ReplayBalance, ReplayBatch, ReplayProbe, ReplayStatus, ReplayTrace,
};

#[derive(Debug, Clone, Serialize, Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub(crate) struct FuzzStartArgs {
    /// Arc chain of the open simulation world: 5042 (mainnet) or 5042002 (testnet).
    pub chain_id: u64,
    #[serde(flatten)]
    pub plan: FuzzPlan,
}

#[derive(Debug, Clone, Serialize, Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub(crate) struct FuzzRoundArgs {
    /// Every compact trace from the last `sim_replay_traces` call, unchanged.
    /// Empty only when nothing is pending (status `budget_exhausted` or
    /// `complete`), to submit a revised plan.
    #[serde(default)]
    pub replay: Vec<CompactTrace>,
    /// Optional revised plan. Actors must stay identical.
    #[serde(default)]
    pub plan: Option<FuzzPlan>,
}

impl FuzzContract {
    /// The runtime bytecode, checked against the EIP-170 size limit.
    pub fn runtime(&self) -> Result<Bytes, String> {
        let code = Bytes::from_str(self.deployed_bytecode.trim())
            .map_err(|_| "deployed_bytecode must be 0x-prefixed hex".to_string())?;
        if code.is_empty() || code.len() > FuzzCampaign::MAX_RUNTIME_BYTES {
            return Err(format!(
                "deployed_bytecode must be 1..={} bytes, got {}",
                FuzzCampaign::MAX_RUNTIME_BYTES,
                code.len()
            ));
        }
        Ok(code)
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
enum Work {
    Explore(Vec<usize>),
    Minimize(Vec<usize>),
    Reproduce(Vec<usize>),
    /// Replay of a prior finding's trace, by its index in `fix_checks`.
    FixCheck(usize),
}

impl Work {
    /// Plan action indexes; empty for a fix check, whose calls are its own.
    fn trace(&self) -> &[usize] {
        match self {
            Self::Explore(trace) | Self::Minimize(trace) | Self::Reproduce(trace) => trace,
            Self::FixCheck(_) => &[],
        }
    }
}

/// A violating trace waiting to be shrunk and reproduced.
#[derive(Debug, Clone, Serialize, Deserialize)]
struct Suspect {
    property: usize,
    trace: Vec<usize>,
    /// Statuses the trace produced, so minimization drops failed steps first.
    #[serde(default)]
    statuses: Vec<ReplayStatus>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
enum Stage {
    Minimizing,
    Reproducing,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct Confirmation {
    property: usize,
    best: Vec<usize>,
    stage: Stage,
    #[serde(default)]
    statuses: Vec<ReplayStatus>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct FindingStep {
    label: String,
    actor: String,
    function: String,
    status: ReplayStatus,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct Finding {
    property: String,
    minimized_trace: Vec<FuzzCall>,
    steps: Vec<FindingStep>,
    balances: Vec<ReplayBalance>,
    probes: Vec<ReplayProbe>,
    reproductions: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct Unconfirmed {
    property: String,
    trace: Vec<FuzzCall>,
    reason: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
enum FixOutcome {
    Pending,
    /// The trace ran cleanly and violated nothing: the fix holds against it.
    Blocked,
    Reproduced,
    /// The host could not execute it, so it says nothing about the fix.
    Inconclusive,
}

/// A prior finding replayed on this build.
#[derive(Debug, Clone, Serialize, Deserialize)]
struct FixCheck {
    property: String,
    trace: Vec<FuzzCall>,
    outcome: FixOutcome,
    detail: Option<String>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
enum CampaignStatus {
    Exploring,
    Confirming,
    /// `max_executions` is spent with traces still queued; a revised plan
    /// with a larger budget resumes the search.
    BudgetExhausted,
    Complete,
}

#[derive(Debug, Serialize)]
struct Setup {
    /// Null when the code already sits in the world (a live deployment or a
    /// harness install).
    set_code: Option<Value>,
    set_balances: Vec<Value>,
    snapshot: Value,
}

// Every batch the campaign emits must fit one sim_replay_traces call.
const _: () = assert!(
    FuzzCampaign::EXPLORE_BATCH <= ReplayBatch::MAX_TRACES
        && FuzzPlan::MAX_DEPTH <= ReplayBatch::MAX_TRACES
);

pub(crate) struct FuzzCampaign {
    id: B256,
    chain_id: u64,
    contract: FuzzContract,
    targets: Targets,
    artifact: B256,
    target: Address,
    hypothesis: String,
    max_depth: usize,
    max_executions: usize,
    plan: PreparedPlan,
    pub(crate) plan_source: FuzzPlan,
    writable: BTreeSet<String>,
    frontier: VecDeque<Vec<usize>>,
    /// Explore traces already dispatched, so a breadth-first expansion that
    /// re-derives an executed scenario prefix does not run it again.
    executed: BTreeSet<Vec<usize>>,
    pending: HashMap<String, Work>,
    /// State fingerprints already expanded: the search corpus.
    expanded: BTreeSet<B256>,
    covered: BTreeSet<String>,
    /// Each action label run so far, and whether it ever succeeded. One that
    /// never does has unmet preconditions (amounts, ordering) worth revising.
    outcomes: BTreeMap<String, bool>,
    behavior: BTreeSet<String>,
    suspects: VecDeque<Suspect>,
    confirming: Option<Confirmation>,
    findings: Vec<Finding>,
    unconfirmed: Vec<Unconfirmed>,
    round: u32,
    executions: usize,
    inconclusive: usize,
    serial: u64,
    batch: Option<ReplayBatch>,
    last_round: Option<(Value, Value)>,
    /// Trace ids the last round ingested, so a re-sent batch is a retry.
    last_ids: BTreeSet<String>,
    /// Consecutive rounds each action label has sat in `never_succeeded`.
    stuck: BTreeMap<String, u32>,
    /// Times the engine has resized each action on its own.
    resized: BTreeMap<String, u32>,
    /// What the engine changed by itself, for the model and the report.
    engine_actions: Vec<String>,
    /// Prior findings replayed before the search, and their verdicts.
    fix_checks: Vec<FixCheck>,
    /// Each fix check's resolved calls; `None` when the build cannot run it.
    fix_calls: Vec<Option<Vec<PreparedCall>>>,
}

/// Mutable search state only. The artifact and derived ABI indexes are
/// reconstructed on a new worker; accepted rounds are never replayed.
#[derive(Serialize, Deserialize)]
pub(crate) struct CampaignCheckpoint {
    id: B256,
    plan_source: FuzzPlan,
    frontier: VecDeque<Vec<usize>>,
    #[serde(default)]
    executed: BTreeSet<Vec<usize>>,
    pending: HashMap<String, Work>,
    expanded: BTreeSet<B256>,
    covered: BTreeSet<String>,
    outcomes: BTreeMap<String, bool>,
    behavior: BTreeSet<String>,
    suspects: VecDeque<Suspect>,
    confirming: Option<Confirmation>,
    findings: Vec<Finding>,
    unconfirmed: Vec<Unconfirmed>,
    round: u32,
    executions: usize,
    inconclusive: usize,
    serial: u64,
    batch: Option<ReplayBatch>,
    last_round: Option<(Value, Value)>,
    #[serde(default)]
    last_ids: BTreeSet<String>,
    #[serde(default)]
    stuck: BTreeMap<String, u32>,
    #[serde(default)]
    resized: BTreeMap<String, u32>,
    #[serde(default)]
    engine_actions: Vec<String>,
    #[serde(default)]
    fix_checks: Vec<FixCheck>,
}

impl CampaignCheckpoint {
    pub fn start_args(&self, chain_id: u64) -> FuzzStartArgs {
        FuzzStartArgs {
            chain_id,
            plan: self.plan_source.clone(),
        }
    }
}

impl FuzzCampaign {
    pub fn checkpoint(&self) -> CampaignCheckpoint {
        CampaignCheckpoint {
            id: self.id,
            plan_source: self.plan_source.clone(),
            frontier: self.frontier.clone(),
            executed: self.executed.clone(),
            pending: self.pending.clone(),
            expanded: self.expanded.clone(),
            covered: self.covered.clone(),
            outcomes: self.outcomes.clone(),
            behavior: self.behavior.clone(),
            suspects: self.suspects.clone(),
            confirming: self.confirming.clone(),
            findings: self.findings.clone(),
            unconfirmed: self.unconfirmed.clone(),
            round: self.round,
            executions: self.executions,
            inconclusive: self.inconclusive,
            serial: self.serial,
            batch: self.batch.clone(),
            last_round: self.last_round.clone(),
            last_ids: self.last_ids.clone(),
            stuck: self.stuck.clone(),
            resized: self.resized.clone(),
            engine_actions: self.engine_actions.clone(),
            fix_checks: self.fix_checks.clone(),
        }
    }

    pub fn restore(
        contract: FuzzContract,
        start: FuzzStartArgs,
        saved: CampaignCheckpoint,
    ) -> Result<Self, String> {
        let mut campaign = Self::new(contract, start)?;
        campaign.plan =
            saved
                .plan_source
                .prepare(&campaign.targets, campaign.artifact, &saved.covered)?;
        campaign.hypothesis = saved.plan_source.hypothesis.clone();
        campaign.max_depth = saved.plan_source.max_depth;
        campaign.max_executions = saved.plan_source.max_executions;
        campaign.plan_source = saved.plan_source;
        campaign.id = saved.id;
        campaign.frontier = saved.frontier;
        campaign.executed = saved.executed;
        campaign.pending = saved.pending;
        campaign.expanded = saved.expanded;
        campaign.covered = saved.covered;
        campaign.outcomes = saved.outcomes;
        campaign.behavior = saved.behavior;
        campaign.suspects = saved.suspects;
        campaign.confirming = saved.confirming;
        campaign.findings = saved.findings;
        campaign.unconfirmed = saved.unconfirmed;
        campaign.round = saved.round;
        campaign.executions = saved.executions;
        campaign.inconclusive = saved.inconclusive;
        campaign.serial = saved.serial;
        campaign.batch = saved.batch;
        campaign.last_round = saved.last_round;
        campaign.last_ids = saved.last_ids;
        campaign.stuck = saved.stuck;
        campaign.resized = saved.resized;
        campaign.engine_actions = saved.engine_actions;
        if !saved.fix_checks.is_empty() {
            campaign.fix_checks = saved.fix_checks;
        }
        Ok(campaign)
    }

    pub const ARC_CHAINS: [u64; 2] = [5042, 5_042_002];
    pub const MAX_RUNTIME_BYTES: usize = 24_576;
    /// Traces per exploration batch. Every trace transits the model twice,
    /// so this stays well under the host's own limit.
    const EXPLORE_BATCH: usize = 8;
    const REPRODUCTIONS: usize = 2;
    const INSTALLED_LIMITATION: &'static str = "Installed runtime bytecode runs no constructor; its storage is only what the harness seeded (empty unless it seeded a deployment's state).";
    const DEPLOYED_LIMITATION: &'static str = "Fuzzes the live deployment with its on-chain state at the pinned block; fixed-address actors act without signatures in simulation only.";
    /// Rounds an action may sit in `never_succeeded` before the engine
    /// halves its amounts itself, and how often it does so per action.
    pub(crate) const STUCK_ROUNDS: u32 = 3;
    const MAX_RESIZES: u32 = 4;
    const STUCK_ADVICE: &'static str = "Actions in never_succeeded have unmet preconditions, so paths through them are never tested. Resize their amounts from the state you read, or add enabling steps, and send the revised plan with the next arc_fuzz_round.";
    const BUDGET_ADVICE: &'static str = "max_executions is spent while traces remain queued. To continue, call arc_fuzz_round with an empty replay and a revised plan whose max_executions is larger; otherwise report the campaign as budget-limited.";
    const LIMITATIONS: [&'static str; 2] = [
        "Coverage measures writable entrypoints and distinct observed states, not opcode coverage.",
        "A completed budget is evidence for the tested properties, not proof of contract safety.",
    ];

    pub fn new(contract: FuzzContract, args: FuzzStartArgs) -> Result<Self, String> {
        if !Self::ARC_CHAINS.contains(&args.chain_id) {
            return Err(format!(
                "Arc fuzzing supports chain {:?}, got {}",
                Self::ARC_CHAINS,
                args.chain_id
            ));
        }
        let abi = ContractAbi::parse(&contract.abi)?;
        let runtime = contract.runtime()?;
        let artifact = keccak256([contract.abi.as_bytes(), runtime.as_ref()].concat());
        let target = match &contract.deployment {
            Some(deployment) if deployment.chain_id != args.chain_id => {
                return Err(format!(
                    "this contract is deployed on chain {}; open that chain and pass chain_id {}",
                    deployment.chain_id, deployment.chain_id
                ));
            }
            Some(deployment) => deployment.target()?,
            None => Address::from_slice(&artifact[12..]),
        };
        let writable = abi.writable();
        let targets = Targets::new(&contract.name, target, abi, &contract.protocol)?;
        let plan = args.plan.prepare(&targets, artifact, &BTreeSet::new())?;
        let plan_source = args.plan.clone();
        let fix_checks = args
            .plan
            .prior_findings
            .iter()
            .zip(&plan.prior)
            .map(|(finding, prepared)| FixCheck {
                property: finding.property.clone(),
                trace: finding.trace.clone(),
                outcome: match prepared {
                    Ok(_) => FixOutcome::Pending,
                    Err(_) => FixOutcome::Blocked,
                },
                detail: prepared
                    .as_ref()
                    .err()
                    .map(|error| format!("this build cannot run the trace: {error}")),
            })
            .collect();
        let fix_calls = plan.prior.iter().map(|prepared| prepared.clone().ok()).collect();
        let mut campaign = Self {
            id: keccak256([artifact.as_slice(), args.plan.hypothesis.as_bytes()].concat()),
            chain_id: args.chain_id,
            writable,
            contract,
            targets,
            artifact,
            target,
            hypothesis: args.plan.hypothesis,
            max_depth: args.plan.max_depth,
            max_executions: args.plan.max_executions,
            plan,
            plan_source,
            frontier: VecDeque::new(),
            executed: BTreeSet::new(),
            pending: HashMap::new(),
            expanded: BTreeSet::new(),
            covered: BTreeSet::new(),
            outcomes: BTreeMap::new(),
            behavior: BTreeSet::new(),
            suspects: VecDeque::new(),
            confirming: None,
            findings: Vec::new(),
            unconfirmed: Vec::new(),
            round: 0,
            executions: 0,
            inconclusive: 0,
            serial: 0,
            batch: None,
            last_round: None,
            last_ids: BTreeSet::new(),
            stuck: BTreeMap::new(),
            resized: BTreeMap::new(),
            engine_actions: Vec::new(),
            fix_checks,
            fix_calls,
        };
        campaign.frontier = campaign
            .scenario()
            .chain((0..campaign.plan.actions.len()).map(|i| vec![i]))
            .collect();
        Ok(campaign)
    }

    /// Setup operations for the host, then the first batch.
    pub fn start(&mut self) -> Value {
        let setup = Setup {
            set_code: self.contract.deployment.is_none().then(|| {
                json!({
                    "chain_id": self.chain_id,
                    "address": format!("{:#x}", self.target),
                    "runtime_bytecode": self.contract.deployed_bytecode.trim(),
                })
            }),
            set_balances: self
                .plan
                .actors
                .iter()
                .map(|(name, actor)| {
                    json!({
                        "chain_id": self.chain_id,
                        "actor": name,
                        "address": format!("{:#x}", actor.address),
                        "balance": actor.balance.to_string(),
                    })
                })
                .collect(),
            snapshot: json!({ "label": BASELINE }),
        };
        self.batch = self.next_batch();
        json!({
            "campaign_id": self.id,
            "setup": setup,
            "next_batch": self.batch,
            "progress": self.progress(),
        })
    }

    pub fn round(&mut self, args: FuzzRoundArgs) -> Result<Value, String> {
        let request = serde_json::to_value(&args).map_err(|e| e.to_string())?;
        if let Some((previous, response)) = &self.last_round
            && previous == &request
        {
            return Ok(response.clone());
        }
        let ids: BTreeSet<String> = args.replay.iter().map(|r| r.id.clone()).collect();
        if !ids.is_empty() && ids == self.last_ids && !self.pending.is_empty() {
            // The last batch sent again while its successor is pending: a
            // retry after a lost turn. Answer as before; a revision has to
            // wait for the pending replay, which indexes the current plan.
            let mut response = self
                .last_round
                .as_ref()
                .map(|(_, response)| response.clone())
                .unwrap_or(Value::Null);
            if args.plan.is_some() {
                response["revision"] =
                    json!("deferred: send the pending batch's replay with the revised plan");
            }
            return Ok(response);
        }
        if self.pending.is_empty() && (ids.is_empty() || ids == self.last_ids) {
            // Nothing ran since the last response: a plan-only round, or the
            // last batch sent again with nothing pending. There is nothing to
            // ingest and the round count stays.
        } else {
            self.ingest(args.replay)?;
            self.round += 1;
            self.last_ids = ids;
        }
        // A path that never succeeds is never tested. After a few rounds the
        // engine resizes the stuck action itself, so the search does not wait
        // on the model to notice the advice.
        if args.plan.is_none() {
            self.resize_stuck();
        }
        // A revision re-indexes actions, which would orphan an open
        // confirmation; defer it instead of failing after ingestion.
        let revision = match args.plan {
            None => None,
            Some(_) if self.confirming.is_some() || !self.suspects.is_empty() => Some(
                "deferred: a violation is being confirmed; resend the revised plan after it completes"
                    .to_string(),
            ),
            // The replay is already ingested, so a rejected revision must not
            // fail the round: that would drop the next batch.
            Some(plan) => Some(match self.revise(plan) {
                Ok(()) => "applied".to_string(),
                Err(error) => format!("rejected, the previous plan continues: {error}"),
            }),
        };
        self.batch = self.next_batch();
        let response = json!({
            "revision": revision,
            "next_batch": self.batch,
            "progress": self.progress(),
        });
        self.last_round = Some((request, response.clone()));
        Ok(response)
    }

    /// What a round needs to steer the search, without the growing coverage
    /// lists or static text the full report carries. Every round result stays
    /// in the conversation, so this keeps history small; `arc_fuzz_report`
    /// returns everything.
    fn progress(&self) -> Value {
        json!({
            "campaign_id": self.id,
            "status": self.status(),
            "target": format!("{:#x}", self.target),
            "deployed": self.deployed(),
            "round": self.round,
            "executions": self.executions,
            "max_executions": self.max_executions,
            "inconclusive_traces": self.inconclusive,
            "corpus_size": self.expanded.len(),
            "frontier_size": self.frontier.len(),
            "uncovered_writes": self.writable.difference(&self.covered).collect::<Vec<_>>(),
            "never_succeeded": self.never_succeeded(),
            "engine_actions": self.engine_actions,
            "fix_verdict": self.fix_verdict(),
            "advice": self.advice(),
            "findings": self.findings,
            "unconfirmed": self.unconfirmed,
        })
    }

    /// Halve the amounts of every action that has sat in `never_succeeded`
    /// for `STUCK_ROUNDS` rounds, up to `MAX_RESIZES` times each, and queue
    /// the resized action at depth one. Only when nothing is being confirmed:
    /// a re-index would orphan the open confirmation.
    fn resize_stuck(&mut self) {
        if self.confirming.is_some() || !self.suspects.is_empty() {
            return;
        }
        let stuck_now: BTreeSet<String> = self
            .never_succeeded()
            .into_iter()
            .map(str::to_owned)
            .collect();
        self.stuck.retain(|label, _| stuck_now.contains(label));
        for label in &stuck_now {
            *self.stuck.entry(label.clone()).or_default() += 1;
        }
        let due: Vec<String> = self
            .stuck
            .iter()
            .filter(|(label, rounds)| {
                **rounds >= Self::STUCK_ROUNDS
                    && self.resized.get(*label).copied().unwrap_or(0) < Self::MAX_RESIZES
            })
            .map(|(label, _)| label.clone())
            .collect();
        if due.is_empty() {
            return;
        }
        let mut plan = self.plan_source.clone();
        let mut changed = Vec::new();
        for action in &mut plan.actions {
            if !due.contains(&action.label) {
                continue;
            }
            let mut halved = false;
            for argument in &mut action.arguments {
                if let Some(smaller) = Self::halve(argument) {
                    *argument = smaller;
                    halved = true;
                }
            }
            if let Some(smaller) = Self::halve(&action.value) {
                action.value = smaller;
                halved = true;
            }
            if halved {
                changed.push(action.label.clone());
            } else {
                // Nothing numeric to shrink: leave it to the model.
                self.resized.insert(action.label.clone(), Self::MAX_RESIZES);
            }
        }
        if changed.is_empty() {
            return;
        }
        match self.revise(plan) {
            Ok(()) => {
                for label in &changed {
                    *self.resized.entry(label.clone()).or_default() += 1;
                    self.stuck.insert(label.clone(), 0);
                    // The resized action is a new action to the outcome
                    // ledger; the old label's history would keep it "stuck".
                    self.outcomes.remove(label);
                }
                self.engine_actions.push(format!(
                    "round {}: halved the amounts of {} after {} rounds without a success",
                    self.round,
                    changed
                        .iter()
                        .map(|label| format!("`{label}`"))
                        .collect::<Vec<_>>()
                        .join(", "),
                    Self::STUCK_ROUNDS
                ));
            }
            Err(error) => self.engine_actions.push(format!(
                "round {}: could not resize {}: {error}",
                self.round,
                changed.join(", ")
            )),
        }
    }

    /// Half of a decimal or hex integer greater than one, as decimal.
    fn halve(text: &str) -> Option<String> {
        let value = U256::from_str(text.trim()).ok()?;
        (value > U256::from(1)).then(|| (value / U256::from(2)).to_string())
    }

    /// What the model should do about the search's state, if anything.
    fn advice(&self) -> Option<String> {
        let mut advice = Vec::new();
        if !self.never_succeeded().is_empty() {
            advice.push(Self::STUCK_ADVICE);
        }
        if self.status() == CampaignStatus::BudgetExhausted {
            advice.push(Self::BUDGET_ADVICE);
        }
        (!advice.is_empty()).then(|| advice.join(" "))
    }

    pub fn report(&self) -> Value {
        let mode = if self.deployed() {
            Self::DEPLOYED_LIMITATION
        } else {
            Self::INSTALLED_LIMITATION
        };
        let limitations: Vec<&str> = [mode].into_iter().chain(Self::LIMITATIONS).collect();
        json!({
            "campaign_id": self.id,
            "hypothesis": self.hypothesis,
            "status": self.status(),
            "round": self.round,
            "executions": self.executions,
            "max_executions": self.max_executions,
            "inconclusive_traces": self.inconclusive,
            "corpus_size": self.expanded.len(),
            "frontier_size": self.frontier.len(),
            "covered_writes": self.covered,
            "uncovered_writes": self.writable.difference(&self.covered).collect::<Vec<_>>(),
            "never_succeeded": self.never_succeeded(),
            "engine_actions": self.engine_actions,
            "fix_verdict": self.fix_verdict(),
            "behavior_coverage": self.behavior,
            "findings": self.findings,
            "unconfirmed": self.unconfirmed,
            "target": format!("{:#x}", self.target),
            "deployed": self.deployed(),
            "limitations": limitations,
            "next_batch": self.batch,
        })
    }

    /// Whether the prior findings still reproduce on this build; null when
    /// the plan replayed none. `still_reproduces` wins over everything, and
    /// the verdict is `blocked` only once every trace ran cleanly.
    fn fix_verdict(&self) -> Value {
        if self.fix_checks.is_empty() {
            return Value::Null;
        }
        let outcomes = || self.fix_checks.iter().map(|check| check.outcome);
        let verdict = if outcomes().any(|outcome| outcome == FixOutcome::Reproduced) {
            "still_reproduces"
        } else if outcomes().all(|outcome| outcome == FixOutcome::Blocked) {
            "blocked"
        } else {
            "inconclusive"
        };
        json!({ "verdict": verdict, "replayed": self.fix_checks })
    }

    /// A live deployment, as opposed to code installed at a fresh address.
    fn deployed(&self) -> bool {
        self.contract
            .deployment
            .as_ref()
            .is_some_and(|deployment| !deployment.installed)
    }

    /// Action labels that ran but never succeeded.
    fn never_succeeded(&self) -> Vec<&str> {
        self.outcomes
            .iter()
            .filter(|(_, succeeded)| !**succeeded)
            .map(|(label, _)| label.as_str())
            .collect()
    }

    fn status(&self) -> CampaignStatus {
        if self.confirming.is_some() || !self.suspects.is_empty() {
            CampaignStatus::Confirming
        } else if !self.pending.is_empty() {
            CampaignStatus::Exploring
        } else if self
            .frontier
            .iter()
            .any(|trace| !self.executed.contains(trace))
        {
            CampaignStatus::BudgetExhausted
        } else {
            CampaignStatus::Complete
        }
    }

    fn revise(&mut self, plan: FuzzPlan) -> Result<(), String> {
        let prepared = plan.prepare(&self.targets, self.artifact, &self.covered)?;
        if prepared.actors != self.plan.actors {
            return Err("a revised plan cannot change actors, addresses, or balances".into());
        }
        // Carry the search over: queued traces keep their place when every
        // action they use survives, and new actions start at depth one.
        // Re-sending an unchanged plan is therefore a no-op.
        let remap: Vec<Option<usize>> = self
            .plan
            .actions
            .iter()
            .map(|old| {
                prepared
                    .actions
                    .iter()
                    .position(|new| new.input == old.input)
            })
            .collect();
        let added = (0..prepared.actions.len())
            .filter(|new| !remap.contains(&Some(*new)))
            .map(|new| vec![new]);
        let remapped = |trace: &Vec<usize>| -> Option<Vec<usize>> {
            trace.iter().map(|old| remap[*old]).collect()
        };
        let queued: Vec<Vec<usize>> = self.scenario().filter_map(|t| remapped(&t)).collect();
        let kept: Vec<Vec<usize>> = self
            .frontier
            .drain(..)
            .filter_map(|trace| remapped(&trace))
            .chain(added)
            .collect();
        self.plan_source = plan.clone();
        self.executed = self.executed.iter().filter_map(remapped).collect();
        self.hypothesis = plan.hypothesis;
        self.max_depth = plan.max_depth;
        self.max_executions = plan.max_executions;
        self.plan = prepared;
        // A reordered scenario is the new hypothesis, so it runs first;
        // prefixes the old order already queued or run are not repeated.
        let scenario: Vec<Vec<usize>> = self
            .scenario()
            .filter(|trace| {
                !queued.contains(trace) && !kept.contains(trace) && !self.executed.contains(trace)
            })
            .collect();
        self.frontier = scenario.into_iter().chain(kept).collect();
        Ok(())
    }

    /// The plan's own order is the hypothesized attack path. Breadth-first
    /// search over many actions cannot reach a deep path within budget, so
    /// each ordered prefix of the plan is queued ahead of the search.
    fn scenario(&self) -> impl Iterator<Item = Vec<usize>> + use<> {
        let depth = self.max_depth.min(self.plan.actions.len());
        (2..=depth).map(|len| (0..len).collect())
    }

    fn confirmed(&self, property: usize) -> bool {
        let name = &self.plan.properties[property].name;
        self.findings
            .iter()
            .any(|finding| &finding.property == name)
    }

    fn next_batch(&mut self) -> Option<ReplayBatch> {
        if self.confirming.is_none() {
            while let Some(suspect) = self.suspects.pop_front() {
                if !self.confirmed(suspect.property) {
                    self.confirming = Some(Confirmation {
                        property: suspect.property,
                        best: suspect.trace,
                        stage: Stage::Minimizing,
                        statuses: suspect.statuses,
                    });
                    break;
                }
            }
        }
        let watch = self.plan.actors.len() + 1;
        let fix_checks: Vec<Work> = if self.confirming.is_none() {
            // Prior findings run before anything else, in their own batch,
            // so the verdict on a fix never waits on the search.
            let worst = ReplayBatch::MAX_CALLS + self.plan.probes.len() + 2 * watch;
            let dispatched: BTreeSet<usize> = self
                .pending
                .values()
                .filter_map(|work| match work {
                    Work::FixCheck(index) => Some(*index),
                    _ => None,
                })
                .collect();
            self.fix_checks
                .iter()
                .enumerate()
                .filter(|(index, check)| {
                    check.outcome == FixOutcome::Pending && !dispatched.contains(index)
                })
                .map(|(index, _)| Work::FixCheck(index))
                .take((ReplayBatch::MAX_EXECUTIONS / worst).clamp(1, Self::EXPLORE_BATCH))
                .collect()
        } else {
            Vec::new()
        };
        let work: Vec<Work> = match self.confirming.as_mut() {
            _ if !fix_checks.is_empty() => fix_checks,
            Some(confirmation) => {
                if confirmation.best.len() <= 1 {
                    confirmation.stage = Stage::Reproducing;
                }
                match confirmation.stage {
                    Stage::Reproducing => {
                        vec![Work::Reproduce(confirmation.best.clone()); Self::REPRODUCTIONS]
                    }
                    // Steps that failed (ran out of gas, hit an invalid
                    // opcode) are dropped first: a reproduction that needs
                    // one is not evidence about the contract.
                    Stage::Minimizing => {
                        let failed = |drop: &usize| {
                            confirmation.statuses.get(*drop) == Some(&ReplayStatus::Failed)
                        };
                        let mut drops: Vec<usize> = (0..confirmation.best.len()).collect();
                        drops.sort_by_key(|drop| !failed(drop));
                        drops
                            .into_iter()
                            .map(|drop| {
                                let mut shorter = confirmation.best.clone();
                                shorter.remove(drop);
                                Work::Minimize(shorter)
                            })
                            .collect()
                    }
                }
            }
            None => {
                let worst = self.max_depth + self.plan.probes.len() + 2 * watch;
                let capacity = (ReplayBatch::MAX_EXECUTIONS / worst)
                    .clamp(1, Self::EXPLORE_BATCH)
                    .min(self.max_executions.saturating_sub(self.executions));
                (0..capacity)
                    .map_while(|_| self.pop_unexecuted())
                    .map(Work::Explore)
                    .collect()
            }
        };
        if work.is_empty() {
            return None;
        }
        let probes: Vec<_> = self
            .plan
            .probes
            .iter()
            .enumerate()
            .map(|(index, probe)| probe.replay(format!("p{index}")))
            .collect();
        let traces = work
            .into_iter()
            .map(|work| {
                self.serial += 1;
                let id = format!("{}-{}", self.round + 1, self.serial);
                let calls = match &work {
                    Work::FixCheck(index) => self.fix_calls[*index]
                        .as_deref()
                        .unwrap_or_default()
                        .iter()
                        .enumerate()
                        .map(|(step, call)| call.replay(format!("f{step}")))
                        .collect(),
                    _ => work
                        .trace()
                        .iter()
                        .map(|index| self.plan.actions[*index].replay(format!("a{index}")))
                        .collect(),
                };
                let trace = ReplayTrace {
                    id: id.clone(),
                    calls,
                    probes: probes.clone(),
                };
                self.pending.insert(id, work);
                trace
            })
            .collect();
        Some(ReplayBatch {
            snapshot: BASELINE.to_owned(),
            chain_id: self.chain_id,
            watch: self
                .plan
                .actors
                .iter()
                .map(|(_, actor)| actor.address)
                .chain([self.target])
                .map(|address| format!("{address:#x}"))
                .collect(),
            traces,
        })
    }

    /// The next queued trace that has not run yet.
    fn pop_unexecuted(&mut self) -> Option<Vec<usize>> {
        while let Some(trace) = self.frontier.pop_front() {
            if self.executed.insert(trace.clone()) {
                return Some(trace);
            }
        }
        None
    }

    fn ingest(&mut self, replay: Vec<CompactTrace>) -> Result<(), String> {
        if self.pending.is_empty() {
            return Err("campaign has no pending replay batch".into());
        }
        if replay.len() != self.pending.len() {
            return Err(format!(
                "expected {} replayed traces, got {}; pass every compact trace unchanged",
                self.pending.len(),
                replay.len()
            ));
        }
        let ids: BTreeSet<&str> = replay.iter().map(|r| r.id.as_str()).collect();
        if ids.len() != replay.len() {
            return Err("replay repeats a trace id".into());
        }
        if let Some(unknown) = replay.iter().find(|r| !self.pending.contains_key(&r.id)) {
            return Err(format!("unknown replay trace id `{}`", unknown.id));
        }
        let observations: Vec<(Work, CompactTrace)> = replay
            .into_iter()
            .map(|report| {
                (
                    self.pending.remove(&report.id).expect("checked above"),
                    report,
                )
            })
            .collect();
        self.executions += observations.len();

        let mut evaluated = Vec::with_capacity(observations.len());
        for (work, report) in observations {
            let calls: Vec<&FuzzCall> = match &work {
                Work::FixCheck(index) => self.fix_calls[*index]
                    .as_deref()
                    .unwrap_or_default()
                    .iter()
                    .map(|call| &call.input)
                    .collect(),
                _ => work
                    .trace()
                    .iter()
                    .map(|index| &self.plan.actions[*index].input)
                    .collect(),
            };
            let conclusive = report.conclusive(calls.len());
            if !conclusive {
                self.inconclusive += 1;
            }
            let violations = if conclusive {
                self.violations(&calls, &report)
            } else {
                Vec::new()
            };
            evaluated.push((work, report, conclusive, violations));
        }

        // Fix checks come in their own batch, before any confirmation.
        if evaluated
            .iter()
            .any(|(work, ..)| matches!(work, Work::FixCheck(_)))
        {
            for (work, report, conclusive, violations) in evaluated {
                let Work::FixCheck(index) = work else { continue };
                self.settle_fix_check(index, report, conclusive, &violations);
            }
            return Ok(());
        }

        if let Some(confirmation) = self.confirming.take() {
            self.confirming = match confirmation.stage {
                Stage::Minimizing => {
                    let shorter = evaluated
                        .iter()
                        .find(|(_, _, _, violations)| violations.contains(&confirmation.property))
                        .map(|(work, report, ..)| (work.trace().to_vec(), report.statuses.clone()));
                    Some(match shorter {
                        Some((best, statuses)) => Confirmation {
                            best,
                            statuses,
                            ..confirmation
                        },
                        None => Confirmation {
                            stage: Stage::Reproducing,
                            ..confirmation
                        },
                    })
                }
                Stage::Reproducing => {
                    let reproduced = evaluated
                        .iter()
                        .all(|(_, _, _, violations)| violations.contains(&confirmation.property));
                    let calls = confirmation
                        .best
                        .iter()
                        .map(|i| self.plan.actions[*i].input.clone())
                        .collect::<Vec<_>>();
                    let property = self.plan.properties[confirmation.property].name.clone();
                    let failed_step = evaluated.iter().find_map(|(_, report, _, _)| {
                        calls
                            .iter()
                            .zip(&report.statuses)
                            .find(|(_, status)| **status == ReplayStatus::Failed)
                            .map(|(call, _)| call.label.clone())
                    });
                    if let Some(label) = failed_step.filter(|_| reproduced) {
                        // A step that failed is a call the EVM could not finish
                        // (out of gas, invalid opcode), never contract logic.
                        self.unconfirmed.push(Unconfirmed {
                            property,
                            trace: calls,
                            reason: format!(
                                "step `{label}` failed: the reproduction needs a call that did not execute cleanly, so it is not evidence about the contract"
                            ),
                        });
                    } else if reproduced {
                        let (_, report, _, _) = &evaluated[0];
                        self.findings.push(Finding {
                            property,
                            steps: calls
                                .iter()
                                .zip(&report.statuses)
                                .map(|(call, status)| FindingStep {
                                    label: call.label.clone(),
                                    actor: call.actor.clone(),
                                    function: call.function.clone(),
                                    status: *status,
                                })
                                .collect(),
                            minimized_trace: calls,
                            balances: report.balances.clone(),
                            // Replay probe labels are short ids; restore the plan's prose.
                            probes: report
                                .probes
                                .iter()
                                .map(|probe| ReplayProbe {
                                    label: probe
                                        .label
                                        .strip_prefix('p')
                                        .and_then(|i| i.parse::<usize>().ok())
                                        .and_then(|i| self.plan.probes.get(i))
                                        .map_or_else(
                                            || probe.label.clone(),
                                            |p| p.input.label.clone(),
                                        ),
                                    ..probe.clone()
                                })
                                .collect(),
                            reproductions: Self::REPRODUCTIONS,
                        });
                    } else {
                        self.unconfirmed.push(Unconfirmed {
                            property,
                            trace: calls,
                            reason: if evaluated.iter().all(|(_, _, conclusive, _)| *conclusive) {
                                "violation did not reproduce from the baseline"
                            } else {
                                "host engine error during reproduction"
                            }
                            .to_owned(),
                        });
                    }
                    None
                }
            };
            return Ok(());
        }

        for (work, report, conclusive, violations) in evaluated {
            let Work::Explore(trace) = work else { continue };
            for (index, status) in trace.iter().zip(&report.statuses) {
                let call = &self.plan.actions[*index].input;
                *self.outcomes.entry(call.label.clone()).or_default() |= status.succeeded();
                // Coverage is the contract under test's writable surface.
                if self.targets.is_primary(call.contract.as_deref()) {
                    self.covered.insert(call.function.clone());
                }
                self.behavior.insert(format!(
                    "{}:{}{}:{}",
                    call.actor,
                    call.contract
                        .as_deref()
                        .map(|name| format!("{name}."))
                        .unwrap_or_default(),
                    call.function,
                    status.as_str()
                ));
            }
            if !conclusive {
                continue;
            }
            for property in violations {
                if !self.suspects.iter().any(|s| s.property == property) {
                    self.suspects.push_back(Suspect {
                        property,
                        trace: trace.clone(),
                        statuses: report.statuses.clone(),
                    });
                }
            }
            if self.suspects.iter().any(|s| s.trace == trace) {
                continue;
            }
            let fingerprint = self.fingerprint(&trace, &report);
            if self.expanded.insert(fingerprint) && trace.len() < self.max_depth {
                for action in 0..self.plan.actions.len() {
                    let mut next = trace.clone();
                    next.push(action);
                    if !self.executed.contains(&next) {
                        self.frontier.push_back(next);
                    }
                }
            }
        }
        Ok(())
    }

    /// Settle a replayed prior finding. One that still violates a property
    /// re-enters the search as a suspect when its calls are plan actions, so
    /// it is minimized and reproduced like any other finding.
    fn settle_fix_check(
        &mut self,
        index: usize,
        report: CompactTrace,
        conclusive: bool,
        violations: &[usize],
    ) {
        let (outcome, detail) = if !conclusive {
            (
                FixOutcome::Inconclusive,
                Some("the host could not execute the trace".to_owned()),
            )
        } else if violations.is_empty() {
            let statuses: Vec<&str> = report.statuses.iter().map(|s| s.as_str()).collect();
            (
                FixOutcome::Blocked,
                Some(format!("statuses: {}", statuses.join(", "))),
            )
        } else {
            let names: Vec<&str> = violations
                .iter()
                .map(|p| self.plan.properties[*p].name.as_str())
                .collect();
            (
                FixOutcome::Reproduced,
                Some(format!("still violates {}", names.join(", "))),
            )
        };
        let check = &mut self.fix_checks[index];
        check.outcome = outcome;
        check.detail = detail;
        if outcome != FixOutcome::Reproduced {
            return;
        }
        let as_actions: Option<Vec<usize>> = self.fix_checks[index]
            .trace
            .iter()
            .map(|call| {
                self.plan.actions.iter().position(|action| {
                    (&action.input.actor, &action.input.function, &action.input.arguments, &action.input.value)
                        == (&call.actor, &call.function, &call.arguments, &call.value)
                        && self.targets.canonical(action.input.contract.as_deref())
                            == self.targets.canonical(call.contract.as_deref())
                })
            })
            .collect();
        match as_actions {
            Some(trace) => {
                self.executed.insert(trace.clone());
                for property in violations {
                    if !self.suspects.iter().any(|s| s.property == *property) {
                        self.suspects.push_back(Suspect {
                            property: *property,
                            trace: trace.clone(),
                            statuses: report.statuses.clone(),
                        });
                    }
                }
            }
            None => {
                let check = &mut self.fix_checks[index];
                check.detail = Some(format!(
                    "{}; its calls are not actions in this plan, so it was not minimized again",
                    check.detail.as_deref().unwrap_or_default()
                ));
            }
        }
    }

    /// Properties (not yet confirmed) this conclusive trace violates.
    fn violations(&self, calls: &[&FuzzCall], report: &CompactTrace) -> Vec<usize> {
        let mut out = BTreeSet::new();
        for (index, property) in self.plan.properties.iter().enumerate() {
            if self.confirmed(index) {
                continue;
            }
            let actor = format!("{:#x}", property.actor_address);
            let profit = report
                .balances
                .iter()
                .find(|balance| balance.address.eq_ignore_ascii_case(&actor))
                .and_then(|balance| {
                    let before = U256::from_str(&balance.before).ok()?;
                    let after = U256::from_str(&balance.after).ok()?;
                    Some(after.saturating_sub(before))
                })
                .unwrap_or_default();
            let violated = calls
                .iter()
                .zip(&report.statuses)
                .any(|(call, status)| property.violated_by(call, *status, profit));
            if violated {
                out.insert(index);
            }
        }
        out.into_iter().collect()
    }

    /// Identity of the state a trace reached: changed balances and probe
    /// outputs. Without probes, storage-only effects are invisible, so the
    /// call sequence and its statuses are included to avoid over-pruning.
    fn fingerprint(&self, trace: &[usize], report: &CompactTrace) -> B256 {
        let mut balances: Vec<_> = report
            .balances
            .iter()
            .map(|b| (b.address.to_ascii_lowercase(), &b.after))
            .collect();
        balances.sort();
        let sequence = self
            .plan
            .probes
            .is_empty()
            .then_some((trace, &report.statuses));
        keccak256(
            serde_json::to_vec(&(balances, &report.probes, sequence))
                .expect("fingerprint inputs serialize"),
        )
    }
}

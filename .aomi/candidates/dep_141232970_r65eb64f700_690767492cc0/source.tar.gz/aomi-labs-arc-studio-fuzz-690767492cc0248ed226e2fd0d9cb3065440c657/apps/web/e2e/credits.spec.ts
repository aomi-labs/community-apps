import { test, expect } from "@playwright/test";

test("exhausted credit opens account checkout and explicitly retries the same campaign", async ({ page, context }, testInfo) => {
  const submissions: Record<string, unknown>[] = [];
  let funded = false;
  await page.route("**/v1/agent/chat", async (route) => {
    if (route.request().method() !== "POST") return route.continue();
    submissions.push(route.request().postDataJSON());
    if (funded) return route.continue();
    return route.fulfill({ status: 402, contentType: "application/json", body: JSON.stringify({ error: "Insufficient account credits" }) });
  });
  // Checkout is external: this fixture verifies the handoff, never fabricates a payment receipt.
  await context.route("http://localhost:4128/?topup=credits", (route) => route.fulfill({
    contentType: "text/html", body: "<h1>Add credits</h1><p>Card · Apple Pay · Link · USDC</p>",
  }));
  await page.goto("/");
  await page.getByLabel("Arc Studio token").fill("origin_pat_mock_local_dev");
  await page.getByRole("button", { name: "Connect", exact: true }).click();
  await expect(page.getByText("Pick an Arc Studio app to fuzz")).toBeVisible();
  await page.goto("/apps/00000000-0000-4000-8000-00000000a11c");
  await page.getByRole("button", { name: /UnsafeVault.*built/ }).click();
  await page.getByTestId("run-aomi-fuzz").click();
  await expect(page.getByRole("heading", { name: "Add credits to continue" })).toBeVisible();
  await expect(page.getByText("Set up BYOK", { exact: true })).toHaveCount(0);
  await expect(page.getByPlaceholder("Paste LLM provider key")).toHaveCount(0);
  expect(submissions).toHaveLength(1);
  const link = page.getByRole("link", { name: "Add credits on Aomi" });
  await expect(link).toHaveAttribute("href", "http://localhost:4128/?topup=credits");
  await page.screenshot({ path: testInfo.outputPath("credit-exhausted.png"), fullPage: true });
  const popupPromise = page.waitForEvent("popup");
  await link.click();
  const popup = await popupPromise;
  await expect(popup.getByRole("heading", { name: "Add credits" })).toBeVisible();
  await popup.close();
  expect(submissions).toHaveLength(1);
  await page.getByRole("button", { name: "I’ve added credits — retry" }).click();
  await expect(page.getByRole("heading", { name: "Add credits to continue" })).toBeVisible();
  expect(submissions).toHaveLength(2);
  funded = true;
  await page.getByRole("button", { name: "I’ve added credits — retry" }).click();
  await expect(page.getByRole("heading", { name: "Add credits to continue" })).toHaveCount(0);
  await expect(page.getByRole("region", { name: "Campaign progress" })).toContainText("Planning");
  expect(submissions).toHaveLength(3);
  expect(submissions[1]).toEqual(submissions[0]);
  expect(submissions[2]).toEqual(submissions[0]);
  await page.screenshot({ path: testInfo.outputPath("credit-retry.png"), fullPage: true });
});

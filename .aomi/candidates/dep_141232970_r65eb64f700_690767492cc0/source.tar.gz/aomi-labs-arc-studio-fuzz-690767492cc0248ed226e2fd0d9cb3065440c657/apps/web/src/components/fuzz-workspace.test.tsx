import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, expect, test, vi } from "vitest";
import type { TargetData } from "@/app/actions";
import { FuzzWorkspace } from "./fuzz-workspace";

const runtime = createContext("");
const calls = vi.hoisted(() => ({ handoff: vi.fn(), send: vi.fn(), load: vi.fn(), resume: vi.fn(async () => null as { id: string; address: string; session: () => Promise<string>; client?: unknown } | null), next: 0,
  /** The server store: what `listCampaigns` returns and what `saveCampaign` received. */
  stored: [] as unknown[], saved: vi.fn(async (input: { data: Record<string, unknown> }) => ({ ok: true as const, updatedAt: 42 })) }));
vi.mock("@/app/campaign-actions", () => ({
  listCampaigns: async () => ({ ok: true, json: JSON.stringify(calls.stored) }),
  saveCampaign: calls.saved,
}));
vi.mock("@aomi-labs/react", () => ({
  AomiRuntimeProvider: ({ children }: { children: ReactNode }) => {
    const [id] = useState(() => `thread-${++calls.next}`);
    return <runtime.Provider value={id}>{children}</runtime.Provider>;
  },
}));
vi.mock("@aomi-labs/widget/host-composition", () => ({
  WidgetScope: ({ children }: { children: ReactNode }) => children,
  AomiWalletKitProvider: ({ children }: { children: ReactNode }) => children,
  useAomiWalletKit: () => ({ wallets: [] }),
  AccountAvatar: () => null,
  AccountMenu: ({ open, onManageAccount }: { open: boolean; onManageAccount: () => void }) => open ? <button onClick={onManageAccount}>Manage account</button> : null,
  CreditCheckoutDialog: () => null,
}));
vi.mock("@tanstack/react-router", () => ({ useRouter: () => ({ invalidate: vi.fn() }), Link: ({ children, to }: { children: ReactNode; to: string }) => <a href={to}>{children}</a> }));
vi.mock("@/lib/aomi-account", () => ({ AomiAccount: { resume: calls.resume, openPortal: calls.handoff }, guestSession: () => async () => null }));
vi.mock("@/app/actions", () => ({
  loadTarget: calls.load,
  prepareTargetWithProgress: async (input: unknown) => {
    const result = await calls.load(input);
    return new ReadableStream({ start(controller) {
      controller.enqueue(new TextEncoder().encode(JSON.stringify(result.ok
        ? { type: "ready", target: result.value } : { type: "error", error: result.error }) + "\n"));
      controller.close();
    } });
  },
}));
// Keep the real workspace lifecycle; substitute only the network-facing panel.
// A mounted campaign must retain its thread and continue while another is visible.
vi.mock("@/components/fuzz-panel", () => ({
  FuzzPanel: ({ target, onChange }: { target: TargetData; onChange?: (update: Record<string, unknown>) => void }) => {
    const thread = useContext(runtime);
    const [started, start] = useState(false);
    useEffect(() => {
      if (!started) return;
      onChange?.({ threadId: thread, status: "Running", resumes: 0, events: [{ type: "turn_state_changed", sequence: 1, state: "processing" }], local: { started: true } });
      const timer = setInterval(() => calls.send(target.name, thread), 20);
      return () => clearInterval(timer);
    }, [started, target.name, thread]);
    return <button onClick={() => start(true)}>{target.name} {thread} {started ? "running" : "start"}</button>;
  },
}));

const accountClient = {
  request: async () => ({ user: {} }),
  account: { getAccount: async () => ({ user: {} }), credits: { get: async () => ({ available_microusd: 0 }) } },
};
const savedRuns = new Map<string, string>();
beforeEach(() => {
  vi.stubGlobal("localStorage", { getItem: (key: string) => savedRuns.get(key) ?? null, setItem: (key: string, value: string) => savedRuns.set(key, value) });
});
afterEach(() => { cleanup(); savedRuns.clear(); calls.stored = []; vi.clearAllMocks(); vi.unstubAllGlobals(); });

test("a campaign known only to the server store is listed, and a started run is written through", async () => {
  vi.useFakeTimers({ shouldAdvanceTime: true });
  const target: TargetData = { name: "A", sourcePath: "A.sol", source: "contract A {}", abi: [], deployedBytecode: "0x00", chainId: 5042002 };
  calls.stored = [{
    id: "stored", appId: "test", target, threadId: "existing", local: { started: true, turnState: "complete", resumes: 2 },
    events: [], state: { status: "complete", report: null, findings: [], rejected: [], executions: 0, budget: 0, notTested: [], fixVerdict: null, next: { kind: "none" }, error: null, busy: false, terminal: true },
    createdAt: 1, updatedAt: 2,
  }];
  calls.load.mockResolvedValue({ ok: true, value: target });
  const props = { appId: "test", appName: "Protocol", studioUrl: "https://example.com", files: [], contracts: [{ path: "A.sol", source: target.source, contracts: ["A"], built: true }] };
  render(<QueryClientProvider client={new QueryClient()}><FuzzWorkspace {...props} /></QueryClientProvider>);
  expect(await screen.findByRole("button", { name: /A Complete/ })).toBeTruthy();
  fireEvent.click(screen.getByRole("button", { name: /A A.sol built/ }));
  fireEvent.click(await screen.findByRole("button", { name: /A thread-\d+ start/ }));
  await act(async () => { await vi.advanceTimersByTimeAsync(1_500); });
  await waitFor(() => expect(calls.saved).toHaveBeenCalled());
  const written = calls.saved.mock.calls.at(-1)![0].data;
  expect(written).toMatchObject({ appId: "test", target: { name: "A" }, local: { started: true, resumes: 0 } });
  expect((written.events as unknown[]).length).toBe(1);
  expect(JSON.stringify(written)).not.toContain("artifactUrl");
  vi.useRealTimers();
});

test("A keeps its thread and continuation through B loading and A → B → A", async () => {
  const targets = ["A", "B"].map((name) => ({
    name, sourcePath: `${name}.sol`, source: `contract ${name} {}`, abi: [],
    deployedBytecode: "0x00", chainId: 5042002,
  }));
  let resolveB!: (value: { ok: true; value: TargetData }) => void;
  calls.load.mockImplementation(async ({ data: { contract } }) => contract === "B"
    ? new Promise((resolve) => { resolveB = resolve; })
    : { ok: true, value: targets[0] });
  render(<QueryClientProvider client={new QueryClient()}><FuzzWorkspace appId="test" appName="Protocol" studioUrl="https://example.com"
    files={[]} contracts={targets.map((target) => ({ path: target.sourcePath, source: target.source,
      contracts: [target.name], built: true }))} /></QueryClientProvider>);
  fireEvent.click(screen.getByRole("button", { name: /A A.sol built/ }));
  fireEvent.click(await screen.findByRole("button", { name: /A thread-\d+ start/ }));
  const a = screen.getByRole("button", { name: /A thread-\d+ running/ }).textContent!;
  fireEvent.click(screen.getByRole("button", { name: /B B.sol built/ }));
  await waitFor(() => expect(calls.send).toHaveBeenCalledWith("A", a.split(" ")[1]));
  await act(async () => resolveB({ ok: true, value: targets[1]! }));
  fireEvent.click(await screen.findByRole("button", { name: /B thread-\d+ start/ }));
  const b = screen.getByRole("button", { name: /B thread-\d+ running/ }).textContent!;
  expect(b.split(" ")[1]).not.toBe(a.split(" ")[1]);
  fireEvent.click(screen.getByRole("button", { name: /A A.sol built/ }));
  expect(await screen.findByRole("button", { name: a })).toBeTruthy();
  await waitFor(() => expect(calls.send).toHaveBeenCalledWith("B", b.split(" ")[1]));
});

test("saved account campaigns stay listed without mounting an authenticated runtime", async () => {
  const target: TargetData = { name: "A", sourcePath: "A.sol", source: "contract A {}", abi: [], deployedBytecode: "0x00", chainId: 5042002 };
  const address = "0x8b400FaEFC043C2F68E6243e49D7dE66564D63f9";
  const key = JSON.stringify(["https://chat-staging.aomi.dev", "test", address.toLowerCase()]);
  localStorage.setItem(key, JSON.stringify([{ id: "saved", threadId: "existing", status: "Unavailable", resumes: 1, createdAt: 1, target }]));
  calls.resume.mockResolvedValueOnce({ id: address.toLowerCase(), address, client: accountClient, session: vi.fn(async () => "test-bearer") });
  calls.load.mockResolvedValue({ ok: true, value: target });
  const props = { appId: "test", appName: "Protocol", studioUrl: "https://example.com", files: [], contracts: [{ path: "A.sol", source: target.source, contracts: ["A"], built: true }] };
  render(<QueryClientProvider client={new QueryClient()}><FuzzWorkspace {...props} /></QueryClientProvider>);
  const saved = await screen.findByRole("button", { name: /A Incomplete/ });
  expect(screen.queryByRole("button", { name: /A thread-\d+/ })).toBeNull();
  expect(JSON.parse(localStorage.getItem(key)!)[0]).toMatchObject({ threadId: "existing", status: "Incomplete" });
  fireEvent.click(saved);
  expect(await screen.findByRole("button", { name: /A thread-\d+ start/ })).toBeTruthy();
});

test("closing a source tab shows its neighbour, and closing the last tab empties the viewer", async () => {
  const targets: TargetData[] = ["A", "B"].map((name) => ({
    name, sourcePath: `${name}.sol`, source: `contract ${name} {}`, abi: [], deployedBytecode: "0x00", chainId: 5042002,
  }));
  calls.load.mockImplementation(async ({ data: { contract } }) => ({ ok: true, value: targets.find((target) => target.name === contract) }));
  render(<QueryClientProvider client={new QueryClient()}><FuzzWorkspace appId="test" appName="Protocol" studioUrl="https://example.com"
    files={[]} contracts={targets.map((target) => ({ path: target.sourcePath, source: target.source, contracts: [target.name], built: true }))} /></QueryClientProvider>);
  fireEvent.click(screen.getByRole("button", { name: /A A.sol built/ }));
  fireEvent.click(screen.getByRole("button", { name: /B B.sol built/ }));
  expect(screen.getAllByRole("tab", { name: /\.sol/ }).map((tab) => tab.getAttribute("aria-selected"))).toEqual(["false", "true"]);
  fireEvent.click(screen.getByRole("button", { name: "Close B.sol" }));
  expect(screen.queryByRole("tab", { name: "B.sol" })).toBeNull();
  expect(screen.getByRole("tab", { name: "A.sol" }).getAttribute("aria-selected")).toBe("true");
  fireEvent.click(screen.getByRole("button", { name: "Close A.sol" }));
  expect(screen.queryAllByRole("tab", { name: /\.sol/ })).toHaveLength(0);
  expect(screen.getByText("Select a file to view it")).toBeTruthy();
});

test("a failed preparation is actionable and retry fetches a fresh result", async () => {
  const target: TargetData = { name: "A", sourcePath: "A.sol", source: "contract A {}", abi: [], deployedBytecode: "0x00", chainId: 5042002 };
  calls.load.mockResolvedValueOnce({ ok: false, error: "Snapshot storage unavailable" }).mockResolvedValue({ ok: true, value: target });
  render(<QueryClientProvider client={new QueryClient()}><FuzzWorkspace appId="test" appName="Protocol" studioUrl="https://example.com"
    files={[]} contracts={[{ path: target.sourcePath, source: target.source, contracts: [target.name], built: true }]} /></QueryClientProvider>);
  expect(await screen.findByRole("alert")).toHaveProperty("textContent", expect.stringContaining("Snapshot storage unavailable"));
  fireEvent.click(screen.getByRole("button", { name: "Try again" }));
  await waitFor(() => expect(screen.queryByRole("alert")).toBeNull());
  expect(calls.load).toHaveBeenCalledTimes(2);
  expect(calls.load.mock.calls[1]?.[0].data.refresh).toBe(false);
});


test("choosing Portal account B preserves A's campaigns without retrying them as B", async () => {
  const target: TargetData = { name: "A", sourcePath: "A.sol", source: "contract A {}", abi: [], deployedBytecode: "0x00", chainId: 5042002 };
  const dispose = vi.fn();
  calls.resume.mockResolvedValueOnce({ id: "canonical-a", address: "wallet-a", client: accountClient, session: vi.fn(), dispose } as never);
  calls.handoff.mockResolvedValueOnce({ id: "canonical-b", address: "canonical-b", client: accountClient, options: {}, dispose: vi.fn() });
  calls.load.mockResolvedValue({ok:true,value:target});
  const scopeA=JSON.stringify(["https://chat-staging.aomi.dev","test","canonical-a"]);
  savedRuns.set(scopeA,JSON.stringify([{id:"saved-a",threadId:"private-a",status:"Incomplete",resumes:1,createdAt:1,target}]));
  render(<QueryClientProvider client={new QueryClient()}><FuzzWorkspace appId="test" appName="Protocol" studioUrl="https://example.com" files={[]} contracts={[{path:"A.sol",source:target.source,contracts:["A"],built:true}]} /></QueryClientProvider>);
  expect(await screen.findByRole("button",{name:/A Incomplete/})).toBeTruthy();
  fireEvent.click(screen.getByRole("button",{name:/Aomi · canonica/}));
  fireEvent.click(screen.getByRole("button",{name:"Manage account"}));
  await waitFor(()=>expect(screen.queryByRole("button",{name:/A Incomplete/})).toBeNull());
  expect(JSON.parse(savedRuns.get(scopeA)!)[0].threadId).toBe("private-a");
  expect(calls.send).not.toHaveBeenCalled();
  expect(dispose).toHaveBeenCalledOnce();
});

import { createFileRoute } from "@tanstack/react-router";

// The opener consumes the PKCE code. Never relay tokens or start a campaign here.
export const Route = createFileRoute("/auth/aomi")({
  component: () => <main className="p-8">Completing Aomi sign-in… You can return to the Fuzzer.</main>,
});

import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { createContext, StrictMode, useContext, useLayoutEffect, useRef, useState } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import type { Event } from "@aomi-labs/client";
import type { Campaign } from "@/lib/campaign";
import type { TargetData } from "@/app/actions";
import type { AomiAccount } from "@/lib/aomi-account";
import { loadTarget } from "@/app/actions";
import { FuzzPanel } from "./fuzz-panel";

const submissions = vi.fn<(threadId: string, text: string) => Promise<void>>();
const models = vi.fn<(threadId: string, model: string) => Promise<void>>();
const created = vi.fn();
const setUser = vi.fn();
let activeThread = "old-busy";
let nextThread = 0;
let turnState = "idle";
let events: Event[] = [];
let paymentNotice = false;
/** The picker's state for the active thread, as the SDK reports it. */
/** What the backend's model catalog lists. */
let catalog = ["Claude Opus 5.5"];
let threadControl: { model?: string; modelMode?: "auto" | "manual" } = { model: "Claude Opus 5.5", modelMode: "manual" };

function useRuntime(local = false) {
  const [currentThreadId, select] = useState(local ? "local" : "old-busy");
  const remote = useRef(new Set(["old-busy"]));
  const committed = useRef(currentThreadId);
  useLayoutEffect(() => {
    committed.current = currentThreadId;
    activeThread = currentThreadId;
  }, [currentThreadId]);
  return {
    currentThreadId,
    // Match SDK 0.7.5: selection uses React state and the returned ID is read
    // after a microtask. A caller awaiting this alone need not have committed.
    createThread: async () => {
      created();
      if (!remote.current.has(currentThreadId)) return currentThreadId;
      select(`campaign-${++nextThread}`);
      await Promise.resolve();
      return committed.current;
    },
    // Match the SDK's render-bound sender, rather than masking the bug with a
    // stable mock that always reads the latest thread.
    sendMessage: (text: string) => {
      remote.current.add(currentThreadId);
      return submissions(currentThreadId, text);
    },
    events,
    getMessages: () => [],
    isRunning: false,
    isSubmitting: false,
    turnState,
    setUser,
    cancelGeneration: vi.fn(),
  };
}
const Runtime = createContext<ReturnType<typeof useRuntime> | null>(null);
vi.mock("@aomi-labs/react", () => ({
  useNotification: () => ({ notifications: paymentNotice ? [{ id: "credits", kind: "payment_required" }] : [], dismissNotification: () => { paymentNotice = false; } }),
  useAomiRuntime: () => {
    const value = useContext(Runtime);
    if (!value) throw new Error("Missing runtime");
    return value;
  },
  usePerThreadControl: () => ({
    actions: {
      getCurrentThreadControl: () => threadControl,
      onModelSelect: (model: string, options: { mode: "auto" | "manual" }) => {
        threadControl = { model, modelMode: options.mode };
        return models(activeThread, model);
      },
    },
  }),
}));
vi.mock("./account-surface", () => ({ useAddCredits: () => vi.fn(), useManageCredits: () => vi.fn() }));
vi.mock("@aomi-labs/widget", () => ({ AomiFrame: () => null }));
vi.mock("@/app/actions", () => ({ requestFix: vi.fn(), loadTarget: vi.fn() }));

const target = {
  name: "LendingPool",
  sourcePath: "contracts/LendingPool.sol",
  source: "contract LendingPool {}",
  abi: [{ type: "function", name: "supply", stateMutability: "nonpayable" }],
  deployedBytecode: "0x6000",
  chainId: 5042002,
  deployment: { address: "0x0000000000000000000000000000000000000001", chainId: 5042002 },
  artifactUrl: "https://arc-studio-fuzz.vercel.app/api/artifacts/test",
  immutableReferences: [], protocol: [], installedArtifactUrl: undefined,
} satisfies TargetData;

const testAccount = {
  address: "0x0000000000000000000000000000000000000002",
  session: Object.assign(async () => "test-bearer", {
    required: true as const,
    revoke: async () => {},
    signOut: async () => {},
    dispose: () => {},
    subscribe: () => () => {},
  }),
  id: "account-a", options: {}, client: {} as AomiAccount["client"],
  request: async (_method, path, options) => fetch(new URL(path, "https://backend.example"), {
    method: _method, signal: options?.signal,
    headers: { authorization: "Bearer test-bearer", "X-Session-Id": options?.sessionId ?? "", "X-Thread-Id": options?.sessionId ?? "" },
    body: options?.body === undefined ? undefined : JSON.stringify(options.body),
  }),
  dispose: () => {}, signOut: async () => {},
} satisfies AomiAccount;

function Harness({
  signedIn = true,
  local = false,
  saved,
  priorFindings,
}: {
  signedIn?: boolean;
  local?: boolean;
  saved?: Campaign;
  priorFindings?: Parameters<typeof FuzzPanel>[0]["priorFindings"];
}) {
  const runtime = useRuntime(local);
  return (
    <Runtime.Provider value={runtime}>
      <output data-testid="active-thread">{runtime.currentThreadId}</output>
      <FuzzPanel
        saved={saved}
        priorFindings={priorFindings}
        appId="test-app"
        backendUrl="https://backend.example"
        account={signedIn ? testAccount : null}
        target={target}
        onRefresh={() => {}}
      />
    </Runtime.Provider>
  );
}

const seeds: string[] = [];
/** Threads whose model was pinned on the backend before their first message. */
const pins: string[] = [];
let seedGate: Promise<void>;

beforeEach(() => {
  paymentNotice = false;
  threadControl = { model: "Claude Opus 5.5", modelMode: "manual" };
  catalog = ["Claude Opus 5.5"];
  vi.clearAllMocks();
  vi.mocked(loadTarget).mockResolvedValue({ ok: true, value: target });
  activeThread = "old-busy";
  nextThread = 0;
  turnState = "idle";
  events = [];
  seeds.length = 0;
  pins.length = 0;
  seedGate = Promise.resolve();
  submissions.mockImplementation(async (threadId) => {
    if (threadId === "old-busy") throw new Error("session busy");
  });
  models.mockResolvedValue(undefined);
  vi.stubGlobal(
    "fetch",
    vi.fn(async (input: URL, init?: RequestInit) => {
      if (input.pathname === "/api/thread/models") return Response.json(catalog);
      if (input.pathname === "/api/thread/model") {
        const headers = new Headers(init?.headers);
        expect(headers.get("X-Session-Id")).toBe(headers.get("X-Thread-Id"));
        expect(input.searchParams.get("rig")).toBe(threadControl.model);
        pins.push(headers.get("X-Thread-Id") ?? "missing");
        return Response.json({ success: true, rig: "opus-5.5" });
      }
      if (input.pathname === "/api/thread/sim/world") {
        const headers = new Headers(init?.headers);
        expect(headers.get("X-Session-Id")).toBe(headers.get("X-Thread-Id"));
        seeds.push(headers.get("X-Thread-Id") ?? "missing");
        await seedGate;
        return Response.json({ verified_code_checks: 1 });
      }
      throw new Error(`Unexpected request: ${input}`);
    }),
  );
  Element.prototype.scrollIntoView = vi.fn();
});

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

describe("campaign thread targeting", () => {
  it.each([true, false])(
    "sends initial and repeat runs to the visible fresh thread (signed in: %s)",
    async (signedIn) => {
      render(
        <StrictMode>
          <Harness signedIn={signedIn} />
        </StrictMode>,
      );
      for (const index of [1, 2]) {
        fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
        await waitFor(() => expect(submissions).toHaveBeenCalledTimes(index));
        const threadId = `campaign-${index}`;
        expect(screen.getByTestId("active-thread").textContent).toBe(threadId);
        expect(submissions.mock.calls[index - 1]?.[0]).toBe(threadId);
        expect(models.mock.calls[index - 1]).toEqual([threadId, "Claude Opus 5.5"]);
        if (signedIn) expect(seeds[index - 1]).toBe(threadId);
        if (signedIn) expect(pins[index - 1]).toBe(threadId);
        expect(screen.queryByText("session busy")).toBeNull();
        await waitFor(() => expect(screen.getByTestId("run-aomi-fuzz").hasAttribute("disabled")).toBe(false));
      }
      expect(created).toHaveBeenCalledTimes(2);
      if (!signedIn) expect(seeds).toEqual([]);
      if (!signedIn) expect(pins).toEqual([]);
    },
  );

  it("uses the initial unsent local thread when the SDK reuses it", async () => {
    render(<Harness local />);
    fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
    await waitFor(() => expect(submissions).toHaveBeenCalledTimes(1));
    expect(screen.getByTestId("active-thread").textContent).toBe("local");
    expect(submissions.mock.calls[0]?.[0]).toBe("local");
    expect(models.mock.calls[0]).toEqual(["local", "Claude Opus 5.5"]);
    expect(seeds).toEqual(["local"]);
  });

  it("disables duplicate starts and model changes while seeding is pending", async () => {
    const gate = Promise.withResolvers<void>();
    seedGate = gate.promise;
    render(<Harness />);
    const button = screen.getByTestId("run-aomi-fuzz");
    fireEvent.click(button);
    await waitFor(() => expect(seeds).toEqual(["campaign-1"]));
    expect(button.hasAttribute("disabled")).toBe(true);
    expect(screen.getByRole("combobox", { name: "Campaign model" }).hasAttribute("disabled")).toBe(true);
    fireEvent.click(button);
    expect(created).toHaveBeenCalledTimes(1);
    expect(submissions).not.toHaveBeenCalled();
    await act(async () => gate.resolve());
    await waitFor(() => expect(submissions).toHaveBeenCalledTimes(1));
    expect(submissions.mock.calls[0]?.[0]).toBe("campaign-1");
  });

  it("releases startup after a rejected send so the next campaign can retry", async () => {
    submissions.mockRejectedValueOnce(new Error("test submission failure"));
    render(<Harness />);
    fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
    await screen.findByText("test submission failure");
    expect(screen.getByTestId("run-aomi-fuzz").hasAttribute("disabled")).toBe(false);
    fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
    await waitFor(() => expect(submissions).toHaveBeenCalledTimes(2));
    expect(submissions.mock.calls[1]?.[0]).toBe("campaign-2");
    expect(screen.queryByText("test submission failure")).toBeNull();
  });
});


it("does not call a completed model turn a completed campaign without a report", async () => {
  const view = render(<Harness />);
  fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
  await waitFor(() => expect(submissions).toHaveBeenCalledTimes(1));
  turnState = "complete";
  view.rerender(<Harness />);
  expect(await screen.findByText("Turn ended · campaign incomplete")).toBeTruthy();
  expect(screen.queryByText("Campaign complete")).toBeNull();
});

describe("campaign model", () => {
  it("never offers the backend's Balanced auto routing", async () => {
    render(<Harness />);
    const picker = screen.getByRole("combobox", { name: "Campaign model" }) as HTMLSelectElement;
    await waitFor(() => expect(Array.from(picker.options, (option) => option.value)).toEqual(["Claude Opus 5.5"]));
    expect(screen.queryByText("Balanced")).toBeNull();
    expect(picker.value).toBe("Claude Opus 5.5");
  });

  it("runs a thread left on auto routing on Sonnet, pinned manually", async () => {
    threadControl = { model: "Claude Opus 5.5", modelMode: "auto" };
    catalog = ["Claude Opus 5.5", "Claude Sonnet 5.5"];
    render(<Harness />);
    fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
    await waitFor(() => expect(submissions).toHaveBeenCalledTimes(1));
    expect(models.mock.calls[0]).toEqual(["campaign-1", "Claude Sonnet 5.5"]);
    expect(threadControl).toEqual({ model: "Claude Sonnet 5.5", modelMode: "manual" });
  });
});

it("offers the result JSON only once the agent has reported", () => {
  turnState = "complete";
  render(<Harness local saved={savedRun("Incomplete")} />);
  const button = screen.getByTestId("download-result");
  expect(button.hasAttribute("disabled")).toBe(true);
  expect(screen.getByText("Export evidence")).toBeTruthy();
});

describe("cost guardrails and the finish turn", () => {
  const startedTurn = (): Event[] => [
    { type: "message", sender: "user", content: "Fuzz it", event_id: "m1", sequence: 1, turn_id: "t1", occurred_at: 1 },
    { type: "turn_state_changed", state: "processing", event_id: "e1", sequence: 2, turn_id: "t1", occurred_at: 2 },
  ] as unknown as Event[];
  const openReport = {
    campaign_id: "c1", hypothesis: "h", status: "confirming", round: 3, executions: 20, max_executions: 64,
    inconclusive_traces: 0, corpus_size: 1, frontier_size: 1, covered_writes: [], uncovered_writes: [],
    behavior_coverage: [], findings: [], unconfirmed: [], limitations: [],
  };

  it("sends the finish prompt once when the model stops with the engine still confirming", async () => {
    turnState = "complete";
    events = [
      ...startedTurn(),
      { type: "tool_complete", id: "r1", tool_name: "arc-studio-fuzzer::arc_fuzz_round", result: JSON.stringify({ progress: openReport }), event_id: "e2", sequence: 3, turn_id: "t1", occurred_at: 3 },
      { type: "turn_state_changed", state: "complete", event_id: "e3", sequence: 4, turn_id: "t1", occurred_at: 4 },
    ] as unknown as Event[];
    const view = render(<Harness local saved={savedRun("Incomplete")} />);
    await waitFor(() => expect(submissions).toHaveBeenCalledTimes(1));
    expect(submissions.mock.calls[0]?.[1]).toContain("Finish the existing fuzz campaign");
    view.rerender(<Harness local saved={savedRun("Incomplete")} />);
    expect(submissions).toHaveBeenCalledTimes(1);
  });

  it("offers a credit cap, warns at half of it and stops the run at nine tenths", async () => {
    vi.useFakeTimers({ shouldAdvanceTime: true });
    // Read on mount, at run start, then on each 30 s poll.
    const balances = [50_000_000, 50_000_000, 20_000_000, 2_000_000];
    const credits = vi.fn(async () => ({ available_microusd: balances.length > 1 ? balances.shift()! : balances[0]! }));
    const account = { ...testAccount, client: { account: { credits: { get: credits } } } as unknown as AomiAccount["client"] };
    const view = render(<Harness local signedIn={false} />);
    expect(screen.queryByRole("combobox", { name: "Credit cap per run" })).toBeNull();
    cleanup();
    const Signed = () => {
      const runtime = useRuntime(true);
      return (
        <Runtime.Provider value={runtime}>
          <FuzzPanel appId="test-app" backendUrl="https://backend.example" account={account} target={target} onRefresh={() => {}} />
        </Runtime.Provider>
      );
    };
    view.unmount();
    const signed = render(<Signed />);
    const cap = screen.getByRole("combobox", { name: "Credit cap per run" }) as HTMLSelectElement;
    expect(cap.value).toBe("5000");
    fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
    await waitFor(() => expect(submissions).toHaveBeenCalledTimes(1));
    turnState = "processing";
    events = startedTurn();
    signed.rerender(<Signed />);
    await act(async () => { await vi.advanceTimersByTimeAsync(31_000); });
    expect(screen.getByTestId("credit-warning").textContent).toContain("3,000 of the 5,000 credit cap used");
    await act(async () => { await vi.advanceTimersByTimeAsync(31_000); });
    await waitFor(() => expect(screen.getByTestId("credit-warning").textContent).toContain("the run was stopped"));
    expect(screen.getByText(/Stopped at 4,800 credits, 90% of the 5,000 credit cap/)).toBeTruthy();
    vi.useRealTimers();
  });
});

const limitedTurn = (): Event[] => [
  { type: "error", message: "execution_limit_reached", event_id: "e1", sequence: 1, turn_id: "t1", occurred_at: 1 },
  { type: "turn_state_changed", state: "failed", event_id: "e2", sequence: 2, turn_id: "t1", occurred_at: 2 },
];
const savedRun = (status: string): Campaign => ({ id: "run", threadId: "local", target, status, resumes: 0, createdAt: 1 });

it("restoring a stopped campaign never sends an automatic continuation", () => {
  turnState = "failed";
  events = limitedTurn();
  render(<Harness local saved={savedRun("Stopped")} />);
  expect(submissions).not.toHaveBeenCalled();
});

it("late events do not send a second continuation for the same stopped turn", async () => {
  turnState = "failed";
  events = limitedTurn();
  const view = render(<Harness local saved={savedRun("Incomplete")} />);
  await waitFor(() => expect(submissions).toHaveBeenCalledTimes(1));
  events = [...events, { type: "title_changed", title: "Campaign", event_id: "e3", sequence: 3, turn_id: "t1", occurred_at: 3 }];
  view.rerender(<Harness local saved={savedRun("Incomplete")} />);
  expect(submissions).toHaveBeenCalledTimes(1);
});

it.each(["http", "network"])("does not submit a campaign when explicit world seeding fails (%s)", async (kind) => {
  const original = globalThis.fetch;
  let fail = true;
  vi.stubGlobal("fetch", vi.fn(async (input: URL, init?: RequestInit) => {
    if (fail && input.pathname === "/api/thread/sim/world") {
      if (kind === "network") throw new Error("network unavailable");
      return new Response("simulation setup unavailable", { status: 503 });
    }
    return original(input, init);
  }));
  render(<Harness />);
  fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
  await screen.findByText(/Could not seed the simulation world/);
  expect(submissions).not.toHaveBeenCalled();
  expect(screen.queryByText("Continue campaign")).toBeNull();
  expect(screen.getByTestId("run-aomi-fuzz").hasAttribute("disabled")).toBe(false);
  fail = false;
  fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
  await waitFor(() => expect(submissions).toHaveBeenCalledTimes(1));
  expect(submissions.mock.calls[0]?.[0]).toBe("campaign-1");
});

it("does not submit after Stop during pending seed", async () => {
  const gate = Promise.withResolvers<void>();
  seedGate = gate.promise;
  render(<Harness />);
  fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
  await waitFor(() => expect(seeds).toEqual(["campaign-1"]));
  fireEvent.click(screen.getByText("Stop execution"));
  await act(async () => gate.resolve());
  await waitFor(() => expect(screen.getByTestId("run-aomi-fuzz").hasAttribute("disabled")).toBe(false));
  expect(submissions).not.toHaveBeenCalled();
});

it("refreshes expired links at launch and rejects a changed build", async () => {
  vi.mocked(loadTarget).mockResolvedValueOnce({ ok: true, value: { ...target, artifactUrl: "https://arc-studio-fuzz.vercel.app/api/artifacts/fresh" } });
  render(<Harness />);
  fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
  await waitFor(() => expect(submissions).toHaveBeenCalledTimes(1));
  expect(submissions.mock.calls[0]?.[1]).toContain("/artifacts/fresh");
  vi.mocked(loadTarget).mockResolvedValueOnce({ ok: true, value: { ...target, deployedBytecode: "0x6001" } });
  fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
  await screen.findByText(/compiled target changed/);
  expect(submissions).toHaveBeenCalledTimes(1);
});

it("continues unfinished work after reproducing a first finding", async () => {
  turnState = "failed";
  const result = { campaign_id: "c", status: "exploring", findings: [{ property: "p", minimized_trace: [], balances: [], probes: [] }], executions: 12, round: 3, frontier_size: 8, corpus_size: 2, uncovered_writes: [], never_succeeded: [] };
  events = [{ type: "tool_complete", sequence: 0, tool_name: "arc_fuzz_round", id: "round", result: { progress: result } } as unknown as Event, ...limitedTurn()];
  render(<Harness local saved={savedRun("Incomplete")} />);
  await waitFor(() => expect(submissions).toHaveBeenCalledTimes(1));
  expect(submissions.mock.calls[0]?.[1]).toContain("arc_fuzz_report");
});

it("hands earlier findings to the agent so the engine replays them first", async () => {
  const trace = [{ label: "bob withdraws", actor: "bob", contract: null, function: "withdraw(uint256)", arguments: ["100"], value: "0" }];
  render(<Harness priorFindings={[{ property: "unauthorized withdrawal", trace }]} />);
  fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
  await waitFor(() => expect(submissions).toHaveBeenCalledTimes(1));
  expect(submissions.mock.calls[0]?.[1]).toContain("as prior_findings exactly as given");
  expect(submissions.mock.calls[0]?.[1]).toContain('"function":"withdraw(uint256)"');
});

it("shows the fix verdict and the actions that were never tested once the agent reports", () => {
  turnState = "complete";
  const report = {
    campaign_id: "c1", hypothesis: "h", status: "complete", round: 4, executions: 30, max_executions: 64,
    inconclusive_traces: 0, corpus_size: 3, frontier_size: 0, covered_writes: [], uncovered_writes: [],
    behavior_coverage: [], findings: [], unconfirmed: [], limitations: [], never_succeeded: ["bob borrows"],
    fix_verdict: { verdict: "still_reproduces", replayed: [{ property: "unauthorized withdrawal", trace: [], outcome: "reproduced", detail: "still violates unauthorized withdrawal" }] },
  };
  events = [
    { type: "message", sender: "user", content: "Fuzz it", event_id: "m1", sequence: 1, turn_id: "t1", occurred_at: 1 },
    { type: "tool_complete", id: "r1", tool_name: "arc-studio-fuzzer::arc_fuzz_report", result: JSON.stringify(report), event_id: "e2", sequence: 2, turn_id: "t1", occurred_at: 2 },
    { type: "turn_state_changed", state: "complete", event_id: "e3", sequence: 3, turn_id: "t1", occurred_at: 3 },
  ] as unknown as Event[];
  render(<Harness local saved={savedRun("Complete")} />);
  expect(screen.getByTestId("fix-verdict").textContent).toContain("still reproduces · unauthorized withdrawal");
  expect(screen.getByTestId("not-tested").textContent).toContain("Not tested: bob borrows never succeeded");
  expect(screen.getByText("Campaign complete · no violation reproduced")).toBeTruthy();
  expect(submissions).not.toHaveBeenCalled();
});

it("launches blind by default and lets the builder opt out before the run", async () => {
  const view = render(<Harness />);
  const toggle = screen.getByRole("checkbox", { name: "Blind run" }) as HTMLInputElement;
  expect(toggle.checked).toBe(true);
  fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
  await waitFor(() => expect(submissions).toHaveBeenCalledTimes(1));
  expect(vi.mocked(loadTarget).mock.calls.at(-1)?.[0]).toMatchObject({ data: { blind: true } });
  expect((screen.getByRole("checkbox", { name: "Blind run" }) as HTMLInputElement).disabled).toBe(true);
  view.unmount();

  render(<Harness />);
  fireEvent.click(screen.getByRole("checkbox", { name: "Blind run" }));
  fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
  await waitFor(() => expect(submissions).toHaveBeenCalledTimes(2));
  expect(vi.mocked(loadTarget).mock.calls.at(-1)?.[0]).toMatchObject({ data: { blind: false } });
});

it("does not accept an older backend that ignores deployment code checks", async () => {
  const original = globalThis.fetch;
  vi.stubGlobal("fetch", vi.fn(async (input: URL, init?: RequestInit) => input.pathname === "/api/thread/sim/world" ? Response.json({}) : original(input, init)));
  render(<Harness />);
  fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
  await screen.findByText(/backend has not verified/);
  expect(submissions).not.toHaveBeenCalled();
});

it("seeds a harness protocol as the harness user without renewing an Arc Studio target", async () => {
  const seed = { forks: [{ chain_id: 5042002, overrides: [{ address: "0x1", code: "0x60" }] }] };
  const original = globalThis.fetch;
  const seeded: Array<{ authorization: string | null; body: unknown }> = [];
  vi.stubGlobal("fetch", vi.fn(async (input: URL, init?: RequestInit) => {
    if (input.pathname === "/api/thread/sim/world") {
      seeded.push({ authorization: new Headers(init?.headers).get("authorization"), body: JSON.parse(String(init?.body)) });
      // A harness seed is not checked against a deployment, so no verified_code_checks.
      return Response.json({ chain_id: 5042002, forks: [{ overrides: 1 }] });
    }
    return original(input, init);
  }));
  const runtime = { ...target, artifactUrl: undefined };
  function HarnessRun() {
    const value = useRuntime();
    return (
      <Runtime.Provider value={value}>
        <FuzzPanel
          appId="local-harness"
          backendUrl="http://127.0.0.1:3108"
          account={null}
          target={runtime}
          onRefresh={() => {}}
          harness={{ seed, backendBearer: "backend-bearer", artifactUrl: "http://127.0.0.1:3108/api/harness/artifact", contracts: ["LendingPool", "Token"] }}
        />
      </Runtime.Provider>
    );
  }
  render(<HarnessRun />);
  expect(screen.queryByText(/running as an Aomi guest/)).toBeNull();
  fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
  await waitFor(() => expect(submissions).toHaveBeenCalledTimes(1));
  expect(loadTarget).not.toHaveBeenCalled();
  expect(seeded).toEqual([{ authorization: "Bearer backend-bearer", body: seed }]);
  expect(pins).toEqual(["campaign-1"]);
  const prompt = submissions.mock.calls[0]?.[1] ?? "";
  expect(prompt).toContain("made of LendingPool, Token");
  expect(prompt).toContain("artifact_url http://127.0.0.1:3108/api/harness/artifact");
  expect(prompt).toContain("do not call sim_open or sim_set_code");
});


it("does not replay a failed campaign prompt after an unrelated later credit error", async () => {
  submissions.mockRejectedValueOnce(new Error("HTTP 500"));
  const view = render(<Harness />);
  fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
  await screen.findByText("HTTP 500");
  paymentNotice = true;
  view.rerender(<Harness />);
  expect(screen.getByRole("button", { name: "Return to campaign" })).toBeTruthy();
  expect(screen.queryByRole("button", { name: /I’ve added credits/ })).toBeNull();
  expect(submissions).toHaveBeenCalledTimes(1);
});

it("retains a credit-blocked prompt but retries only on the explicit retry action", async () => {
  submissions.mockRejectedValueOnce(Object.assign(new Error("HTTP 402"), { status: 402 }));
  const view = render(<Harness />);
  fireEvent.click(screen.getByTestId("run-aomi-fuzz"));
  await screen.findByText("HTTP 402");
  paymentNotice = true;
  view.rerender(<Harness />);
  expect(submissions).toHaveBeenCalledTimes(1);
  fireEvent.click(screen.getByRole("button", { name: /I’ve added credits/ }));
  await waitFor(() => expect(submissions).toHaveBeenCalledTimes(2));
  expect(submissions.mock.calls[1]?.[1]).toBe(submissions.mock.calls[0]?.[1]);
});

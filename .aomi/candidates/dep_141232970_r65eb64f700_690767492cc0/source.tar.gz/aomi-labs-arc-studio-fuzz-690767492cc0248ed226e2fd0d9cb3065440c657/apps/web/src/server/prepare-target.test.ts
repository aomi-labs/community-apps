import { beforeEach, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  launch: vi.fn(),
  saved: vi.fn(),
  save: vi.fn(),
  timed: vi.fn(async (_label: string, work: () => Promise<unknown>) => work()),
}));

vi.mock("@tanstack/react-start/server-only", () => ({}));
vi.mock("@/server/snapshot-store", () => ({
  launchSnapshot: mocks.launch,
  savedSnapshot: mocks.saved,
  saveSnapshot: mocks.save,
}));
vi.mock("@/server/studio-session", () => ({ StudioSession: { timed: mocks.timed } }));

import type { StudioSession } from "@/server/studio-session";
import { readPreparation } from "@/lib/preparation";
import { prepareTarget, targetPreparationStream } from "./prepare-target";

const selection = {
  appId: "11111111-1111-4111-8111-111111111111",
  sourcePath: "contracts/Vault.sol",
  contract: "Vault",
};
const target = {
  name: "Vault", sourcePath: selection.sourcePath, source: "contract Vault {}",
  abi: [], deployedBytecode: "0x6000", chainId: 5042,
};

beforeEach(() => vi.clearAllMocks());

it("launches the selected snapshot without any Arc Studio request", async () => {
  const app = vi.fn(() => { throw new Error("Arc Studio must not be called at Run"); });
  const session = { token: "arc-token", app } as unknown as StudioSession;
  mocks.launch.mockResolvedValue({ ...target, snapshotId: "pinned" });
  const result = await prepareTarget(session, { ...selection, snapshotId: "pinned", blind: true });
  expect(result.snapshotId).toBe("pinned");
  expect(mocks.launch).toHaveBeenCalledWith("arc-token", selection.appId, selection.sourcePath, selection.contract, "pinned", true);
  expect(app).not.toHaveBeenCalled();
  expect(mocks.saved).not.toHaveBeenCalled();
  expect(mocks.timed).not.toHaveBeenCalled();
});

it("reuses a saved preview and calls Arc only for an explicit refresh", async () => {
  const arc = { target: vi.fn().mockResolvedValue(target) };
  const app = vi.fn().mockResolvedValue(arc);
  const session = { token: "arc-token", app } as unknown as StudioSession;
  mocks.saved.mockResolvedValue({ ...target, snapshotId: "saved" });
  expect((await prepareTarget(session, selection)).snapshotId).toBe("saved");
  expect(app).not.toHaveBeenCalled();
  mocks.save.mockResolvedValue({ ...target, snapshotId: "new" });
  expect((await prepareTarget(session, { ...selection, refresh: true })).snapshotId).toBe("new");
  expect(arc.target).toHaveBeenCalledWith(selection.sourcePath, selection.contract);
  expect(app).toHaveBeenCalledTimes(1);
});

it("streams the saved-build check before storage finishes, without calling Arc", async () => {
  let finish!: (value: typeof target) => void;
  mocks.saved.mockReturnValue(new Promise((resolve) => { finish = resolve; }));
  const app = vi.fn();
  const stream = targetPreparationStream({ token: "arc-token", app } as unknown as StudioSession, selection);
  const reader = stream.getReader();
  expect(new TextDecoder().decode((await reader.read()).value)).toContain('"stage":"snapshot"');
  finish(target);
  expect(new TextDecoder().decode((await reader.read()).value)).toContain('"type":"ready"');
  expect(app).not.toHaveBeenCalled();
});

it("reports only the upstream stages it executes, then the saved result", async () => {
  const arc = { target: vi.fn().mockResolvedValue({ ...target, deployment: { address: "0x1" } }), protocol: vi.fn().mockResolvedValue([]) };
  const current = { token: "arc-token", app: vi.fn().mockResolvedValue(arc) } as unknown as StudioSession;
  mocks.saved.mockResolvedValue(null);
  mocks.save.mockResolvedValue(target);
  const stages: string[] = [];
  const result = await readPreparation(targetPreparationStream(current, selection), (stage) => stages.push(stage));
  expect(stages).toEqual(["snapshot", "studio", "protocol", "save"]);
  expect(result).toEqual({ type: "ready", target });
});

it("stops at the failed stage and sends its error instead of a ready result", async () => {
  mocks.saved.mockResolvedValue(null);
  const arc = { target: vi.fn().mockRejectedValue(new Error("Arc Studio is unavailable")) };
  const current = { token: "arc-token", app: vi.fn().mockResolvedValue(arc) } as unknown as StudioSession;
  const stages: string[] = [];
  const result = await readPreparation(targetPreparationStream(current, selection), (stage) => stages.push(stage));
  expect(stages).toEqual(["snapshot", "studio"]);
  expect(result).toMatchObject({ type: "error", error: "Arc Studio is unavailable" });
  expect(mocks.save).not.toHaveBeenCalled();
});

it("does not proceed to Arc Studio after the preparation stream is cancelled", async () => {
  let finish!: (value: null) => void;
  mocks.saved.mockReturnValue(new Promise((resolve) => { finish = resolve; }));
  const app = vi.fn();
  const reader = targetPreparationStream({ token: "arc-token", app } as unknown as StudioSession, selection).getReader();
  await reader.read();
  await reader.cancel();
  finish(null);
  await new Promise((resolve) => setTimeout(resolve, 0));
  expect(app).not.toHaveBeenCalled();
  expect(mocks.save).not.toHaveBeenCalled();
});

"use client";
import { useAomiRuntime, usePerThreadControl } from "@aomi-labs/react";
import { useEffect, useState } from "react";

// The run's settings above the panel: model, credit cap and blind mode.

/**
 * Sonnet first: the backend's "Balanced" auto routing and Opus both stalled or
 * errored on the campaign prompt in the Arc Lending Lab runs, Sonnet finished.
 */
export const FALLBACK_MODELS = ["Claude Sonnet 5.5", "Claude Opus 5.5"];
/** Models a campaign runs on when nothing valid was picked, in order of preference. */
const DEFAULT_MODELS = [process.env.NEXT_PUBLIC_AOMI_MODEL, ...FALLBACK_MODELS].filter(
  (model): model is string => Boolean(model),
);

/** Credits a run may spend unless the user picks another cap (1 credit = 10,000 microUSD). */
export const DEFAULT_MAX_CREDITS = 5_000;
export const CREDIT_CAPS = [1_000, 2_500, 5_000, 10_000];
export const MICROUSD_PER_CREDIT = 10_000;
/** Spend fractions of the cap at which the panel warns, then stops the run itself. */
export const WARN_AT = 0.5;
export const STOP_AT = 0.9;

export function credits(microusd: number): string {
  return Math.max(0, Math.round(microusd / MICROUSD_PER_CREDIT)).toLocaleString("en-US");
}

export function CampaignCapSelect({ value, disabled, onChange }: { value: number; disabled: boolean; onChange: (cap: number) => void }) {
  return (
    <select
      aria-label="Credit cap per run"
      disabled={disabled}
      value={value}
      onChange={(event) => onChange(Number(event.target.value))}
      className="h-8 rounded-pill border border-border bg-bg px-2.5 text-[11px] text-ink outline-none hover:bg-hover disabled:cursor-not-allowed disabled:opacity-50"
    >
      {(CREDIT_CAPS.includes(value) ? CREDIT_CAPS : [...CREDIT_CAPS, value].sort((a, b) => a - b)).map((cap) => (
        <option key={cap} value={cap}>
          cap {cap.toLocaleString("en-US")} credits
        </option>
      ))}
    </select>
  );
}

/** Blind runs hand the agent the source without comments, so planted hints cannot steer it. */
export function CampaignBlindToggle({ value, disabled, onChange }: { value: boolean; disabled: boolean; onChange: (blind: boolean) => void }) {
  return (
    <label
      title="Strip comments and NatSpec from the source the agent reads, so hints in comments cannot steer it"
      className={`flex h-8 shrink-0 items-center gap-1.5 rounded-pill border border-border bg-bg px-2.5 text-[11px] text-ink ${disabled ? "opacity-50" : "cursor-pointer hover:bg-hover"}`}
    >
      <input
        type="checkbox"
        aria-label="Blind run"
        checked={value}
        disabled={disabled}
        onChange={(event) => onChange(event.target.checked)}
        className="size-3 accent-current"
      />
      blind
    </label>
  );
}

/** The model a campaign would run on now: the picker's choice when the catalog still lists it. */
export function campaignModel(picked: string | null | undefined, catalog: readonly string[]): string {
  return (
    [picked, ...DEFAULT_MODELS].find((model): model is string => Boolean(model && catalog.includes(model))) ??
    catalog[0] ??
    DEFAULT_MODELS[0]
  );
}

/** The backend's current catalog, or the bundled list when it cannot be read. */
export async function modelCatalog(backendUrl: string, threadId: string, signal?: AbortSignal): Promise<string[]> {
  const url = new URL("/api/thread/models", backendUrl);
  const response = await fetch(url, { headers: { "X-Session-Id": threadId, "X-Thread-Id": threadId }, signal });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  const available = (await response.json()) as unknown;
  if (Array.isArray(available) && available.every((model) => typeof model === "string") && available.length > 0) {
    return available;
  }
  return FALLBACK_MODELS;
}

export function CampaignModelSelect({ backendUrl, disabled }: { backendUrl: string; disabled: boolean }) {
  const { currentThreadId } = useAomiRuntime();
  const {
    actions: { getCurrentThreadControl, onModelSelect },
  } = usePerThreadControl();
  const [models, setModels] = useState(FALLBACK_MODELS);
  const control = getCurrentThreadControl();
  // "Balanced" (the backend's auto routing) is not offered: its first choice
  // stalls on the campaign prompt. A thread without a pin shows the model the
  // run would pick.
  const value = campaignModel(control.modelMode === "auto" ? undefined : control.model, models);

  useEffect(() => {
    const controller = new AbortController();
    void modelCatalog(backendUrl, currentThreadId, controller.signal)
      .then(setModels)
      .catch((error: unknown) => {
        if (!(error instanceof DOMException && error.name === "AbortError")) {
          console.warn("Could not refresh the Aomi model catalog; using the bundled list.", error);
        }
      });
    return () => controller.abort();
  }, [backendUrl, currentThreadId]);

  return (
    <select
      aria-label="Campaign model"
      disabled={disabled}
      value={value}
      onChange={(event) => void onModelSelect(event.target.value, { mode: "manual" })}
      className="h-8 max-w-40 rounded-pill border border-border bg-bg px-2.5 text-[11px] text-ink outline-none hover:bg-hover disabled:cursor-not-allowed disabled:opacity-50"
    >
      {!models.includes(value) && <option value={value}>{value}</option>}
      {models.map((model) => (
        <option key={model} value={model}>
          {model}
        </option>
      ))}
    </select>
  );
}

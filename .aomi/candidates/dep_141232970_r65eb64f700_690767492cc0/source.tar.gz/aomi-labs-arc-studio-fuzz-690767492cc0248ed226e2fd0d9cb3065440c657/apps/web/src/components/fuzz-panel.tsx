"use client";
import { useAddCredits, useManageCredits } from "./account-surface";

import {
  ArcStudioApp,
  CampaignTrace,
  FuzzTarget,
  INSTALL_ADDRESS,
  campaignState,
  priorFindingsPrompt,
  statusLabel,
  type PriorFinding,
  type SeedWorld,
} from "@aomi-labs/arc-studio-fuzz-core";
import { useAomiRuntime, useNotification, usePerThreadControl } from "@aomi-labs/react";
import { AomiFrame } from "@aomi-labs/widget";
import { WidgetScope } from "@aomi-labs/widget/host-composition";
import {
  AlertTriangle,
  Check,
  ChevronRight,
  CircleDot,
  ExternalLink,
  Play,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  Wrench,
  X,
} from "lucide-react";
import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState, useTransition } from "react";
import { createPortal, flushSync } from "react-dom";

import { AomiMark } from "@/components/brand";
import {
  CampaignBlindToggle,
  CampaignCapSelect,
  CampaignModelSelect,
  DEFAULT_MAX_CREDITS,
  FALLBACK_MODELS,
  MICROUSD_PER_CREDIT,
  STOP_AT,
  WARN_AT,
  campaignModel,
  credits,
  modelCatalog,
} from "@/components/campaign-controls";
import { CampaignExplorer, CampaignProgress } from "@/components/campaign-explorer";
import { FixVerdictBadge, NotTested, VerifiedFinding, short } from "@/components/campaign-findings";
import { ErrorBoundary, errorText } from "@/components/error-boundary";
import { campaignError, type Campaign } from "@/lib/campaign";
import { loadTarget, requestFix, type TargetData } from "@/app/actions";
import type { AomiAccount } from "@/lib/aomi-account";

export { CREDIT_CAPS, DEFAULT_MAX_CREDITS, campaignModel } from "@/components/campaign-controls";

/** Save `value` as a JSON file through the browser's download flow. */
function download(filename: string, value: unknown): void {
  const url = URL.createObjectURL(new Blob([JSON.stringify(value, null, 2)], { type: "application/json" }));
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

function pretty(value: unknown): string {
  if (value === undefined) return "";
  const output = typeof value === "string" ? value : JSON.stringify(value, null, 2);
  return output.length > 1_200 ? `${output.slice(0, 1_200)}\n…` : output;
}

function messageText(content: unknown): string {
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    return content
      .map((item) => (item && typeof item === "object" ? (item as { text?: unknown }).text : undefined))
      .filter((item): item is string => typeof item === "string")
      .join("\n");
  }
  return pretty(content);
}

/**
 * A whole protocol the local harness seeds into the thread's world instead of
 * one Arc Studio contract (the development-only /harness page).
 */
export interface HarnessLaunch {
  seed: SeedWorld;
  /** User bearer for the backend's thread routes (model pin, world seeding). */
  backendBearer: string;
  /** Where the fuzzer app downloads the artifact. */
  artifactUrl: string;
  /** Every contract in the seeded world, the target first. */
  contracts: string[];
}

export function FuzzPanel({
  appId,
  backendUrl,
  applicationId,
  account,
  target: data,
  onRefresh,
  harness,
  visible = true,
  saved,
  onChange,
  onNew,
  onSource,
  activityHost,
  maxCredits = DEFAULT_MAX_CREDITS,
  estimate,
  priorFindings = [],
}: {
  appId: string;
  backendUrl: string;
  /** The arc-studio-fuzzer application campaigns are pinned to, when the host fixes one. */
  applicationId?: number;
  /** Signed-in runs seed the world first; guests hit the per-call input cap partway through. */
  account: AomiAccount | null;
  target: TargetData;
  onRefresh: () => void;
  /** Seed this protocol as the harness user instead of running as `account`. */
  harness?: HarnessLaunch;
  visible?: boolean;
  saved?: Campaign;
  onChange?: (update: Partial<Campaign>) => void;
  onNew?: () => void;
  onSource?: (name: string, contract?: string | null) => void;
  /**
   * Where the workspace shows a running campaign's activity (the wide
   * "Campaign activity" section); the panel itself then keeps only the chat.
   * Without it everything renders inside the panel, chat as a tab.
   */
  activityHost?: HTMLElement | null;
  /** Credits this run may spend; the backend stops the turn at the cap. */
  maxCredits?: number;
  /** What recent runs on this app cost, from the campaign store. */
  estimate?: { microusd: number; runs: number } | null;
  /** Findings earlier campaigns confirmed on this target; the engine replays them first. */
  priorFindings?: readonly PriorFinding[];
}) {
  const addCredits = useAddCredits();
  const manageCredits = useManageCredits();
  const runtime = useAomiRuntime();
  const { createThread, events, getMessages, isRunning, isSubmitting, setUser, turnState } = runtime;
  const { notifications, dismissNotification } = useNotification();
  const paymentRequired = notifications.find((notice) => notice.kind === "payment_required");
  const lastSubmission = useRef("");
  const sendMessage = useCallback(
    (message: string) => {
      lastSubmission.current = message;
      return runtime.sendMessage(message).then(() => { lastSubmission.current = ""; })
        .catch((error: unknown) => {
          if (!(error instanceof Error && "status" in error && error.status === 402)) lastSubmission.current = "";
          throw error;
        });
    },
    [runtime.sendMessage],
  );
  const committedRuntime = useRef(runtime);
  useLayoutEffect(() => {
    committedRuntime.current = runtime;
  }, [runtime]);
  const starting = useRef(false);
  const launch = useRef<AbortController | null>(null);
  useEffect(() => () => launch.current?.abort(), []);
  const [preparing, setPreparing] = useState(false);

  const signedIn = Boolean(account) || Boolean(harness);
  const providerLabel = harness ? "Local harness" : "Arc Studio app";
  const threadControl = usePerThreadControl();
  const {
    actions: { getCurrentThreadControl },
  } = threadControl;
  // As with the runtime above: read and write the control through the object
  // committed after the campaign thread became active.
  const committedControl = useRef(threadControl);
  useLayoutEffect(() => {
    committedControl.current = threadControl;
  }, [threadControl]);
  const target = useMemo(
    () =>
      new FuzzTarget(
        data.name,
        data.sourcePath,
        data.source,
        data.abi,
        data.deployedBytecode,
        data.chainId,
        data.deployment,
        data.immutableReferences,
      ),
    [data],
  );
  const [started, setStarted] = useState(Boolean(saved?.threadId));
  /** Automatic "continue" messages sent after execution-limit stops in this run. */
  const [resumes, setResumes] = useState(saved?.resumes ?? 0);
  const [follow, setFollow] = useState(true);
  const docked = started && Boolean(activityHost);
  /** Comments are stripped from the agent's copy of the source unless the builder opts out. */
  const [blind, setBlind] = useState(saved?.blind ?? true);
  const [stopped, setStopped] = useState(saved?.status === "Stopped" || saved?.status === "Stopping");
  const continued = useRef<string | undefined>(undefined);
  const change = useRef(onChange);
  change.current = onChange;
  /** Tool calls, every runtime event, or the canonical Aomi conversation. */
  const [view, setView] = useState<"tree" | "tools" | "ledger" | "chat">("tree");
  // Once the chat moves into the panel, the activity's chat tab is gone.
  useEffect(() => {
    if (docked) setView((current) => (current === "chat" ? "tree" : current));
  }, [docked]);
  const [failure, setFailure] = useState<string | null>(null);
  const [targetChanged, setTargetChanged] = useState(false);
  /** This run's world was seeded by the harness rather than set up in the chat. */
  const [seeded, setSeeded] = useState(false);
  const [fix, setFix] = useState<{ webUrl?: string; error?: string } | null>(null);
  const [fixing, startFix] = useTransition();
  const traceEnd = useRef<HTMLDivElement>(null);

  const trace = useMemo(() => new CampaignTrace(events), [events]);
  const { report, finding } = trace;
  const wrongThread = Boolean(saved?.threadId && runtime.currentThreadId !== saved.threadId);
  // Everything the campaign "is" comes from one pure function in fuzz-core,
  // so the server store and the CLI read the same status as this panel.
  const state = useMemo(
    () =>
      campaignState(trace, {
        started,
        preparing,
        stopped,
        running: isSubmitting || isRunning,
        turnState,
        threadUnavailable: wrongThread,
        failure,
        paymentRequired: Boolean(paymentRequired),
        resumes,
        signedIn,
      }),
    [trace, started, preparing, stopped, isSubmitting, isRunning, turnState, wrongThread, failure, paymentRequired, resumes, signedIn],
  );
  const { busy } = state;
  const finished = started && !busy && turnState === "complete";
  /** Why the backend's turn ended without a campaign result, when it did. */
  const turnError = !failure && state.status === "failed" ? state.error : null;
  const finalMessage = [...getMessages()].reverse().find((message) => message.role === "assistant");

  useEffect(() => {
    if (!wrongThread) setUser(target.userState(appId, providerLabel));
  }, [appId, providerLabel, setUser, target, wrongThread]);

  const status = statusLabel(state.status);
  /** The server-rendered report, once the store holds this campaign. */
  const exportUrl = saved?.savedAt && !harness ? `/api/campaigns/${appId}/${saved.id}/export` : null;

  // Cost guardrails. The backend enforces the cap per turn through the run
  // budget header; the panel reads the balance every 30 s while a run is
  // busy, warns at half the cap and stops the run itself at nine tenths, so
  // a run never ends with a negative balance like the first Lending Lab run.
  const [balance, setBalance] = useState<number | null>(null);
  const balanceAtStart = useRef<number | null>(null);
  const readBalance = useCallback(async (): Promise<number | null> => {
    if (!account || harness) return null;
    try {
      const { available_microusd } = await account.client.account.credits.get();
      setBalance(available_microusd);
      return available_microusd;
    } catch {
      return null;
    }
  }, [account, harness]);
  useEffect(() => {
    void readBalance();
  }, [readBalance]);
  useEffect(() => {
    if (!busy) return;
    const timer = setInterval(() => void readBalance(), 30_000);
    return () => clearInterval(timer);
  }, [busy, readBalance]);
  const capMicrousd = maxCredits * MICROUSD_PER_CREDIT;
  const spent = balanceAtStart.current !== null && balance !== null ? Math.max(0, balanceAtStart.current - balance) : null;
  const spentFraction = spent !== null ? spent / capMicrousd : 0;
  useEffect(() => {
    if (!busy || stopped || spentFraction < STOP_AT) return;
    setStopped(true);
    setFailure(`Stopped at ${credits(spent ?? 0)} credits, ${Math.round(STOP_AT * 100)}% of the ${credits(capMicrousd)} credit cap.`);
    launch.current?.abort();
    runtime.cancelGeneration();
  }, [busy, stopped, spentFraction, spent, capMicrousd, runtime]);
  // Record what the run cost once it has ended, for the report and the next estimate.
  const costed = useRef<string | null>(null);
  useEffect(() => {
    if (!started || !state.terminal || balanceAtStart.current === null) return;
    const key = `${runtime.currentThreadId}:${state.status}`;
    if (costed.current === key) return;
    costed.current = key;
    const start = balanceAtStart.current;
    void readBalance().then((end) => {
      if (end === null) return;
      change.current?.({ cost: { microusd: Math.max(0, start - end), executions: state.executions } });
    });
  }, [started, state.terminal, state.status, state.executions, runtime.currentThreadId, readBalance]);
  const insufficient =
    estimate !== null && estimate !== undefined && balance !== null && !started && balance < estimate.microusd;
  // Report the campaign to the workspace: status changes at once, the event
  // ledger trailing by a second so a busy turn does not re-render the page
  // per event. The workspace writes it through to the server store.
  const localInput = useMemo(
    () => ({ started, stopped, turnState, failure, paymentRequired: Boolean(paymentRequired), resumes, signedIn }),
    [started, stopped, turnState, failure, paymentRequired, resumes, signedIn],
  );
  useEffect(() => {
    if (!started || wrongThread) return;
    change.current?.({ threadId: runtime.currentThreadId, status, resumes, local: localInput });
  }, [started, wrongThread, runtime.currentThreadId, status, resumes, localInput]);
  useEffect(() => {
    if (!started || wrongThread || events.length === 0) return;
    const timer = setTimeout(() => change.current?.({ events, local: localInput }), 1_000);
    return () => clearTimeout(timer);
  }, [started, wrongThread, events, localInput]);

  // Perform the reducer's next action: one continuation per terminal ledger
  // position, even if React renders twice.
  const { next } = state;
  useEffect(() => {
    if (starting.current || (next.kind !== "continue" && next.kind !== "finish")) return;
    const terminal = events.findLast((event) => event.type === "turn_state_changed" && event.state !== "processing");
    if (!terminal) return;
    const cursor = `${runtime.currentThreadId}:${terminal.turn_id ?? terminal.sequence}`;
    if (continued.current === cursor) return;
    continued.current = cursor;
    starting.current = true;
    setResumes((count) => count + 1);
    void sendMessage(next.prompt)
      .catch((error: unknown) => setFailure(campaignError(error)))
      .finally(() => {
        starting.current = false;
      });
  }, [next, sendMessage, events, runtime.currentThreadId]);

  useEffect(() => {
    if (!visible || !follow || view === "tree") return;
    traceEnd.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }, [trace.rows.length, turnState, visible, follow, view]);

  async function run(): Promise<void> {
    if (starting.current || busy || wrongThread) return;
    starting.current = true;
    const controller = new AbortController();
    launch.current = controller;
    setStopped(false);
    setPreparing(true);
    setFailure(null);
    setTargetChanged(false);
    setFix(null);
    setSeeded(false);
    balanceAtStart.current = await readBalance();
    try {
      // Renew only the capability for the exact build shown in the preview.
      // The launch path reads the app snapshot store and never calls Arc Studio.
      // A harness protocol comes from disk: nothing to renew.
      let fresh = data;
      if (!harness) {
        const refreshed = await loadTarget({
          data: {
            appId,
            sourcePath: data.sourcePath,
            contract: data.name,
            ...(data.snapshotId ? { snapshotId: data.snapshotId } : {}),
            blind,
          },
        });
        controller.signal.throwIfAborted();
        change.current?.({ blind });
        if (!refreshed.ok) throw new Error(refreshed.error);
        const identity = (value: TargetData) =>
          value.snapshotHash ??
          JSON.stringify([
            value.source,
            value.abi,
            value.deployedBytecode,
            value.chainId,
            value.deployment ?? null,
            value.protocol ?? [],
            value.immutableReferences ?? [],
          ]);
        if (
          identity(refreshed.value) !== identity(data) ||
          (data.snapshotId && refreshed.value.snapshotId !== data.snapshotId)
        ) {
          setTargetChanged(true);
          throw new Error("The compiled target changed. Prepare a new campaign to use the current build.");
        }
        fresh = refreshed.value;
      }
      const control = getCurrentThreadControl();
      // Commit the SDK's React selection before reading its ID and capturing
      // its render-bound sender.
      const threadId = await flushSync(createThread);
      controller.signal.throwIfAborted();
      const campaign = committedRuntime.current;
      if (campaign.currentThreadId !== threadId)
        throw new Error("Campaign thread did not become active. Please retry.");
      // A name the backend no longer serves (its catalog moves) would silently
      // fall back to auto routing, so the choice is checked against the catalog.
      const catalog = await modelCatalog(backendUrl, threadId, controller.signal).catch(() => FALLBACK_MODELS);
      // Always a manual pin: auto routing ("Balanced") stalls on this prompt.
      const model = campaignModel(control.modelMode === "auto" ? undefined : control.model, catalog);
      const mode = "manual" as const;
      change.current?.({ threadId, status: "Preparing fork", resumes: 0 });
      controller.signal.throwIfAborted();
      setStarted(true);
      setResumes(0);
      // Carry the user's picker choice into the fresh campaign thread. The new
      // thread's metadata can lag its selection by a tick, in which case the
      // write is dropped and the turn would route on auto (whose first choice
      // stalls on this prompt), so re-apply until the control reads back.
      for (let attempt = 0; attempt < 20; attempt += 1) {
        const { actions } = committedControl.current;
        controller.signal.throwIfAborted();
        await actions.onModelSelect(model, { mode });
        if (actions.getCurrentThreadControl().model === model) break;
        await new Promise((resolve) => setTimeout(resolve, 100));
      }
      if (committedControl.current.actions.getCurrentThreadControl().model !== model) {
        throw new Error(`Could not pin the campaign to ${model}. Please retry.`);
      }
      const bearer = harness?.backendBearer;
      // The runtime keeps the picker's choice client-side; the backend learns a
      // thread's model only through /api/thread/model, and without it a fresh
      // thread routes on auto. Pin it there before the first message.
      if (bearer || account) {
        const url = new URL("/api/thread/model", backendUrl);
        url.searchParams.set("rig", model);
        url.searchParams.set("app", "arc-studio-fuzzer");
        if (applicationId) url.searchParams.set("application_id", String(applicationId));
        try {
          const clientId = localStorage.getItem("aomi_client_id");
          if (clientId) url.searchParams.set("client_id", clientId);
        } catch {
          /* the backend falls back to the session's client */
        }
        const pinned = await (
          account && !harness
            ? account.request("POST", url.pathname + url.search, { signal: controller.signal, sessionId: threadId })
            : fetch(url, {
                method: "POST",
                signal: controller.signal,
                headers: { authorization: `Bearer ${bearer}`, "X-Session-Id": threadId, "X-Thread-Id": threadId },
              })
        ).catch((error: unknown) => error);
        if (!(pinned instanceof Response && pinned.ok)) {
          const reason = pinned instanceof Response ? `HTTP ${pinned.status} ${await pinned.text()}` : String(pinned);
          throw new Error(`Could not pin the campaign to ${model} on the backend (${reason}). Please retry.`);
        }
      }
      // A signed-in launch must establish its world before the first message.
      // A setup failure cannot silently become an agent-created campaign.
      const link = harness ? harness.artifactUrl : fresh.deployment ? fresh.artifactUrl : fresh.installedArtifactUrl;
      let seededLink: string | undefined;
      if ((bearer || account) && link) {
        const url = new URL("/api/thread/sim/world", backendUrl);
        url.searchParams.set("user_state", JSON.stringify(target.userState(appId, providerLabel)));
        const response = await (
          account && !harness
            ? account.request("POST", url.pathname + url.search, {
                signal: controller.signal,
                sessionId: threadId,
                body: target.seedWorld(),
              })
            : fetch(url, {
                method: "POST",
                headers: {
                  authorization: `Bearer ${bearer}`,
                  "content-type": "application/json",
                  "X-Session-Id": threadId,
                  "X-Thread-Id": threadId,
                },
                body: JSON.stringify(harness ? harness.seed : target.seedWorld()),
                signal: controller.signal,
              })
        ).catch((error: unknown) => error);
        if (response instanceof Response && response.ok) {
          const stamp = (await response.json()) as { verified_code_checks?: number };
          // A harness seed installs the protocol's code itself; there is no deployment to verify against.
          if (!harness && data.deployment && stamp.verified_code_checks !== 1) {
            throw new Error(
              "This backend has not verified the compiled code against the deployment. Update the simulation backend before running this build.",
            );
          }
          seededLink = link;
        } else {
          const reason = response instanceof Response ? `HTTP ${response.status} ${await response.text()}` : response;
          throw new Error(`Could not seed the simulation world (${reason}). Retry the campaign.`);
        }
      }
      controller.signal.throwIfAborted();
      setSeeded(Boolean(seededLink));
      lastSubmission.current =
        (seededLink
          ? harness
            ? target.seededProtocolPrompt(seededLink, harness.contracts)
            : target.seededPrompt(
                seededLink,
                (data.protocol ?? []).map((contract) => contract.name),
              )
          : target.prompt(fresh.artifactUrl)) + priorFindingsPrompt(priorFindings);
      await campaign.sendMessage(lastSubmission.current);
      lastSubmission.current = "";
    } catch (error) {
      if (!(error instanceof Error && "status" in error && error.status === 402)) lastSubmission.current = "";
      setStopped(true);
      if (controller.signal.aborted) return;
      const message = campaignError(error);
      setFailure(
        message === "Failed to fetch"
          ? `Could not reach the Aomi backend at ${backendUrl}. Is it running with the arc-studio-fuzzer app loaded?`
          : message,
      );
    } finally {
      starting.current = false;
      setPreparing(false);
    }
  }

  /**
   * The one Aomi conversation view. It lives in the panel while the activity
   * is docked in the workspace, otherwise behind the activity's "Chat" tab,
   * never both. A crash inside the widget stays in this box.
   */
  const chat = (
    <ErrorBoundary
      fallback={({ error, reset }) => (
        <div
          role="alert"
          className="m-3 rounded-lg border border-danger/35 bg-danger/8 p-3 text-[12px] leading-5 text-ink"
        >
          <p className="font-semibold text-danger">The chat view crashed.</p>
          <p className="mt-1 font-mono text-[11px] text-ink-muted">{errorText(error)}</p>
          <p className="mt-2">The campaign keeps running and its status, trace and export stay available here.</p>
          <button onClick={reset} className="mt-2 underline">
            Reopen chat
          </button>
        </div>
      )}
    >
      {/* Widget v4 scopes its stylesheet to .aomi-widget, which only AomiFrame.Root adds. A bare
          Composer rendered unstyled: the run status pill was drawn over the reply box. */}
      <WidgetScope>
        <AomiFrame.Composer className="fuzzer-composer h-full" welcomeTitle="Ask Aomi about this campaign" />
      </WidgetScope>
    </ErrorBoundary>
  );

  const activity = (
    <div className={`min-h-0 flex-1 ${view === "tree" && started ? "flex flex-col overflow-hidden p-3" : view === "chat" && started ? "flex flex-col overflow-hidden" : "overflow-auto p-4"}`}>
      {!started && (
        <div>
          <div className="rounded-lg border border-border bg-bg p-4">
            <div className="mb-3 flex items-center gap-2 text-[13px] font-medium text-ink">
              <Sparkles className="size-4 text-accent" />{" "}
              {harness
                ? "Protocol seeded by the local harness"
                : data.capturedAt
                  ? `Pinned Arc build · ${new Date(data.capturedAt).toLocaleString()}`
                  : "Compiled artifact loaded from Arc Studio"}
              {data.snapshotId && !harness && (
                <button onClick={onRefresh} className="ml-auto text-xs text-accent-strong underline">
                  Refresh build
                </button>
              )}
            </div>
            <p className="text-[13px] leading-5 text-ink-muted">
              Source, ABI, and runtime bytecode for <code>{target.name}</code> (
              {ArcStudioApp.workspacePath(target.sourcePath)}) go to the Aomi fuzzer. Every row below comes from the
              agent&apos;s live event stream.
            </p>
            <p className="mt-2 font-mono text-[12px] text-ink-muted">
              writes: {target.writableFunctions.join(", ") || "none"}
            </p>
            {target.deployment ? (
              <p className="mt-3 rounded-md border border-success/30 bg-success/8 px-3 py-2 text-[12px] leading-5 text-ink">
                Fuzzing your live deployment at{" "}
                <span className="font-mono">
                  {target.deployment.address.slice(0, 8)}…{target.deployment.address.slice(-6)}
                </span>{" "}
                on Arc {target.deployment.chainId === 5042 ? "mainnet" : "testnet"}, with its real owner, tokens and
                state.
                {data.protocol && data.protocol.length > 0 && (
                  <>
                    {" "}
                    The fork also holds {data.protocol.map((contract) => contract.name).join(", ")}, deployed alongside
                    it, so the agent can attack the protocol as a whole.
                  </>
                )}{" "}
                Nothing is sent to the chain.
              </p>
            ) : (
              <p className="mt-3 rounded-md border border-warning/40 bg-warning/10 px-3 py-2 text-[12px] leading-5 text-ink">
                No Arc deployment found for this contract, so the fuzzer installs its compiled code on a fresh address.
                The constructor does not run, so owner and token setup will be empty. Deploy it to Arc in Arc Studio to
                fuzz the real thing.
              </p>
            )}
          </div>
          {!signedIn && (
            <div className="mt-4 rounded-lg border border-warning/40 bg-warning/10 p-3 text-[12px] leading-5 text-ink">
              You&apos;re running as an Aomi guest. Guest sessions stop after about 15 tool calls (a per-call input
              cap), before a full campaign can minimize and reproduce a finding. <strong>Sign in to Aomi</strong> (top
              right) for complete campaigns.
            </div>
          )}
          <div className="mt-4 space-y-2">
            {[
              "Agent authors the threat model, actors, and properties",
              "Runtime holds one Arc fork; nothing is broadcast",
              "A finding needs two clean reproductions",
            ].map((label) => (
              <div
                key={label}
                className="flex items-center gap-3 rounded-md border border-border bg-bg px-3 py-3 text-[12px] text-ink-muted"
              >
                <ShieldCheck className="size-4 text-accent" /> {label}
              </div>
            ))}
          </div>
        </div>
      )}

      {started && (
        <div className={view === "tree" ? "flex min-h-0 flex-1 flex-col" : view === "chat" ? "flex h-full min-h-0 flex-col p-4" : undefined}>
          <CampaignProgress trace={trace} busy={busy} preparing={preparing} stopped={stopped} failure={failure ?? turnError} visible={visible} />
          <div
            className={`${view === "tree" || (busy && !failure && !turnError) ? "hidden" : "mb-4 flex"} items-start gap-3 rounded-lg border p-3 ${
              failure || turnError || finding ? "border-danger/35 bg-danger/8" : "border-border bg-bg"
            }`}
          >
            <div className="mt-0.5 grid size-8 shrink-0 place-items-center rounded-pill bg-surface-2">
              {busy ? (
                <RefreshCw className="size-4 animate-spin text-accent" />
              ) : failure || turnError || finding ? (
                <AlertTriangle className="size-4 text-danger" />
              ) : (
                <Check className="size-4 text-success" />
              )}
            </div>
            <div className="min-w-0">
              <h2 className="text-[13px] font-semibold text-ink">
                {failure || turnError
                  ? "Campaign failed"
                  : busy
                    ? "Agent is exploring the fork"
                    : finding
                      ? "Reproduced invariant violation"
                      : finished
                        ? report?.status === "complete"
                          ? "Campaign complete · no violation reproduced"
                          : "Turn ended · campaign incomplete"
                        : "Connecting to agent"}
              </h2>
              {state.fixVerdict && <FixVerdictBadge verdict={state.fixVerdict} />}
              {finished && <NotTested actions={state.notTested} />}
              <p className="mt-1 font-mono text-[11px] text-ink-muted">
                {turnState ?? "submitting"} · {trace.rows.length} tool events · {events.length} ledger events
                {resumes > 0 && ` · continued ${resumes}×`}
              </p>
            </div>
          </div>

          <div className="mb-2 flex shrink-0 flex-wrap items-center justify-between gap-1">
            <h3 className="text-[11px] font-semibold uppercase tracking-[0.12em] text-ink-muted">Live agent trace</h3>
            <div className="flex rounded-pill border border-border bg-surface-2 p-0.5 text-[11px]" role="tablist">
              {(
                [
                  ["tree", "Fuzz tree"],
                  ["tools", `Tools ${trace.rows.length}`],
                  ["ledger", `All events ${trace.ledger.length}`],
                  ["chat", "Chat"],
                ] as const
              )
                .filter(([key]) => !docked || key !== "chat")
                .map(([key, label]) => (
                  <button
                    key={key}
                    role="tab"
                    aria-selected={view === key}
                    onClick={() => setView(key)}
                    className={`rounded-pill px-2.5 py-0.5 transition ${view === key ? "bg-bg text-ink" : "text-ink-muted hover:text-ink"}`}
                  >
                    {label}
                  </button>
                ))}
            </div>
          </div>

          {view === "tree" ? (
            <CampaignExplorer trace={trace} busy={busy} targetName={target.name} />
          ) : view === "tools" ? (
            <div data-testid="agent-trace" className="space-y-2">
              {seeded && (
                <div
                  data-testid="seeded-world"
                  className="flex items-center gap-2 rounded-md border border-success/30 bg-success/8 px-3 py-2 text-[12px] text-success"
                >
                  <ShieldCheck className="size-3.5 shrink-0" />
                  World seeded by the harness on chain {target.chainId}:{" "}
                  {target.deployment ? "live deployment" : "runtime installed"} at{" "}
                  <code className="font-mono">{short(target.deployment?.address ?? INSTALL_ADDRESS)}</code>
                </div>
              )}
              {trace.rows.length === 0 && (
                <div className="rounded-md border border-border bg-bg px-3 py-4 text-center text-[12px] text-ink-muted">
                  Waiting for the first tool call…
                </div>
              )}
              {trace.rows.map((row) => {
                const result = row.result as { error?: { message?: string } | string } | string | undefined;
                const errorText =
                  row.state !== "failed"
                    ? null
                    : typeof result === "string"
                      ? result
                      : typeof result?.error === "string"
                        ? result.error
                        : (result?.error?.message ?? pretty(result));
                return (
                  <details
                    key={row.key}
                    data-tool-name={row.name}
                    className="group rounded-md border border-border bg-bg px-3 py-2.5"
                  >
                    <summary className="flex cursor-pointer list-none items-center gap-2">
                      {row.state === "calling" ? (
                        <CircleDot className="size-3.5 shrink-0 animate-pulse text-accent" />
                      ) : row.state === "failed" ? (
                        <X className="size-3.5 shrink-0 text-danger" />
                      ) : (
                        <Check className="size-3.5 shrink-0 text-success" />
                      )}
                      <span className="min-w-0 flex-1 truncate font-mono text-[12px] text-ink">{row.name}</span>
                      <span className="text-[11px] text-ink-muted/70">#{row.sequence}</span>
                      <ChevronRight className="size-3 text-ink-muted/70 transition group-open:rotate-90" />
                    </summary>
                    {errorText && (
                      <p className="mt-1.5 line-clamp-3 font-mono text-[11px] leading-[1.5] text-danger group-open:line-clamp-none">
                        {errorText}
                      </p>
                    )}
                    {row.result !== undefined && !errorText && (
                      <pre className="mt-2 max-h-72 overflow-auto whitespace-pre-wrap border-t border-border pt-2 font-mono text-[11px] leading-[1.5] text-ink-muted">
                        {`result\n${pretty(row.result)}`}
                      </pre>
                    )}
                    {row.arguments !== undefined && (
                      <details className="mt-2 border-t border-border pt-2">
                        <summary className="cursor-pointer text-[11px] text-ink-muted">args</summary>
                        <pre className="mt-1 max-h-72 overflow-auto whitespace-pre-wrap font-mono text-[11px] leading-[1.5] text-ink-muted">
                          {pretty(row.arguments)}
                        </pre>
                      </details>
                    )}
                  </details>
                );
              })}
            </div>
          ) : view === "ledger" ? (
            <div data-testid="ledger" className="space-y-1">
              {trace.ledger.length === 0 && (
                <div className="rounded-md border border-border bg-bg px-3 py-4 text-center text-[12px] text-ink-muted">
                  No events yet.
                </div>
              )}
              {trace.ledger.map((entry) => (
                <details key={entry.key} className="group rounded-md border border-border bg-bg px-3 py-2">
                  <summary className="flex cursor-pointer list-none items-center gap-2">
                    <span className="w-9 shrink-0 text-[11px] text-ink-muted/70">#{entry.sequence}</span>
                    <span
                      className={`shrink-0 rounded-pill px-1.5 py-0.5 font-mono text-[10.5px] ${
                        entry.type === "error"
                          ? "bg-danger/10 text-danger"
                          : entry.type === "message"
                            ? "bg-accent/10 text-accent-strong"
                            : "bg-surface-2 text-ink-muted"
                      }`}
                    >
                      {entry.type}
                    </span>
                    <span className="min-w-0 flex-1 truncate text-[12px] text-ink">{entry.label}</span>
                    <ChevronRight className="size-3 shrink-0 text-ink-muted/70 transition group-open:rotate-90" />
                  </summary>
                  <pre className="mt-2 max-h-80 overflow-auto whitespace-pre-wrap border-t border-border pt-2 font-mono text-[11px] leading-[1.5] text-ink-muted">
                    {JSON.stringify(entry.event, null, 2)}
                  </pre>
                </details>
              ))}
            </div>
          ) : (
            <div
              data-testid="aomi-chat"
              className="flex min-h-0 flex-1 flex-col overflow-hidden rounded-lg border border-border bg-bg"
            >
              {chat}
            </div>
          )}

          {view !== "chat" && view !== "tree" && finding && report && (
            <VerifiedFinding finding={finding} report={report} onSource={onSource} />
          )}

          {view !== "chat" && view !== "tree" && finalMessage?.content && finished && (
            <div className="mt-4 rounded-lg border border-border bg-bg p-3">
              <div className="mb-2 text-[12px] font-semibold uppercase tracking-wider text-accent-strong">
                Agent conclusion
              </div>
              <div className="max-h-80 overflow-auto whitespace-pre-wrap text-[13px] leading-6 text-ink">
                {messageText(finalMessage.content)}
              </div>
            </div>
          )}
          {view !== "chat" && (failure ?? turnError) && (
            <p className="mt-2 max-h-20 shrink-0 overflow-auto text-[12px] leading-5 text-danger">{failure ?? turnError}</p>
          )}
          <div ref={traceEnd} />
        </div>
      )}
    </div>
  );

  if (wrongThread)
    return (
      <div role="alert" className="p-4 text-danger">
        This saved thread is unavailable. No messages will be sent to a replacement thread.
        {onNew && (
          <button className="block underline" onClick={onNew}>
            Start a new campaign
          </button>
        )}
      </div>
    );

  if (paymentRequired) {
    return (
      <section role="alert" className="m-5 rounded-3xl border border-border bg-surface p-7 text-ink">
        <h2 className="text-xl font-semibold">Add credits to continue</h2>
        <p className="mt-3 leading-6 text-ink-muted">
          Your inference credits have run out. Add credits to your Aomi account here,
          or manage them on Aomi. Your campaign stays here and only retries when you choose.
        </p>
        {account && <p className="mt-3 break-all text-xs text-ink-muted">Fuzzer account: {account.address}</p>}
        <button
          type="button"
          disabled={!addCredits}
          onClick={() => addCredits?.()}
          className="mt-6 flex h-11 w-full items-center justify-center rounded-pill bg-ink px-5 text-bg disabled:opacity-50"
        >
          + Add credits
        </button>
        <button type="button" disabled={!manageCredits} className="mt-3 w-full underline" onClick={manageCredits}>
          Manage credits on Aomi ↗
        </button>
        {failure && (
          <p role="status" className="mt-3 text-danger">
            {failure}
          </p>
        )}
        <button
          type="button"
          className="mt-4 w-full rounded-pill border border-border px-5 py-3"
          onClick={() => {
            dismissNotification(paymentRequired.id);
            setFailure(null);
            setStopped(!lastSubmission.current);
            if (!lastSubmission.current || starting.current) return;
            starting.current = true;
            void sendMessage(lastSubmission.current)
              .catch((error: unknown) => setFailure(campaignError(error)))
              .finally(() => { starting.current = false; });
          }}>
          {lastSubmission.current ? "I’ve added credits — retry" : "Return to campaign"}
        </button>
      </section>
    );
  }

  return (
    <>
      <div className="flex h-14 items-center justify-between border-b border-border px-5">
        <div className="flex items-center gap-2.5">
          <span role="img" aria-label="Aomi">
            <AomiMark className="size-7 text-ink" />
          </span>
          <div>
            <h1 className="text-[15px] font-semibold text-ink">Agentic Fuzzer</h1>
            <p className="text-[12px] text-ink-muted">
              {target.name} · {target.writableFunctions.length} writable function
              {target.writableFunctions.length === 1 ? "" : "s"}
            </p>
          </div>
        </div>
        <div className="flex min-w-0 items-center gap-2">
          <CampaignModelSelect backendUrl={backendUrl} disabled={busy} />
          {!harness && (
            <CampaignBlindToggle
              value={blind}
              disabled={started || busy}
              onChange={(value) => {
                setBlind(value);
                change.current?.({ blind: value });
              }}
            />
          )}
          {account && !harness && (
            <CampaignCapSelect
              value={maxCredits}
              disabled={started || busy}
              onChange={(cap) => change.current?.({ maxCredits: cap })}
            />
          )}
          <span className="shrink-0 rounded-pill border border-accent/45 bg-accent/10 px-2 py-0.5 font-mono text-[11px] text-accent-strong">
            LIVE
          </span>
        </div>
      </div>

      {docked && activityHost ? (
        <>
          {visible && createPortal(activity, activityHost)}
          {/* A flex column: the widget sizes its thread to the column and
              scrolls the messages above its own composer. In a plain block it
              grew to its content and the reply box was drawn over the steps. */}
          <div className="flex min-h-0 flex-1 flex-col overflow-hidden">{chat}</div>
        </>
      ) : (
        activity
      )}

      <div className="space-y-2 border-t border-border p-4">
        {wrongThread && (
          <p role="alert" className="text-danger">
            This saved thread is unavailable. Start a new campaign from the contract; no messages will be sent to a
            replacement thread.
          </p>
        )}
        {started && (
          <div className="flex flex-wrap items-center gap-3 text-xs">
            <label>
              <input type="checkbox" checked={follow} onChange={(event) => setFollow(event.target.checked)} /> Follow
              live
            </label>
            <span>{status}</span>
            {busy && (
              <button
                disabled={stopped}
                onClick={() => {
                  setStopped(true);
                  launch.current?.abort();
                  runtime.cancelGeneration();
                }}
                className="text-danger"
              >
                Stop execution
              </button>
            )}
            {!busy &&
              !wrongThread &&
              events.some((event) => event.type === "message" && event.sender === "user") &&
              report?.status !== "complete" && (
                <button
                  onClick={() => {
                    if (starting.current) return;
                    starting.current = true;
                    setStopped(false);
                    setFailure(null);
                    void sendMessage(next.kind === "continue" || next.kind === "finish" ? next.prompt : trace.continuationPrompt)
                      .catch((error: unknown) => setFailure(campaignError(error)))
                      .finally(() => {
                        starting.current = false;
                      });
                  }}
                >
                  Continue campaign
                </button>
              )}
            {exportUrl ? (
              <a href={exportUrl} target="_blank" rel="noreferrer" data-testid="export-report">
                Export evidence
              </a>
            ) : (
              <button
                onClick={() =>
                  download(`${data.name}-campaign.json`, {
                    target: data.name,
                    threadId: runtime.currentThreadId,
                    report,
                    events,
                  })
                }
              >
                Export evidence
              </button>
            )}
            {exportUrl ? (
              <a href={`${exportUrl}?format=json`} data-testid="download-result">
                Download result JSON
              </a>
            ) : (
              <button
                data-testid="download-result"
                disabled={!report}
                title={report ? "The campaign's report as JSON" : "Available once the agent has reported"}
                onClick={() =>
                  download(`${data.name}-result.json`, {
                    target: data.name,
                    threadId: runtime.currentThreadId,
                    status,
                    exportedAt: new Date().toISOString(),
                    report,
                  })
                }
                className="disabled:opacity-50"
              >
                Download result JSON
              </button>
            )}
          </div>
        )}

        {finding && report && finished && !harness && (
          <>
            {fix?.webUrl ? (
              <div className="rounded-md border border-success/30 bg-success/8 p-3 text-[13px] text-ink">
                Fix request sent to Arc Studio.{" "}
                <a
                  href={fix.webUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 underline"
                >
                  Follow it there <ExternalLink className="size-3" />
                </a>
                <button onClick={onRefresh} className="mt-2 block text-ink-muted underline">
                  Arc Studio finished? Reload the contract, then fuzz again
                </button>
              </div>
            ) : (
              <button
                data-testid="send-fix"
                disabled={fixing}
                onClick={() =>
                  startFix(async () => {
                    const result = await requestFix({
                      data: { appId, sourcePath: target.sourcePath, contract: target.name, report },
                    });
                    setFix(result.ok ? { webUrl: result.value.webUrl } : { error: result.error });
                  })
                }
                className="flex h-10 w-full items-center justify-center gap-2 rounded-pill bg-danger-strong text-[13px] font-medium text-on-danger transition hover:brightness-110 disabled:opacity-70"
              >
                {fixing ? <RefreshCw className="size-3.5 animate-spin" /> : <Wrench className="size-3.5" />}
                Send finding to Arc Studio for a fix
              </button>
            )}
            {fix?.error && <p className="text-[12px] text-danger">{fix.error}</p>}
          </>
        )}
        <button
          data-testid="run-aomi-fuzz"
          onClick={() => ((started || targetChanged) && onNew ? onNew() : void run())}
          disabled={busy || wrongThread || insufficient}
          className="flex h-10 w-full items-center justify-center gap-2 rounded-pill bg-ink text-[13px] font-medium text-bg transition hover:bg-ink/85 disabled:cursor-wait disabled:opacity-70"
        >
          {busy ? (
            <>
              <RefreshCw className="size-3.5 animate-spin" /> Running campaign…
            </>
          ) : targetChanged ? (
            <>
              <RefreshCw className="size-3.5" /> Prepare the current build
            </>
          ) : started ? (
            <>
              <RefreshCw className="size-3.5" /> Run a new campaign
            </>
          ) : (
            <>
              <Play className="size-3.5 fill-current" /> Fuzz {target.name} on an Arc fork
            </>
          )}
        </button>
        {spent !== null && spentFraction >= WARN_AT && (
          <p role="status" data-testid="credit-warning" className="text-center text-[12px] text-warning">
            {credits(spent)} of the {credits(capMicrousd)} credit cap used
            {spentFraction >= STOP_AT ? "; the run was stopped" : "; the run stops at 90%"}.
          </p>
        )}
        {insufficient && (
          <p role="status" className="text-center text-[12px] text-danger">
            Recent runs cost about {credits(estimate.microusd)} credits; {credits(balance)} available. Add credits to run.
          </p>
        )}
        <p className="text-center text-[12px] text-ink-muted/70">
          Real model · {account ? `${credits(capMicrousd)} credit cap per run · ` : ""}
          {estimate && estimate.runs > 0 ? `recent runs about ${credits(estimate.microusd)} credits · ` : ""}
          held Arc fork · no signing or broadcast
        </p>
      </div>
    </>
  );
}

"use client";
import { Component, type ErrorInfo, type ReactNode } from "react";

export type ErrorFallbackProps = {
  error: Error;
  /** Remount the children and try again. */
  reset: () => void;
};

/**
 * Keeps a render error inside one region of the page. The Aomi widget and
 * runtime live in a dependency, and a crash there (for example
 * `useClientLookup: Index 4 out of bounds` at the end of a run) used to take
 * the whole workspace down with the campaign's status and export controls.
 */
export class ErrorBoundary extends Component<
  {
    fallback: (props: ErrorFallbackProps) => ReactNode;
    children: ReactNode;
    onError?: (error: Error) => void;
  },
  { error: Error | null }
> {
  state: { error: Error | null } = { error: null };

  static getDerivedStateFromError(error: unknown): { error: Error } {
    return { error: error instanceof Error ? error : new Error(String(error)) };
  }

  componentDidCatch(error: Error, info: ErrorInfo): void {
    console.error(
      "A panel crashed and was contained.",
      error,
      info.componentStack,
    );
    this.props.onError?.(error);
  }

  reset = (): void => this.setState({ error: null });

  render(): ReactNode {
    if (this.state.error)
      return this.props.fallback({
        error: this.state.error,
        reset: this.reset,
      });
    return this.props.children;
  }
}

/** A readable description of a caught error for a fallback panel. */
export function errorText(error: Error): string {
  const text = error.message.trim() || error.name;
  return text.length > 300 ? `${text.slice(0, 300)}…` : text;
}

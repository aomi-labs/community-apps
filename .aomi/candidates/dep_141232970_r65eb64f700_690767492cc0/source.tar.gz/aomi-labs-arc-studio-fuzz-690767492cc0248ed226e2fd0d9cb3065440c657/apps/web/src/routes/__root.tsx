import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useState } from "react";
import "@aomi-labs/widget/styles.css";
import "@fontsource-variable/geist";
import "@fontsource-variable/geist-mono";
import "@fontsource/pt-serif/400.css";
import "@fontsource/pt-serif/700.css";
import "@fontsource-variable/source-serif-4";
import "@/app/globals.css";
export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Aomi Fuzz for Arc Studio" },
    ],
  }),
  component: Root,
});
function Root() {
  const [queries] = useState(() => new QueryClient());
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <HeadContent />
        <script
          dangerouslySetInnerHTML={{
            __html: `(()=>{try{var m=matchMedia('(prefers-color-scheme: dark)'),s=()=>document.documentElement.classList.toggle('dark',m.matches);s();m.addEventListener('change',s)}catch{}})()`,
          }}
        />
      </head>
      <body>
        <QueryClientProvider client={queries}>
          <Outlet />
        </QueryClientProvider>
        <Scripts />
      </body>
    </html>
  );
}

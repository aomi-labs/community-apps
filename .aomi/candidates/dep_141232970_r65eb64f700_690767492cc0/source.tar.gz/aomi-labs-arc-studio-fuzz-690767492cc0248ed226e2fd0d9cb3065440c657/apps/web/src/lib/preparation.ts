import type { TargetData } from "@/app/actions";

export const preparationSteps = {
  workspace: "Refresh the Arc Studio file list",
  snapshot: "Check saved build",
  studio: "Read source and compiled artifact from Arc Studio",
  protocol: "Load deployed protocol context",
  save: "Save the build snapshot",
} as const;
export type PreparationStage = keyof typeof preparationSteps;
export type PreparationEvent =
  | { type: "stage"; stage: PreparationStage }
  | { type: "ready"; target: TargetData }
  | { type: "error"; error: string; missingBuild?: boolean };

/** Stage updates and the result share one request; no progress polling or extra Arc reads. */
export async function readPreparation(
  stream: ReadableStream<Uint8Array>,
  onStage: (stage: PreparationStage) => void,
  signal?: AbortSignal,
): Promise<Extract<PreparationEvent, { type: "ready" | "error" }>> {
  const reader = stream.getReader();
  const decoder = new TextDecoder();
  const cancel = () => { void reader.cancel().catch(() => {}); };
  signal?.addEventListener("abort", cancel, { once: true });
  let pending = "";
  try {
    for (;;) {
      signal?.throwIfAborted();
      const { done, value } = await reader.read();
      signal?.throwIfAborted();
      if (done) throw new Error("Build preparation disconnected before finishing. Try again.");
      pending += decoder.decode(value, { stream: true });
      let newline: number;
      while ((newline = pending.indexOf("\n")) >= 0) {
        const event = JSON.parse(pending.slice(0, newline)) as PreparationEvent;
        pending = pending.slice(newline + 1);
        if (event.type === "stage") onStage(event.stage);
        else return event;
      }
    }
  } finally {
    signal?.removeEventListener("abort", cancel);
    await reader.cancel().catch(() => {});
  }
}

import { afterEach, expect, test, vi } from "vitest";
const signIn = vi.hoisted(() => vi.fn(async () => "test-guest"));
const auth = vi.hoisted(() => ({ manager: vi.fn(), client: vi.fn() }));
vi.mock("@aomi-labs/client", () => ({
  createGuestSessionProvider: () => Object.assign(signIn, { clear: vi.fn() }),
  createAomiBrowserGrantManager: auth.manager,
  AomiClient: class {
    constructor(options: unknown) {
      auth.client(options);
    }
  },
}));
afterEach(() => {
  vi.unstubAllGlobals();
  vi.unstubAllEnvs();
});

test("campaigns share a guest and reload restores it without creating another identity", async () => {
  const values = new Map<string, string>();
  vi.stubGlobal("sessionStorage", {
    getItem: (key: string) => values.get(key),
    setItem: (key: string, value: string) => values.set(key, value),
    removeItem: (key: string) => values.delete(key),
  });
  const { guestSession } = await import("./aomi-account");
  const a = guestSession("https://staging.test");
  expect(guestSession("https://staging.test")).toBe(a);
  expect(await Promise.all([a(), a()])).toEqual(["test-guest", "test-guest"]);
  expect(signIn).toHaveBeenCalledTimes(1);
  vi.resetModules();
  const reloaded = await import("./aomi-account");
  expect(await reloaded.guestSession("https://staging.test")()).toBe(
    "test-guest",
  );
  expect(signIn).toHaveBeenCalledTimes(1);
  await reloaded.guestSession("https://another.test")();
  expect(signIn).toHaveBeenCalledTimes(2);
  vi.unstubAllGlobals();
});

test("a saved wallet address never triggers a signature while mounting", async () => {
  vi.stubGlobal("sessionStorage", {
    getItem: (key: string) =>
      key === "arc-studio-fuzz:aomi-account" ? "0x123" : null,
  });
  const request = vi.fn();
  vi.stubGlobal("ethereum", { request });
  const { AomiAccount } = await import("./aomi-account");
  expect(await AomiAccount.resume("https://wallet.test")).toBeNull();
  expect(request).not.toHaveBeenCalled();
});

test("reload restores noninteractively and an invalidated grant cannot reacquire", async () => {
  const baseUrl = "https://restore.test";
  vi.stubEnv("NEXT_PUBLIC_AOMI_OAUTH_CLIENT_ID", "fuzzer");
  vi.stubGlobal("sessionStorage", {
    getItem: () => "saved-session",
    removeItem: vi.fn(),
  });
  vi.stubGlobal("window", { location: { origin: "https://fuzzer.test" } });
  let grants = [
    {
      resource: baseUrl + "/v1/agent",
      scopes: ["agent:write"],
      accountId: "account-a",
    },
  ];
  const tokenProvider = vi.fn(async () => {
    grants = [];
    throw new Error("invalid_grant");
  });
  auth.manager.mockResolvedValue({ grants: async () => grants, tokenProvider });
  const { AomiAccount } = await import("./aomi-account");
  const [account, duplicate] = await Promise.all([
    AomiAccount.resume(baseUrl),
    AomiAccount.resume(baseUrl),
  ]);
  expect(account).toBe(duplicate);
  expect(account?.id).toBe("account-a");
  expect(auth.manager).toHaveBeenCalledWith(
    expect.objectContaining({
      interactive: false,
      persistenceKey: "saved-session",
    }),
  );
  const options = auth.client.mock.lastCall![0] as {
    oauth: (request: unknown) => Promise<unknown>;
  };
  const request = { resource: baseUrl + "/v1/agent", scopes: ["agent:write"] };
  await expect(options.oauth(request)).rejects.toThrow("invalid_grant");
  await expect(options.oauth(request)).rejects.toThrow("Sign in to Aomi again");
  expect(tokenProvider).toHaveBeenCalledTimes(1);
});

test("a completed handoff seals its popup against background reacquisition races", async () => {
  const baseUrl = "https://handoff.test";
  vi.stubEnv("NEXT_PUBLIC_AOMI_OAUTH_CLIENT_ID", "fuzzer");
  vi.stubGlobal("sessionStorage", { setItem: vi.fn(), removeItem: vi.fn() });
  const popup = {
    closed: false,
    close: vi.fn(),
    location: { href: "about:blank", replace: vi.fn() },
    history: { replaceState: vi.fn() },
  };
  vi.stubGlobal("window", {
    location: { origin: "https://fuzzer.test" },
    open: () => popup,
  });
  auth.manager.mockResolvedValue({
    grants: async () => [
      {
        resource: baseUrl + "/v1/agent",
        scopes: ["agent:write"],
        accountId: "account-a",
      },
    ],
    tokenProvider: async (request: { resource: string }) => {
      if (request.resource.endsWith("/v1/account")) {
        expect(popup.history.replaceState).toHaveBeenCalledWith(null, "", "/");
      } else {
        expect(popup.history.replaceState).not.toHaveBeenCalled();
      }
      return { accountId: "account-a" };
    },
    clear: vi.fn(),
  });
  const { AomiAccount } = await import("./aomi-account");
  await AomiAccount.openPortal(baseUrl, null, "credits");
  const options = auth.manager.mock.lastCall![0] as {
    popup: (url: string) => Window;
  };
  expect(() => options.popup("https://handoff.test/authorize")).toThrow(
    "Sign in to Aomi again",
  );
  expect(popup.location.href).toBe("about:blank");
  expect(popup.location.replace).toHaveBeenCalledTimes(1);
});

test("a balance read refreshes the whole credit grant, so checkout stays authorized", async () => {
  const baseUrl = "https://credits.test";
  vi.stubEnv("NEXT_PUBLIC_AOMI_OAUTH_CLIENT_ID", "fuzzer");
  vi.stubGlobal("sessionStorage", { getItem: () => "saved-session" });
  vi.stubGlobal("window", { location: { origin: "https://fuzzer.test" } });
  const resource = baseUrl + "/v1/account";
  const scopes = [
    "account:credits:read",
    "account:credits:fund",
    "payments:submit",
    "offline_access",
  ];
  let grants = [{ resource, scopes, accountId: "account-a" }];
  // Like Better Auth: a refresh reissues exactly the scopes it asks for.
  const tokenProvider = vi.fn(
    async (request: { resource: string; scopes: string[] }) => {
      grants = [{ ...grants[0]!, scopes: request.scopes }];
      return { accessToken: "token", scopes: request.scopes };
    },
  );
  auth.manager.mockResolvedValue({ grants: async () => grants, tokenProvider });
  const { AomiAccount } = await import("./aomi-account");
  await AomiAccount.resume(baseUrl);
  const options = auth.client.mock.lastCall![0] as {
    oauth: (request: unknown) => Promise<unknown>;
  };
  await options.oauth({
    resource,
    scopes: ["account:credits:read"],
    forceRefresh: true,
  });
  expect(tokenProvider).toHaveBeenLastCalledWith({
    resource,
    scopes,
    forceRefresh: true,
  });
  await expect(
    options.oauth({ resource, scopes: ["account:credits:fund"] }),
  ).resolves.toMatchObject({ accessToken: "token" });
  expect(grants[0]!.scopes).toEqual(scopes);
});

test("a grant without the credit scope asks checkout to reconnect", async () => {
  const baseUrl = "https://narrowed.test";
  vi.stubEnv("NEXT_PUBLIC_AOMI_OAUTH_CLIENT_ID", "fuzzer");
  vi.stubGlobal("sessionStorage", { getItem: () => "saved-session" });
  vi.stubGlobal("window", { location: { origin: "https://fuzzer.test" } });
  const resource = baseUrl + "/v1/account";
  const tokenProvider = vi.fn();
  auth.manager.mockResolvedValue({
    grants: async () => [
      { resource, scopes: ["account:credits:read"], accountId: "account-a" },
    ],
    tokenProvider,
  });
  const { AomiAccount } = await import("./aomi-account");
  expect((await AomiAccount.resume(baseUrl))?.id).toBe("account-a");
  const options = auth.client.mock.lastCall![0] as {
    oauth: (request: unknown) => Promise<unknown>;
  };
  await expect(
    options.oauth({ resource, scopes: ["account:credits:fund"] }),
  ).rejects.toMatchObject({
    code: "reauthorization_required",
    reason: "missing_grant",
  });
  expect(tokenProvider).not.toHaveBeenCalled();
});

test("sign-in asks for consent once when the portal takes a /v1 grant", async () => {
  const baseUrl = "https://single.test";
  vi.stubEnv("NEXT_PUBLIC_AOMI_OAUTH_CLIENT_ID", "fuzzer");
  vi.stubGlobal("sessionStorage", { setItem: vi.fn(), removeItem: vi.fn() });
  vi.stubGlobal(
    "fetch",
    vi.fn(async () =>
      Response.json({
        scopes_supported: [
          "agent:read",
          "agent:write",
          "agent:actions:resolve",
          "account:credits:read",
          "account:credits:fund",
          "payments:submit",
          "offline_access",
        ],
      }),
    ),
  );
  const popup = {
    closed: false,
    close: vi.fn(),
    location: { href: "about:blank", replace: vi.fn() },
    history: { replaceState: vi.fn() },
  };
  vi.stubGlobal("window", { location: { origin: "https://fuzzer.test" }, open: () => popup });
  const grants: { resource: string; scopes: string[]; accountId: string }[] = [];
  const tokenProvider = vi.fn(async (request: { resource: string; scopes: string[] }) => {
    grants.push({ ...request, accountId: "account-a" });
    return { accessToken: "token" };
  });
  auth.manager.mockResolvedValue({ grants: async () => grants, tokenProvider, clear: vi.fn() });
  const { AomiAccount } = await import("./aomi-account");
  const account = await AomiAccount.openPortal(baseUrl, null, "signin");
  expect(account.id).toBe("account-a");
  expect(tokenProvider).toHaveBeenCalledTimes(1);
  expect(tokenProvider.mock.calls[0]![0].resource).toBe(baseUrl + "/v1");
  expect(popup.close).toHaveBeenCalled();
  // The one grant serves the agent and the account APIs.
  const options = auth.client.mock.lastCall![0] as { oauth: (request: unknown) => Promise<unknown> };
  await options.oauth({ resource: baseUrl + "/v1/account", scopes: ["account:credits:fund"] });
  expect(tokenProvider).toHaveBeenLastCalledWith(expect.objectContaining({ resource: baseUrl + "/v1" }));
  await expect(
    options.oauth({ resource: baseUrl + "/v1/agent/mcp", scopes: ["agent:read"] }),
  ).rejects.toMatchObject({ reason: "missing_grant" });
});

test("a signed-in account opens Aomi settings without asking for consent again", async () => {
  const baseUrl = "https://signed-in.test";
  vi.stubEnv("NEXT_PUBLIC_AOMI_OAUTH_CLIENT_ID", "fuzzer");
  vi.stubGlobal("sessionStorage", { getItem: () => "saved-session" });
  const popup = { closed: false, close: vi.fn(), location: { href: "about:blank", replace: vi.fn() } };
  vi.stubGlobal("window", { location: { origin: "https://fuzzer.test" }, open: () => popup });
  auth.manager.mockResolvedValue({
    grants: async () => [{ resource: baseUrl + "/v1", scopes: ["agent:read"], accountId: "account-a" }],
    tokenProvider: vi.fn(),
  });
  const { AomiAccount } = await import("./aomi-account");
  const account = (await AomiAccount.resume(baseUrl))!;
  auth.manager.mockClear();
  expect(await AomiAccount.openPortal(baseUrl, account, "account")).toBe(account);
  expect(auth.manager).not.toHaveBeenCalled();
  expect(popup.location.replace).toHaveBeenCalledWith(baseUrl + "/?settings=account&expectedAccount=account-a");
});

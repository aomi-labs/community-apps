import { act, cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, expect, it, vi } from "vitest";
import { BuildPreparation } from "./build-preparation";

afterEach(() => { cleanup(); vi.useRealTimers(); });

it("shows the real stage, elapsed wait, slow warning and cancellation", () => {
  vi.useFakeTimers();
  vi.setSystemTime(100_000);
  const cancel = vi.fn();
  render(<BuildPreparation contract="CollateralToken" stages={["snapshot", "studio"]} startedAt={90_000} stageStartedAt={100_000} onCancel={cancel} />);
  expect(screen.getByRole("heading").textContent).toBe("Preparing CollateralToken");
  expect(screen.getByText(/No fork has been created/)).toBeTruthy();
  expect(screen.getByText("Read source and compiled artifact from Arc Studio").closest("li")?.getAttribute("aria-current")).toBe("step");
  expect(screen.getByLabelText("Preparation elapsed time").textContent).toBe("10s");
  act(() => { vi.advanceTimersByTime(16_000); });
  expect(screen.getByText(/Waiting for Arc Studio to respond/)).toBeTruthy();
  fireEvent.click(screen.getByRole("button", { name: "Cancel preparation" }));
  expect(cancel).toHaveBeenCalledOnce();
});

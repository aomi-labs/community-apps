import "@tanstack/react-start/server-only";

import type { PreparationStage, PreparationEvent } from "@/lib/preparation";
import { MissingBuildError } from "@aomi-labs/arc-studio-fuzz-core";
import { studioErrorMessage } from "@/server/studio-error";
import type { TargetData } from "@/app/actions";
import { StudioSession } from "@/server/studio-session";
import { launchSnapshot, savedSnapshot, saveSnapshot } from "@/server/snapshot-store";

export interface TargetSelection {
  appId: string;
  sourcePath: string;
  contract: string;
  snapshotId?: string;
  refresh?: boolean;
  /** Launch with comments stripped from the source the agent reads. */
  blind?: boolean;
}

export async function prepareTarget(current: StudioSession, selection: TargetSelection, onStage?: (stage: PreparationStage) => void): Promise<TargetData> {
  const { appId, sourcePath, contract, snapshotId, refresh, blind } = selection;
  // A launch always uses the exact object that was previewed. Neither branch
  // below touches Arc Studio unless preparation was explicitly requested.
  if (snapshotId) return launchSnapshot(current.token, appId, sourcePath, contract, snapshotId, blind);
  if (!refresh) {
    onStage?.("snapshot");
    const saved = await savedSnapshot(current.token, appId, sourcePath, contract);
    if (saved) return saved;
  }
  onStage?.("studio");
  const target = await StudioSession.timed(`target ${contract}`, async () =>
    (await current.app(appId, { fresh: true })).target(sourcePath, contract),
  );
  if (target.deployment) onStage?.("protocol");
  const protocol = target.deployment ? await (await current.app(appId)).protocol(target.name, target.chainId) : [];
  const prepared: TargetData = {
    name: target.name, sourcePath: target.sourcePath, source: target.source,
    abi: target.abi, deployedBytecode: target.deployedBytecode, chainId: target.chainId,
    immutableReferences: target.immutableReferences, deployment: target.deployment,
    protocol: protocol.map(({ name, address }) => ({ name, address })),
  };
  onStage?.("save");
  return saveSnapshot(current.token, appId, prepared, protocol);
}


/** Streams only observed preparation stages; the launch path stays pinned and unchanged. */
export function targetPreparationStream(current: StudioSession, selection: TargetSelection): ReadableStream<Uint8Array> {
  let cancelled = false;
  const encoder = new TextEncoder();
  return new ReadableStream({
    start(controller) {
      const send = (event: PreparationEvent) => {
        if (cancelled) throw new Error("Build preparation cancelled");
        controller.enqueue(encoder.encode(`${JSON.stringify(event)}\n`));
      };
      void prepareTarget(current, selection, (stage) => send({ type: "stage", stage }))
        .then((target) => send({ type: "ready", target }))
        .catch((error: unknown) => {
          if (!cancelled) send({ type: "error", error: studioErrorMessage(error), missingBuild: error instanceof MissingBuildError || undefined });
        })
        .finally(() => { if (!cancelled) controller.close(); });
    },
    cancel() { cancelled = true; },
  });
}

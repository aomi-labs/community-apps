"use client";
import { AomiRuntimeProvider } from "@aomi-labs/react";
import { type ReactNode, useMemo, useRef } from "react";

import { DEFAULT_MAX_CREDITS } from "@/components/campaign-controls";
import { errorText } from "@/components/error-boundary";
import { type AomiAccount, guestSession } from "@/lib/aomi-account";
import type { Campaign } from "@/lib/campaign";

// The Aomi portal (auth + proxy to the backend). Staging hosts arc-studio-fuzzer today.
export const backendUrl = process.env.NEXT_PUBLIC_AOMI_BACKEND_URL ?? "https://chat-staging.aomi.dev";
const configuredApplicationId = Number(process.env.NEXT_PUBLIC_AOMI_APPLICATION_ID);
export const applicationId =
  Number.isSafeInteger(configuredApplicationId) && configuredApplicationId > 0 ? configuredApplicationId : undefined;

/**
 * What the agent panel shows when the Aomi runtime or widget throws: the
 * campaign's saved status stays readable, the record can be downloaded, and a
 * reload reopens the campaign from its saved thread.
 */
export function CampaignCrashed({ campaign, error }: { campaign: Campaign; error: Error }) {
  return (
    <div role="alert" data-testid="campaign-crashed" className="flex flex-col gap-3 p-4 text-[13px] leading-5 text-ink">
      <div className="rounded-lg border border-danger/35 bg-danger/8 p-3">
        <p className="font-semibold text-danger">The agent panel crashed.</p>
        <p className="mt-1 font-mono text-[11px] text-ink-muted">{errorText(error)}</p>
      </div>
      <dl className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1 font-mono text-[12px]">
        <dt className="text-ink-muted">Campaign</dt>
        <dd>{campaign.target.name}</dd>
        <dt className="text-ink-muted">Status</dt>
        <dd>{campaign.status}</dd>
        {campaign.threadId && (
          <>
            <dt className="text-ink-muted">Thread</dt>
            <dd className="truncate">{campaign.threadId}</dd>
          </>
        )}
      </dl>
      <p className="text-ink-muted">
        The campaign itself was not affected: its thread keeps running on the backend and this record is saved.
      </p>
      <div className="flex flex-wrap gap-3 text-[12px]">
        <button onClick={() => window.location.reload()} className="underline">
          Reopen campaign
        </button>
        <button
          onClick={() => {
            const url = URL.createObjectURL(new Blob([JSON.stringify(campaign, null, 2)], { type: "application/json" }));
            const link = document.createElement("a");
            link.href = url;
            link.download = `${campaign.target.name}-campaign-record.json`;
            link.click();
            URL.revokeObjectURL(url);
          }}
          className="underline"
        >
          Download campaign record
        </button>
      </div>
    </div>
  );
}

export function CampaignRuntime({
  campaign,
  account,
  children,
}: {
  campaign: Campaign;
  account: AomiAccount | null;
  children: ReactNode;
}) {
  // Only recovery selects an initial thread. Publishing a new thread ID must
  // not re-run the SDK's restoration flow during the first submission.
  const initialThreadId = useRef(campaign.threadId).current;
  const clientOptions = useMemo(() => {
    if (!account) return { guest: guestSession(backendUrl) };
    const campaignFetch: typeof fetch = (input, init) => {
      const url = new URL(input instanceof Request ? input.url : String(input), backendUrl);
      if (url.pathname !== "/v1/agent/chat" || init?.method?.toUpperCase() !== "POST") return fetch(input, init);
      const headers = new Headers(init.headers);
      headers.set("x-aomi-run-budget-microusd", String((campaign.maxCredits ?? DEFAULT_MAX_CREDITS) * 10_000));
      return fetch(input, { ...init, headers });
    };
    return { ...account.options, fetch: campaignFetch };
  }, [account, campaign.maxCredits]);
  return (
    <AomiRuntimeProvider
      backendUrl={backendUrl}
      clientOptions={clientOptions}
      account={account ? { kind: "user", id: account.id } : null}
      accountSessionAvailable={Boolean(account)}
      initialThreadId={initialThreadId}
      persistThread={false}
      agentTarget={
        applicationId
          ? { mode: "direct", applicationId, app: "arc-studio-fuzzer" }
          : { mode: "direct", app: "arc-studio-fuzzer" }
      }
    >
      {children}
    </AomiRuntimeProvider>
  );
}

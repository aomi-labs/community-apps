import "@tanstack/react-start/server-only";

import { createHash, createHmac } from "node:crypto";

import { INSTALL_ADDRESS, stripComments, type ContractSource, type ProtocolContract } from "@aomi-labs/arc-studio-fuzz-core";
import type { TargetData } from "@/app/actions";

const BUCKET = "arc-snapshots";
const MAX_BYTES = 4 * 1024 * 1024;

type Artifact = {
  name: string;
  source_path: string;
  deployment_source_path?: string;
  source_code: string;
  abi: string;
  deployed_bytecode: string;
  chain_id: number;
  immutable_references: Array<{ start: number; length: number }>;
  deployment?: { address: string; chain_id: number; installed?: boolean };
  protocol: ProtocolContract[];
};
type Row = {
  id: string;
  digest: string;
  storage_path: string;
  installed_path: string | null;
  captured_at: string;
};
export type WorkspaceSnapshot = {
  appName: string;
  studioUrl: string;
  contracts: ContractSource[];
  files: string[];
  capturedAt: string;
};

function config(): { url: string; key: string; ownerKey: string } {
  const url = process.env.SUPABASE_SNAPSHOT_URL?.replace(/\/+$/, "");
  const key = process.env.SUPABASE_SNAPSHOT_SERVICE_ROLE_KEY;
  const ownerKey = process.env.SESSION_SECRET;
  // A local http fixture is allowed so the e2e stack can stand in for the store.
  const trusted = /^https:\/\/[^/]+$/.test(url ?? "") || /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(url ?? "");
  if (!url || !trusted || !key || !ownerKey || ownerKey.length < 32) {
    throw new Error("The dedicated snapshot store is not configured.");
  }
  return { url, key, ownerKey };
}

function owner(token: string, key: string): string {
  return createHmac("sha256", key).update(`arc-snapshot:${token}`).digest("hex");
}

function authHeaders(key: string): Record<string, string> {
  return key.startsWith("sb_secret_")
    ? { apikey: key }
    : { apikey: key, authorization: `Bearer ${key}` };
}

async function request(url: string, key: string, init: RequestInit = {}): Promise<Response> {
  const response = await fetch(url, {
    ...init,
    signal: init.signal ?? AbortSignal.timeout(20_000),
    headers: {
      ...authHeaders(key),
      ...init.headers,
    },
    cache: "no-store",
  });
  if (!response.ok) throw new Error(`Snapshot store returned HTTP ${response.status}.`);
  return response;
}

function digest(body: string): string {
  return createHash("sha256").update(body).digest("hex");
}

function serialize(target: TargetData, protocol: ProtocolContract[], installed: boolean): string {
  const artifact: Artifact = {
    name: target.name,
    source_path: target.sourcePath,
    source_code: target.source,
    abi: JSON.stringify(target.abi),
    deployed_bytecode: target.deployedBytecode,
    chain_id: target.chainId,
    immutable_references: target.immutableReferences ?? [],
    ...(target.deployment
      ? {
          deployment: { address: target.deployment.address, chain_id: target.deployment.chainId },
          deployment_source_path: target.sourcePath,
        }
      : installed
        ? { deployment: { address: INSTALL_ADDRESS, chain_id: target.chainId, installed: true } }
        : {}),
    protocol,
  };
  const body = JSON.stringify(artifact);
  if (Buffer.byteLength(body) > MAX_BYTES) throw new Error("Compiled artifact exceeds the 4 MB snapshot limit.");
  return body;
}

async function upload(url: string, key: string, path: string, body: string): Promise<void> {
  const response = await fetch(`${url}/storage/v1/object/${BUCKET}/${path}`, {
    method: "POST",
    signal: AbortSignal.timeout(20_000),
    headers: {
      ...authHeaders(key),
      "content-type": "application/json",
      "x-upsert": "false",
    },
    body,
  });
  if (response.ok) return;
  // Supabase currently uses HTTP 400 for an existing object, though newer
  // storage errors may use 409. Only that exact conflict is safe to ignore.
  const error = (await response.json().catch(() => ({}))) as { code?: string; error?: string; message?: string };
  const duplicate = [error.code, error.error, error.message].some((value) =>
    /^(Asset Already Exists|Duplicate|ResourceAlreadyExists|already_exists)$/i.test(value ?? ""),
  );
  if (!duplicate || (response.status !== 400 && response.status !== 409)) {
    throw new Error(`Snapshot upload returned HTTP ${response.status}.`);
  }
}

async function findRow(
  token: string,
  appId: string,
  sourcePath: string,
  contract: string,
  snapshotId?: string,
  hash?: string,
): Promise<Row | null> {
  const { url, key, ownerKey } = config();
  const query = new URLSearchParams({
    select: "id,digest,storage_path,installed_path,captured_at",
    owner_hash: `eq.${owner(token, ownerKey)}`,
    app_id: `eq.${appId}`,
    source_path: `eq.${sourcePath}`,
    contract_name: `eq.${contract}`,
    ...(snapshotId ? { id: `eq.${snapshotId}` } : {}),
    ...(hash ? { digest: `eq.${hash}` } : {}),
    ...(!snapshotId && !hash ? { order: "captured_at.desc", limit: "1" } : {}),
  });
  const response = await request(`${url}/rest/v1/arc_snapshots?${query}`, key);
  const rows = (await response.json()) as Row[];
  return rows[0] ?? null;
}

async function readArtifact(row: Row): Promise<Artifact> {
  const { url, key } = config();
  const response = await request(`${url}/storage/v1/object/authenticated/${BUCKET}/${row.storage_path}`, key);
  const reader = response.body?.getReader();
  if (!reader) throw new Error("The saved Arc snapshot is empty.");
  const chunks: Uint8Array[] = [];
  let size = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > MAX_BYTES) throw new Error("The saved Arc snapshot exceeds 4 MB.");
      chunks.push(value);
    }
  } finally {
    await reader.cancel().catch(() => {});
  }
  const body = Buffer.concat(chunks).toString("utf8");
  if (digest(body) !== row.digest) {
    throw new Error("The saved Arc snapshot failed its content hash check.");
  }
  return JSON.parse(body) as Artifact;
}

function deploymentMatchesSource(artifact: Artifact): boolean {
  if (!artifact.deployment || artifact.deployment.installed === true) return true;
  return artifact.deployment_source_path === artifact.source_path;
}

function toTarget(row: Row, artifact: Artifact): TargetData {
  return {
    name: artifact.name,
    sourcePath: artifact.source_path,
    source: artifact.source_code,
    abi: JSON.parse(artifact.abi) as TargetData["abi"],
    deployedBytecode: artifact.deployed_bytecode,
    chainId: artifact.chain_id,
    immutableReferences: artifact.immutable_references,
    ...(artifact.deployment && !artifact.deployment.installed
      ? { deployment: { address: artifact.deployment.address, chainId: artifact.deployment.chain_id } }
      : {}),
    protocol: artifact.protocol.map(({ name, address }) => ({ name, address })),
    snapshotId: row.id,
    snapshotHash: row.digest,
    capturedAt: row.captured_at,
  };
}

export async function savedSnapshot(
  token: string,
  appId: string,
  sourcePath: string,
  contract: string,
  snapshotId?: string,
): Promise<TargetData | null> {
  const row = await findRow(token, appId, sourcePath, contract, snapshotId);
  if (!row) return null;
  const artifact = await readArtifact(row);
  // Earlier snapshots paired deployments by name alone. Keep them immutable,
  // but prepare a source-scoped build before using one for a new campaign.
  if (!deploymentMatchesSource(artifact)) return null;
  return toTarget(row, artifact);
}

export async function saveSnapshot(
  token: string,
  appId: string,
  target: TargetData,
  protocol: ProtocolContract[],
): Promise<TargetData> {
  const { url, key, ownerKey } = config();
  const scope = owner(token, ownerKey);
  const body = serialize(target, protocol, false);
  const hash = digest(body);
  const path = `${scope}/${appId}/${hash}.json`;
  const installed = target.deployment ? null : serialize(target, protocol, true);
  const installedPath = installed ? `${scope}/${appId}/${digest(installed)}.json` : null;
  await upload(url, key, path, body);
  if (installed && installedPath) await upload(url, key, installedPath, installed);
  const response = await request(`${url}/rest/v1/arc_snapshots?on_conflict=owner_hash,app_id,source_path,contract_name,digest`, key, {
    method: "POST",
    headers: { "content-type": "application/json", prefer: "resolution=ignore-duplicates,return=representation" },
    body: JSON.stringify({
      owner_hash: scope,
      app_id: appId,
      source_path: target.sourcePath,
      contract_name: target.name,
      digest: hash,
      storage_path: path,
      installed_path: installedPath,
    }),
  });
  const rows = (await response.json()) as Row[];
  const row = rows[0] ?? (await findRow(token, appId, target.sourcePath, target.name, undefined, hash));
  if (!row || row.digest !== hash) throw new Error("Could not confirm the saved Arc snapshot.");
  return toTarget(row, JSON.parse(body) as Artifact);
}

async function signedUrl(path: string): Promise<string> {
  const { url, key } = config();
  const response = await request(`${url}/storage/v1/object/sign/${BUCKET}/${path}`, key, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ expiresIn: 1800 }),
  });
  const { signedURL } = (await response.json()) as { signedURL?: string };
  if (!signedURL?.startsWith(`/object/sign/${BUCKET}/`)) throw new Error("Snapshot store returned an invalid signed link.");
  return `${url}/storage/v1${signedURL}`;
}

/**
 * The same artifact with comments stripped from its source, stored beside the
 * original. Content-addressed like it, so a repeat launch reuses the object.
 */
async function blindCopy(path: string, artifact: Artifact, installed: boolean): Promise<string> {
  const { url, key } = config();
  const blind: Artifact = {
    ...artifact,
    source_code: stripComments(artifact.source_code),
    ...(installed && { deployment: { address: INSTALL_ADDRESS, chain_id: artifact.chain_id, installed: true } }),
  };
  const body = JSON.stringify(blind);
  const blindPath = `${path.slice(0, path.lastIndexOf("/"))}/${digest(body)}.blind.json`;
  await upload(url, key, blindPath, body);
  return blindPath;
}

export async function launchSnapshot(
  token: string,
  appId: string,
  sourcePath: string,
  contract: string,
  snapshotId: string,
  blind = false,
): Promise<TargetData> {
  const row = await findRow(token, appId, sourcePath, contract, snapshotId);
  if (!row) throw new Error("This prepared snapshot is unavailable. Refresh the build before running.");
  const artifact = await readArtifact(row);
  if (!deploymentMatchesSource(artifact)) {
    throw new Error("Refresh the build to verify its deployment source before running a new campaign.");
  }
  const target = toTarget(row, artifact);
  // Blind runs hand the agent a copy without comments; the preview keeps them.
  const storagePath = blind ? await blindCopy(row.storage_path, artifact, false) : row.storage_path;
  const installedPath = row.installed_path && blind ? await blindCopy(row.installed_path, artifact, true) : row.installed_path;
  target.artifactUrl = await signedUrl(storagePath);
  if (installedPath) target.installedArtifactUrl = await signedUrl(installedPath);
  return target;
}

export async function savedWorkspace(token: string, appId: string): Promise<WorkspaceSnapshot | null> {
  const { url, key, ownerKey } = config();
  const query = new URLSearchParams({
    select: "app_name,studio_url,contracts,files,captured_at",
    owner_hash: `eq.${owner(token, ownerKey)}`,
    app_id: `eq.${appId}`,
    limit: "1",
  });
  const response = await request(`${url}/rest/v1/arc_workspaces?${query}`, key);
  const rows = (await response.json()) as Array<{
    app_name: string; studio_url: string; contracts: ContractSource[]; files: string[]; captured_at: string;
  }>;
  const row = rows[0];
  return row ? { appName: row.app_name, studioUrl: row.studio_url, contracts: row.contracts,
    files: row.files, capturedAt: row.captured_at } : null;
}

export async function saveWorkspace(token: string, appId: string, workspace: Omit<WorkspaceSnapshot, "capturedAt">): Promise<void> {
  const { url, key, ownerKey } = config();
  await request(`${url}/rest/v1/arc_workspaces?on_conflict=owner_hash,app_id`, key, {
    method: "POST",
    headers: { "content-type": "application/json", prefer: "resolution=merge-duplicates,return=minimal" },
    body: JSON.stringify({ owner_hash: owner(token, ownerKey), app_id: appId,
      app_name: workspace.appName, studio_url: workspace.studioUrl,
      contracts: workspace.contracts, files: workspace.files, captured_at: new Date().toISOString() }),
  });
}

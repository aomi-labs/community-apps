import {
  cleanup,
  fireEvent,
  render,
  screen,
  waitFor,
} from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { afterEach, expect, test, vi } from "vitest";
import type { ReactNode } from "react";
import {
  AccountSurface,
  AccountControl,
  useAddCredits,
} from "./account-surface";
import type { AomiAccount } from "@/lib/aomi-account";

const dialog = vi.hoisted(() => vi.fn());
vi.mock("@aomi-labs/widget/host-composition", () => ({
  WidgetScope: ({ children }: { children: ReactNode }) => children,
  AomiWalletKitProvider: ({ children }: { children: ReactNode }) => children,
  useAomiWalletKit: () => ({ wallets: [] }),
  AccountAvatar: () => null,
  AccountMenu: () => null,
  CreditCheckoutDialog: (props: {
    open: boolean;
    onSuccess: () => Promise<void>;
    onClose: () => void;
  }) => {
    dialog(props);
    return props.open ? (
      <div role="dialog">
        <button onClick={props.onSuccess}>Complete fixture payment</button>
        <button onClick={props.onClose}>Close</button>
      </div>
    ) : null;
  },
}));
afterEach(cleanup);
function Controls() {
  const add = useAddCredits();
  return (
    <>
      <AccountControl />
      <button onClick={add}>Add credits</button>
    </>
  );
}
function account(id: string) {
  const credits = {
    get: vi.fn(async () => ({ available_microusd: 10_000_000 })),
  };
  return {
    id,
    client: {
      account: {
        credits,
        getAccount: async () => ({ user: { id, displayName: id } }),
      },
    },
  } as unknown as AomiAccount;
}
test("local checkout refreshes the signed-in account balance without replaying work", async () => {
  const current = account("account-a");
  const onAccount = vi.fn();
  const queries = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });
  render(
    <QueryClientProvider client={queries}>
      <AccountSurface
        account={current}
        baseUrl="https://aomi.test"
        onAccount={onAccount}
      >
        <Controls />
      </AccountSurface>
    </QueryClientProvider>,
  );
  await screen.findByText("1,000 credits available");
  fireEvent.click(screen.getByText("Add credits"));
  expect(screen.getByRole("dialog")).toBeTruthy();
  expect(dialog.mock.lastCall?.[0].credits).toBe(
    current.client.account.credits,
  );
  vi.mocked(current.client.account.credits.get).mockResolvedValue({
    balance_microusd: 15_000_000,
    available_microusd: 15_000_000,
    reserved_microusd: 0,
    debt_microusd: 0,
    period_utc_month: "2026-10",
    included: { limit_microusd: 0, used_microusd: 0, remaining_microusd: 0 },
  });
  fireEvent.click(screen.getByText("Complete fixture payment"));
  await screen.findByText("1,500 credits available");
  expect(onAccount).not.toHaveBeenCalled();
});
test("account switching closes the old checkout and never reuses its transport", async () => {
  const queries = new QueryClient();
  const a = account("account-a"),
    b = account("account-b");
  const view = (current: AomiAccount) => (
    <QueryClientProvider client={queries}>
      <AccountSurface
        account={current}
        baseUrl="https://aomi.test"
        onAccount={() => {}}
      >
        <Controls />
      </AccountSurface>
    </QueryClientProvider>
  );
  const rendered = render(view(a));
  fireEvent.click(screen.getByText("Add credits"));
  expect(screen.getByRole("dialog")).toBeTruthy();
  rendered.rerender(view(b));
  await waitFor(() => expect(screen.queryByRole("dialog")).toBeNull());
  fireEvent.click(screen.getByText("Add credits"));
  expect(dialog.mock.lastCall?.[0].credits).toBe(b.client.account.credits);
});

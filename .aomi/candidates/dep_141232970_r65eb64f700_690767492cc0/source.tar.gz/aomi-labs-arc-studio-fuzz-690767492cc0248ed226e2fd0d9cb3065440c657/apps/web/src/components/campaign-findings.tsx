// What a campaign proved: the verified finding, the fix verdict on a patched
// build, and the actions whose paths were never exercised.
import type { FixVerdict, FuzzCampaignReport, FuzzFinding } from "@aomi-labs/arc-studio-fuzz-core";

export function short(value: string, head = 8, tail = 6): string {
  return value.length <= head + tail + 1 ? value : `${value.slice(0, head)}…${value.slice(-tail)}`;
}

/** A violation the engine minimized and reproduced twice from the baseline. */
export function VerifiedFinding({
  finding,
  report,
  onSource,
}: {
  finding: FuzzFinding;
  report: FuzzCampaignReport;
  onSource?: (name: string, contract?: string | null) => void;
}) {
  return (
    <div data-testid="verified-finding" className="mt-4 rounded-lg border border-danger/35 bg-danger/8 p-3">
      <div className="flex items-center justify-between">
        <span className="text-[12px] font-bold uppercase tracking-wider text-danger">Verified finding</span>
        <span className="rounded-pill bg-success/10 px-2 py-1 font-mono text-[11px] text-success">
          REPLAYED 2×
        </span>
      </div>
      <p className="mt-2 text-[13px] leading-5 text-ink">{finding.property}</p>
      <div className="mt-3 space-y-1.5">
        {finding.minimized_trace.map((call, index) => (
          <div
            key={`${call.label}-${index}`}
            className="flex items-center gap-2 rounded-sm border border-border bg-bg px-2.5 py-2"
          >
            <span className="grid size-5 place-items-center rounded-pill bg-accent-subtle font-mono text-[11px] text-accent-strong">
              {index + 1}
            </span>
            <span className="font-mono text-[12px] text-ink">
              {call.actor} → {call.contract ? `${call.contract}.` : ""}{" "}
              <button className="underline" onClick={() => onSource?.(call.function, call.contract)}>
                {call.function}
              </button>
            </span>
          </div>
        ))}
      </div>
      {finding.balances.length > 0 && (
        <details className="mt-3 text-xs">
          <summary className="cursor-pointer">Observed balance changes</summary>
          <table className="mt-2 w-full text-left">
            <thead>
              <tr>
                <th>Address</th>
                <th>Before (base units)</th>
                <th>After (base units)</th>
              </tr>
            </thead>
            <tbody>
              {finding.balances.map((balance) => (
                <tr key={balance.address}>
                  <td title={balance.address}>{short(balance.address)}</td>
                  <td>{balance.before}</td>
                  <td>{balance.after}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </details>
      )}
      <div className="mt-3 grid grid-cols-3 gap-2">
        {(
          [
            ["round", report.round],
            ["executions", report.executions],
            ["corpus", report.corpus_size],
          ] as const
        ).map(([label, value]) => (
          <div key={label} className="rounded-sm border border-border bg-bg p-2">
            <div className="text-[11px] uppercase text-ink-muted">{label}</div>
            <div className="mt-1 font-mono text-[13px] text-ink">{value}</div>
          </div>
        ))}
      </div>
      <p className="mt-3 text-center font-mono text-[11px] text-ink-muted/70">
        {short(report.campaign_id)} · Arc fork · no signing
      </p>
    </div>
  );
}

/** Whether earlier findings still reproduce on this build. */
export function FixVerdictBadge({ verdict }: { verdict: FixVerdict }) {
  const reproduced = verdict.replayed.filter((item) => item.outcome === "reproduced").map((item) => item.property);
  return (
    <p
      data-testid="fix-verdict"
      className={`mt-1 inline-block rounded-pill px-2 py-0.5 text-[11px] font-semibold ${
        verdict.verdict === "blocked"
          ? "bg-success/10 text-success"
          : verdict.verdict === "still_reproduces"
            ? "bg-danger/10 text-danger"
            : "bg-warning/10 text-warning"
      }`}
    >
      {verdict.verdict === "blocked"
        ? `Fix verdict: blocked · ${verdict.replayed.length} earlier ${verdict.replayed.length === 1 ? "finding" : "findings"} no longer reproduce`
        : verdict.verdict === "still_reproduces"
          ? `Fix verdict: still reproduces · ${reproduced.join(", ")}`
          : "Fix verdict: inconclusive · an earlier finding could not be replayed to a conclusion"}
    </p>
  );
}

/** Actions that never succeeded: paths through them were not tested, not proven safe. */
export function NotTested({ actions }: { actions: readonly string[] }) {
  if (actions.length === 0) return null;
  return (
    <p data-testid="not-tested" className="mt-1 text-[12px] leading-5 text-warning">
      Not tested: {actions.join(", ")} never succeeded, so paths through {actions.length === 1 ? "it were" : "them were"} not
      exercised.
    </p>
  );
}

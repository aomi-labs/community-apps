"use client";
import { AccountSurface, AccountControl } from "./account-surface";

import { useQueryClient } from "@tanstack/react-query";

import {
  ArcStudioApp,
  recordState,
  statusLabel as statusLabelOf,
  type CampaignRecord,
  type ContractSource,
  type PriorFinding,
} from "@aomi-labs/arc-studio-fuzz-core";
import { campaignSignature, readCampaigns, saveCampaigns, type Campaign } from "@/lib/campaign";
import { listCampaigns, saveCampaign } from "@/app/campaign-actions";
import {
  Check,
  ChevronLeft,
  CircleDashed,
  ExternalLink,
  File as FileIcon,
  FileCode2,
  Hammer,
  Loader2,
  X,
} from "lucide-react";
import { Link, useRouter } from "@tanstack/react-router";
import {
  type Dispatch,
  type ReactNode,
  type SetStateAction,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  useTransition,
} from "react";

import { loadTarget, prepareTargetWithProgress, refreshApp, requestBuild, type TargetData } from "@/app/actions";
import { BuildPreparation } from "@/components/build-preparation";
import { readPreparation, preparationSteps, type PreparationStage } from "@/lib/preparation";
import { Brand } from "@/components/brand";
import { AomiAccount } from "@/lib/aomi-account";
import { FileTree } from "@/components/file-tree";
import { ErrorBoundary } from "@/components/error-boundary";
import { FuzzPanel } from "@/components/fuzz-panel";
import { CampaignCrashed, CampaignRuntime, applicationId, backendUrl } from "@/components/campaign-runtime";


const KEYWORDS =
  /\b(?:contract|interface|library|abstract|is|mapping|address|bool|string|bytes\d*|u?int\d*|public|private|internal|external|view|pure|payable|function|modifier|event|error|emit|returns?|require|revert|if|else|for|while|memory|storage|calldata|constructor|pragma|solidity|import|using|struct|enum|override|virtual|immutable|constant)\b/;

export function highlight(line: string): ReactNode {
  if (line.trim().startsWith("//")) return <span className="text-ink-muted">{line}</span>;
  return line.split(new RegExp(`(${KEYWORDS.source})`, "g")).map((token, index) =>
    KEYWORDS.test(token) ? (
      <span key={index} className="text-accent-strong">
        {token}
      </span>
    ) : (
      token
    ),
  );
}

type TargetState =
  | { status: "idle" }
  | { status: "loading"; stages: PreparationStage[]; startedAt: number; stageStartedAt: number }
  | { status: "ready"; target: TargetData }
  | { status: "missing-build"; error: string; buildUrl?: string }
  | { status: "error"; error: string };

export interface FuzzWorkspaceProps {
  appId: string;
  appName: string;
  studioUrl: string;
  contracts: ContractSource[];
  /** Paths Arc Studio listed in the sandbox; empty usually means it was still waking up. */
  files: string[];
}

export function FuzzWorkspace(props: FuzzWorkspaceProps) {
  const queries = useQueryClient();
  const [account, setAccount] = useState<AomiAccount | null>(null);
  const accountRef = useRef(account);
  accountRef.current = account;
  const [identityReady, setIdentityReady] = useState(false);
  // Navigation is independent of the runtimes retained for each contract.
  const firstBuilt =
    props.contracts.find((file) => file.built && file.contracts.length > 0) ??
    props.contracts.find((file) => file.contracts.length > 0);
  const [selected, setSelected] = useState<Selection | null>(
    firstBuilt ? { path: firstBuilt.path, contract: firstBuilt.contracts[0] as string } : null,
  );
  const [opened, setOpened] = useState<OpenFile | null>(
    firstBuilt ? { path: firstBuilt.path, content: firstBuilt.source } : null,
  );
  const [target, setTarget] = useState<TargetState>({ status: "idle" });
  const [refreshRequest, setRefreshRequest] = useState<{
    path: string;
    contract: string;
    nonce: number;
    refresh: boolean;
  } | null>(null);
  const preparation = useRef<AbortController | null>(null);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [activeCampaign, setActiveCampaign] = useState<string>();
  const [restored, setRestored] = useState<string>();
  const scope = JSON.stringify([backendUrl, props.appId, account?.id ?? "guest"]);

  useEffect(() => {
    if (!identityReady) return;
    let cancelled = false;
    setCampaigns([]);
    setActiveCampaign(undefined);
    // Listing saved campaigns must not renew an expired wallet session.
    // The runtime reconnects only when the visitor opens a campaign.
    const local = readCampaigns(scope).map((run) =>
      run.status === "Unavailable" ? { ...run, status: "Incomplete" } : run,
    );
    // The server store is the record of truth; the browser's copy is a cache
    // that survives an unreachable store. A campaign only the browser knows
    // (saved before the store existed) is written through on its next change.
    void listCampaigns({ data: { appId: props.appId } })
      .then((result) => {
        if (cancelled) return;
        if (!result.ok) {
          setCampaigns(local);
          return;
        }
        const merged = new Map(local.map((run) => [run.id, run]));
        for (const record of JSON.parse(result.json) as CampaignRecord[]) {
          const known = merged.get(record.id);
          const target = record.target as Campaign["target"];
          if (typeof target.source !== "string" || !Array.isArray(target.abi)) continue;
          merged.set(record.id, {
            id: record.id,
            target,
            threadId: record.threadId,
            status: known?.status ?? statusLabelOf(record.state.status),
            resumes: record.local.resumes ?? known?.resumes ?? 0,
            createdAt: record.createdAt,
            events: record.events,
            local: record.local,
            blind: record.blind,
            cost: record.cost,
            maxCredits: record.maxCredits,
            savedAt: record.updatedAt,
          });
        }
        setCampaigns([...merged.values()].sort((a, b) => a.createdAt - b.createdAt));
      })
      .catch(() => {
        if (!cancelled) setCampaigns(local);
      })
      .finally(() => {
        if (!cancelled) setRestored(scope);
      });
    return () => {
      cancelled = true;
    };
  }, [scope, identityReady, props.appId]);

  useEffect(() => {
    if (restored === scope) saveCampaigns(scope, campaigns);
  }, [scope, restored, campaigns]);

  // Write-through: every change to a started campaign reaches the store
  // within a second, so a crashed tab or an empty balance never loses a run.
  const savedSignatures = useRef(new Map<string, string>());
  useEffect(() => {
    if (restored !== scope) return;
    const pending = campaigns.filter(
      (run) => run.threadId && run.events && savedSignatures.current.get(run.id) !== campaignSignature(run),
    );
    if (pending.length === 0) return;
    const timer = setTimeout(() => {
      for (const run of pending) {
        const signature = campaignSignature(run);
        savedSignatures.current.set(run.id, signature);
        const { artifactUrl: _artifact, installedArtifactUrl: _installed, ...target } = run.target;
        void saveCampaign({
          data: {
            id: run.id,
            appId: props.appId,
            target,
            threadId: run.threadId,
            local: { ...(run.local ?? { started: true }), resumes: run.resumes },
            events: (run.events ?? []) as unknown as Array<Record<string, unknown>>,
            blind: run.blind,
            cost: run.cost,
            maxCredits: run.maxCredits,
            createdAt: run.createdAt,
          },
        })
          .then((result) => {
            if (!result.ok) throw new Error(result.error);
            setCampaigns((current) =>
              current.map((item) => (item.id === run.id ? { ...item, savedAt: result.updatedAt } : item)),
            );
          })
          .catch((error: unknown) => {
            console.warn("Could not save the campaign to the store; the browser copy remains.", error);
            if (savedSignatures.current.get(run.id) === signature) savedSignatures.current.delete(run.id);
          });
      }
    }, 1_000);
    return () => clearTimeout(timer);
  }, [campaigns, restored, scope, props.appId]);

  useEffect(() => {
    if (!selected) return;
    let cancelled = false;
    const controller = new AbortController();
    preparation.current = controller;
    const deadline = AbortSignal.timeout(90_000);
    let stage: PreparationStage | undefined;
    setTarget({ status: "loading", stages: [], startedAt: Date.now(), stageStartedAt: Date.now() });
    void queries
      .fetchQuery({
        queryKey: ["target", props.appId, selected.path, selected.contract, refreshRequest?.nonce ?? 0],
        queryFn: async ({ signal }) => {
          const requestSignal = AbortSignal.any([signal, controller.signal, deadline]);
          const stream = await prepareTargetWithProgress({
            data: {
              appId: props.appId,
              sourcePath: selected.path,
              contract: selected.contract,
              refresh:
                refreshRequest?.path === selected.path &&
                refreshRequest.contract === selected.contract &&
                refreshRequest.refresh,
            },
            signal: requestSignal,
          });
          const result = await readPreparation(
            stream,
            (next) => {
              stage = next;
              if (!cancelled)
                setTarget((current) =>
                  current.status === "loading"
                    ? { ...current, stages: [...current.stages, next], stageStartedAt: Date.now() }
                    : current,
                );
            },
            requestSignal,
          );
          return result.type === "ready"
            ? { ok: true as const, value: result.target }
            : { ok: false as const, error: result.error, missingBuild: result.missingBuild };
        },
        retry: false,
        staleTime: 60_000,
      })
      .then((result) => {
        if (cancelled) return;
        if (result.ok) {
          setTarget({ status: "ready", target: result.value });
        } else if (result.missingBuild) setTarget({ status: "missing-build", error: result.error });
        else setTarget({ status: "error", error: result.error });
      })
      .catch((error: unknown) => {
        if (!cancelled)
          setTarget({
            status: "error",
            error: deadline.aborted
              ? `Build preparation timed out after 90 seconds${stage ? ` at “${preparationSteps[stage]}”` : ""}. No fork was created. Try again.`
              : controller.signal.aborted
                ? "Build preparation cancelled. No fork was created."
                : error instanceof Error
                  ? error.message
                  : String(error),
          });
      });
    return () => {
      cancelled = true;
      controller.abort();
      void queries.cancelQueries({
        queryKey: ["target", props.appId, selected.path, selected.contract, refreshRequest?.nonce ?? 0],
      });
    };
  }, [props.appId, selected, refreshRequest, queries]);

  useEffect(() => {
    let canceled = false;
    void AomiAccount.resume(backendUrl)
      .then((restored) => {
        if (!canceled && !accountRef.current) { accountRef.current = restored; setAccount(restored); }
      })
      .catch(() => {})
      .finally(() => { if (!canceled) setIdentityReady(true); });
    return () => { canceled = true; };
  }, []);

  return (
    <Workspace
      {...props}
      account={account}
      onAccount={(next) => {
        if (accountRef.current !== account) {
          next?.dispose();
          return;
        }
        account?.dispose();
        accountRef.current = next;
        setAccount(next);
      }}
      selected={selected}
      onSelect={(selection) => { setRefreshRequest(null); setSelected(selection); }}
      opened={opened}
      onOpen={setOpened}
      target={target}
      campaigns={campaigns}
      activeCampaign={activeCampaign}
      onCampaign={setActiveCampaign}
      onCampaigns={setCampaigns}
      ready={restored === scope}
      onTarget={setTarget}
      onCancelPreparation={() => preparation.current?.abort()}
      onRetry={() => {
        if (!selected) return;
        queries.removeQueries({ queryKey: ["target", props.appId] });
        setRefreshRequest((current) => ({ ...selected, nonce: (current?.nonce ?? 0) + 1, refresh: false }));
      }}
      onReload={() => {
        if (!selected) return;
        queries.removeQueries({ queryKey: ["target", props.appId] });
        setRefreshRequest((current) => ({ ...selected, nonce: (current?.nonce ?? 0) + 1, refresh: true }));
      }}
    />
  );
}


const LAYOUT_KEY = "arc-studio-fuzz:layout";
const LIMITS = { explorer: [180, 520], agent: [340, 760], activity: [10, 80] } as const;
// Side widths use pixels; activity height uses viewport height units.
const DEFAULT_LAYOUT = { explorer: 280, agent: 460, activity: 55 };
const MAX_VIEW_BYTES = 300_000;

type Layout = typeof DEFAULT_LAYOUT;
type OpenFile = { path: string; content?: string; error?: string; line?: number };
type Selection = { path: string; contract: string };

/** Drag a panel boundary; double-click restores its default size. */
function Divider({
  onDrag,
  onReset,
  horizontal = false,
}: {
  onDrag: (delta: number) => void;
  onReset: () => void;
  horizontal?: boolean;
}) {
  return (
    <div
      role="separator"
      aria-orientation={horizontal ? "horizontal" : "vertical"}
      aria-label={horizontal ? "Resize campaign activity" : "Resize side panel"}
      title="Drag to resize · double-click to reset"
      onDoubleClick={onReset}
      onPointerDown={(event) => {
        if (event.button !== 0) return;
        const handle = event.currentTarget;
        handle.setPointerCapture(event.pointerId);
        let last = horizontal ? event.clientY : event.clientX;
        const move = (e: PointerEvent) => {
          const position = horizontal ? e.clientY : e.clientX;
          onDrag(position - last);
          last = position;
        };
        const up = () => {
          handle.removeEventListener("pointermove", move);
          handle.removeEventListener("pointerup", up);
          handle.removeEventListener("lostpointercapture", up);
          document.body.style.removeProperty("cursor");
          document.body.style.removeProperty("user-select");
        };
        document.body.style.cursor = horizontal ? "row-resize" : "col-resize";
        document.body.style.userSelect = "none";
        handle.addEventListener("pointermove", move);
        handle.addEventListener("pointerup", up);
        handle.addEventListener("lostpointercapture", up);
      }}
      className={`group relative z-10 flex shrink-0 touch-none ${horizontal ? "-my-1 h-2 cursor-row-resize" : "-mx-1 w-2 cursor-col-resize"}`}
    >
      <div
        className={`bg-border transition group-hover:bg-accent group-active:bg-accent ${
          horizontal ? "my-auto h-px w-full group-hover:h-0.5" : "mx-auto h-full w-px group-hover:w-0.5"
        }`}
      />
    </div>
  );
}

function Workspace({
  appId,
  appName,
  studioUrl,
  contracts,
  files,
  account,
  onAccount,
  selected,
  onSelect: setSelected,
  opened,
  onOpen: setOpened,
  target,
  campaigns,
  activeCampaign,
  onCampaign,
  onCampaigns,
  ready,
  onTarget: setTarget,
  onReload,
  onRetry,
  onCancelPreparation,
}: FuzzWorkspaceProps & {
  account: AomiAccount | null;
  onAccount: (account: AomiAccount | null) => void;
  selected: Selection | null;
  onSelect: (selection: Selection | null) => void;
  opened: OpenFile | null;
  onOpen: Dispatch<SetStateAction<OpenFile | null>>;
  target: TargetState;
  campaigns: Campaign[];
  activeCampaign?: string;
  onCampaign: (id: string | undefined) => void;
  onCampaigns: Dispatch<SetStateAction<Campaign[]>>;
  ready: boolean;
  onTarget: (target: TargetState) => void;
  onReload: () => void;
  onRetry: () => void;
  onCancelPreparation: () => void;
}) {
  const router = useRouter();
  const refreshController = useRef<AbortController | null>(null);
  /** The mean cost of the last ten costed runs on this app, for the panel's estimate. */
  const estimate = useMemo(() => {
    const costed = campaigns
      .filter((run) => run.cost && run.cost.microusd > 0)
      .sort((a, b) => b.createdAt - a.createdAt)
      .slice(0, 10);
    if (costed.length === 0) return null;
    return { microusd: costed.reduce((sum, run) => sum + (run.cost?.microusd ?? 0), 0) / costed.length, runs: costed.length };
  }, [campaigns]);
  /**
   * For each campaign, the findings earlier campaigns confirmed on the same
   * target, latest per property, so a run on a fixed build replays them first
   * and gets a fix verdict.
   */
  const priorFindings = useMemo(() => {
    const byCampaign = new Map<string, PriorFinding[]>();
    for (const campaign of campaigns) {
      const prior = new Map<string, PriorFinding>();
      const earlier = campaigns
        .filter(
          (run) =>
            run.id !== campaign.id &&
            run.createdAt < campaign.createdAt &&
            run.target.sourcePath === campaign.target.sourcePath &&
            run.target.name === campaign.target.name &&
            run.events &&
            run.local,
        )
        .sort((a, b) => a.createdAt - b.createdAt);
      for (const run of earlier) {
        const events = run.events as unknown as CampaignRecord["events"];
        for (const finding of recordState({ events, local: run.local! }).findings) {
          prior.set(finding.property, { property: finding.property, trace: finding.minimized_trace });
        }
      }
      if (prior.size > 0) byCampaign.set(campaign.id, [...prior.values()]);
    }
    return byCampaign;
  }, [campaigns]);
  const [building, startBuild] = useTransition();
  const [layout, setLayout] = useState<Layout>(DEFAULT_LAYOUT);
  /** File reads by path, fetched only when a viewer opens them. */
  const reads = useRef(new Map<string, Promise<OpenFile>>());
  const [tabs, setTabs] = useState<string[]>([]);
  const [chosenTarget, setChosenTarget] = useState(false);
  const [activatedCampaigns, setActivatedCampaigns] = useState<Set<string>>(() => new Set());
  /** The "Campaign activity" section's body, where a running campaign's feed is shown. */
  const [activityHost, setActivityHost] = useState<HTMLElement | null>(null);
  const sourceView = useRef<HTMLDivElement>(null);
  const scrolls = useRef(new Map<string, number>());
  useEffect(() => {
    if (opened) setTabs((current) => (current.includes(opened.path) ? current : [...current, opened.path]));
  }, [opened]);
  useLayoutEffect(() => {
    if (sourceView.current && opened)
      sourceView.current.scrollTop =
        opened.line !== undefined ? opened.line * 23 : (scrolls.current.get(opened.path) ?? 0);
  }, [opened?.path, opened?.line]);
  const fuzzable = contracts.filter((file) => file.contracts.length > 0);
  const scaffoldOnly = files.some((path) => /(^|\/)contracts\/(out|script)\//.test(path));

  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(LAYOUT_KEY) ?? "null") as Partial<Layout> | null;
      if (saved) setLayout((current) => ({ ...current, ...saved }));
    } catch {
      /* per-viewer convenience only */
    }
  }, []);

  function resize(panel: keyof Layout, delta: number) {
    setLayout((current) => {
      const [min, max] = LIMITS[panel];
      const next = { ...current, [panel]: Math.min(max, Math.max(min, current[panel] + delta)) };
      try {
        localStorage.setItem(LAYOUT_KEY, JSON.stringify(next));
      } catch {
        /* ignore */
      }
      return next;
    });
  }

  function read(path: string): Promise<OpenFile> {
    let pending = reads.current.get(path);
    if (!pending) {
      pending = fetch(`/api/apps/${appId}/file?path=${encodeURIComponent(path)}`).then(async (response) =>
        response.ok ? { path, content: await response.text() } : { path, error: await response.text() },
      );
      // Failed reads are retried on the next click.
      void pending.then((file) => file.error && reads.current.delete(path));
      reads.current.set(path, pending);
    }
    return pending;
  }

  /** Closes a source tab; closing the viewed file shows its left neighbour (or the next one), or nothing when it was the last tab. */
  function close(path: string) {
    const index = tabs.indexOf(path);
    const remaining = tabs.filter((tab) => tab !== path);
    setTabs(remaining);
    scrolls.current.delete(path);
    if (opened?.path !== path) return;
    const next = remaining[index - 1] ?? remaining[index];
    if (next === undefined) setOpened(null);
    else open(next);
  }

  function open(path: string) {
    const known = contracts.find((file) => file.path === path);
    if (known) {
      setOpened({ path, content: known.source });
      return;
    }
    setOpened({ path });
    void read(path).then((file) => setOpened((current) => (current?.path === path ? file : current)));
  }

  function choose(path: string, contract: string) {
    setChosenTarget(true);
    onCampaign(undefined);
    setSelected({ path, contract });
    open(path);
  }

  /** Re-read the workspace from Arc Studio (after a build or fix landed there). */
  async function refresh() {
    reads.current.clear();
    const controller = new AbortController();
    refreshController.current = controller;
    const deadline = AbortSignal.timeout(90_000);
    setTarget({ status: "loading", stages: ["workspace"], startedAt: Date.now(), stageStartedAt: Date.now() });
    onCampaign(undefined);
    try {
      await refreshApp({ data: { appId }, signal: AbortSignal.any([controller.signal, deadline]) });
      await router.invalidate();
      onReload();
    } catch (error) {
      setTarget({
        status: "error",
        error: deadline.aborted
          ? "Refreshing the file list timed out after 90 seconds. Try again."
          : controller.signal.aborted
            ? "Workspace refresh cancelled."
            : error instanceof Error
              ? error.message
              : String(error),
      });
    } finally {
      refreshController.current = null;
    }
  }

  useEffect(() => {
    if (
      !ready ||
      !chosenTarget ||
      target.status !== "ready" ||
      activeCampaign ||
      selected?.path !== target.target.sourcePath ||
      selected.contract !== target.target.name
    )
      return;
    const existing = campaigns.findLast(
      (run) => run.target.sourcePath === target.target.sourcePath && run.target.name === target.target.name,
    );
    if (existing) {
      setActivatedCampaigns((current) => new Set(current).add(existing.id));
      onCampaign(existing.id);
      return;
    }
    const run: Campaign = {
      id: crypto.randomUUID(),
      target: target.target,
      status: "Ready",
      resumes: 0,
      createdAt: Date.now(),
    };
    onCampaigns((current) => [...current, run]);
    setActivatedCampaigns((current) => new Set(current).add(run.id));
    onCampaign(run.id);
  }, [ready, target, selected, activeCampaign, campaigns, chosenTarget, onCampaign, onCampaigns]);

  function newCampaign(data: TargetData) {
    const run: Campaign = { id: crypto.randomUUID(), target: data, status: "Ready", resumes: 0, createdAt: Date.now() };
    onCampaigns((current) => [...current, run]);
    setActivatedCampaigns((current) => new Set(current).add(run.id));
    onCampaign(run.id);
  }

  const content = opened?.content ?? "";
  const truncated = content.length > MAX_VIEW_BYTES;
  const lines = (truncated ? content.slice(0, MAX_VIEW_BYTES) : content).split("\n");
  const solidity = opened?.path.endsWith(".sol") ?? false;

  return (
    <AccountSurface account={account} baseUrl={backendUrl} onAccount={onAccount}><main className="flex h-screen flex-col overflow-hidden text-[13px]">
      <header className="flex h-14 shrink-0 items-center justify-between gap-4 border-b border-border bg-surface px-4">
        <div className="flex min-w-0 items-center gap-4">
          <Link
            to="/"
            className="rounded-pill p-1 text-ink-muted hover:bg-hover hover:text-ink"
            aria-label="Back to apps"
          >
            <ChevronLeft className="size-5" />
          </Link>
          <Brand />
          <div className="h-5 w-px bg-border" />
          <span className="truncate text-[14px] font-medium text-ink">{appName}</span>
        </div>
        <div className="flex shrink-0 items-center gap-3">
          <AccountControl />
          <div className="flex items-center gap-2 rounded-pill border border-accent/45 bg-accent/10 px-3 py-1.5 text-[12px] text-accent-strong">
            <span className="size-1.5 rounded-pill bg-accent" />
            Arc fork · {target.status === "ready" ? target.target.chainId : 5042}
            {target.status === "ready" && target.target.deployment && " · live deployment"}
          </div>
          <a
            href={studioUrl}
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1.5 rounded-pill border border-border px-3 py-1.5 text-[12px] font-medium text-ink transition hover:bg-hover"
          >
            Open in Arc Studio <ExternalLink className="size-3.5" />
          </a>
        </div>
      </header>

      <div className="flex min-h-0 flex-1">
        <aside style={{ width: layout.explorer }} className="flex shrink-0 flex-col overflow-hidden bg-surface">
          <div className="min-h-0 flex-1 overflow-auto">
            <h2 className="px-3 pb-2 pt-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-ink-muted">
              Fuzz targets
            </h2>
            {fuzzable.length === 0 ? (
              <div className="mx-3 mb-4 space-y-2 rounded-md border border-border bg-bg p-3 text-[12px] leading-5 text-ink">
                <p>
                  {files.length === 0
                    ? "Arc Studio returned an empty workspace. The app's sandbox may still be waking up."
                    : scaffoldOnly
                      ? "This app has Foundry scaffolding (forge-std, deploy scripts) but no contract of its own. It likely uses existing contracts such as USDC."
                      : "No Solidity contracts in this app yet."}
                </p>
                <p className="text-ink-muted">Ask Arc Studio to write a contract, then check again.</p>
                <button onClick={refresh} className="font-medium text-accent-strong hover:underline">
                  Check again
                </button>
              </div>
            ) : (
              <ul className="space-y-0.5 px-2 pb-4">
                {fuzzable.flatMap((file) =>
                  file.contracts.map((name) => {
                    const active = selected?.path === file.path && selected.contract === name;
                    return (
                      <li key={`${file.path}:${name}`}>
                        <button
                          onClick={() => choose(file.path, name)}
                          className={`flex w-full items-center gap-2 rounded-md px-2 py-2 text-left ${
                            active ? "bg-accent-subtle text-ink" : "text-ink hover:bg-hover"
                          }`}
                        >
                          <FileCode2 className="size-4 shrink-0 text-accent" />
                          <span className="min-w-0 flex-1">
                            <span className="block truncate font-medium">{name}</span>
                            <span className="block truncate text-[11px] text-ink-muted">
                              {ArcStudioApp.workspacePath(file.path)}
                            </span>
                          </span>
                          {file.built ? (
                            <span className="flex shrink-0 items-center gap-1 text-[11px] text-success">
                              <Check className="size-3.5" /> built
                            </span>
                          ) : (
                            <span className="flex shrink-0 items-center gap-1 text-[11px] text-ink-muted">
                              <CircleDashed className="size-3.5" /> not built
                            </span>
                          )}
                        </button>
                      </li>
                    );
                  }),
                )}
              </ul>
            )}

            <h2 className="border-t border-border px-3 pb-2 pt-4 text-[11px] font-semibold uppercase">Campaigns</h2>
            {campaigns
              .filter((run) => run.threadId)
              .map((run) => (
                <button
                  key={run.id}
                  onClick={() => {
                    setActivatedCampaigns((current) => new Set(current).add(run.id));
                    onCampaign(run.id);
                    setOpened({ path: run.target.sourcePath, content: run.target.source });
                  }}
                  className={`mx-2 block w-[calc(100%-1rem)] rounded-md px-2 py-2 text-left ${activeCampaign === run.id ? "bg-accent-subtle" : "hover:bg-hover"}`}
                >
                  <span className="block font-medium">{run.target.name}</span>
                  <span className="block text-xs text-ink-muted">
                    {run.status} · {new Date(run.createdAt).toLocaleTimeString()}
                  </span>
                </button>
              ))}
            <h2 className="flex items-center justify-between border-t border-border px-3 pb-2 pt-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-ink-muted">
              Files <span className="font-normal normal-case tracking-normal text-ink-muted/70">{files.length}</span>
            </h2>
            <FileTree files={files} openPath={opened?.path} onOpen={open} onPrefetch={(path) => void read(path)} />
          </div>
        </aside>

        <Divider
          onDrag={(dx) => resize("explorer", dx)}
          onReset={() => resize("explorer", DEFAULT_LAYOUT.explorer - layout.explorer)}
        />

        <section className="flex min-h-0 min-w-0 flex-1 flex-col bg-bg">
          <div
            role="tablist"
            aria-label="Source files"
            className="flex shrink-0 overflow-x-auto border-b border-border"
          >
            {tabs.map((path) => {
              const name = path.split("/").at(-1);
              return (
                <div
                  key={path}
                  role="tab"
                  aria-selected={opened?.path === path}
                  title={path}
                  onAuxClick={(event) => {
                    if (event.button === 1) close(path);
                  }}
                  className={`group flex shrink-0 items-center ${opened?.path === path ? "bg-accent-subtle" : "hover:bg-hover"}`}
                >
                  <button onClick={() => open(path)} className="py-2 pl-3 pr-1">
                    {name}
                  </button>
                  <button
                    aria-label={`Close ${name}`}
                    onClick={() => close(path)}
                    className="mr-1.5 rounded p-0.5 text-ink-muted opacity-0 hover:bg-hover hover:text-ink focus:opacity-100 group-hover:opacity-100 group-aria-selected:opacity-100"
                  >
                    <X className="size-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
          <div className="flex h-11 shrink-0 items-center gap-2 border-b border-border bg-surface px-4 text-[13px] text-ink">
            {opened ? (
              <>
                {solidity ? (
                  <FileCode2 className="size-4 text-accent" />
                ) : (
                  <FileIcon className="size-4 text-ink-muted" />
                )}
                <span className="truncate">{ArcStudioApp.workspacePath(opened.path)}</span>
              </>
            ) : (
              <span className="text-ink-muted">Select a file to view it</span>
            )}
          </div>
          <div
            ref={sourceView}
            onScroll={() => {
              if (opened && sourceView.current) scrolls.current.set(opened.path, sourceView.current.scrollTop);
            }}
            className="min-h-0 flex-1 overflow-auto py-4 font-mono text-[13px] leading-[1.75]"
          >
            {opened && opened.content === undefined && !opened.error && (
              <p className="flex items-center gap-2 px-6 text-ink-muted">
                <Loader2 className="size-4 animate-spin" /> Reading from Arc Studio…
              </p>
            )}
            {opened?.error && <p className="px-6 text-danger">{opened.error}</p>}
            {opened?.content !== undefined &&
              lines.map((line, index) => (
                <div key={index} className={`flex min-h-[23px] ${opened.line === index ? "bg-accent-subtle" : ""}`}>
                  <span className="w-14 shrink-0 select-none pr-4 text-right text-ink-muted/60">{index + 1}</span>
                  <span className="whitespace-pre pr-6 text-ink">{solidity ? highlight(line) : line}</span>
                </div>
              ))}
            {truncated && (
              <p className="px-6 pt-2 text-ink-muted">
                Showing the first {MAX_VIEW_BYTES.toLocaleString()} characters of a large file.
              </p>
            )}
          </div>
          <Divider
            horizontal
            onDrag={(dy) => resize("activity", (-dy / window.innerHeight) * 100)}
            onReset={() => resize("activity", DEFAULT_LAYOUT.activity - layout.activity)}
          />
          <section
            aria-label="Campaign activity"
            style={{ height: `${layout.activity}vh`, maxHeight: "calc(100% - 9rem)" }}
            className="flex min-h-32 shrink-0 flex-col bg-surface"
          >
            <div className="flex shrink-0 items-center justify-between gap-2 border-b border-border px-3 py-2">
              <h2 className="truncate text-xs font-semibold">
                Campaign activity ·{" "}
                {campaigns.find((run) => run.id === activeCampaign)?.target.name ?? "Select a campaign"}
              </h2>
              <button onClick={() => resize("activity", (layout.activity >= 75 ? DEFAULT_LAYOUT.activity : 80) - layout.activity)} className="shrink-0 text-[11px] text-accent-strong hover:underline">
                {layout.activity >= 75 ? "Restore activity size" : "Expand activity"}
              </button>
            </div>
            <div id="campaign-activity" ref={setActivityHost} className="flex min-h-0 flex-1 flex-col overflow-auto" />
          </section>
        </section>

        <Divider
          onDrag={(dx) => resize("agent", -dx)}
          onReset={() => resize("agent", DEFAULT_LAYOUT.agent - layout.agent)}
        />

        <aside style={{ width: layout.agent }} className="flex min-h-0 shrink-0 flex-col bg-surface">
          {/* Keep the runtime and continuation mounted even while another artifact loads. */}
          {campaigns.map((campaign) => {
            if (campaign.threadId && !activatedCampaigns.has(campaign.id)) return null;
            const visible = activeCampaign === campaign.id;
            if (campaign.status === "Unavailable")
              return visible ? (
                <div key={campaign.id} role="alert" className="p-4">
                  Saved campaign unavailable. Its thread may have expired or access could not be verified.
                  <button
                    className="block underline"
                    onClick={() => {
                      void loadTarget({
                        data: { appId, sourcePath: campaign.target.sourcePath, contract: campaign.target.name },
                      }).then((result) => {
                        if (result.ok) newCampaign(result.value);
                      });
                    }}
                  >
                    Prepare a new campaign
                  </button>
                </div>
              ) : null;
            return (
              <div key={campaign.id} hidden={!visible} className={visible ? "flex min-h-0 flex-1 flex-col" : "hidden"}>
                <ErrorBoundary fallback={({ error }) => <CampaignCrashed campaign={campaign} error={error} />}>
                  <CampaignRuntime campaign={campaign} account={account}>
                    <FuzzPanel
                      activityHost={activityHost}
                      maxCredits={campaign.maxCredits}
                      estimate={estimate}
                      priorFindings={priorFindings.get(campaign.id) ?? []}
                      appId={appId}
                      backendUrl={backendUrl}
                      applicationId={applicationId}
                      account={account}
                      target={campaign.target}
                      saved={campaign}
                      onSource={(name: string, contract?: string | null) => {
                        if (contract && contract !== campaign.target.name) {
                          const file = contracts.find((file) => file.contracts.includes(contract));
                          if (file) void read(file.path).then(setOpened);
                          return;
                        }
                        const fn = name.split("(")[0];
                        const line = campaign.target.source
                          .split("\n")
                          .findIndex((text) => text.includes(`function ${fn}(`));
                        setOpened({
                          path: campaign.target.sourcePath,
                          content: campaign.target.source,
                          line: line >= 0 ? line : undefined,
                        });
                      }}
                      onChange={(update) =>
                        onCampaigns((current) =>
                          current.map((run) => (run.id === campaign.id ? { ...run, ...update } : run)),
                        )
                      }
                      onNew={() => {
                        void loadTarget({
                          data: { appId, sourcePath: campaign.target.sourcePath, contract: campaign.target.name },
                        }).then((result) => {
                          if (result.ok) newCampaign(result.value);
                          else setTarget({ status: "error", error: result.error });
                        });
                      }}
                      onRefresh={refresh}
                      visible={visible}
                    />
                  </CampaignRuntime>
                </ErrorBoundary>
              </div>
            );
          })}
          {!activeCampaign && (
            <div className="flex flex-1 flex-col items-center justify-center gap-3 p-8 text-center text-[14px] leading-6 text-ink-muted">
              {target.status === "ready" && <p>Select a saved campaign or pick a fuzz target to continue.</p>}
              {target.status === "idle" &&
                (fuzzable.length === 0 ? (
                  <p>Nothing to fuzz yet. Pick an app with a Solidity contract, or ask Arc Studio to write one.</p>
                ) : (
                  <p>Pick a fuzz target on the left.</p>
                ))}
              {target.status === "loading" && (
                <BuildPreparation contract={selected?.contract ?? "contract"} stages={target.stages}
                  startedAt={target.startedAt} stageStartedAt={target.stageStartedAt} onCancel={() => { refreshController.current?.abort(); onCancelPreparation(); }} />
              )}
              {target.status === "error" && (
                <div role="alert" className="w-full max-w-md rounded-lg border border-danger/30 bg-bg p-5 text-left">
                  <h2 className="font-semibold text-ink">Could not prepare the build</h2>
                  <p className="mt-2 text-sm text-danger">{target.error}</p>
                  <button onClick={onRetry} className="mt-4 text-sm text-accent-strong underline">Try again</button>
                </div>
              )}
              {target.status === "missing-build" && (
                <>
                  <p>{target.error}</p>
                  {target.buildUrl ? (
                    <>
                      <a
                        href={target.buildUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="text-accent-strong underline"
                      >
                        Follow the build in Arc Studio
                      </a>
                      <button onClick={refresh} className="text-ink-muted underline">
                        Check again
                      </button>
                    </>
                  ) : (
                    <button
                      disabled={building}
                      onClick={() =>
                        startBuild(async () => {
                          const result = await requestBuild({ data: { appId } });
                          setTarget(
                            result.ok
                              ? {
                                  status: "missing-build",
                                  error: "Arc Studio is building the app.",
                                  buildUrl: result.value.webUrl,
                                }
                              : { status: "error", error: result.error },
                          );
                        })
                      }
                      className="flex items-center gap-2 rounded-pill bg-ink px-4 py-2 font-medium text-bg transition hover:bg-ink/85 disabled:opacity-70"
                    >
                      {building ? <Loader2 className="size-4 animate-spin" /> : <Hammer className="size-4" />}
                      Ask Arc Studio to build
                    </button>
                  )}
                </>
              )}
            </div>
          )}
        </aside>
      </div>
    </main></AccountSurface>
  );
}

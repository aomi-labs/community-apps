import { createFileRoute } from "@tanstack/react-router";

import { loadCampaignRecord } from "@/server/campaign-store";
import { StudioSession } from "@/server/studio-session";

/**
 * One stored campaign as JSON. Reads the store only, so it answers at zero
 * Aomi credits and after the agent thread has expired.
 */
export const Route = createFileRoute("/api/campaigns/$appId/$id")({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const session = await StudioSession.current();
        if (!session) return new Response("Sign in to Arc Studio first.", { status: 401 });
        try {
          const record = await loadCampaignRecord(session.token, params.appId, params.id);
          if (!record) return new Response("No such campaign.", { status: 404 });
          return Response.json(record, { headers: { "cache-control": "private, no-store" } });
        } catch (error) {
          return new Response(error instanceof Error ? error.message : String(error), { status: 422 });
        }
      },
    },
  },
});

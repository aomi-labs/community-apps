import { createFileRoute } from "@tanstack/react-router";

import { renderCampaignReport } from "@aomi-labs/arc-studio-fuzz-core";

import { loadCampaignRecord } from "@/server/campaign-store";
import { StudioSession } from "@/server/studio-session";

/**
 * The campaign's evidence: a self-contained HTML report by default, or the
 * result JSON (`?format=json`). Neither names the thread or any signed link.
 */
export const Route = createFileRoute("/api/campaigns/$appId/$id/export")({
  server: {
    handlers: {
      GET: async ({ request, params }) => {
        const session = await StudioSession.current();
        if (!session) return new Response("Sign in to Arc Studio first.", { status: 401 });
        try {
          const record = await loadCampaignRecord(session.token, params.appId, params.id);
          if (!record) return new Response("No such campaign.", { status: 404 });
          const format = new URL(request.url).searchParams.get("format");
          const stem = `${record.target.name}-${record.id.slice(0, 8)}`;
          if (format === "json") {
            const { state, target, blind, cost, createdAt, updatedAt } = record;
            const result = {
              target,
              blind: blind ?? null,
              status: state.status,
              findings: state.findings,
              rejected: state.rejected,
              not_tested: state.notTested,
              executions: state.executions,
              budget: state.budget,
              cost: cost ?? null,
              report: state.report,
              createdAt,
              updatedAt,
            };
            return new Response(JSON.stringify(result, null, 2), {
              headers: {
                "content-type": "application/json",
                "content-disposition": `attachment; filename="${stem}-result.json"`,
                "cache-control": "private, no-store",
              },
            });
          }
          return new Response(renderCampaignReport(record), {
            headers: {
              "content-type": "text/html; charset=utf-8",
              ...(format === "download" && { "content-disposition": `attachment; filename="${stem}-report.html"` }),
              "cache-control": "private, no-store",
            },
          });
        } catch (error) {
          return new Response(error instanceof Error ? error.message : String(error), { status: 422 });
        }
      },
    },
  },
});

import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, expect, it, vi } from "vitest";

import { ErrorBoundary, errorText } from "./error-boundary";

afterEach(cleanup);

function Widget({ crash }: { crash: boolean }) {
  if (crash) throw new Error("useClientLookup: Index 4 out of bounds");
  return <p>widget content</p>;
}

it("keeps a crash inside the boundary and can remount its children", () => {
  const error = vi.spyOn(console, "error").mockImplementation(() => {});
  let crash = true;
  const view = render(
    <>
      <p>campaign status: Complete</p>
      <ErrorBoundary
        fallback={({ error, reset }) => (
          <div role="alert">
            {errorText(error)}
            <button onClick={reset}>Reopen</button>
          </div>
        )}
      >
        <Widget crash={crash} />
      </ErrorBoundary>
    </>,
  );
  expect(screen.getByRole("alert").textContent).toContain("useClientLookup: Index 4 out of bounds");
  expect(screen.getByText("campaign status: Complete")).toBeTruthy();
  crash = false;
  view.rerender(
    <>
      <p>campaign status: Complete</p>
      <ErrorBoundary fallback={({ reset }) => <button onClick={reset}>Reopen</button>}>
        <Widget crash={crash} />
      </ErrorBoundary>
    </>,
  );
  fireEvent.click(screen.getByText("Reopen"));
  expect(screen.getByText("widget content")).toBeTruthy();
  error.mockRestore();
});

it("shortens long error text for a panel", () => {
  expect(errorText(new Error("x".repeat(400))).length).toBe(301);
  expect(errorText(Object.assign(new Error(""), { name: "RangeError" }))).toBe("RangeError");
});

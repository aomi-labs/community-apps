"use client";

import { createContext, useContext, useState, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  AccountAvatar,
  AccountMenu,
  CreditCheckoutDialog,
  WidgetScope,
  AomiWalletKitProvider,
  useAomiWalletKit,
} from "@aomi-labs/widget/host-composition";
import { AomiAccount } from "@/lib/aomi-account";

const Credits = createContext<{ add: () => void; manage: () => void } | null>(
  null,
);
export const useAddCredits = () => useContext(Credits)?.add;
export const useManageCredits = () => useContext(Credits)?.manage;

export function AccountSurface({
  account,
  baseUrl,
  onAccount,
  children,
}: {
  account: AomiAccount | null;
  baseUrl: string;
  onAccount: (account: AomiAccount | null) => void;
  children: ReactNode;
}) {
  return (
    <AomiWalletKitProvider
      preset="wallets-only"
      auth={false}
      account={false}
      wallets={{ evm: { preset: "minimal" }, solana: false }}
    >
      <AccountSurfaceBody
        key={account?.id ?? "guest"}
        account={account}
        baseUrl={baseUrl}
        onAccount={onAccount}
      >
        {children}
      </AccountSurfaceBody>
    </AomiWalletKitProvider>
  );
}

const AccountControls = createContext<ReactNode>(null);
export const AccountControl = () => (
  <WidgetScope>{useContext(AccountControls)}</WidgetScope>
);

function AccountSurfaceBody({
  account,
  baseUrl,
  onAccount,
  children,
}: Parameters<typeof AccountSurface>[0]) {
  const wallet = useAomiWalletKit();
  const [menu, setMenu] = useState(false);
  const [checkout, setCheckout] = useState(false);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const balance = useQuery({
    queryKey: ["fuzzer-credits", baseUrl, account?.id],
    enabled: Boolean(account),
    queryFn: () => account!.client.account.credits.get(),
    retry: false,
  });
  const profile = useQuery({
    queryKey: ["fuzzer-account", baseUrl, account?.id],
    enabled: Boolean(account),
    queryFn: () => account!.client.account.getAccount(),
    retry: false,
  });
  const label =
    profile.data?.user?.displayName ??
    profile.data?.user?.email ??
    (account ? `Aomi · ${account.id.slice(0, 8)}` : "Sign in to Aomi");
  const credits = balance.data
    ? `${(balance.data.available_microusd / 10000).toLocaleString()} credits available`
    : undefined;
  const portal = (destination: "account" | "credits" | "signin") => {
    if (pending) return;
    setPending(true);
    setError(null);
    setMenu(false);
    void AomiAccount.openPortal(baseUrl, account, destination)
      .then(onAccount)
      .catch((cause: unknown) =>
        setError(cause instanceof Error ? cause.message : String(cause)),
      )
      .finally(() => setPending(false));
  };
  const control = (
    <div className="relative text-sm">
      <button
        type="button"
        disabled={pending}
        aria-expanded={menu}
        className="flex items-center gap-2 rounded-xl border border-border bg-surface px-3 py-2"
        onClick={() => (account ? setMenu(!menu) : portal("signin"))}
      >
        <AccountAvatar seed={account?.id} size={30} />
        <span className="text-left">
          <span className="block font-semibold">
            {pending ? "Connecting…" : label}
          </span>
          {credits && (
            <span className="block text-xs text-ink-muted">{credits}</span>
          )}
        </span>
      </button>
      {account && (
        <AccountMenu
          open={menu}
          placement="below"
          accountId={account.id}
          accountLabel={label}
          rows={wallet.wallets}
          onActivateWallet={wallet.activateWallet}
          allowanceLine={credits}
          allowanceLoading={balance.isPending}
          onClose={() => setMenu(false)}
          onManageAccount={() => portal("account")}
          // Straight to the Add credits dialog: no hop through Aomi's chat and settings.
          settingsLabel="Add credits"
          onOpenSettings={() => {
            setMenu(false);
            setCheckout(true);
          }}
          onAddWallet={() => portal("account")}
          onSignOut={() => {
            setPending(true);
            void account
              .signOut()
              .then(() => onAccount(null))
              .catch((cause) => setError(String(cause)))
              .finally(() => setPending(false));
          }}
          onDisconnect={() => {
            void wallet.disconnect?.();
          }}
        />
      )}
      {error && (
        <p role="alert" className="max-w-sm text-danger">
          {error}
        </p>
      )}
    </div>
  );
  return (
    <AccountControls.Provider value={control}>
      <Credits.Provider
        value={{
          add: () => (account ? setCheckout(true) : portal("signin")),
          manage: () => portal("credits"),
        }}
      >
        {children}
        {account && (
          <WidgetScope>
            <CreditCheckoutDialog
              open={checkout}
              credits={account.client.account.credits}
              onClose={() => setCheckout(false)}
              onSuccess={async () => {
                await balance.refetch();
              }}
            />
          </WidgetScope>
        )}
      </Credits.Provider>
    </AccountControls.Provider>
  );
}

import { expect, it, vi } from "vitest";
import { readPreparation } from "./preparation";

it("decodes split chunks and reports each stage before the final error", async () => {
  const chunks = ['{"type":"stage","stage":"stu', 'dio"}\n{"type":"error","error":"unavailable"}\n'];
  const stream = new ReadableStream({ start(controller) {
    for (const chunk of chunks) controller.enqueue(new TextEncoder().encode(chunk));
    controller.close();
  } });
  const progress = vi.fn();
  expect(await readPreparation(stream, progress)).toEqual({ type: "error", error: "unavailable" });
  expect(progress).toHaveBeenCalledExactlyOnceWith("studio");
});

it("cancels an idle stream when the request is aborted", async () => {
  const cancel = vi.fn();
  const stream = new ReadableStream<Uint8Array>({ cancel });
  const controller = new AbortController();
  const result = readPreparation(stream, vi.fn(), controller.signal);
  controller.abort(new DOMException("Timed out", "TimeoutError"));
  await expect(result).rejects.toMatchObject({ name: "TimeoutError" });
  expect(cancel).toHaveBeenCalledOnce();
});

it("treats a disconnected stream as an error, never as readiness", async () => {
  const stream = new ReadableStream<Uint8Array>({ start(controller) { controller.close(); } });
  await expect(readPreparation(stream, vi.fn())).rejects.toThrow("disconnected before finishing");
});

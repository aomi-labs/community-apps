"use client";

import {
  AomiClient,
  createAomiBrowserGrantManager,
  type AomiOAuthGrantManager,
  type AomiOAuthResource,
  type AomiClientOptions,
  type AomiRequestOptions,
  type AccountSessionProvider,
  createAccountSessionProvider,
  createGuestSessionProvider,
  type GuestSessionProvider,
  createSiweAccountAuthAdapter,
} from "@aomi-labs/client";

/** Minimal EIP-1193 surface of an injected browser wallet. */
interface InjectedWallet {
  request(args: { method: string; params?: unknown[] }): Promise<unknown>;
}

const ADDRESS_KEY = "arc-studio-fuzz:aomi-account";
const SESSION_KEY = "arc-studio-fuzz:oauth-session";
const restoring = new Map<string, Promise<AomiAccount | null>>();
const agentScopes = [
  "agent:read",
  "agent:write",
  "agent:actions:resolve",
  "offline_access",
];
const creditScopes = [
  "account:credits:read",
  "account:credits:fund",
  "payments:submit",
  "offline_access",
];
// One `/v1` grant carries both, so signing in asks for consent once.
const signInScopes = [...new Set([...agentScopes, ...creditScopes])];
const restApi = /\/v1\/(agent|account|pipeline)$/;

/** A `/v1` grant stands for the agent, account and pipeline REST APIs (never MCP). */
function covers(grant: string, resource: string): boolean {
  return grant === resource || (restApi.test(resource) && grant === resource.replace(restApi, "/v1"));
}

/** Whether this portal accepts the single `/v1` sign-in; older ones need one grant per API. */
async function acceptsSingleSignIn(baseUrl: string): Promise<boolean> {
  try {
    const response = await fetch(new URL("/.well-known/oauth-protected-resource/v1", baseUrl), {
      credentials: "omit",
    });
    if (!response.ok) return false;
    const { scopes_supported: scopes } = (await response.json()) as { scopes_supported?: string[] };
    return signInScopes.every((scope) => scopes?.includes(scope));
  } catch {
    return false;
  }
}

/**
 * The saved authorization no longer covers this request. Recoverable by
 * reconnecting the same account; checkout keys its Reconnect Aomi on `code`.
 */
export class AomiReauthorizationRequired extends Error {
  readonly code = "reauthorization_required";
  constructor(readonly reason: "inactive" | "missing_grant" | "no_token") {
    super("Sign in to Aomi again before continuing.");
    this.name = "AomiReauthorizationRequired";
  }
}

function injected(): InjectedWallet | undefined {
  return (globalThis as { ethereum?: InjectedWallet }).ethereum;
}

function storage(): Storage | undefined {
  try {
    return sessionStorage;
  } catch {
    return undefined;
  }
}

/**
 * An Aomi account signed in with the visitor's browser wallet (Sign-In with
 * Ethereum through the portal's widget session). Signed-in sessions run with
 * an account budget instead of the guest per-call input cap, which full fuzz
 * campaigns exceed. The wallet only signs the login message; it never signs
 * or sends transactions here.
 */
export class AomiAccount {
  private constructor(
    readonly address: string,
    readonly session: AccountSessionProvider | null,
    readonly id: string,
    readonly client: AomiClient,
    readonly options: Pick<
      AomiClientOptions,
      "oauth" | "getAccountBearer" | "guest"
    >,
    readonly grants?: AomiOAuthGrantManager,
    readonly portalBaseUrl?: string,
  ) {}

  static get walletAvailable(): boolean {
    return Boolean(injected());
  }

  /** Prompts the wallet for an account, then signs in (one signature). */
  static async signIn(
    baseUrl: string,
    wallet = injected(),
  ): Promise<AomiAccount> {
    if (!wallet)
      throw new Error(
        "No browser wallet found. Install MetaMask or another Ethereum wallet.",
      );
    const [address] = (await wallet.request({
      method: "eth_requestAccounts",
    })) as string[];
    if (!address) throw new Error("The wallet did not share an account.");
    const account = await AomiAccount.#create(baseUrl, wallet, address);
    try {
      // Mints the account session now, so a rejected signature fails here, not mid-campaign.
      await account.session!();
    } catch (error) {
      account.session?.dispose();
      throw error;
    }
    storage()?.setItem(ADDRESS_KEY, address);
    return account;
  }

  /** Restore only an existing OAuth grant. Never prompt a wallet from an effect. */
  static resume(baseUrl: string): Promise<AomiAccount | null> {
    const pending = restoring.get(baseUrl);
    if (pending) return pending;
    const result = AomiAccount.#restore(baseUrl).finally(() =>
      restoring.delete(baseUrl),
    );
    restoring.set(baseUrl, result);
    return result;
  }

  static async #restore(baseUrl: string): Promise<AomiAccount | null> {
    const key = storage()?.getItem(`${SESSION_KEY}:${baseUrl}`);
    const clientId = process.env.NEXT_PUBLIC_AOMI_OAUTH_CLIENT_ID;
    if (!key || !clientId) return null;
    const manager = await createAomiBrowserGrantManager({
      portalBaseUrl: baseUrl,
      clientId,
      redirectUri: new URL("/auth/aomi", window.location.origin).href,
      persistenceKey: key,
      interactive: false,
    });
    const grants = await manager.grants();
    const id = grants[0]?.accountId;
    if (!id || grants.some((grant) => grant.accountId !== id)) return null;
    return AomiAccount.#fromGrants(baseUrl, id, manager);
  }

  static #fromGrants(
    baseUrl: string,
    id: string,
    manager: AomiOAuthGrantManager,
  ): AomiAccount {
    let active = true;
    const options: Pick<AomiClientOptions, "oauth" | "guest"> = {
      guest: false,
      oauth: async (request) => {
        if (!active) throw new AomiReauthorizationRequired("inactive");
        const grant = (await manager.grants())
          .filter(
            (item) =>
              covers(item.resource, request.resource) &&
              request.scopes.every((scope) => item.scopes.includes(scope)),
          )
          .sort((a, b) => a.scopes.length - b.scopes.length)[0];
        if (!grant) throw new AomiReauthorizationRequired("missing_grant");
        // Ask for the whole grant: a refresh for only this request's scopes
        // would reissue the refresh token narrowed to them, so a balance read
        // would strip checkout's account:credits:fund and offline_access.
        const token = await manager.tokenProvider({
          ...request,
          resource: grant.resource,
          scopes: grant.scopes,
        });
        if (!active) throw new AomiReauthorizationRequired("inactive");
        if (!token) throw new AomiReauthorizationRequired("no_token");
        return token;
      },
    };
    const account = new AomiAccount(
      id,
      null,
      id,
      new AomiClient({ baseUrl, ...options }),
      options,
      manager,
      baseUrl,
    );
    account.dispose = () => {
      active = false;
    };
    return account;
  }

  static async #create(
    baseUrl: string,
    wallet: InjectedWallet,
    address: string,
  ): Promise<AomiAccount> {
    const adapter = createSiweAccountAuthAdapter({
      async getSigner() {
        const chainId = Number.parseInt(
          String(await wallet.request({ method: "eth_chainId" })),
          16,
        );
        return {
          address,
          chainId,
          signMessage: (message: string) =>
            wallet.request({
              method: "personal_sign",
              params: [message, address],
            }) as Promise<string>,
        };
      },
    });
    const session = createAccountSessionProvider({
      baseUrl,
      adapter,
      storage: storage(),
    });
    const options = { getAccountBearer: session };
    const client = new AomiClient({ baseUrl, ...options });
    try {
      const profile = await client.request<{ user: { id: string } }>(
        "GET",
        "/v1/account",
      );
      if (!profile.user?.id)
        throw new Error("Aomi account is unavailable. Sign in again.");
      return new AomiAccount(
        address,
        session,
        profile.user.id,
        client,
        options,
      );
    } catch (error) {
      session.dispose();
      throw error;
    }
  }

  /** Open synchronously on the click, before discovery or signing can lose activation. */
  static async openPortal(
    baseUrl: string,
    current: AomiAccount | null,
    destination: "account" | "credits" | "signin",
  ): Promise<AomiAccount> {
    const clientId = process.env.NEXT_PUBLIC_AOMI_OAUTH_CLIENT_ID;
    if (!clientId)
      throw new Error("Aomi account handoff is not configured for this site.");
    const popup = window.open(
      "about:blank",
      `aomi-oauth-${crypto.randomUUID()}`,
      "popup,width=560,height=780,resizable=yes,scrollbars=yes",
    );
    if (!popup) throw new Error("Allow popups to continue to Aomi.");
    const target = (accountId: string) => {
      const url = new URL(
        destination === "credits" ? "/?topup=credits" : "/?settings=account",
        baseUrl,
      );
      url.searchParams.set("expectedAccount", accountId);
      return url.href;
    };
    // Already signed in with Aomi: the portal has its own session, so go
    // straight there instead of asking for consent again.
    if (current?.grants && destination !== "signin") {
      popup.location.replace(target(current.id));
      return current;
    }
    const persistenceKey = crypto.randomUUID();
    let authorizing = true;
    let manager:
      | Awaited<ReturnType<typeof createAomiBrowserGrantManager>>
      | undefined;
    try {
      manager = await createAomiBrowserGrantManager({
        portalBaseUrl: baseUrl,
        clientId,
        redirectUri: new URL("/auth/aomi", window.location.origin).href,
        ...(current?.session ? { getWidgetBearer: current.session } : {}),
        closePopup: false,
        persistenceKey,
        popup: (url) => {
          if (!authorizing) throw new AomiReauthorizationRequired("inactive");
          popup.location.href = url;
          return popup;
        },
      });
      const origin = new URL(baseUrl).origin;
      const grant = await AomiAccount.#authorize(
        manager,
        origin,
        popup,
        await acceptsSingleSignIn(baseUrl),
      );
      if (current && !current.session && current.id !== grant.accountId)
        throw new Error(
          "Aomi Portal is signed into a different account. Sign out here to switch accounts, or use your Fuzzer account on Aomi.",
        );
      const selected = AomiAccount.#fromGrants(
        baseUrl,
        grant.accountId,
        manager,
      );
      storage()?.setItem(`${SESSION_KEY}:${baseUrl}`, persistenceKey);
      storage()?.removeItem(ADDRESS_KEY);
      if (destination === "signin") popup.close();
      else popup.location.replace(target(grant.accountId));
      return selected;
    } catch (error) {
      await manager?.clear().catch(() => undefined);
      if (!popup.closed) popup.close();
      throw error;
    } finally {
      // Even a request that raced with invalidation cannot reuse the checkout window.
      authorizing = false;
    }
  }

  /** One consent for a `/v1` grant; one per API on a portal without it, or if it refuses. */
  static async #authorize(
    manager: AomiOAuthGrantManager,
    origin: string,
    popup: Window,
    single: boolean,
  ): Promise<{ accountId: string }> {
    const verified = async (resource: string) => {
      const grant = (await manager.grants()).find(
        (item) => item.resource === resource,
      );
      if (!grant?.accountId)
        throw new Error("Aomi did not verify the selected account.");
      return { accountId: grant.accountId };
    };
    if (single) {
      // The SDK's resource type predates `/v1`; the grant manager takes any absolute URL.
      const resource = `${origin}/v1` as AomiOAuthResource;
      try {
        await manager.tokenProvider({ resource, scopes: signInScopes });
        return await verified(resource);
      } catch (error) {
        // The user closing or denying the popup is an answer, not an unsupported portal.
        if ((error as { code?: string }).code === "access_denied") throw error;
        if (popup.closed) throw error;
        popup.history.replaceState(null, "", "/");
      }
    }
    const resource = `${origin}/v1/agent` as const;
    await manager.tokenProvider({ resource, scopes: agentScopes });
    const grant = await verified(resource);
    // Remove the consumed callback synchronously before reusing this window.
    // Navigation is asynchronous: otherwise the next grant can read the old state.
    popup.history.replaceState(null, "", "/");
    // Account funding has its own audience and least-privilege grant.
    await manager.tokenProvider({
      resource: `${origin}/v1/account`,
      scopes: creditScopes,
    });
    return grant;
  }

  request(
    method: "POST" | "GET",
    path: string,
    options?: AomiRequestOptions,
  ): Promise<Response> {
    return this.client.requestResponse(method, path, options);
  }

  dispose(): void {
    this.session?.dispose();
  }

  async signOut(): Promise<void> {
    storage()?.removeItem(ADDRESS_KEY);
    this.dispose();
    if (this.portalBaseUrl)
      storage()?.removeItem(`${SESSION_KEY}:${this.portalBaseUrl}`);
    await this.session?.signOut().catch(() => undefined);
    for (const grant of (await this.grants?.grants()) ?? [])
      await this.grants?.revoke(grant.resource).catch(() => undefined);
    await this.grants?.clear();
    this.dispose();
  }
}

// Every campaign and recovery request in this tab must use the same guest identity.
const guests = new Map<string, GuestSessionProvider>();
export function guestSession(baseUrl: string): GuestSessionProvider {
  const existing = guests.get(baseUrl);
  if (existing) return existing;
  const key = `arc-studio-fuzz:guest:${baseUrl}`;
  const create = createGuestSessionProvider({ baseUrl });
  let pending: Promise<string | null> | undefined;
  const clear = () => {
    pending = undefined;
    create.clear();
    try {
      storage()?.removeItem(key);
    } catch {
      /* memory-only when storage is unavailable */
    }
  };
  const session = Object.assign(
    async (options?: { forceRefresh?: boolean }) => {
      if (options?.forceRefresh) clear();
      if (!pending) {
        let saved: string | null = null;
        try {
          saved = storage()?.getItem(key) ?? null;
        } catch {
          /* memory-only */
        }
        pending = saved
          ? Promise.resolve(saved)
          : create()
              .then((token) => {
                try {
                  if (token) storage()?.setItem(key, token);
                } catch {
                  /* memory-only */
                }
                return token;
              })
              .catch((error) => {
                pending = undefined;
                throw error;
              });
      }
      return pending;
    },
    { clear },
  );
  guests.set(baseUrl, session);
  return session;
}

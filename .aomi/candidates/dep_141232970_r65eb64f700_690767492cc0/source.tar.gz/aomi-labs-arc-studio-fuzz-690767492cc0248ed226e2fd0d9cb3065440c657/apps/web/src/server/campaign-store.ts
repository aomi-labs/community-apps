import "@tanstack/react-start/server-only";

import { createHmac } from "node:crypto";

import type { CampaignRecord } from "@aomi-labs/arc-studio-fuzz-core";

const BUCKET = "arc-snapshots";
const PREFIX = "campaigns";
const MAX_BYTES = 4 * 1024 * 1024;
const MAX_LIST = 200;

/**
 * Campaign records, one JSON object per campaign in the snapshot bucket,
 * scoped to the Arc Studio token's owner like the snapshots themselves. The
 * browser writes through as a run goes, so a crashed tab, an expired wallet
 * session or an empty credit balance never loses a run: reading a record
 * never calls Aomi.
 *
 * Without the store configured (a local checkout, the e2e harness) records
 * live in this process's memory, which is enough to resume within a session.
 */
type Backend =
  | { kind: "supabase"; url: string; key: string; ownerKey: string }
  | { kind: "memory"; records: Map<string, string> };

function backend(): Backend {
  const url = process.env.SUPABASE_SNAPSHOT_URL?.replace(/\/+$/, "");
  const key = process.env.SUPABASE_SNAPSHOT_SERVICE_ROLE_KEY;
  const ownerKey = process.env.SESSION_SECRET;
  const trusted = /^https:\/\/[^/]+$/.test(url ?? "") || /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(url ?? "");
  if (url && trusted && key && ownerKey && ownerKey.length >= 32) return { kind: "supabase", url, key, ownerKey };
  const store = globalThis as { __arcCampaignRecords?: Map<string, string> };
  store.__arcCampaignRecords ??= new Map();
  return { kind: "memory", records: store.__arcCampaignRecords };
}

function owner(token: string, key: string): string {
  return createHmac("sha256", key).update(`arc-campaign:${token}`).digest("hex");
}

function authHeaders(key: string): Record<string, string> {
  return key.startsWith("sb_secret_") ? { apikey: key } : { apikey: key, authorization: `Bearer ${key}` };
}

const SAFE_ID = /^[A-Za-z0-9-]{1,64}$/;

function path(scope: string, appId: string, id: string): string {
  if (!SAFE_ID.test(appId) || !SAFE_ID.test(id)) throw new Error("Invalid campaign id.");
  return `${PREFIX}/${scope}/${appId}/${id}.json`;
}

function scopeOf(store: Backend, token: string): string {
  return store.kind === "supabase" ? owner(token, store.ownerKey) : owner(token, "memory");
}

function parse(body: string): CampaignRecord | null {
  try {
    const record = JSON.parse(body) as CampaignRecord;
    return typeof record?.id === "string" && typeof record.appId === "string" && record.state ? record : null;
  } catch {
    return null;
  }
}

/** The stored record, or null when there is none for this owner and app. */
export async function loadCampaignRecord(token: string, appId: string, id: string): Promise<CampaignRecord | null> {
  const store = backend();
  const key = path(scopeOf(store, token), appId, id);
  if (store.kind === "memory") return parse(store.records.get(key) ?? "null");
  const response = await fetch(`${store.url}/storage/v1/object/${BUCKET}/${key}`, {
    headers: authHeaders(store.key),
    signal: AbortSignal.timeout(20_000),
    cache: "no-store",
  });
  if (response.status === 404 || response.status === 400) return null;
  if (!response.ok) throw new Error(`Campaign store returned HTTP ${response.status}.`);
  return parse(await response.text());
}

/** Every record for this owner and app, newest first. */
export async function listCampaignRecords(token: string, appId: string): Promise<CampaignRecord[]> {
  const store = backend();
  const scope = scopeOf(store, token);
  if (!SAFE_ID.test(appId)) throw new Error("Invalid app id.");
  const prefix = `${PREFIX}/${scope}/${appId}/`;
  let bodies: string[];
  if (store.kind === "memory") {
    bodies = [...store.records.entries()].filter(([key]) => key.startsWith(prefix)).map(([, body]) => body);
  } else {
    const response = await fetch(`${store.url}/storage/v1/object/list/${BUCKET}`, {
      method: "POST",
      headers: { ...authHeaders(store.key), "content-type": "application/json" },
      body: JSON.stringify({ prefix, limit: MAX_LIST, offset: 0, sortBy: { column: "updated_at", order: "desc" } }),
      signal: AbortSignal.timeout(20_000),
      cache: "no-store",
    });
    if (!response.ok) throw new Error(`Campaign store returned HTTP ${response.status}.`);
    const entries = (await response.json()) as Array<{ name: string }>;
    const ids = entries.map((entry) => entry.name.replace(/\.json$/, "")).filter((id) => SAFE_ID.test(id));
    const records = await Promise.all(ids.map((id) => loadCampaignRecord(token, appId, id)));
    return records.filter((record): record is CampaignRecord => record !== null).sort((a, b) => b.updatedAt - a.updatedAt);
  }
  return bodies
    .map(parse)
    .filter((record): record is CampaignRecord => record !== null)
    .sort((a, b) => b.updatedAt - a.updatedAt);
}

/** Upsert a record. Rejects anything that still carries a signed link. */
export async function saveCampaignRecord(token: string, record: CampaignRecord): Promise<void> {
  const store = backend();
  const body = JSON.stringify(record);
  if (Buffer.byteLength(body) > MAX_BYTES) throw new Error("Campaign record exceeds the 4 MB store limit.");
  if (/\/api\/artifacts\/|\/storage\/v1\/object\/sign\//.test(body)) {
    throw new Error("Campaign record must not contain signed artifact links.");
  }
  const key = path(scopeOf(store, token), record.appId, record.id);
  if (store.kind === "memory") {
    store.records.set(key, body);
    return;
  }
  const response = await fetch(`${store.url}/storage/v1/object/${BUCKET}/${key}`, {
    method: "POST",
    headers: { ...authHeaders(store.key), "content-type": "application/json", "x-upsert": "true" },
    body,
    signal: AbortSignal.timeout(20_000),
  });
  if (!response.ok) throw new Error(`Campaign store returned HTTP ${response.status}.`);
}

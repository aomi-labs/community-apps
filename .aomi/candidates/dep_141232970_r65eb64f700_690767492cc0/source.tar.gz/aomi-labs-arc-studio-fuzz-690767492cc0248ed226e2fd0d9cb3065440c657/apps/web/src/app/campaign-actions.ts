import { createServerFn } from "@tanstack/react-start";
import { redirect } from "@tanstack/react-router";
import { z } from "zod";

import { compactEvents, recordState, type CampaignRecord } from "@aomi-labs/arc-studio-fuzz-core";

import { listCampaignRecords, saveCampaignRecord } from "@/server/campaign-store";
import { StudioSession } from "@/server/studio-session";

async function session(): Promise<StudioSession> {
  const current = await StudioSession.current();
  if (!current) throw redirect({ to: "/" });
  return current;
}

const id = z.string().regex(/^[A-Za-z0-9-]{1,64}$/);

/** Every stored campaign for an app; never calls Aomi, so it works at zero credits. */
export const listCampaigns = createServerFn({ method: "POST" })
  .validator(z.object({ appId: id }))
  .handler(async ({ data }): Promise<{ ok: true; json: string } | { ok: false; error: string }> => {
    try {
      const current = await session();
      // Records carry arbitrary event payloads, so they cross the boundary as JSON text.
      return { ok: true, json: JSON.stringify(await listCampaignRecords(current.token, data.appId)) };
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : String(error) };
    }
  });

const recordInput = z.object({
  id,
  appId: id,
  // The browser sends its full TargetData (source, ABI, bytecode) so a reopened
  // campaign can rebuild its FuzzTarget; signed links are stripped client-side
  // and refused by the store.
  target: z.looseObject({
    name: z.string().min(1).max(256),
    sourcePath: z.string().min(1).max(4096),
    chainId: z.number().int(),
    deployment: z.object({ address: z.string(), chainId: z.number().int() }).nullable().optional(),
    protocol: z.array(z.object({ name: z.string(), address: z.string() })).nullable().optional(),
    artifactUrl: z.undefined().optional(),
    installedArtifactUrl: z.undefined().optional(),
  }),
  threadId: z.string().max(256).optional(),
  local: z.record(z.string(), z.unknown()),
  events: z.array(z.record(z.string(), z.unknown())),
  blind: z.boolean().optional(),
  cost: z.object({ microusd: z.number(), executions: z.number().int() }).nullable().optional(),
  maxCredits: z.number().int().positive().optional(),
  createdAt: z.number(),
});

/**
 * Write-through from the browser as a run goes. The server reduces the
 * events itself, so the stored state can never disagree with the ledger.
 */
export const saveCampaign = createServerFn({ method: "POST" })
  .validator(recordInput)
  .handler(async ({ data }): Promise<{ ok: true; updatedAt: number } | { ok: false; error: string }> => {
    try {
      const current = await session();
      const events = compactEvents(data.events as CampaignRecord["events"]);
      const local = data.local as unknown as CampaignRecord["local"];
      const record: CampaignRecord = {
        ...data,
        events,
        local,
        state: recordState({ events, local }),
        updatedAt: Date.now(),
      };
      await saveCampaignRecord(current.token, record);
      return { ok: true, updatedAt: record.updatedAt };
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : String(error) };
    }
  });

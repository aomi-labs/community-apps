import { useEffect, useState } from "react";
import { Check, Circle, Loader2 } from "lucide-react";
import { preparationSteps, type PreparationStage } from "@/lib/preparation";

export function BuildPreparation({ contract, stages, startedAt, stageStartedAt, onCancel }: {
  contract: string;
  stages: PreparationStage[];
  startedAt: number;
  stageStartedAt: number;
  onCancel: () => void;
}) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);
  const elapsed = Math.max(0, Math.floor((now - startedAt) / 1000));
  const waiting = Math.max(0, Math.floor((now - stageStartedAt) / 1000));
  const active = stages.at(-1);
  return (
    <section aria-label="Build preparation" className="w-full max-w-md rounded-lg border border-border bg-bg p-5 text-left text-ink">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h2 className="text-sm font-semibold">Preparing {contract}</h2>
          <p className="mt-1 text-xs text-ink-muted">Loading the contract build. No fork has been created.</p>
        </div>
        <span aria-label="Preparation elapsed time" className="shrink-0 font-mono text-xs text-ink-muted">{elapsed}s</span>
      </div>
      <ol aria-label="Preparation steps" className="my-5 space-y-3 text-xs">
        {!active && <li role="status" className="flex items-center gap-2"><Loader2 aria-hidden="true" className="size-3.5 animate-spin" />Connecting to the build service…</li>}
        {Object.entries(preparationSteps).filter(([step]) => step !== "workspace" || stages.includes("workspace")).map(([step, title]) => {
          const seen = stages.includes(step as PreparationStage);
          const current = step === active;
          const skipped = !seen && active && Object.keys(preparationSteps).indexOf(step) < Object.keys(preparationSteps).indexOf(active);
          return (
            <li key={step} aria-current={current ? "step" : undefined} className={`flex items-center gap-2 ${current ? "text-ink" : "text-ink-muted"}`}>
              {current ? <Loader2 aria-hidden="true" className="size-3.5 shrink-0 animate-spin" /> : seen ? <Check aria-hidden="true" className="size-3.5 shrink-0 text-success" /> : skipped ? <span aria-hidden="true" className="w-3.5 shrink-0 text-center">–</span> : <Circle aria-hidden="true" className="size-3.5 shrink-0" />}
              <span>{title}</span>
              {skipped && <span className="ml-auto shrink-0 text-ink-muted">Not needed</span>}
              {current && <span role="status" className="ml-auto shrink-0 font-mono text-ink-muted">{waiting}s</span>}
            </li>
          );
        })}
      </ol>
      {waiting >= 15 && (
        <p role="status" className="mb-4 text-xs leading-5 text-warning">
          This step is taking longer than usual. {active === "workspace" || active === "studio" || active === "protocol" ? "Waiting for Arc Studio to respond." : "Waiting for the build service to respond."} You can cancel or choose another target. Preparation stops after 90 seconds.
        </p>
      )}
      <button onClick={onCancel} className="text-xs text-ink-muted underline underline-offset-4 hover:text-ink">Cancel preparation</button>
    </section>
  );
}

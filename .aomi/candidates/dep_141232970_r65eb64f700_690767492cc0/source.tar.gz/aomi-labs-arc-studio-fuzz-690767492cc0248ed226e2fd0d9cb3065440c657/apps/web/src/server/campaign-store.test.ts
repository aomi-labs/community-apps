import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import type { CampaignRecord } from "@aomi-labs/arc-studio-fuzz-core";
import { listCampaignRecords, loadCampaignRecord, saveCampaignRecord } from "./campaign-store";

const record = (id: string, updatedAt = 1): CampaignRecord => ({
  id,
  appId: "11111111-1111-4111-8111-111111111111",
  target: { name: "Vault", sourcePath: "contracts/Vault.sol", chainId: 5042002 },
  threadId: "thread-1",
  local: { started: true },
  events: [],
  state: { status: "incomplete", report: null, findings: [], rejected: [], executions: 0, budget: 0, notTested: [], fixVerdict: null, next: { kind: "none" }, error: null, busy: false, terminal: false },
  createdAt: 1,
  updatedAt,
});

describe("campaign store", () => {
  describe("without a configured store", () => {
    beforeEach(() => {
      delete process.env.SUPABASE_SNAPSHOT_URL;
      (globalThis as { __arcCampaignRecords?: Map<string, string> }).__arcCampaignRecords = new Map();
    });

    it("keeps records in memory per owner and app, newest first", async () => {
      await saveCampaignRecord("token-a", record("one", 1));
      await saveCampaignRecord("token-a", record("two", 5));
      await saveCampaignRecord("token-b", record("three", 9));
      expect((await listCampaignRecords("token-a", record("x").appId)).map((r) => r.id)).toEqual(["two", "one"]);
      expect(await loadCampaignRecord("token-b", record("x").appId, "three")).toMatchObject({ id: "three" });
      expect(await loadCampaignRecord("token-b", record("x").appId, "one")).toBeNull();
    });

    it("refuses a record that carries a signed link or a bad id", async () => {
      const leaky = record("leak");
      leaky.events = [{ type: "message", content: "https://arc-studio-fuzz.vercel.app/api/artifacts/t.k" } as never];
      await expect(saveCampaignRecord("token", leaky)).rejects.toThrow(/signed artifact links/);
      await expect(saveCampaignRecord("token", record("../etc"))).rejects.toThrow(/Invalid campaign id/);
    });
  });

  describe("with the Supabase bucket", () => {
    let objects: Map<string, string>;
    let requests: string[];
    beforeEach(() => {
      process.env.SUPABASE_SNAPSHOT_URL = "https://snapshots.example.test";
      process.env.SUPABASE_SNAPSHOT_SERVICE_ROLE_KEY = "sb_secret_test";
      process.env.SESSION_SECRET = "a test-only session secret longer than 32 characters";
      objects = new Map();
      requests = [];
      vi.stubGlobal("fetch", vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
        const url = new URL(String(input));
        requests.push(`${init?.method ?? "GET"} ${url.pathname} upsert=${new Headers(init?.headers).get("x-upsert") ?? ""}`);
        const object = url.pathname.match(/^\/storage\/v1\/object\/arc-snapshots\/(.+)$/);
        if (object && init?.method === "POST") {
          objects.set(object[1]!, String(init.body));
          return Response.json({ Key: object[1] });
        }
        if (object) {
          const body = objects.get(object[1]!);
          return body ? new Response(body) : Response.json({ message: "missing" }, { status: 404 });
        }
        if (url.pathname === "/storage/v1/object/list/arc-snapshots") {
          const { prefix } = JSON.parse(String(init?.body)) as { prefix: string };
          return Response.json([...objects.keys()].filter((key) => key.startsWith(prefix)).map((key) => ({ name: key.slice(prefix.length) })));
        }
        throw new Error(`Unexpected request: ${url}`);
      }));
    });
    afterEach(() => vi.unstubAllGlobals());

    it("upserts one object per campaign under the owner's prefix and lists it back", async () => {
      await saveCampaignRecord("origin_pat_a", record("one", 1));
      await saveCampaignRecord("origin_pat_a", record("one", 2));
      expect(objects.size).toBe(1);
      expect([...objects.keys()][0]).toMatch(/^campaigns\/[0-9a-f]{64}\/11111111-1111-4111-8111-111111111111\/one\.json$/);
      expect(requests[0]).toContain("upsert=true");
      const listed = await listCampaignRecords("origin_pat_a", record("x").appId);
      expect(listed.map((r) => [r.id, r.updatedAt])).toEqual([["one", 2]]);
      expect(await listCampaignRecords("origin_pat_b", record("x").appId)).toEqual([]);
    });
  });
});

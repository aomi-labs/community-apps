import { cloudflare } from "@cloudflare/vite-plugin";
import { defineConfig, loadEnv } from "vite";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { fileURLToPath } from "node:url";

export default defineConfig(({ command, mode, isPreview }) => {
  const env = loadEnv(mode, process.cwd(), "");
  for (const key of [
    "SESSION_SECRET",
    "ARC_STUDIO_API_URL",
    "HARNESS_SEED_DIR",
    "HARNESS_API_URL",
    "HARNESS_BACKEND_URL",
    "HARNESS_APPLICATION_ID",
    "HARNESS_PUBLIC_ORIGIN",
  ]) {
    if (!process.env[key] && env[key]) process.env[key] = env[key];
  }
  return {
    resolve: { dedupe: ["react", "react-dom", "@tanstack/react-query"], alias: { "@": fileURLToPath(new URL("./src", import.meta.url)) } },
    define: Object.fromEntries(
      ["NEXT_PUBLIC_AOMI_BACKEND_URL", "NEXT_PUBLIC_AOMI_APPLICATION_ID", "NEXT_PUBLIC_AOMI_MODEL", "NEXT_PUBLIC_AOMI_OAUTH_CLIENT_ID"].map((key) => [
        `process.env.${key}`,
        JSON.stringify(process.env[key] ?? env[key]) ?? "undefined",
      ]),
    ),
    plugins: [
      // The Worker build and its preview run in workerd. `vite dev` stays on Node so the
      // local harness can read its seed directory from disk.
      ...(command === "build" || isPreview ? [cloudflare({ viteEnvironment: { name: "ssr" } })] : []),
      tailwindcss(),
      tanstackStart(),
      react(),
    ],
    server: { port: 3108 },
  };
});

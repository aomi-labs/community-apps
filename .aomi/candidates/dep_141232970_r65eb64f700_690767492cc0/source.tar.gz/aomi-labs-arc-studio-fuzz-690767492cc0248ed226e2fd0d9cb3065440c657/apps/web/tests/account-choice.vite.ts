import { defineConfig, searchForWorkspaceRoot } from "vite";
import react from "@vitejs/plugin-react";
import { fileURLToPath } from "node:url";
export default defineConfig({
  root: fileURLToPath(new URL(".", import.meta.url)),
  plugins: [
    react(),
    {
      name: "local-oauth-callback",
      configureServer(server) {
        server.middlewares.use("/auth/aomi", (_req, res) => {
          res.setHeader("Content-Type", "text/html; charset=utf-8");
          res.end("<!doctype html><title>Aomi sign-in</title><p>Completing sign-in. Return to the Fuzzer.</p>");
        });
      },
    },
  ],
  define: { "process.env.NEXT_PUBLIC_AOMI_OAUTH_CLIENT_ID": JSON.stringify("fuzzer-local") },
  server: {
    host: "127.0.0.1",
    port: 3420,
    fs: {
      allow: [
        searchForWorkspaceRoot(process.cwd()),
        ...(process.env.AOMI_WIDGET_ROOT ? [process.env.AOMI_WIDGET_ROOT] : []),
      ],
    },
  },
});

// Local-only browser acceptance host. Uses the real Fuzzer account implementation;
// the disposable fixture server supplies deterministic SIWE signatures, not auth responses.
import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import { AomiAccount } from "../src/lib/aomi-account";
const portal = "http://127.0.0.1:3417";
const wallet = await fetch("http://127.0.0.1:3419/wallet").then((r) => r.json());
const testWallet = {
  async request({ method, params }: { method: string; params?: string[] }) {
    if (method === "eth_accounts" || method === "eth_requestAccounts") return [wallet.address];
    if (method === "eth_chainId") return "0x1";
    if (method === "personal_sign")
      return fetch("http://127.0.0.1:3419/sign", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ message: params![0] }),
      })
        .then((r) => r.json())
        .then((r) => r.signature);
    throw new Error("No transaction support in auth fixture");
  },
};
function App() {
  const [account, setAccount] = useState<AomiAccount | null>(null);
  const [status, setStatus] = useState("Ready");
  async function run(job: Promise<AomiAccount>) {
    setStatus("Waiting for Aomi…");
    try {
      const next = await job;
      account?.dispose();
      setAccount(next);
      setStatus("Selected canonical account: " + next.id);
    } catch (e) {
      setStatus(String(e));
    }
  }
  return (
    <main style={{ fontFamily: "system-ui", maxWidth: 740, margin: "60px auto", lineHeight: 1.6 }}>
      <h1>Fuzzer account handoff</h1>
      <p>Disposable local auth database · real Portal, PKCE and DPoP · test wallets only</p>
      <p>
        <a href="http://127.0.0.1:3419/portal/a">Portal: Cecilia</a> ·{" "}
        <a href="http://127.0.0.1:3419/portal/b">Portal: Account B</a> ·{" "}
        <a href="http://127.0.0.1:3419/portal/logout">Portal: signed out</a>
      </p>
      <button onClick={() => void run(AomiAccount.signIn(portal, testWallet))}>Fuzzer: sign in as Cecilia</button>{" "}
      <button onClick={() => void run(AomiAccount.openPortal(portal, account, "account"))}>
        Manage account on Aomi
      </button>{" "}
      <button onClick={() => void run(AomiAccount.openPortal(portal, account, "credits"))}>Add credits</button>
      <p role="status">{status}</p>
      <p>Account: {account?.id ?? "signed out"}</p>
      <button
        disabled={!account}
        onClick={() =>
          void account!
            .request("GET", "/v1/agent/sessions")
            .then((r) => setStatus("Selected-account API: HTTP " + r.status))
            .catch((e) => setStatus(String(e)))
        }
      >
        Read selected account sessions
      </button>
      <p>No campaign auto-retry. No payment submitted by this harness.</p>
    </main>
  );
}
createRoot(document.getElementById("root")!).render(<App />);

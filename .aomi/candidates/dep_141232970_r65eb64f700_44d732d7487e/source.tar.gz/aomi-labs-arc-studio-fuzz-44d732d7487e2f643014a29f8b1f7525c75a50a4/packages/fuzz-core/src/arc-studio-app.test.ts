import type { ChatBody, StudioClient } from "@aomi-labs/arc-studio-cli/client";
import { describe, expect, it } from "vitest";

import { ArcStudioApp, MissingBuildError } from "./arc-studio-app.ts";
import type { FuzzCampaignReport } from "./report.ts";

const VAULT = `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.30;
import {Owned} from "./base/Owned.sol";
import "forge-std/console.sol";

contract UnsafeVault is Owned {
    mapping(address => uint256) public deposits;
    function deposit() external payable { deposits[msg.sender] += msg.value; }
    function withdraw(uint256 amount) external { payable(msg.sender).transfer(amount); }
}`;
const OWNED = `pragma solidity ^0.8.30;
abstract contract Owned { address public owner; }`;
const ARTIFACT = {
  abi: [
    { type: "function", name: "deposit", inputs: [], outputs: [], stateMutability: "payable" },
    { type: "function", name: "deposits", inputs: [], outputs: [], stateMutability: "view" },
    { type: "function", name: "withdraw", inputs: [], outputs: [], stateMutability: "nonpayable" },
  ],
  deployedBytecode: { object: "0x6080604052" },
};

function fakeClient(workspace: Record<string, string>, chats: ChatBody[] = []) {
  return {
    webUrl: (appId: string) => `https://studio.arc.io/app/${appId}`,
    getSandbox: async () => ({ sandboxId: "sbx_1" }),
    listSandboxFiles: async () => Object.keys(workspace).map((path) => ({ path, hash: "h" })),
    batchReadFiles: async (_: string, paths: string[]) =>
      paths.map((path) => ({ path, content: workspace[path], error: workspace[path] ? undefined : "missing" })),
    chatDetached: async (body: ChatBody) => {
      chats.push(body);
      return { appId: "app_1", threadId: "thr_9" };
    },
  } as unknown as StudioClient;
}

const WORKSPACE = {
  "foundry.toml": `[profile.default]\nsrc = "contracts"\nout = "out"\n`,
  "contracts/UnsafeVault.sol": VAULT,
  "contracts/base/Owned.sol": OWNED,
  "contracts/UnsafeVault.t.sol": "contract VaultTest {}",
  "out/UnsafeVault.sol/UnsafeVault.json": JSON.stringify(ARTIFACT),
  "src/App.tsx": "export {}",
};

describe("ArcStudioApp", () => {
  it("lists concrete contracts under the Foundry src dir with build status", async () => {
    const app = await ArcStudioApp.open(fakeClient(WORKSPACE), "app_1");
    expect(await app.contracts()).toEqual([
      { path: "contracts/UnsafeVault.sol", source: VAULT, contracts: ["UnsafeVault"], built: true },
      { path: "contracts/base/Owned.sol", source: OWNED, contracts: [], built: false },
    ]);
  });

  it("builds a target from the Foundry artifact and inlines workspace imports only", async () => {
    const app = await ArcStudioApp.open(fakeClient(WORKSPACE), "app_1");
    const target = await app.target("contracts/UnsafeVault.sol", "UnsafeVault");
    expect(target.deployedBytecode).toBe("0x6080604052");
    expect(target.writableFunctions).toEqual(["deposit", "withdraw"]);
    expect(target.source).toContain("// ==== contracts/base/Owned.sol ====");
    expect(target.source).not.toContain("forge-std/console.sol ====");
    expect(target.prompt()).toContain('"deployed_bytecode": "0x6080604052"');
  });

  it("reports a missing build instead of guessing", async () => {
    const { ["out/UnsafeVault.sol/UnsafeVault.json"]: _, ...unbuilt } = WORKSPACE;
    const app = await ArcStudioApp.open(fakeClient(unbuilt), "app_1");
    await expect(app.target("contracts/UnsafeVault.sol", "UnsafeVault")).rejects.toBeInstanceOf(
      MissingBuildError,
    );
  });

  it("sends only confirmed findings back to Arc Studio as a fix request", async () => {
    const chats: ChatBody[] = [];
    const app = await ArcStudioApp.open(fakeClient(WORKSPACE, chats), "app_1");
    const target = await app.target("contracts/UnsafeVault.sol", "UnsafeVault");
    const call = (actor: string, fn: string, args: string[], value = "0") => ({
      label: fn, actor, function: fn, arguments: args, value,
    });
    const report = {
      campaign_id: "0xabc",
      round: 4,
      executions: 10,
      findings: [
        {
          property: "unauthorized_withdraw_must_revert",
          minimized_trace: [call("alice", "deposit()", [], "5"), call("bob", "withdraw(uint256)", ["5"])],
          reproductions: 2,
        },
      ],
      unconfirmed: [{ property: "unconfirmed", trace: [], reason: "violation did not reproduce" }],
    } as unknown as FuzzCampaignReport;

    const result = await app.requestFix(target, report);
    expect(result).toEqual({ threadId: "thr_9", webUrl: "https://studio.arc.io/app/app_1" });
    const content = chats[0]?.messages[0]?.content ?? "";
    expect(chats[0]?.appId).toBe("app_1");
    expect(content).toContain("2. bob calls withdraw(uint256) with (5)");
    expect(content).not.toContain("unconfirmed");
  });
});

// Wire types for the report the Aomi `arc-studio-fuzzer` app returns from
// arc_fuzz_start / arc_fuzz_round / arc_fuzz_report. Mirrors
// apps/arc-studio-fuzzer/src/campaign.rs in this repository.

export interface FuzzCall {
  label: string;
  actor: string;
  function: string;
  arguments: string[];
  value: string;
}

export type ReplayStatus = "succeeded" | "reverted" | "halted" | "failed" | "engine_error";

export interface FindingStep {
  label: string;
  actor: string;
  function: string;
  status: ReplayStatus;
}

export interface BalanceChange {
  address: string;
  before: string;
  after: string;
}

export interface ProbeResult {
  label: string;
  status: ReplayStatus;
  return_data: string | null;
}

/** A violation minimized and reproduced twice from the baseline. */
export interface FuzzFinding {
  property: string;
  minimized_trace: FuzzCall[];
  steps: FindingStep[];
  balances: BalanceChange[];
  probes: ProbeResult[];
  reproductions: number;
}

/** A violation that did not reproduce; never a finding. */
export interface UnconfirmedViolation {
  property: string;
  trace: FuzzCall[];
  reason: string;
}

export interface FuzzCampaignReport {
  campaign_id: string;
  hypothesis: string;
  status: "exploring" | "confirming" | "complete";
  round: number;
  executions: number;
  max_executions: number;
  inconclusive_traces: number;
  corpus_size: number;
  frontier_size: number;
  covered_writes: string[];
  uncovered_writes: string[];
  behavior_coverage: string[];
  findings: FuzzFinding[];
  unconfirmed: UnconfirmedViolation[];
  limitations: string[];
}

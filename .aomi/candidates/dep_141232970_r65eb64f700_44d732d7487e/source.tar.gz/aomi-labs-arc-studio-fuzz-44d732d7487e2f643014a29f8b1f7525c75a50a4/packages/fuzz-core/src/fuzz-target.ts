export const ARC_MAINNET_CHAIN_ID = 5042;

type AbiItem = { type?: string; name?: string; stateMutability?: string };

/** One compiled contract from an Arc Studio app, ready to hand to the Aomi fuzzer. */
export class FuzzTarget {
  constructor(
    readonly name: string,
    /** Workspace path of the defining file, e.g. `contracts/Vault.sol`. */
    readonly sourcePath: string,
    /** The defining file plus any workspace imports, concatenated with path headers. */
    readonly source: string,
    readonly abi: AbiItem[],
    readonly deployedBytecode: string,
    readonly chainId: number = ARC_MAINNET_CHAIN_ID,
  ) {
    if (!/^0x[0-9a-fA-F]+$/.test(deployedBytecode) || deployedBytecode === "0x") {
      throw new Error(`${name} has no deployed bytecode (abstract contract or interface?)`);
    }
  }

  /** Builds a target from a Foundry `out/<File>.sol/<Contract>.json` artifact. */
  static fromFoundryArtifact(
    name: string,
    sourcePath: string,
    source: string,
    artifact: unknown,
    chainId?: number,
  ): FuzzTarget {
    const json = artifact as {
      abi?: AbiItem[];
      deployedBytecode?: { object?: string } | string;
    };
    const deployed =
      typeof json.deployedBytecode === "string"
        ? json.deployedBytecode
        : json.deployedBytecode?.object;
    if (!Array.isArray(json.abi) || !deployed) {
      throw new Error(`${sourcePath}:${name} artifact is missing abi or deployedBytecode`);
    }
    return new FuzzTarget(
      name,
      sourcePath,
      source,
      json.abi,
      deployed.startsWith("0x") ? deployed : `0x${deployed}`,
      chainId,
    );
  }

  /** Writable entrypoints, in ABI order, as `name(...)` labels for display. */
  get writableFunctions(): string[] {
    return this.abi
      .filter(
        (item) =>
          item.type === "function" &&
          item.stateMutability !== "view" &&
          item.stateMutability !== "pure",
      )
      .map((item) => item.name ?? "?");
  }

  /** The user message that starts an autonomous campaign in the Aomi fuzzer app. */
  prompt(): string {
    const artifact = {
      chain_id: this.chainId,
      contract: {
        name: this.name,
        abi: this.abi,
        deployed_bytecode: this.deployedBytecode,
      },
    };
    return `Arc Studio has handed you a compiled contract from a builder's app (${this.sourcePath}). Run a real, complete adversarial fuzz campaign against a held Arc fork. Do not stop after static analysis and do not merely suggest tests.

Use the app-owned breadth-first campaign loop: pass the complete compiler artifact once to arc_map_attack_surface, open chain ${this.chainId}, author a comprehensive executable plan covering every writable entrypoint with the actor roles and properties your threat model calls for, then call arc_fuzz_start with chain_id and the plan fields at the top level (do not nest them under plan). Copy deployed_bytecode from the artifact verbatim; never abbreviate or alter its hex. Actor addresses are app-derived, so provide only lowercase names and balances. Before anything else in the world, install the returned runtime with sim_set_code and the actor balances with sim_set_balance, then take the setup.snapshot checkpoint (overrides are refused after it), execute every returned replay batch, feed every full replay result back into the campaign, and continue through minimization and two successful reproductions. Read the final report before closing the campaign and fork. Explain any confirmed finding with the exact minimized call order and observed fork evidence. If no property is violated within budget, say so plainly and list what was and was not covered.

Tool wire format: serialize each ABI array to a JSON string when calling the plugin. Every FuzzCall argument is a string; encode array or tuple values as JSON text. Treat every returned next_batch as an opaque app-owned recipe: do not invent, remove, reorder, relabel, or rewrite its traces or IDs. Call sim_replay_traces with that exact snapshot, chain_id, watch, and traces plus compact=true, then pass its returned traces array unchanged to arc_fuzz_round.replay. Put state-building actions before extraction actions in the plan so breadth-first expansion reaches meaningful ordered prefixes early. Labels are prose and functions are exact canonical ABI signatures. Use expected_status=reverted for unauthorized actions that must fail; succeeded is coverage pressure only because it has no scenario precondition. Probes must be view/pure only; add a getter probe for each important piece of state so storage-only changes stay distinguishable. An engine_error status means the host could not run the call and is never evidence about the contract. The campaign is finished when next_batch is null.

Critical handoff rule: immediately after every sim_replay_traces result, your very next tool call must be arc_fuzz_round with replay set to that exact returned traces array and plan=null. Never synthesize your own minimization or reproduction traces; the app returns those recipes only after it ingests the preceding replay.

Source:
\`\`\`solidity
${this.source}
\`\`\`

Compiler artifact:
\`\`\`json
${JSON.stringify(artifact, null, 2)}
\`\`\``;
  }
}

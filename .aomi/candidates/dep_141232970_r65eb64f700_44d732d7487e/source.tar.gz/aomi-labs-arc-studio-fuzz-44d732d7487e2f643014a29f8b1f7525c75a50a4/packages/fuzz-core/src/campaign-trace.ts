import type { Event } from "@aomi-labs/client";

import type { FuzzCampaignReport } from "./report.ts";

export interface TraceRow {
  key: string;
  sequence: number;
  /** Tool name without namespace, e.g. `arc_fuzz_round`, `sim_replay_traces`. */
  name: string;
  state: "calling" | "complete" | "failed";
  arguments?: unknown;
  result?: unknown;
}

type RecordValue = Record<string, unknown>;

function record(value: unknown): RecordValue | undefined {
  if (!value || typeof value !== "object" || Array.isArray(value)) return;
  return value as RecordValue;
}

/** Tool results arrive as JSON text, possibly wrapped in MCP `content` blocks. */
function decode(value: unknown): unknown {
  if (typeof value === "string") {
    try {
      return decode(JSON.parse(value));
    } catch {
      return value;
    }
  }
  const object = record(value);
  const content = object?.content;
  if (Array.isArray(content)) {
    const text = content
      .map((item) => record(item)?.text)
      .find((item): item is string => typeof item === "string");
    if (text) return decode(text);
  }
  return object ?? value;
}

/**
 * The fuzz campaign as seen through an Aomi session's event ledger: the
 * `arc_*` / `sim_*` tool calls in order, and the latest campaign report.
 */
export class CampaignTrace {
  readonly rows: TraceRow[];
  readonly report: FuzzCampaignReport | null;

  constructor(events: readonly Event[]) {
    const ordered = [...events].sort((a, b) => a.sequence - b.sequence);
    const rows = new Map<string, TraceRow>();
    let report: FuzzCampaignReport | null = null;

    for (const event of ordered) {
      let name: string | undefined;
      let result: unknown;
      if (event.type === "tool_update" || event.type === "tool_complete") {
        name = event.tool_name.split("::").at(-1);
        result = decode(event.result);
      } else if (event.type === "message" && event.tool_name) {
        name = event.tool_name.split("::").at(-1);
        result = event.tool_result ? decode(event.tool_result[1]) : undefined;
      }
      if (!name || (!name.startsWith("arc_") && !name.startsWith("sim_"))) continue;

      const callId =
        event.type === "tool_update" || event.type === "tool_complete"
          ? (event.call_id ?? event.id)
          : event.type === "message"
            ? (event.tool_call_id ?? `${event.turn_id}:${name}:${event.sequence}`)
            : `${event.sequence}`;
      const key = `${event.turn_id ?? "turn"}:${callId}`;
      const previous = rows.get(key);
      const object = record(result);
      rows.set(key, {
        key,
        sequence: event.sequence,
        name,
        state:
          object?.is_error === true || object?.error
            ? "failed"
            : result !== undefined
              ? "complete"
              : "calling",
        arguments: event.type === "message" ? event.tool_arguments : previous?.arguments,
        result: result ?? previous?.result,
      });

      if (name.startsWith("arc_fuzz_")) {
        const candidate = record(object?.report) ?? object;
        if (typeof candidate?.campaign_id === "string" && Array.isArray(candidate.findings)) {
          report = candidate as unknown as FuzzCampaignReport;
        }
      }
    }

    this.rows = [...rows.values()].sort((a, b) => a.sequence - b.sequence);
    this.report = report;
  }

  /** The first finding; every finding was reproduced twice. */
  get finding() {
    return this.report?.findings[0];
  }
}

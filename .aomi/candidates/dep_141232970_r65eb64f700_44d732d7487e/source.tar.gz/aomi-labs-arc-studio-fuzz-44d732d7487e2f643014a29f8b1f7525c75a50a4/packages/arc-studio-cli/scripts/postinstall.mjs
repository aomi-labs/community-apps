import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

export function getNpmGlobalBin() {
  try {
    const prefix = execFileSync('npm', ['config', 'get', 'prefix'], { encoding: 'utf8' }).trim();
    return `${prefix}/bin`;
  } catch {
    return null;
  }
}

export function needsPathHint(platform, pathEnv, globalBin, isGlobalInstall) {
  if (platform !== 'linux' || !isGlobalInstall) {
    return false;
  }
  if (!globalBin) {
    return false;
  }
  return !(pathEnv ?? '').split(':').includes(globalBin);
}

// Run only when invoked directly as the npm postinstall script, not when
// imported by tests — import.meta.url !== process.argv[1] in test context.
if (fileURLToPath(import.meta.url) === process.argv[1]) {
  try {
    const isGlobalInstall = process.env['npm_config_global'] === 'true';
    const globalBin = isGlobalInstall && process.platform === 'linux' ? getNpmGlobalBin() : null;
    if (needsPathHint(process.platform, process.env['PATH'], globalBin, isGlobalInstall)) {
      process.stdout.write(
        `\narc-studio: add npm's global bin to PATH to use this command:\n` +
          `  export PATH="${globalBin}:$PATH"\n\n` +
          `Add this to ~/.bashrc or ~/.profile to make it permanent.\n`,
      );
    }
  } catch {
    // Never fail a package install
  }
}

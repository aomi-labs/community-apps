import type { NextConfig } from "next";

const config: NextConfig = {
  // fuzz-core ships TypeScript source.
  transpilePackages: ["@aomi-labs/arc-studio-fuzz-core"],
  // The forked CLI client uses Node APIs (keychain fallback); keep it out of bundling.
  serverExternalPackages: ["@aomi-labs/arc-studio-cli"],
};

export default config;

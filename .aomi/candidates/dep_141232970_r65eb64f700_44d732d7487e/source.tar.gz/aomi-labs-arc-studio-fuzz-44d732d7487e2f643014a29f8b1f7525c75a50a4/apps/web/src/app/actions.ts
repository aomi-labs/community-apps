"use server";

import type { FuzzCampaignReport } from "@aomi-labs/arc-studio-fuzz-core";
import { MissingBuildError } from "@aomi-labs/arc-studio-fuzz-core";
import { redirect } from "next/navigation";

import { StudioSession } from "@/server/studio-session";

/** Plain-data form of a FuzzTarget, safe to cross the server-action boundary. */
export interface TargetData {
  name: string;
  sourcePath: string;
  source: string;
  abi: Array<{ type?: string; name?: string; stateMutability?: string }>;
  deployedBytecode: string;
  chainId: number;
}

type Result<T> = { ok: true; value: T } | { ok: false; error: string; missingBuild?: boolean };

async function session(): Promise<StudioSession> {
  const current = await StudioSession.current();
  if (!current) redirect("/");
  return current;
}

function failure(error: unknown): { ok: false; error: string; missingBuild?: boolean } {
  return {
    ok: false,
    error: error instanceof Error ? error.message : String(error),
    missingBuild: error instanceof MissingBuildError || undefined,
  };
}

export async function connect(_: unknown, form: FormData): Promise<{ error: string } | undefined> {
  try {
    await StudioSession.start(String(form.get("token") ?? ""));
  } catch (error) {
    return { error: error instanceof Error ? error.message : String(error) };
  }
  redirect("/");
}

export async function disconnect(): Promise<void> {
  await StudioSession.end();
  redirect("/");
}

export async function loadTarget(
  appId: string,
  sourcePath: string,
  contract: string,
): Promise<Result<TargetData>> {
  try {
    const target = await (await (await session()).app(appId)).target(sourcePath, contract);
    return {
      ok: true,
      value: {
        name: target.name,
        sourcePath: target.sourcePath,
        source: target.source,
        abi: target.abi,
        deployedBytecode: target.deployedBytecode,
        chainId: target.chainId,
      },
    };
  } catch (error) {
    return failure(error);
  }
}

export async function requestBuild(appId: string): Promise<Result<{ webUrl: string }>> {
  try {
    const { webUrl } = await (await (await session()).app(appId)).requestBuild();
    return { ok: true, value: { webUrl } };
  } catch (error) {
    return failure(error);
  }
}

export async function requestFix(
  appId: string,
  sourcePath: string,
  contract: string,
  report: FuzzCampaignReport,
): Promise<Result<{ webUrl: string }>> {
  try {
    const app = await (await session()).app(appId);
    const { webUrl } = await app.requestFix(await app.target(sourcePath, contract), report);
    return { ok: true, value: { webUrl } };
  } catch (error) {
    return failure(error);
  }
}

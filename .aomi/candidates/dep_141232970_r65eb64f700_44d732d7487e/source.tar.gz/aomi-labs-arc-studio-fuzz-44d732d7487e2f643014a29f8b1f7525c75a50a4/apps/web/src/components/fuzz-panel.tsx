"use client";

import { CampaignTrace, FuzzTarget } from "@aomi-labs/arc-studio-fuzz-core";
import { useAomiRuntime, usePerThreadControl } from "@aomi-labs/react";
import {
  AlertTriangle,
  BrainCircuit,
  Check,
  ChevronRight,
  CircleDot,
  ExternalLink,
  Play,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  Wrench,
  X,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState, useTransition } from "react";

import { requestFix, type TargetData } from "@/app/actions";

function short(value: string, head = 8, tail = 6): string {
  return value.length <= head + tail + 1 ? value : `${value.slice(0, head)}…${value.slice(-tail)}`;
}

function pretty(value: unknown): string {
  if (value === undefined) return "";
  const output = typeof value === "string" ? value : JSON.stringify(value, null, 2);
  return output.length > 1_200 ? `${output.slice(0, 1_200)}\n…` : output;
}

function messageText(content: unknown): string {
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    return content
      .map((item) => (item && typeof item === "object" ? (item as { text?: unknown }).text : undefined))
      .filter((item): item is string => typeof item === "string")
      .join("\n");
  }
  return pretty(content);
}

export function FuzzPanel({
  appId,
  backendUrl,
  target: data,
  onRefresh,
}: {
  appId: string;
  backendUrl: string;
  target: TargetData;
  onRefresh: () => void;
}) {
  const { createThread, events, getMessages, isRunning, isSubmitting, sendMessage, setUser, turnState } =
    useAomiRuntime();
  const {
    actions: { onModelSelect },
  } = usePerThreadControl();
  const target = useMemo(
    () => new FuzzTarget(data.name, data.sourcePath, data.source, data.abi, data.deployedBytecode, data.chainId),
    [data],
  );
  const [runs, setRuns] = useState(0);
  const [failure, setFailure] = useState<string | null>(null);
  const [fix, setFix] = useState<{ webUrl?: string; error?: string } | null>(null);
  const [fixing, startFix] = useTransition();
  const traceEnd = useRef<HTMLDivElement>(null);

  const trace = useMemo(() => new CampaignTrace(events), [events]);
  const { report, finding } = trace;
  const started = runs > 0;
  const busy = started && (isSubmitting || isRunning || turnState === "processing");
  const finished = started && !busy && turnState === "complete";
  const finalMessage = [...getMessages()].reverse().find((message) => message.role === "assistant");

  useEffect(() => {
    setUser({
      connection: { is_connected: true, provider: "arc-studio", provider_label: "Arc Studio app" },
      ext: { host: "arc-studio", execution: "isolated-fork", arc_studio_app_id: appId },
    });
  }, [appId, setUser]);

  useEffect(() => {
    traceEnd.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }, [trace.rows.length, turnState]);

  async function run(): Promise<void> {
    setFailure(null);
    setFix(null);
    try {
      // Each campaign gets a fresh session so the trace and report are its own.
      if (runs > 0) await createThread();
      setRuns((count) => count + 1);
      await onModelSelect("sonnet-5", { mode: "manual" });
      await sendMessage(target.prompt());
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      setFailure(
        message === "Failed to fetch"
          ? `Could not reach the Aomi backend at ${backendUrl}. Is it running with the arc-studio-fuzzer app loaded?`
          : message,
      );
    }
  }

  return (
    <>
      <div className="flex h-14 items-center justify-between border-b border-white/10 px-5">
        <div className="flex items-center gap-2.5">
          <div className="grid size-7 place-items-center rounded-md bg-[#6e59ff] shadow-[0_0_20px_rgba(110,89,255,.3)]">
            <BrainCircuit className="size-4 text-white" />
          </div>
          <div>
            <h1 className="text-[13px] font-semibold text-[#e9edf5]">Aomi Security Agent</h1>
            <p className="text-[10px] text-[#8996ab]">
              {target.name} · {target.writableFunctions.length} writable function
              {target.writableFunctions.length === 1 ? "" : "s"}
            </p>
          </div>
        </div>
        <span className="rounded border border-[#8b7cff]/30 bg-[#6e59ff]/10 px-2 py-1 font-mono text-[9px] text-[#b8adff]">
          LIVE
        </span>
      </div>

      <div className="min-h-0 flex-1 overflow-auto p-4">
        {!started && (
          <div>
            <div className="rounded-lg border border-[#6e59ff]/25 bg-[#6e59ff]/8 p-4">
              <div className="mb-3 flex items-center gap-2 text-[11px] font-medium text-[#c7bdff]">
                <Sparkles className="size-4" /> Compiled artifact loaded from Arc Studio
              </div>
              <p className="text-[11px] leading-5 text-[#a7b0c0]">
                Source, ABI, and runtime bytecode for <code>{target.name}</code> ({target.sourcePath}) go to the
                Aomi fuzzer. Every row below comes from the agent&apos;s live event stream.
              </p>
              <p className="mt-2 font-mono text-[10px] text-[#7d899d]">
                writes: {target.writableFunctions.join(", ") || "none"}
              </p>
            </div>
            <div className="mt-4 space-y-2">
              {[
                "Agent authors the threat model, actors, and properties",
                "Runtime holds one Arc fork; nothing is broadcast",
                "A finding needs two clean reproductions",
              ].map((label) => (
                <div
                  key={label}
                  className="flex items-center gap-3 rounded-md border border-white/7 bg-white/[.02] px-3 py-3 text-[10px] text-[#9aa5b6]"
                >
                  <ShieldCheck className="size-4 text-[#8f81f7]" /> {label}
                </div>
              ))}
            </div>
          </div>
        )}

        {started && (
          <div>
            <div
              className={`mb-4 flex items-start gap-3 rounded-lg border p-3 ${
                failure || finding ? "border-[#ff4d6d]/30 bg-[#ff4d6d]/7" : "border-[#6e59ff]/25 bg-[#6e59ff]/8"
              }`}
            >
              <div className="mt-0.5 grid size-8 shrink-0 place-items-center rounded-full bg-white/[.04]">
                {busy ? (
                  <RefreshCw className="size-4 animate-spin text-[#a99cff]" />
                ) : failure || finding ? (
                  <AlertTriangle className="size-4 text-[#ff718b]" />
                ) : (
                  <Check className="size-4 text-[#7fe3aa]" />
                )}
              </div>
              <div className="min-w-0">
                <h2 className="text-[11px] font-semibold">
                  {failure
                    ? "Campaign failed"
                    : busy
                      ? "Agent is exploring the fork"
                      : finding
                        ? "Reproduced invariant violation"
                        : finished
                          ? "Campaign complete"
                          : "Connecting to agent"}
                </h2>
                <p className="mt-1 font-mono text-[9px] text-[#7d899d]">
                  {turnState ?? "submitting"} · {trace.rows.length} tool events · {events.length} ledger events
                </p>
              </div>
            </div>

            <h3 className="mb-2 text-[9px] font-semibold uppercase tracking-[0.12em] text-[#78859a]">
              Live agent trace
            </h3>
            <div data-testid="agent-trace" className="space-y-2">
              {trace.rows.length === 0 && (
                <div className="rounded-md border border-white/7 bg-white/[.02] px-3 py-4 text-center text-[10px] text-[#657187]">
                  Waiting for the first tool call…
                </div>
              )}
              {trace.rows.map((row) => (
                <details
                  key={row.key}
                  data-tool-name={row.name}
                  className="group rounded-md border border-white/7 bg-[#0b0f16]/70 px-3 py-2.5"
                >
                  <summary className="flex cursor-pointer list-none items-center gap-2">
                    {row.state === "calling" ? (
                      <CircleDot className="size-3.5 animate-pulse text-[#a99cff]" />
                    ) : row.state === "failed" ? (
                      <X className="size-3.5 text-[#ff718b]" />
                    ) : (
                      <Check className="size-3.5 text-[#7fe3aa]" />
                    )}
                    <span className="min-w-0 flex-1 truncate font-mono text-[10px] text-[#c7cfdb]">{row.name}</span>
                    <span className="text-[9px] text-[#5f6a7d]">#{row.sequence}</span>
                    <ChevronRight className="size-3 text-[#5f6a7d] transition group-open:rotate-90" />
                  </summary>
                  {(row.arguments !== undefined || row.result !== undefined) && (
                    <pre className="mt-2 max-h-40 overflow-auto whitespace-pre-wrap border-t border-white/6 pt-2 font-mono text-[9px] leading-4 text-[#768399]">
                      {row.arguments !== undefined ? `args\n${pretty(row.arguments)}\n` : ""}
                      {row.result !== undefined ? `result\n${pretty(row.result)}` : ""}
                    </pre>
                  )}
                </details>
              ))}
            </div>

            {finding && report && (
              <div
                data-testid="verified-finding"
                className="mt-4 rounded-lg border border-[#ff4d6d]/25 bg-[#ff4d6d]/6 p-3"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#ff8196]">
                    Verified finding
                  </span>
                  <span className="rounded bg-[#7fe3aa]/10 px-2 py-1 font-mono text-[9px] text-[#7fe3aa]">
                    REPLAYED 2×
                  </span>
                </div>
                <p className="mt-2 text-[12px] leading-5 text-[#eadde1]">{finding.property}</p>
                <div className="mt-3 space-y-1.5">
                  {finding.minimized_trace.map((call, index) => (
                    <div
                      key={`${call.label}-${index}`}
                      className="flex items-center gap-2 rounded border border-white/7 bg-black/10 px-2.5 py-2"
                    >
                      <span className="grid size-5 place-items-center rounded-full bg-[#6e59ff]/15 font-mono text-[9px] text-[#b9afff]">
                        {index + 1}
                      </span>
                      <span className="font-mono text-[10px] text-[#b7c0cf]">
                        {call.actor} → {call.function}
                      </span>
                    </div>
                  ))}
                </div>
                <div className="mt-3 grid grid-cols-3 gap-2">
                  {(
                    [
                      ["round", report.round],
                      ["executions", report.executions],
                      ["corpus", report.corpus_size],
                    ] as const
                  ).map(([label, value]) => (
                    <div key={label} className="rounded border border-white/7 bg-black/10 p-2">
                      <div className="text-[8px] uppercase text-[#6f7b8f]">{label}</div>
                      <div className="mt-1 font-mono text-[11px] text-white">{value}</div>
                    </div>
                  ))}
                </div>
                <p className="mt-3 text-center font-mono text-[9px] text-[#566276]">
                  {short(report.campaign_id)} · Arc fork · no signing
                </p>
              </div>
            )}

            {finalMessage?.content && finished && (
              <div className="mt-4 rounded-lg border border-white/8 bg-white/[.025] p-3">
                <div className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-[#8f81f7]">
                  Agent conclusion
                </div>
                <div className="max-h-44 overflow-auto whitespace-pre-wrap text-[10px] leading-4 text-[#aeb7c6]">
                  {messageText(finalMessage.content)}
                </div>
              </div>
            )}
            {failure && <p className="mt-3 text-[10px] leading-4 text-[#ff8ca1]">{failure}</p>}
            <div ref={traceEnd} />
          </div>
        )}
      </div>

      <div className="space-y-2 border-t border-white/10 p-4">
        {finding && report && finished && (
          <>
            {fix?.webUrl ? (
              <div className="rounded-md border border-[#7fe3aa]/25 bg-[#7fe3aa]/5 p-3 text-[11px] text-[#bfeccf]">
                Fix request sent to Arc Studio.{" "}
                <a href={fix.webUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 underline">
                  Follow it there <ExternalLink className="size-3" />
                </a>
                <button onClick={onRefresh} className="mt-2 block text-[#8996ab] underline">
                  Arc Studio finished? Reload the contract, then fuzz again
                </button>
              </div>
            ) : (
              <button
                data-testid="send-fix"
                disabled={fixing}
                onClick={() =>
                  startFix(async () => {
                    const result = await requestFix(appId, target.sourcePath, target.name, report);
                    setFix(result.ok ? { webUrl: result.value.webUrl } : { error: result.error });
                  })
                }
                className="flex h-10 w-full items-center justify-center gap-2 rounded-md border border-[#ff4d6d]/40 bg-[#ff4d6d]/10 text-[11px] font-semibold text-[#ffc2cd] hover:bg-[#ff4d6d]/15 disabled:opacity-70"
              >
                {fixing ? <RefreshCw className="size-3.5 animate-spin" /> : <Wrench className="size-3.5" />}
                Send finding to Arc Studio for a fix
              </button>
            )}
            {fix?.error && <p className="text-[10px] text-[#ff8ca1]">{fix.error}</p>}
          </>
        )}
        <button
          data-testid="run-aomi-fuzz"
          onClick={() => void run()}
          disabled={busy}
          className="flex h-10 w-full items-center justify-center gap-2 rounded-md bg-[#6e59ff] text-[11px] font-semibold text-white shadow-[0_8px_30px_rgba(110,89,255,.24)] transition hover:bg-[#7d6aff] disabled:cursor-wait disabled:opacity-70"
        >
          {busy ? (
            <>
              <RefreshCw className="size-3.5 animate-spin" /> Running campaign…
            </>
          ) : started ? (
            <>
              <RefreshCw className="size-3.5" /> Run a new campaign
            </>
          ) : (
            <>
              <Play className="size-3.5 fill-current" /> Fuzz {target.name} on an Arc fork
            </>
          )}
        </button>
        <p className="text-center text-[10px] text-[#566276]">Real model · held Arc fork · no signing or broadcast</p>
      </div>
    </>
  );
}

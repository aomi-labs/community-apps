import { ShieldCheck } from "lucide-react";

export function Brand() {
  return (
    <div className="flex items-center gap-2.5">
      <span className="grid size-7 place-items-center rounded-md bg-[#6e59ff] shadow-[0_0_20px_rgba(110,89,255,.3)]">
        <ShieldCheck className="size-4 text-white" />
      </span>
      <span className="text-[14px] font-semibold tracking-tight">
        Aomi Fuzz <span className="font-normal text-[#8996ab]">for Arc Studio</span>
      </span>
    </div>
  );
}

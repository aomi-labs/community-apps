"use client";

import type { ContractSource } from "@aomi-labs/arc-studio-fuzz-core";
import { AomiRuntimeProvider } from "@aomi-labs/react";
import { Check, ChevronLeft, CircleDashed, ExternalLink, FileCode2, Hammer, Loader2 } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { type ReactNode, useEffect, useState, useTransition } from "react";

import { loadTarget, requestBuild, type TargetData } from "@/app/actions";
import { Brand } from "@/components/brand";
import { FuzzPanel } from "@/components/fuzz-panel";

const backendUrl = process.env.NEXT_PUBLIC_AOMI_BACKEND_URL ?? "http://127.0.0.1:3000";
const configuredApplicationId = Number(process.env.NEXT_PUBLIC_AOMI_APPLICATION_ID);
const applicationId =
  Number.isSafeInteger(configuredApplicationId) && configuredApplicationId > 0
    ? configuredApplicationId
    : undefined;

const KEYWORDS =
  /\b(?:contract|interface|library|abstract|is|mapping|address|bool|string|bytes\d*|u?int\d*|public|private|internal|external|view|pure|payable|function|modifier|event|error|emit|returns?|require|revert|if|else|for|while|memory|storage|calldata|constructor|pragma|solidity|import|using|struct|enum|override|virtual|immutable|constant)\b/;

function highlight(line: string): ReactNode {
  if (line.trim().startsWith("//")) return <span className="text-[#70809a]">{line}</span>;
  return line.split(new RegExp(`(${KEYWORDS.source})`, "g")).map((token, index) =>
    KEYWORDS.test(token) ? (
      <span key={index} className="text-[#c995ff]">
        {token}
      </span>
    ) : (
      token
    ),
  );
}

type TargetState =
  | { status: "idle" }
  | { status: "loading" }
  | { status: "ready"; target: TargetData }
  | { status: "missing-build"; error: string; buildUrl?: string }
  | { status: "error"; error: string };

export interface FuzzWorkspaceProps {
  appId: string;
  appName: string;
  studioUrl: string;
  contracts: ContractSource[];
}

export function FuzzWorkspace(props: FuzzWorkspaceProps) {
  return (
    <AomiRuntimeProvider
      backendUrl={backendUrl}
      applicationId={applicationId}
      agentTarget={
        applicationId
          ? { mode: "direct", applicationId, app: "arc-studio-fuzzer" }
          : { mode: "direct", app: "arc-studio-fuzzer" }
      }
      persistThread={false}
      threadPersistenceScope={`arc-studio-fuzz:${props.appId}`}
    >
      <Workspace {...props} />
    </AomiRuntimeProvider>
  );
}

function Workspace({ appId, appName, studioUrl, contracts }: FuzzWorkspaceProps) {
  const router = useRouter();
  const firstBuilt =
    contracts.find((file) => file.built && file.contracts.length > 0) ??
    contracts.find((file) => file.contracts.length > 0);
  const [selected, setSelected] = useState<{ path: string; contract: string } | null>(
    firstBuilt ? { path: firstBuilt.path, contract: firstBuilt.contracts[0] as string } : null,
  );
  const [target, setTarget] = useState<TargetState>({ status: "idle" });
  const [reloads, setReloads] = useState(0);
  const [building, startBuild] = useTransition();
  const file = contracts.find((item) => item.path === selected?.path);

  useEffect(() => {
    if (!selected) return;
    let cancelled = false;
    setTarget({ status: "loading" });
    void loadTarget(appId, selected.path, selected.contract).then((result) => {
      if (cancelled) return;
      if (result.ok) setTarget({ status: "ready", target: result.value });
      else if (result.missingBuild) setTarget({ status: "missing-build", error: result.error });
      else setTarget({ status: "error", error: result.error });
    });
    return () => {
      cancelled = true;
    };
  }, [appId, selected, reloads]);

  /** Re-read the workspace from Arc Studio (after a build or fix landed there). */
  function refresh() {
    router.refresh();
    setReloads((count) => count + 1);
  }

  return (
    <main className="h-screen overflow-hidden">
      <header className="flex h-13 items-center justify-between border-b border-white/10 bg-[#0c1018] px-4">
        <div className="flex min-w-0 items-center gap-4">
          <Link href="/" className="text-[#8996ab] hover:text-white" aria-label="Back to apps">
            <ChevronLeft className="size-4" />
          </Link>
          <Brand />
          <div className="h-5 w-px bg-white/10" />
          <span className="truncate text-[12px] font-medium text-[#eef2f8]">{appName}</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 rounded-full border border-[#6e59ff]/35 bg-[#6e59ff]/10 px-3 py-1.5 text-[11px] text-[#c5baff]">
            <span className="size-1.5 rounded-full bg-[#8b7cff] shadow-[0_0_8px_#8b7cff]" />
            Arc fork · {target.status === "ready" ? target.target.chainId : 5042}
          </div>
          <a
            href={studioUrl}
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1.5 rounded-md border border-white/10 bg-white/5 px-3 py-1.5 text-[11px] font-medium text-[#cbd3e1] hover:bg-white/10"
          >
            Open in Arc Studio <ExternalLink className="size-3" />
          </a>
        </div>
      </header>

      <div className="grid h-[calc(100vh-52px)] grid-cols-[200px_minmax(0,1fr)_minmax(340px,440px)]">
        <aside className="overflow-auto border-r border-white/10 bg-[#0d1119] text-[12px]">
          <div className="flex h-10 items-center px-3 text-[10px] font-semibold uppercase tracking-[0.12em] text-[#78859a]">
            Contracts
          </div>
          {contracts.length === 0 && (
            <p className="px-3 text-[11px] leading-5 text-[#8996ab]">
              No Solidity files in this app&apos;s workspace yet.
            </p>
          )}
          <ul className="space-y-1 px-2 pb-4">
            {contracts.map((item) => (
              <li key={item.path}>
                <div className="flex items-center gap-1.5 px-1 py-1.5 text-[#8793a7]">
                  <FileCode2 className="size-3.5 shrink-0" />
                  <span className="truncate" title={item.path}>
                    {item.path}
                  </span>
                </div>
                {item.contracts.map((name) => {
                  const active = selected?.path === item.path && selected.contract === name;
                  return (
                    <button
                      key={name}
                      onClick={() => setSelected({ path: item.path, contract: name })}
                      className={`ml-4 flex w-[calc(100%-1rem)] items-center justify-between gap-2 rounded px-2 py-1.5 text-left ${
                        active ? "bg-[#6e59ff]/15 text-[#e2ddff]" : "text-[#b7c0cf] hover:bg-white/5"
                      }`}
                    >
                      <span className="truncate">{name}</span>
                      {item.built ? (
                        <Check className="size-3 shrink-0 text-[#7fe3aa]" aria-label="built" />
                      ) : (
                        <CircleDashed className="size-3 shrink-0 text-[#68758a]" aria-label="not built" />
                      )}
                    </button>
                  );
                })}
              </li>
            ))}
          </ul>
        </aside>

        <section className="min-w-0 bg-[#0b0f16]">
          <div className="flex h-10 items-center border-b border-white/10 bg-[#0d1119] px-4 text-[11px] text-[#dfe4ec]">
            {file?.path ?? "No file selected"}
          </div>
          <div className="h-[calc(100%-40px)] overflow-auto py-4 font-mono text-[12px] leading-[1.8]">
            {(file?.source ?? "").split("\n").map((line, index) => (
              <div key={index} className="flex min-h-[22px]">
                <span className="w-12 shrink-0 select-none pr-4 text-right text-[#465165]">
                  {index + 1}
                </span>
                <span className="whitespace-pre text-[#d5dbe6]">{highlight(line)}</span>
              </div>
            ))}
          </div>
        </section>

        <aside className="flex min-h-0 min-w-0 flex-col border-l border-white/10 bg-[#10151f]">
          {target.status === "ready" ? (
            <FuzzPanel
              key={`${target.target.sourcePath}:${target.target.name}`}
              appId={appId}
              backendUrl={backendUrl}
              target={target.target}
              onRefresh={refresh}
            />
          ) : (
            <div className="flex flex-1 flex-col items-center justify-center gap-3 p-6 text-center text-[12px] text-[#a7b0c0]">
              {target.status === "idle" && <p>Pick a contract to fuzz.</p>}
              {target.status === "loading" && (
                <p className="flex items-center gap-2">
                  <Loader2 className="size-4 animate-spin" /> Loading compiled artifact from Arc Studio…
                </p>
              )}
              {target.status === "error" && <p className="text-[#ff8ca1]">{target.error}</p>}
              {target.status === "missing-build" && (
                <>
                  <p>{target.error}</p>
                  {target.buildUrl ? (
                    <>
                      <a href={target.buildUrl} target="_blank" rel="noreferrer" className="text-[#b9afff] underline">
                        Follow the build in Arc Studio
                      </a>
                      <button onClick={refresh} className="text-[#8996ab] underline">
                        Check again
                      </button>
                    </>
                  ) : (
                    <button
                      disabled={building}
                      onClick={() =>
                        startBuild(async () => {
                          const result = await requestBuild(appId);
                          setTarget(
                            result.ok
                              ? { status: "missing-build", error: "Arc Studio is building the app.", buildUrl: result.value.webUrl }
                              : { status: "error", error: result.error },
                          );
                        })
                      }
                      className="flex items-center gap-2 rounded-md bg-[#6e59ff] px-4 py-2 font-semibold text-white disabled:opacity-70"
                    >
                      {building ? <Loader2 className="size-4 animate-spin" /> : <Hammer className="size-4" />}
                      Ask Arc Studio to build
                    </button>
                  )}
                </>
              )}
            </div>
          )}
        </aside>
      </div>
    </main>
  );
}

import "server-only";

import { createCipheriv, createDecipheriv, createHash, randomBytes } from "node:crypto";

import { ArcStudioApp } from "@aomi-labs/arc-studio-fuzz-core";
import { StudioClient } from "@aomi-labs/arc-studio-cli/client";
import { cookies } from "next/headers";

const COOKIE = "arc_studio_session";
const MAX_AGE_SECONDS = 60 * 60 * 24 * 7;
const ALLOWED_API_URLS = new Set(["https://studio.arc.io", "https://studio-staging.arc.io"]);

/**
 * The visitor's Arc Studio personal access token, held only server-side in an
 * AES-256-GCM encrypted, httpOnly cookie. Every Arc Studio call goes through
 * the forked CLI's StudioClient with that token injected.
 */
export class StudioSession {
  private constructor(readonly token: string) {}

  static get apiUrl(): string {
    const url = (process.env.ARC_STUDIO_API_URL ?? "https://studio.arc.io").replace(/\/+$/, "");
    if (!ALLOWED_API_URLS.has(url) && !/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(url)) {
      throw new Error(`ARC_STUDIO_API_URL must be an Arc Studio host, got ${url}`);
    }
    return url;
  }

  static #key(): Buffer {
    const secret = process.env.SESSION_SECRET;
    if (!secret || secret.length < 32) {
      throw new Error("SESSION_SECRET must be set (at least 32 characters).");
    }
    return createHash("sha256").update(secret).digest();
  }

  static async current(): Promise<StudioSession | null> {
    const sealed = (await cookies()).get(COOKIE)?.value;
    if (!sealed) return null;
    try {
      const raw = Buffer.from(sealed, "base64url");
      const decipher = createDecipheriv("aes-256-gcm", StudioSession.#key(), raw.subarray(0, 12));
      decipher.setAuthTag(raw.subarray(raw.length - 16));
      const token = Buffer.concat([
        decipher.update(raw.subarray(12, raw.length - 16)),
        decipher.final(),
      ]).toString("utf8");
      return new StudioSession(token);
    } catch {
      return null;
    }
  }

  /** Verifies the token against Arc Studio before storing it. */
  static async start(token: string): Promise<StudioSession> {
    const trimmed = token.trim();
    if (!/^origin_pat_[A-Za-z0-9_-]+$/.test(trimmed)) {
      throw new Error("That does not look like an Arc Studio token (expected origin_pat_…).");
    }
    const session = new StudioSession(trimmed);
    try {
      await session.client().listApps();
    } catch {
      throw new Error("Arc Studio rejected that token. Authorize again and paste the new token.");
    }
    const iv = randomBytes(12);
    const cipher = createCipheriv("aes-256-gcm", StudioSession.#key(), iv);
    const body = Buffer.concat([cipher.update(trimmed, "utf8"), cipher.final()]);
    (await cookies()).set(COOKIE, Buffer.concat([iv, body, cipher.getAuthTag()]).toString("base64url"), {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: MAX_AGE_SECONDS,
    });
    return session;
  }

  static async end(): Promise<void> {
    (await cookies()).delete(COOKIE);
  }

  client(): StudioClient {
    return new StudioClient(StudioSession.apiUrl, {
      headers: { authorization: `Bearer ${this.token}` },
      source: "injected-token",
    });
  }

  app(appId: string): Promise<ArcStudioApp> {
    return ArcStudioApp.open(this.client(), appId);
  }
}

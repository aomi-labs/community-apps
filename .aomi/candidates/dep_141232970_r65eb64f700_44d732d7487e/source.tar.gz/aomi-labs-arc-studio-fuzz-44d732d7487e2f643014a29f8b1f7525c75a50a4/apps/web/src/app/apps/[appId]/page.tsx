import Link from "next/link";
import { redirect } from "next/navigation";

import { Brand } from "@/components/brand";
import { FuzzWorkspace } from "@/components/fuzz-workspace";
import { StudioSession } from "@/server/studio-session";

export const dynamic = "force-dynamic";

export default async function AppPage({ params }: { params: Promise<{ appId: string }> }) {
  const { appId } = await params;
  const session = await StudioSession.current();
  if (!session) redirect("/");

  const client = session.client();
  const [described, loaded] = await Promise.all([
    client.listApps().then((apps) => apps.find((app) => app.id === appId)),
    session
      .app(appId)
      .then(async (app) => ({ app, contracts: await app.contracts() }))
      .catch((error: unknown) => (error instanceof Error ? error.message : String(error))),
  ]);

  if (typeof loaded === "string") {
    return (
      <main className="min-h-screen">
        <header className="flex h-14 items-center border-b border-white/10 px-5">
          <Brand />
        </header>
        <div className="mx-auto max-w-lg px-4 py-16 text-center">
          <p className="text-sm text-[#ff8ca1]">{loaded}</p>
          <div className="mt-6 flex justify-center gap-4 text-sm">
            <a href={client.webUrl(appId)} target="_blank" rel="noreferrer" className="text-[#b9afff] underline">
              Open in Arc Studio
            </a>
            <Link href="/" className="text-[#8996ab] underline">
              Back to apps
            </Link>
          </div>
        </div>
      </main>
    );
  }

  return (
    <FuzzWorkspace
      appId={appId}
      appName={described?.description || "Untitled app"}
      studioUrl={loaded.app.webUrl}
      contracts={loaded.contracts}
    />
  );
}

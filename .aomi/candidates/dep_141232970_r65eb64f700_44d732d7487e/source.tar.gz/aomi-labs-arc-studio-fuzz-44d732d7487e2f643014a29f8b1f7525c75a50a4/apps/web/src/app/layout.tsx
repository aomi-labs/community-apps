import type { Metadata } from "next";
import type { ReactNode } from "react";

import "./globals.css";

export const metadata: Metadata = {
  title: "Aomi Fuzz for Arc Studio",
  description:
    "Stateful fuzzing of your Arc Studio contracts on a held Arc fork, with verified reproductions sent back to Arc Studio for a fix.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}

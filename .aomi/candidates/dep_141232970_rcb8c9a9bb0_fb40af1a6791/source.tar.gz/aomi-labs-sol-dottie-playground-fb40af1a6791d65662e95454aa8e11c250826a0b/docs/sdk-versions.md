# Dottie SDK versions

Both `aomi-labs/sol-dottie-playground` and `aomi-labs/sol-dottie` now pin SDK `=7.0.0` and build Dottie v3. The staging backend advertises SDK 7.0.0 / FFI 1 and has the Solana tools from product-mono #1618 deployed.

The existing Telegram bot remains owned by **sol-dottie-playground**, Project 1672 / app 2937818 / @DottieSolBot. This repository's main-merge workflow deploys and activates that exact binding. The canonical sol-dottie repository still has its separate Project 1671; its frontend uses the existing bot's app ID. The SDK upgrade does not move the bot or wallets.

Both manifests use agent wallets, additional wallet creation, Solana only (`families = ["svm"]`), and Instant suggested at onboarding. Existing owner-selected lanes remain in effect. Pasted Solana mints call the existing read-only token check. No direct buy/sell commands are added.

## SDK 6 rollback

The last verified SDK 6 source commit is `38a90e8bd0f2a26e9e156d0fb215d8b45a5cfaf4` (also preserved as tag `dottie-sdk6-last-live`). Its release is `apps-141232970-rcb8c9a9bb0-dottie-38a90e8bd0f2` and deployment is `dep_141232970_rcb8c9a9bb0_38a90e8bd0f2`.

A rollback requires an explicit activation of that exact prior deployment; do not move repository ownership or swap application IDs. Recheck the target host's SDK/FFI compatibility before using the older release. A later merge to main redeploys SDK 7.

## Verification

Keep the root SDK pin, app workspace dependency and Cargo.lock in agreement. Verify the generated manifest's SDK 7 / FFI 1 metadata and strict tool schemas, then platform preflight, candidate build/release, activation, readiness on both hosts, and a completed HTTP chat. Wallet screens and receipts are separate evidence; do not claim a trade without a confirmed transaction.

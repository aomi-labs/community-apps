# API-wallet testnet verification — 2026-09-22

Machine-readable accepted venue responses and final account state:
[testnet-api-evidence.json](testnet-api-evidence.json).

## Implementation

The app reads optional user-owned `HYPERLIQUID_API_PRIVATE_KEY` (mainnet) or
`HYPERLIQUID_TESTNET_API_PRIVATE_KEY` (testnet) from the invocation context.
Each trading call checks `/info userRole` to confirm that the credential is an
agent approved for the connected master account. Keys are never accepted as tool
arguments, resolved from operator environment variables, cached across users, or
returned in tool results. The temporary runner injects the local test credential
into this same path; no credential is embedded in source or the plugin binary.
A repository scan confirmed that the supplied credential is absent from tracked
and untracked non-ignored source files; its external local file is mode 0600.

Trading calls with a key execute immediately. Without one they retain the
existing wallet-signature route. The exported submission continuation cannot
use a secret to sign arbitrary caller-supplied actions. Mainnet and testnet slots
are distinct. Transfers, withdrawals and account-mode changes retain their
master-wallet routes; bridge funding remains mainnet-only.

SDK 5.1.1 is pinned to immutable secrets-PR commit
`175ae55671d47e9554246c16200f2033497256e5` because it is not yet published.
Deployment requires the coordinated secrets release and matching host ABI.
This work did not deploy or change the existing secrets PRs.

## Account and execution

- Network: Hyperliquid testnet only (`https://api.hyperliquid-testnet.xyz`).
- Master: `0xda65d415cc9d5ddc2a08bdffc996750755fc3cf0`.
- Agent: `0xa6f3552622684a6f56ff93e3369a721c028c91d7`.
- Account mode: `unifiedAccount`; initial spot USDC: `3450.20741903`.
- Initial native orders/positions: empty. Initial BTC leverage: cross, 20.
- The app ran locally with injected user secrets and the real venue adapter.
  This verifies exchange acceptance and observed state, not the undeployed
  host's settings UI or browser transport.

## Live native-market evidence

The complete native suite passed **50 read checks** (25 before and 25 after
trading) and **40 accepted trading calls**, including two TWAP roundtrips in the
initial run. The runner now avoids that duplicate TWAP invocation.

| Area | Live result |
|---|---|
| All eight read tools | Markets, snapshot, orderbook, candles, funding, orders, portfolio and activity passed |
| Funding reads | Current, historical and predicted passed |
| Order reads | Open, history and exact status passed |
| Portfolio | All ten sections passed; unified collateral is taken from spot |
| Activity | Fills, funding payments, ledger, transfers and TWAP history passed |
| Limits and batching | GTC, post-only, IOC, two-order batch, single/batch modification and exact/scoped cancellation accepted |
| Market execution | IOC entry filled and reduce-only close filled |
| Triggers | Both TP and SL with market/limit execution rested; modifications and cancellation accepted. Trigger firing itself was not forced |
| Brackets/protection | Limit-entry bracket, market-entry bracket, TP/SL protection and cancel-before-replacement accepted |
| Ladders | Two-level ladder placed and scoped cancellation accepted |
| Partial close | Half-position and remaining-position closes filled |
| Risk | Isolated leverage 2, margin addition 1 USDC and removal 0.5 USDC accepted |
| TWAP | IDs 17986 and 17987 accepted, first slices filled, cancellations accepted, resulting positions closed |
| Cleanup | All three native cleanup snapshots had empty positions and open orders |

Representative order IDs: resting limit `60739382150`, market entry
`60739401247`, batch `60739426417` / `60739426418`, IOC entry `60739445173`,
partial close `60739517784`, market bracket `60739557225`.

## Bugs fixed during verification

1. Unified accounts could misleadingly show the empty per-DEX margin summary as
   account equity. Overview/margin reads now fetch the account mode and spot
   collateral, label the per-DEX summary, and leave uncomputed aggregate equity
   and withdrawal capacity unknown rather than zero.
2. Spot contexts were joined to metadata by array offset. Testnet's sparse
   metadata demonstrated a wrong-token price for HYPE. Contexts now join by
   `coin`; a reordered-context regression test covers it.
3. Unfiltered discovery queried every DEX even when displaying only a handful
   of markets. It now batches metadata and fetches context after filtering and
   limiting; bare-symbol resolution also avoids a full context scan.
4. HTTP errors and malformed response errors could echo venue response bodies.
   Signed-exchange transport errors now omit the body, with a local HTTP test.

## Checks and remaining boundaries

- Managed `test --package hyperliquid --all-targets`: **65 passed, 0 failed**;
  three network/paid-route tests remain explicitly ignored.
- Spot HYPE/USDC (`@1035`) and HIP-3 `xyz:XYZ100`: snapshots, order books and candles passed; post-only orders `60739846866` and `60739864142` placed and canceled.
- Final native and XYZ order/position snapshots are empty; original BTC cross leverage 20 restored and read back.
- Managed Clippy with `--all-targets --no-deps -- -D warnings`: passed. Formatting and diff checks passed.
- Batched unfiltered discovery passed against the live 266-DEX testnet catalog; the final 25-check read sweep also passed.
- The initial unfiltered catalog walk exceeded testnet's request limit across
  266 DEXs. Discovery now uses `allPerpMetas` and fetches context only for displayed
  DEXs; bare-symbol resolution uses that catalog before a fresh exact-market
  lookup. A regression test requires one batched catalog request and only the
  selected DEX context. Unscoped account aggregation still queries each DEX;
  prefer explicit DEX/market selection for large testnet catalogs.
- Transfers, deposits, withdrawals, bridge settlement, onward bridging and
  account-mode mutation were not signed with this agent key. Their deterministic
  tests pass; live master-wallet and mainnet funding execution remains a gate.
- Nonces are monotonic per network/signer in one process. Multiple write-capable
  replicas still require shared nonce coordination or serialized writes.

Protocol references: [API-wallet identity and nonces](https://hyperliquid.gitbook.io/hyperliquid-docs/for-developers/api/nonces-and-api-wallets),
[account abstraction modes](https://hyperliquid.gitbook.io/hyperliquid-docs/trading/account-abstraction-modes),
[asset IDs](https://hyperliquid.gitbook.io/hyperliquid-docs/for-developers/api/asset-ids).

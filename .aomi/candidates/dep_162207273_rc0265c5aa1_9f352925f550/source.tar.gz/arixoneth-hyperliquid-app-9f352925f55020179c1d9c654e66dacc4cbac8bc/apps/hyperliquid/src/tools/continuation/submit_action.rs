use std::str::FromStr;

use aomi_sdk::{DynAomiTool, DynToolCallCtx, ToolReturn};
use chrono::Utc;
use hypersdk::hypercore::types::{Action, ActionRequest, OrderResponseStatus};
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};

use crate::{
    client::HyperliquidApp,
    domain::signing::{
        OnAccept, PreparedHyperliquidAction, action_prehash, connected_signer, parse_signature,
        recover_signer,
    },
};

pub struct SubmitHyperliquidAction;

#[derive(Debug, Serialize, Deserialize, JsonSchema)]
pub struct SubmitHyperliquidActionArgs {
    #[schemars(skip)]
    pub prepared: PreparedHyperliquidAction,
    #[schemars(with = "Option<String>")]
    pub hyperliquid_signature: Option<Value>,
    #[serde(default)]
    #[schemars(skip)]
    pub followup: Option<OnAccept>,
}

impl DynAomiTool for SubmitHyperliquidAction {
    type App = HyperliquidApp;
    type Args = SubmitHyperliquidActionArgs;
    const NAME: &'static str = "submit_hyperliquid_action";
    const DESCRIPTION: &'static str =
        "Routed continuation that verifies and submits an exact wallet-signed Hyperliquid action.";

    fn run_with_routes(
        app: &HyperliquidApp,
        args: Self::Args,
        ctx: DynToolCallCtx,
    ) -> Result<ToolReturn, String> {
        let signer = connected_signer(&ctx)?;
        submit_signed_action(app, args, ctx, &signer)
    }
}

/// Internal entrypoint: the API-wallet path supplies a signer verified against
/// the connected master account. The exported continuation remains wallet-only.
pub(crate) fn submit_signed_action(
    app: &HyperliquidApp,
    args: SubmitHyperliquidActionArgs,
    ctx: DynToolCallCtx,
    authorized_signer: &str,
) -> Result<ToolReturn, String> {
    if args.prepared.version != 1 {
        return Err("unsupported prepared action version".into());
    }
    if args.prepared.network != app.network {
        return Err("prepared action network does not match this app".into());
    }
    let connected = connected_signer(&ctx)?;
    if connected != args.prepared.expected_signer {
        return Err("connected wallet changed after the action was prepared".into());
    }
    if args
        .prepared
        .expires_after
        .is_some_and(|expiry| Utc::now().timestamp_millis() as u64 >= expiry)
    {
        return Err("prepared Hyperliquid action expired; prepare it again".into());
    }
    let action: Action = serde_json::from_value(args.prepared.action.clone())
        .map_err(|e| format!("prepared action is invalid: {e}"))?;
    let vault = args
        .prepared
        .vault_address
        .as_deref()
        .map(alloy::primitives::Address::from_str)
        .transpose()
        .map_err(|_| "prepared vault address is invalid")?;
    let prehash = action_prehash(
        &action,
        &args.prepared.action,
        args.prepared.nonce,
        vault,
        args.prepared.expires_after,
        app.network,
    )?;
    if prehash.to_string() != args.prepared.prehash {
        return Err("prepared action was modified after wallet review".into());
    }
    let signature = parse_signature(
        args.hyperliquid_signature
            .ok_or("wallet signature is required")?,
    )?;
    let recovered = recover_signer(&signature, prehash)?;
    if recovered != authorized_signer {
        return Err("wallet signature does not authorize this prepared action".into());
    }
    let followup = validate_followup(args.followup, &args.prepared)?;
    let request = ActionRequest {
        action,
        nonce: args.prepared.nonce,
        signature,
        vault_address: vault,
        expires_after: args.prepared.expires_after,
    };
    let request = serde_json::to_value(request)
        .map_err(|e| format!("could not serialize signed action: {e}"))?;
    let result = match app.venue.exchange(request) {
        Ok(response) => {
            normalize_exchange_response(&args.prepared.action, response, &args.prepared.prehash)
        }
        Err(error) => {
            json!({"status":"submission_ambiguous","prehash":args.prepared.prehash,"message":error,"retry":false,"reconcile":"Check order status, open orders, fills, or account activity before preparing another action."})
        }
    };
    if result["status"] != "accepted" {
        return Ok(ToolReturn::value(result));
    }
    match followup {
        None => Ok(ToolReturn::value(result)),
        Some(OnAccept::ProtectionAfterCancel(value)) => {
            let followup = serde_json::from_value(value)
                .map_err(|e| format!("invalid protection continuation: {e}"))?;
            crate::tools::trading::prepare_order::prepare_protection_after_cancel(
                app, followup, ctx,
            )
        }
        Some(OnAccept::TwapCancels(value)) => {
            crate::tools::trading::cancel::continue_twap_cancels(app, value, ctx)
        }
        Some(OnAccept::CompleteFunding(mut value)) => {
            value["arbitrum_from_block"] = json!(
                app.funding
                    .block_number(crate::domain::funding::ARBITRUM_CHAIN_ID)?
            );
            crate::tools::continuation::complete_funding::complete_withdrawal(app, value, ctx)
        }
    }
}

fn normalize_exchange_response(action: &Value, response: Value, prehash: &str) -> Value {
    match response.get("status").and_then(Value::as_str) {
        Some("err") => {
            return json!({"status":"rejected","prehash":prehash,"error":response.get("response").cloned().unwrap_or(Value::Null)});
        }
        Some("ok") => {}
        _ => return malformed(response, prehash),
    }

    let kind = action
        .get("type")
        .and_then(Value::as_str)
        .unwrap_or_default();
    if kind == "modify" {
        return if response.pointer("/response/type").and_then(Value::as_str) == Some("default") {
            json!({"status":"accepted","prehash":prehash,"response":response})
        } else {
            malformed(response, prehash)
        };
    }
    if kind == "twapOrder" {
        if response.pointer("/response/type").and_then(Value::as_str) != Some("twapOrder") {
            return malformed(response, prehash);
        }
        let status = response.pointer("/response/data/status");
        return if status
            .and_then(|value| value.pointer("/running/twapId"))
            .and_then(Value::as_u64)
            .is_some()
        {
            json!({"status":"accepted","prehash":prehash,"response":response})
        } else if status
            .and_then(|value| value.get("error"))
            .and_then(Value::as_str)
            .is_some()
        {
            json!({"status":"rejected","prehash":prehash,"response":response})
        } else {
            malformed(response, prehash)
        };
    }
    if kind == "twapCancel" {
        if response.pointer("/response/type").and_then(Value::as_str) != Some("twapCancel") {
            return malformed(response, prehash);
        }
        return match response.pointer("/response/data/status") {
            Some(Value::String(status)) if status == "success" => {
                json!({"status":"accepted","prehash":prehash,"response":response})
            }
            Some(Value::Object(status))
                if status.get("error").and_then(Value::as_str).is_some() =>
            {
                json!({"status":"rejected","prehash":prehash,"response":response})
            }
            _ => malformed(response, prehash),
        };
    }
    let expected = match kind {
        "order" => action.get("orders").and_then(Value::as_array).map(Vec::len),
        "batchModify" => action
            .get("modifies")
            .and_then(Value::as_array)
            .map(Vec::len),
        "cancel" | "cancelByCloid" => action
            .get("cancels")
            .and_then(Value::as_array)
            .map(Vec::len),
        _ => None,
    };

    let Some(expected) = expected else {
        return if response.pointer("/response/type").and_then(Value::as_str) == Some("default") {
            json!({"status":"accepted","prehash":prehash,"response":response})
        } else {
            malformed(response, prehash)
        };
    };
    let expected_type = if matches!(kind, "cancel" | "cancelByCloid") {
        "cancel"
    } else {
        "order"
    };
    if response.pointer("/response/type").and_then(Value::as_str) != Some(expected_type) {
        return malformed(response, prehash);
    }
    let Some(statuses) = response
        .pointer("/response/data/statuses")
        .and_then(Value::as_array)
    else {
        return malformed(response, prehash);
    };
    if expected == 0 || statuses.len() != expected {
        return malformed(response, prehash);
    }
    let parsed = statuses
        .iter()
        .map(|status| serde_json::from_value::<OrderResponseStatus>(status.clone()))
        .collect::<Result<Vec<_>, _>>();
    let Ok(parsed) = parsed else {
        return malformed(response, prehash);
    };
    let rejected = parsed
        .iter()
        .filter(|status| matches!(status, OrderResponseStatus::Error(_)))
        .count();
    let status = match rejected {
        0 => "accepted",
        count if count == expected => "rejected",
        _ => "partially_rejected",
    };
    json!({"status":status,"prehash":prehash,"response":response})
}

fn malformed(response: Value, prehash: &str) -> Value {
    json!({"status":"malformed_response","prehash":prehash,"response":response})
}

fn validate_followup(
    followup: Option<OnAccept>,
    prepared: &PreparedHyperliquidAction,
) -> Result<Option<OnAccept>, String> {
    let Some(followup) = followup else {
        return Ok(None);
    };
    let kind = prepared
        .action
        .get("type")
        .and_then(Value::as_str)
        .unwrap_or_default();
    match followup {
        OnAccept::CompleteFunding(mut value) => {
            if kind != "withdraw3" {
                return Err("funding follow-up requires a signed withdraw3 action".into());
            }
            if value["account"].as_str() != Some(&prepared.expected_signer) {
                return Err("withdrawal follow-up account does not match signer".into());
            }
            if value["recipient"] != prepared.action["destination"]
                || value["amount"] != prepared.action["amount"]
            {
                return Err(
                    "withdrawal follow-up does not match signed recipient and amount".into(),
                );
            }
            value["started_at_ms"] =
                json!(prepared.action["time"].as_u64().unwrap_or(prepared.nonce));
            Ok(Some(OnAccept::CompleteFunding(value)))
        }
        OnAccept::ProtectionAfterCancel(value) => {
            if kind != "cancel" {
                return Err("protection continuation requires an accepted cancel action".into());
            }
            if value["account"].as_str() != Some(&prepared.expected_signer) {
                return Err("protection continuation account does not match signer".into());
            }
            let mut signed = prepared.action["cancels"]
                .as_array()
                .ok_or("cancel action omitted cancels")?
                .iter()
                .filter_map(|c| c["o"].as_u64())
                .collect::<Vec<_>>();
            let mut frozen = value["canceled_order_ids"]
                .as_array()
                .ok_or("protection continuation omitted canceled_order_ids")?
                .iter()
                .filter_map(Value::as_u64)
                .collect::<Vec<_>>();
            signed.sort_unstable();
            frozen.sort_unstable();
            if signed != frozen {
                return Err("protection continuation IDs do not match signed cancellations".into());
            }
            Ok(Some(OnAccept::ProtectionAfterCancel(value)))
        }
        OnAccept::TwapCancels(value) => {
            if !matches!(kind, "cancel" | "twapCancel") {
                return Err("TWAP continuation requires an accepted cancel action".into());
            }
            if value["account"].as_str() != Some(&prepared.expected_signer) {
                return Err("TWAP continuation account does not match signer".into());
            }
            if kind == "twapCancel" {
                let current = prepared.action["t"].as_u64();
                if value["pending"]
                    .as_array()
                    .is_some_and(|rows| rows.iter().any(|row| row["twap_id"].as_u64() == current))
                {
                    return Err("TWAP continuation repeats the signed cancellation".into());
                }
            }
            Ok(Some(OnAccept::TwapCancels(value)))
        }
    }
}

#[cfg(test)]
mod tests {
    use serde_json::json;

    use super::normalize_exchange_response;

    fn normalized(action: serde_json::Value, response: serde_json::Value) -> String {
        normalize_exchange_response(&action, response, "0xhash")["status"]
            .as_str()
            .unwrap()
            .to_owned()
    }

    #[test]
    fn status_actions_require_exact_nonempty_cardinality() {
        let action = json!({"type":"order","orders":[{},{}]});
        assert_eq!(
            normalized(
                action.clone(),
                json!({"status":"ok","response":{"type":"order","data":{"statuses":[]}}})
            ),
            "malformed_response"
        );
        assert_eq!(
            normalized(
                action.clone(),
                json!({"status":"ok","response":{"type":"order","data":{"statuses":["success"]}}})
            ),
            "malformed_response"
        );
        assert_eq!(
            normalized(
                action,
                json!({"status":"ok","response":{"type":"order","data":{}}})
            ),
            "malformed_response"
        );
    }

    #[test]
    fn status_actions_require_the_action_specific_response_type() {
        assert_eq!(
            normalized(
                json!({"type":"cancel","cancels":[{"a":0,"o":1}]}),
                json!({"status":"ok","response":{"type":"order","data":{"statuses":["success"]}}})
            ),
            "malformed_response"
        );
        assert_eq!(
            normalized(
                json!({"type":"batchModify","modifies":[{}]}),
                json!({"status":"ok","response":{"type":"cancel","data":{"statuses":["success"]}}})
            ),
            "malformed_response"
        );
    }

    #[test]
    fn status_actions_reject_unknown_status_shapes() {
        assert_eq!(
            normalized(
                json!({"type":"cancel","cancels":[{"a":0,"o":1}]}),
                json!({"status":"ok","response":{"type":"cancel","data":{"statuses":[{"mystery":true}]}}})
            ),
            "malformed_response"
        );
    }

    #[test]
    fn status_actions_distinguish_success_rejection_and_partial_rejection() {
        let action = json!({"type":"order","orders":[{},{}]});
        assert_eq!(
            normalized(
                action.clone(),
                json!({"status":"ok","response":{"type":"order","data":{"statuses":["success",{"resting":{"oid":7,"cloid":null}}]}}})
            ),
            "accepted"
        );
        assert_eq!(
            normalized(
                action.clone(),
                json!({"status":"ok","response":{"type":"order","data":{"statuses":[{"error":"bad one"},{"error":"bad two"}]}}})
            ),
            "rejected"
        );
        assert_eq!(
            normalized(
                action,
                json!({"status":"ok","response":{"type":"order","data":{"statuses":["waitingForTrigger",{"error":"bad two"}]}}})
            ),
            "partially_rejected"
        );
    }

    #[test]
    fn non_status_actions_only_accept_default_responses() {
        let action = json!({"type":"withdraw3"});
        assert_eq!(
            normalized(
                action.clone(),
                json!({"status":"ok","response":{"type":"default"}})
            ),
            "accepted"
        );
        assert_eq!(
            normalized(
                action,
                json!({"status":"ok","response":{"type":"unexpected"}})
            ),
            "malformed_response"
        );
    }

    #[test]
    fn single_modify_accepts_the_live_default_response_shape() {
        assert_eq!(
            normalized(
                json!({"type":"modify","oid":1,"order":{}}),
                json!({"status":"ok","response":{"type":"default"}})
            ),
            "accepted"
        );
        assert_eq!(
            normalized(
                json!({"type":"modify","oid":1,"order":{}}),
                json!({"status":"ok","response":{"type":"order","data":{"statuses":["success"]}}})
            ),
            "malformed_response"
        );
    }

    #[test]
    fn twap_responses_require_documented_success_or_error_shapes() {
        assert_eq!(
            normalized(
                json!({"type":"twapOrder","twap":{}}),
                json!({"status":"ok","response":{"type":"twapOrder","data":{"status":{"running":{"twapId":77}}}}})
            ),
            "accepted"
        );
        assert_eq!(
            normalized(
                json!({"type":"twapOrder","twap":{}}),
                json!({"status":"ok","response":{"type":"twapOrder","data":{"status":{"error":"invalid duration"}}}})
            ),
            "rejected"
        );
        assert_eq!(
            normalized(
                json!({"type":"twapCancel","a":0,"t":77}),
                json!({"status":"ok","response":{"type":"twapCancel","data":{"status":"success"}}})
            ),
            "accepted"
        );
        assert_eq!(
            normalized(
                json!({"type":"twapCancel","a":0,"t":77}),
                json!({"status":"ok","response":{"type":"twapCancel","data":{"status":{"error":"not active"}}}})
            ),
            "rejected"
        );
        assert_eq!(
            normalized(
                json!({"type":"twapCancel","a":0,"t":77}),
                json!({"status":"ok","response":{"type":"twapCancel","data":{"status":{}}}})
            ),
            "malformed_response"
        );
    }

    #[test]
    fn top_level_exchange_errors_are_rejected() {
        assert_eq!(
            normalized(
                json!({"type":"cancel","cancels":[{"a":0,"o":1}]}),
                json!({"status":"err","response":"invalid nonce"})
            ),
            "rejected"
        );
    }
}

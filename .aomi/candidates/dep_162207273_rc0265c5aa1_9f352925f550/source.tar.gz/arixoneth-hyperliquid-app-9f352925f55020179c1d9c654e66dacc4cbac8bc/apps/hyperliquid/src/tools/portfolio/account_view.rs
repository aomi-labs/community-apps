use crate::{
    client::HyperliquidApp,
    domain::{account::account, market::resolve},
};
use aomi_sdk::DynToolCallCtx;
use schemars::JsonSchema;
use serde::Deserialize;
use serde_json::{Value, json};
#[derive(Clone, Copy, Deserialize, JsonSchema, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum PortfolioSection {
    Overview,
    Balances,
    Positions,
    Margin,
    OpenOrders,
    AccountMode,
    Subaccounts,
    Vaults,
    Fees,
    RateLimits,
}
#[derive(Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct PortfolioArgs {
    pub address: Option<String>,
    pub sections: Option<Vec<PortfolioSection>>,
    pub dex: Option<String>,
    pub market: Option<String>,
}
pub fn run(
    app: &HyperliquidApp,
    args: PortfolioArgs,
    ctx: DynToolCallCtx,
) -> Result<Value, String> {
    let user = account(&ctx, args.address.as_deref())?;
    let sections = args.sections.unwrap_or_else(|| {
        vec![
            PortfolioSection::Overview,
            PortfolioSection::Balances,
            PortfolioSection::Positions,
            PortfolioSection::OpenOrders,
            PortfolioSection::AccountMode,
        ]
    });
    let market = args
        .market
        .as_deref()
        .map(|m| resolve(app, m))
        .transpose()?;
    if let (Some(dex), Some(m)) = (&args.dex, &market)
        && m.dex.as_deref().unwrap_or("") != dex
    {
        return Err("Market and DEX selectors disagree".into());
    }
    let selected_dex = args
        .dex
        .as_deref()
        .or_else(|| market.as_ref().map(|m| m.dex.as_deref().unwrap_or("")));
    let dex = selected_dex.unwrap_or("");
    let dexes = crate::domain::account::dexes(app, selected_dex)?;
    let mut output = json!({"account":user,"network":app.network,"dex":dex});
    if sections.iter().any(|s| {
        matches!(
            s,
            PortfolioSection::Overview | PortfolioSection::Positions | PortfolioSection::Margin
        )
    }) {
        let state = app
            .venue
            .info(json!({"type":"clearinghouseState","user":user,"dex":dex}))?;
        output["summary"] = json!({"equity":state["marginSummary"]["accountValue"],"margin_used":state["marginSummary"]["totalMarginUsed"],"withdrawable":state["withdrawable"],"margin":state["marginSummary"],"cross_margin":state["crossMarginSummary"]});
        let positions = state["assetPositions"]
            .as_array()
            .ok_or("Malformed account positions")?;
        output["positions"] = json!(
            positions
                .iter()
                .filter(|p| market
                    .as_ref()
                    .is_none_or(|m| p["position"]["coin"].as_str() == Some(&m.coin)))
                .collect::<Vec<_>>()
        );
    }
    if dexes.len() > 1
        && sections.iter().any(|s| {
            matches!(
                s,
                PortfolioSection::Overview | PortfolioSection::Positions | PortfolioSection::Margin
            )
        })
    {
        let mut accounts = Vec::new();
        for name in dexes.iter().filter(|d| !d.is_empty()) {
            let state = app
                .venue
                .info(json!({"type":"clearinghouseState","user":user,"dex":name}))?;
            accounts.push(json!({"dex":name,"summary":state["marginSummary"],"withdrawable":state["withdrawable"],"positions":state["assetPositions"]}));
        }
        output["dex_accounts"] = json!(accounts);
        output["summary_scope"] = json!(
            "summary describes the native perpetual account; dex_accounts reports each HIP-3 account separately, without summing different collateral units"
        );
    }
    for section in sections {
        let (field, endpoint) = match section {
            PortfolioSection::Balances => ("balances", "spotClearinghouseState"),
            PortfolioSection::OpenOrders => ("open_orders", "frontendOpenOrders"),
            PortfolioSection::AccountMode => ("account_mode", "userAbstraction"),
            PortfolioSection::Subaccounts => ("subaccounts", "subAccounts"),
            PortfolioSection::Vaults => ("vaults", "userVaultEquities"),
            PortfolioSection::Fees => ("fees", "userFees"),
            PortfolioSection::RateLimits => ("rate_limits", "userRateLimit"),
            _ => continue,
        };
        let mut request = json!({"type":endpoint,"user":user});
        if section == PortfolioSection::OpenOrders {
            request["dex"] = json!(dex);
        }
        let mut data = app.venue.info(request)?;
        if section == PortfolioSection::OpenOrders && selected_dex.is_none() {
            let rows = data.as_array_mut().ok_or("Malformed open orders")?;
            for name in dexes.iter().filter(|d| !d.is_empty()) {
                let additional = app
                    .venue
                    .info(json!({"type":"frontendOpenOrders","user":user,"dex":name}))?;
                rows.extend(
                    additional
                        .as_array()
                        .ok_or("Malformed DEX open orders")?
                        .iter()
                        .cloned(),
                );
            }
        }
        if section == PortfolioSection::OpenOrders
            && let Some(m) = &market
            && let Some(rows) = data.as_array_mut()
        {
            rows.retain(|r| r["coin"].as_str() == Some(&m.coin));
        }
        output[field] = data;
    }
    // Unified/portfolio modes keep collateral in spot. A zero per-DEX
    // clearinghouse summary must not be reported as an empty funded account.
    if output.get("summary").is_some() {
        if output.get("account_mode").is_none() {
            output["account_mode"] = app
                .venue
                .info(json!({"type":"userAbstraction","user":user}))?;
        }
        if matches!(
            output["account_mode"].as_str(),
            Some("unifiedAccount" | "portfolioMargin")
        ) {
            if output.get("balances").is_none() {
                output["balances"] = app
                    .venue
                    .info(json!({"type":"spotClearinghouseState","user":user}))?;
            }
            output["dex_summary"] = output["summary"].clone();
            output["summary"] = json!({"equity":null,"margin_used":null,"withdrawable":null});
            output["summary_scope"] = json!(
                "Unified collateral is in balances (spotClearinghouseState). dex_summary is venue per-DEX data, not account equity or available collateral. Cross-asset equity and withdrawal capacity are not computed here."
            );
        }
    }
    Ok(output)
}
read_tool!(
    Portfolio,
    PortfolioArgs,
    "hl_portfolio",
    "Inspect connected-wallet or public-account balances, positions, margin, open orders, mode, subaccounts, vaults, fees and rate limits. Select a HIP-3 DEX explicitly to inspect its margin account.",
    run
);

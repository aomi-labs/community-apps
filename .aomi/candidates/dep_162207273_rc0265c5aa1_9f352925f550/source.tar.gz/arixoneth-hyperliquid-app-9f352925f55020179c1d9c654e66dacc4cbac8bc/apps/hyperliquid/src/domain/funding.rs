//! LI.FI funding primitives for HyperCore.
//!
//! HyperCore perps is represented by LI.FI as synthetic chain `1337`.  It is
//! deliberately not treated as HyperEVM (`999`).  All values crossing this
//! boundary are integer base-unit strings; user-facing decimal conversion is
//! performed with `rust_decimal` and never through a float.

use rust_decimal::Decimal;
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use std::collections::HashMap;
use std::str::FromStr;
use std::time::Duration;

pub const HYPERCORE_CHAIN_ID: u64 = 1337;
pub const ARBITRUM_CHAIN_ID: u64 = 42161;
pub const HYPERCORE_PERP_USDC: &str = "0xaf88d065e77c8cC2239327C5EDb3A432268e5831";
pub const NATIVE_TOKEN: &str = "0x0000000000000000000000000000000000000000";
pub const HYPERLIQUID_ARBITRUM_BRIDGE: &str = "0x2df1c51e09aecf9cacb7bc98cb1742757f163df7";
const TRANSFER_TOPIC: &str = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef";

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct FundingRequest {
    pub from_chain: u64,
    pub from_token: String,
    pub from_decimals: u32,
    pub amount: Decimal,
    pub wallet: String,
    pub slippage_bps: u32,
}

impl FundingRequest {
    pub fn amount_base_units(&self) -> Result<String, String> {
        decimal_to_base_units(self.amount, self.from_decimals)
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, JsonSchema)]
pub struct FundingQuote {
    pub quote_id: String,
    pub route_tool: String,
    pub from_chain: u64,
    pub to_chain: u64,
    pub from_token: String,
    pub to_token: String,
    pub from_amount: String,
    pub to_amount: String,
    pub to_amount_min: String,
    pub from_address: String,
    pub to_address: String,
    pub approval_address: Option<String>,
    pub skip_approval: bool,
    pub transaction: EvmTransaction,
    #[schemars(skip)]
    pub fee_costs: Value,
    #[schemars(skip)]
    pub gas_costs: Value,
    pub execution_duration_seconds: Option<u64>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, JsonSchema)]
pub struct EvmTransaction {
    pub chain_id: u64,
    pub from: String,
    pub to: String,
    pub data: String,
    pub value: String,
    pub gas_limit: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, JsonSchema)]
pub struct FundingStatus {
    pub state: String,
    pub substatus: Option<String>,
    pub sending_tx_hash: Option<String>,
    pub receiving_tx_hash: Option<String>,
    pub from_chain: Option<u64>,
    pub to_chain: Option<u64>,
    pub to_address: Option<String>,
    pub to_token: Option<String>,
    pub received_amount: Option<String>,
}

pub trait FundingVenue: Send + Sync {
    fn token(&self, chain: &str, token: &str) -> Result<Value, String>;
    fn quote(&self, request: &FundingRequest) -> Result<Value, String>;
    fn quote_to(
        &self,
        request: &FundingRequest,
        to_chain: u64,
        to_token: &str,
    ) -> Result<Value, String>;
    fn status(
        &self,
        source_tx_hash: &str,
        route_tool: &str,
        from_chain: u64,
        to_chain: u64,
    ) -> Result<Value, String>;
    fn allowance(
        &self,
        chain_id: u64,
        token: &str,
        owner: &str,
        spender: &str,
    ) -> Result<String, String>;
    fn block_number(&self, chain_id: u64) -> Result<u64, String>;
    fn withdrawal_logs(&self, recipient: &str, from_block: u64) -> Result<Value, String>;
}

#[derive(Clone)]
pub struct LifiFundingVenue {
    http: reqwest::blocking::Client,
    base_url: String,
}

impl Default for LifiFundingVenue {
    fn default() -> Self {
        Self::new("https://li.quest")
    }
}

impl LifiFundingVenue {
    pub fn new(base_url: impl Into<String>) -> Self {
        let mut headers = reqwest::header::HeaderMap::new();
        if let Ok(api_key) = std::env::var("LIFI_API_KEY")
            && let Ok(mut value) = reqwest::header::HeaderValue::from_str(&api_key)
        {
            value.set_sensitive(true);
            headers.insert("x-lifi-api-key", value);
        }
        let http = reqwest::blocking::Client::builder()
            .timeout(Duration::from_secs(30))
            .default_headers(headers)
            .build()
            .expect("valid LI.FI HTTP client configuration");
        Self {
            http,
            base_url: base_url.into().trim_end_matches('/').to_owned(),
        }
    }

    fn rpc_url(chain_id: u64) -> Result<String, String> {
        let env_name = format!("HYPERLIQUID_RPC_{chain_id}");
        if let Ok(url) = std::env::var(&env_name) {
            return Ok(url);
        }
        match chain_id {
            1 => Ok("https://eth.llamarpc.com".into()),
            10 => Ok("https://optimism.llamarpc.com".into()),
            56 => Ok("https://binance.llamarpc.com".into()),
            137 => Ok("https://polygon.llamarpc.com".into()),
            8453 => Ok("https://base.llamarpc.com".into()),
            42161 => Ok("https://arbitrum.llamarpc.com".into()),
            _ => Err(format!(
                "no read-only RPC configured for source chain {chain_id}; set {env_name}"
            )),
        }
    }
}

impl FundingVenue for LifiFundingVenue {
    fn token(&self, chain: &str, token: &str) -> Result<Value, String> {
        let response = self
            .http
            .get(format!("{}/v1/token", self.base_url))
            .query(&[("chain", chain), ("token", token)])
            .send()
            .map_err(|error| format!("LI.FI token lookup failed: {error}"))?;
        parse_json_response(response, "LI.FI token lookup")
    }

    fn quote(&self, request: &FundingRequest) -> Result<Value, String> {
        self.quote_to(request, HYPERCORE_CHAIN_ID, HYPERCORE_PERP_USDC)
    }

    fn quote_to(
        &self,
        request: &FundingRequest,
        to_chain: u64,
        to_token: &str,
    ) -> Result<Value, String> {
        let amount = request.amount_base_units()?;
        let response = self
            .http
            .get(format!("{}/v1/quote", self.base_url))
            .query(&[
                ("fromChain", request.from_chain.to_string()),
                ("toChain", to_chain.to_string()),
                ("fromToken", request.from_token.clone()),
                ("toToken", to_token.to_string()),
                ("fromAmount", amount),
                ("fromAddress", request.wallet.clone()),
                ("toAddress", request.wallet.clone()),
                ("slippage", slippage_decimal(request.slippage_bps)),
            ])
            .send()
            .map_err(|error| format!("LI.FI quote request failed: {error}"))?;
        parse_json_response(response, "LI.FI quote")
    }

    fn status(
        &self,
        source_tx_hash: &str,
        route_tool: &str,
        from_chain: u64,
        to_chain: u64,
    ) -> Result<Value, String> {
        let response = self
            .http
            .get(format!("{}/v1/status", self.base_url))
            .query(&[
                ("txHash", source_tx_hash.to_owned()),
                ("bridge", route_tool.to_owned()),
                ("fromChain", from_chain.to_string()),
                ("toChain", to_chain.to_string()),
            ])
            .send()
            .map_err(|error| format!("LI.FI status request failed: {error}"))?;
        parse_json_response(response, "LI.FI status")
    }

    fn allowance(
        &self,
        chain_id: u64,
        token: &str,
        owner: &str,
        spender: &str,
    ) -> Result<String, String> {
        require_address(token, "token")?;
        require_address(owner, "owner")?;
        require_address(spender, "spender")?;
        let owner_word = &owner.trim_start_matches("0x").to_ascii_lowercase();
        let spender_word = &spender.trim_start_matches("0x").to_ascii_lowercase();
        let calldata = format!("0xdd62ed3e{owner_word:0>64}{spender_word:0>64}");
        let response = self
            .http
            .post(Self::rpc_url(chain_id)?)
            .json(&json!({
                "jsonrpc": "2.0",
                "id": 1,
                "method": "eth_call",
                "params": [{"to": token, "data": calldata}, "latest"]
            }))
            .send()
            .map_err(|error| format!("allowance RPC request failed: {error}"))?;
        let body = parse_json_response(response, "allowance RPC")?;
        if let Some(error) = body.get("error") {
            return Err(format!("allowance RPC returned an error: {error}"));
        }
        let result = required_str(&body, &["result"], "allowance result")?;
        let hex = result.strip_prefix("0x").unwrap_or(result);
        let trimmed = hex.trim_start_matches('0');
        Ok(if trimmed.is_empty() {
            "0".into()
        } else {
            hex_to_decimal(trimmed)?
        })
    }

    fn block_number(&self, chain_id: u64) -> Result<u64, String> {
        let response = self
            .http
            .post(Self::rpc_url(chain_id)?)
            .json(&json!({
                "jsonrpc":"2.0","id":1,"method":"eth_blockNumber","params":[]
            }))
            .send()
            .map_err(|error| format!("block-number RPC request failed: {error}"))?;
        let body = parse_json_response(response, "block-number RPC")?;
        let value = required_str(&body, &["result"], "block number")?.trim_start_matches("0x");
        u64::from_str_radix(value, 16).map_err(|_| "invalid block number from RPC".into())
    }

    fn withdrawal_logs(&self, recipient: &str, from_block: u64) -> Result<Value, String> {
        require_address(recipient, "withdrawal recipient")?;
        let bridge_topic = format!(
            "0x{:0>64}",
            HYPERLIQUID_ARBITRUM_BRIDGE.trim_start_matches("0x")
        );
        let recipient_topic = format!(
            "0x{:0>64}",
            recipient.trim_start_matches("0x").to_ascii_lowercase()
        );
        let response=self.http.post(Self::rpc_url(ARBITRUM_CHAIN_ID)?).json(&json!({
            "jsonrpc":"2.0","id":1,"method":"eth_getLogs","params":[{
                "address":HYPERCORE_PERP_USDC,"fromBlock":format!("0x{from_block:x}"),"toBlock":"latest",
                "topics":[TRANSFER_TOPIC,bridge_topic,recipient_topic]
            }]
        })).send().map_err(|error|format!("withdrawal-log RPC request failed: {error}"))?;
        let body = parse_json_response(response, "withdrawal-log RPC")?;
        if let Some(error) = body.get("error") {
            return Err(format!("withdrawal-log RPC returned an error: {error}"));
        }
        let mut logs = body
            .get("result")
            .and_then(Value::as_array)
            .cloned()
            .ok_or("withdrawal-log RPC omitted its result array")?;
        let mut timestamps = HashMap::new();
        for log in &mut logs {
            let block = required_str(log, &["blockNumber"], "withdrawal log blockNumber")?;
            let timestamp_ms = if let Some(timestamp) = timestamps.get(block) {
                *timestamp
            } else {
                let response = self
                    .http
                    .post(Self::rpc_url(ARBITRUM_CHAIN_ID)?)
                    .json(&json!({
                        "jsonrpc":"2.0","id":1,"method":"eth_getBlockByNumber","params":[block,false]
                    }))
                    .send()
                    .map_err(|error| format!("withdrawal-block RPC request failed: {error}"))?;
                let body = parse_json_response(response, "withdrawal-block RPC")?;
                if let Some(error) = body.get("error") {
                    return Err(format!("withdrawal-block RPC returned an error: {error}"));
                }
                let timestamp = required_str(
                    body.get("result")
                        .ok_or("withdrawal-block RPC omitted result")?,
                    &["timestamp"],
                    "withdrawal block timestamp",
                )?;
                let timestamp_ms = u64::from_str_radix(timestamp.trim_start_matches("0x"), 16)
                    .map_err(|_| "invalid withdrawal block timestamp")?
                    .checked_mul(1_000)
                    .ok_or("withdrawal block timestamp overflow")?;
                timestamps.insert(block.to_owned(), timestamp_ms);
                timestamp_ms
            };
            log.as_object_mut()
                .ok_or("withdrawal log is not an object")?
                .insert("blockTimestampMs".into(), json!(timestamp_ms));
        }
        Ok(Value::Array(logs))
    }
}

pub fn settled_withdrawal(
    logs: &Value,
    expected_amount_base: &str,
    started_at_ms: u64,
) -> Result<Option<Value>, String> {
    let amount = parse_uint(expected_amount_base)?;
    let after_fee = amount
        .checked_sub(1_000_000)
        .ok_or("withdrawal amount must exceed the 1 USDC fee")?;
    let entries = logs
        .as_array()
        .ok_or("Arbitrum withdrawal logs are not an array")?;
    // EVM blocks have one-second timestamps; HyperCore ledger entries use
    // milliseconds. Compare at the shared precision so the same second passes.
    let not_before_second_ms = started_at_ms / 1_000 * 1_000;
    let matches =
        entries
            .iter()
            .filter(|entry| {
                entry.get("removed").and_then(Value::as_bool) != Some(true)
                    && entry
                        .get("blockTimestampMs")
                        .and_then(Value::as_u64)
                        .is_some_and(|timestamp| timestamp >= not_before_second_ms)
                    && entry.get("data").and_then(Value::as_str).and_then(|data| {
                        u128::from_str_radix(data.trim_start_matches("0x"), 16).ok()
                    }) == Some(after_fee)
            })
            .cloned()
            .collect::<Vec<_>>();
    match matches.as_slice(){[]=>Ok(None),[entry]=>Ok(Some(entry.clone())),_=>Err("multiple indistinguishable Arbitrum withdrawal transfers matched; settlement is ambiguous".into())}
}

pub fn resolved_token(raw: &Value, expected_chain: u64) -> Result<(String, u32, String), String> {
    if raw.get("chainId").and_then(Value::as_u64) != Some(expected_chain) {
        return Err("LI.FI token lookup returned a different chain".into());
    }
    let address = required_str(raw, &["address"], "token address")?;
    require_address(address, "token address")?;
    let decimals = raw
        .get("decimals")
        .and_then(Value::as_u64)
        .ok_or("LI.FI token lookup omitted decimals")?;
    if decimals > 28 {
        return Err("token decimals above 28 are not supported".into());
    }
    let symbol = required_str(raw, &["symbol"], "token symbol")?;
    Ok((
        address.to_ascii_lowercase(),
        decimals as u32,
        symbol.to_owned(),
    ))
}

pub fn validate_quote(raw: &Value, request: &FundingRequest) -> Result<FundingQuote, String> {
    validate_quote_to(raw, request, HYPERCORE_CHAIN_ID, HYPERCORE_PERP_USDC)
}

pub fn validate_quote_to(
    raw: &Value,
    request: &FundingRequest,
    to_chain: u64,
    to_token: &str,
) -> Result<FundingQuote, String> {
    let expected_amount = request.amount_base_units()?;
    let action = raw.get("action").ok_or("LI.FI quote is missing action")?;
    let estimate = raw
        .get("estimate")
        .ok_or("LI.FI quote is missing estimate")?;
    let tx = raw
        .get("transactionRequest")
        .ok_or("LI.FI quote is missing transactionRequest")?;

    exact_u64(action, "fromChainId", request.from_chain)?;
    exact_u64(action, "toChainId", to_chain)?;
    exact_ci(action, "fromAddress", &request.wallet)?;
    exact_ci(action, "toAddress", &request.wallet)?;
    exact_ci_path(action, &["fromToken", "address"], &request.from_token)?;
    exact_ci_path(action, &["toToken", "address"], to_token)?;
    exact_string(action, "fromAmount", &expected_amount)?;

    let from = required_str(tx, &["from"], "transactionRequest.from")?;
    if !from.eq_ignore_ascii_case(&request.wallet) {
        return Err("LI.FI transaction sender differs from the connected wallet".into());
    }
    exact_u64(tx, "chainId", request.from_chain)?;
    let to = required_str(tx, &["to"], "transactionRequest.to")?;
    require_address(to, "transactionRequest.to")?;
    let data = required_str(tx, &["data"], "transactionRequest.data")?;
    if !data.starts_with("0x") || data.len() < 10 {
        return Err("LI.FI transaction calldata is empty or malformed".into());
    }

    let from_amount = required_str(estimate, &["fromAmount"], "estimate.fromAmount")?;
    if from_amount != expected_amount {
        return Err("LI.FI estimate amount differs from the requested amount".into());
    }
    let to_amount = integer_string(estimate, "toAmount")?;
    let to_amount_min = integer_string(estimate, "toAmountMin")?;
    let quote_id = required_str(raw, &["id"], "quote id")?;
    let route_tool = required_str(raw, &["tool"], "quote tool")?;
    let approval_address = estimate
        .get("approvalAddress")
        .and_then(Value::as_str)
        .filter(|address| !address.is_empty())
        .map(str::to_owned);
    if let Some(address) = &approval_address {
        require_address(address, "estimate.approvalAddress")?;
    }
    let skip_approval = estimate
        .get("skipApproval")
        .and_then(Value::as_bool)
        .unwrap_or(false);

    Ok(FundingQuote {
        quote_id: quote_id.into(),
        route_tool: route_tool.into(),
        from_chain: request.from_chain,
        to_chain,
        from_token: request.from_token.to_ascii_lowercase(),
        to_token: to_token.to_ascii_lowercase(),
        from_amount: expected_amount,
        to_amount,
        to_amount_min,
        from_address: request.wallet.to_ascii_lowercase(),
        to_address: request.wallet.to_ascii_lowercase(),
        approval_address,
        skip_approval,
        transaction: EvmTransaction {
            chain_id: request.from_chain,
            from: from.into(),
            to: to.into(),
            data: data.into(),
            value: tx
                .get("value")
                .and_then(Value::as_str)
                .unwrap_or("0")
                .into(),
            gas_limit: tx
                .get("gasLimit")
                .or_else(|| tx.get("gas"))
                .and_then(Value::as_str)
                .map(str::to_owned),
        },
        fee_costs: estimate
            .get("feeCosts")
            .cloned()
            .unwrap_or_else(|| json!([])),
        gas_costs: estimate
            .get("gasCosts")
            .cloned()
            .unwrap_or_else(|| json!([])),
        execution_duration_seconds: estimate.get("executionDuration").and_then(Value::as_u64),
    })
}

pub fn needs_approval(quote: &FundingQuote, allowance: &str) -> Result<bool, String> {
    if quote.skip_approval || quote.from_token.eq_ignore_ascii_case(NATIVE_TOKEN) {
        return Ok(false);
    }
    if quote.approval_address.is_none() {
        return Err("ERC-20 LI.FI quote omitted estimate.approvalAddress".into());
    }
    Ok(parse_uint(allowance)? < parse_uint(&quote.from_amount)?)
}

pub fn approval_transaction(quote: &FundingQuote) -> Result<EvmTransaction, String> {
    let spender = quote
        .approval_address
        .as_deref()
        .ok_or("cannot build approval without an approvalAddress")?;
    let spender_word = spender.trim_start_matches("0x");
    let amount_word = decimal_to_hex_word(&quote.from_amount)?;
    Ok(EvmTransaction {
        chain_id: quote.from_chain,
        from: quote.from_address.clone(),
        to: quote.from_token.clone(),
        data: format!("0x095ea7b3{spender_word:0>64}{amount_word}"),
        value: "0".into(),
        gas_limit: None,
    })
}

pub fn parse_status(
    raw: &Value,
    expected_source_hash: &str,
    expected: &FundingQuote,
) -> Result<FundingStatus, String> {
    let state = required_str(raw, &["status"], "status")?.to_ascii_uppercase();
    if !matches!(
        state.as_str(),
        "NOT_FOUND" | "PENDING" | "DONE" | "FAILED" | "INVALID"
    ) {
        return Err(format!("unknown LI.FI status {state}"));
    }
    let transaction_id = raw.get("transactionId").and_then(Value::as_str);
    let sending_hash = raw.pointer("/sending/txHash").and_then(Value::as_str);
    if transaction_id
        .into_iter()
        .chain(sending_hash)
        .any(|hash| !hash.eq_ignore_ascii_case(expected_source_hash))
    {
        return Err("LI.FI status response belongs to a different source transaction".into());
    }
    if let Some(chain) = raw.pointer("/sending/chainId").and_then(Value::as_u64)
        && chain != expected.from_chain
    {
        return Err("LI.FI status source chain does not match the quote".into());
    }
    if let Some(chain) = raw.pointer("/receiving/chainId").and_then(Value::as_u64)
        && chain != expected.to_chain
    {
        return Err("LI.FI status destination chain does not match HyperCore".into());
    }
    if let Some(address) = raw.get("toAddress").and_then(Value::as_str)
        && !address.eq_ignore_ascii_case(&expected.to_address)
    {
        return Err("LI.FI status recipient does not match the connected wallet".into());
    }
    if let Some(token) = raw
        .pointer("/receiving/token/address")
        .and_then(Value::as_str)
        && !token.eq_ignore_ascii_case(&expected.to_token)
    {
        return Err("LI.FI status destination token does not match perps USDC".into());
    }
    Ok(FundingStatus {
        state,
        substatus: raw
            .get("substatus")
            .and_then(Value::as_str)
            .map(str::to_owned),
        sending_tx_hash: sending_hash.map(str::to_owned),
        receiving_tx_hash: raw
            .pointer("/receiving/txHash")
            .and_then(Value::as_str)
            .map(str::to_owned),
        from_chain: raw.pointer("/sending/chainId").and_then(Value::as_u64),
        to_chain: raw.pointer("/receiving/chainId").and_then(Value::as_u64),
        to_address: raw
            .get("toAddress")
            .and_then(Value::as_str)
            .map(str::to_owned),
        to_token: raw
            .pointer("/receiving/token/address")
            .and_then(Value::as_str)
            .map(str::to_owned),
        received_amount: raw
            .pointer("/receiving/amount")
            .and_then(Value::as_str)
            .map(str::to_owned),
    })
}

pub fn credited_deposit(
    ledger: &Value,
    started_at_ms: u64,
    minimum_amount: &str,
    expected_receiving_hash: &str,
) -> Result<Option<Value>, String> {
    let minimum = base_units_to_decimal(minimum_amount, 6)?;
    let entries = ledger
        .as_array()
        .ok_or("Hyperliquid ledger response is not an array")?;
    for entry in entries {
        if entry.get("time").and_then(Value::as_u64).unwrap_or(0) < started_at_ms {
            continue;
        }
        if !entry
            .get("hash")
            .and_then(Value::as_str)
            .is_some_and(|hash| hash.eq_ignore_ascii_case(expected_receiving_hash))
        {
            continue;
        }
        let delta = match entry.get("delta") {
            Some(delta) => delta,
            None => continue,
        };
        if delta.get("type").and_then(Value::as_str) != Some("deposit") {
            continue;
        }
        let Some(usdc) = delta.get("usdc").and_then(Value::as_str) else {
            continue;
        };
        let amount = Decimal::from_str(usdc)
            .map_err(|error| format!("invalid Hyperliquid deposit amount: {error}"))?;
        if amount >= minimum {
            return Ok(Some(entry.clone()));
        }
    }
    Ok(None)
}

pub fn decimal_to_base_units(amount: Decimal, decimals: u32) -> Result<String, String> {
    if amount <= Decimal::ZERO {
        return Err("amount must be greater than zero".into());
    }
    if decimals > 28 {
        return Err("token decimals above 28 are not supported".into());
    }
    let factor = Decimal::from_i128_with_scale(10_i128.pow(decimals), 0);
    let scaled = amount.checked_mul(factor).ok_or("amount is too large")?;
    if !scaled.fract().is_zero() {
        return Err(format!("amount has more than {decimals} decimal places"));
    }
    Ok(scaled.trunc().to_string())
}

pub fn base_units_to_decimal(amount: &str, decimals: u32) -> Result<Decimal, String> {
    if decimals > 28 {
        return Err("token decimals above 28 are not supported".into());
    }
    let integer = Decimal::from_str(amount).map_err(|_| "invalid base-unit amount")?;
    Ok(integer / Decimal::from_i128_with_scale(10_i128.pow(decimals), 0))
}

fn parse_json_response(
    response: reqwest::blocking::Response,
    label: &str,
) -> Result<Value, String> {
    let status = response.status();
    let body: Value = response
        .json()
        .map_err(|error| format!("{label} returned invalid JSON: {error}"))?;
    if !status.is_success() {
        return Err(format!("{label} returned HTTP {status}: {body}"));
    }
    Ok(body)
}

fn slippage_decimal(bps: u32) -> String {
    Decimal::new(i64::from(bps), 4).normalize().to_string()
}

fn require_address(value: &str, label: &str) -> Result<(), String> {
    if value.len() != 42
        || !value.starts_with("0x")
        || !value[2..].bytes().all(|byte| byte.is_ascii_hexdigit())
    {
        return Err(format!("{label} is not a valid EVM address"));
    }
    Ok(())
}

fn required_str<'a>(value: &'a Value, path: &[&str], label: &str) -> Result<&'a str, String> {
    let mut current = value;
    for key in path {
        current = current
            .get(*key)
            .ok_or_else(|| format!("missing {label}"))?;
    }
    current
        .as_str()
        .ok_or_else(|| format!("{label} is not a string"))
}

fn exact_u64(value: &Value, key: &str, expected: u64) -> Result<(), String> {
    if value.get(key).and_then(Value::as_u64) != Some(expected) {
        return Err(format!("LI.FI quote {key} does not match the request"));
    }
    Ok(())
}

fn exact_ci(value: &Value, key: &str, expected: &str) -> Result<(), String> {
    let actual = required_str(value, &[key], key)?;
    if !actual.eq_ignore_ascii_case(expected) {
        return Err(format!("LI.FI quote {key} does not match the request"));
    }
    Ok(())
}

fn exact_ci_path(value: &Value, path: &[&str], expected: &str) -> Result<(), String> {
    let actual = required_str(value, path, &path.join("."))?;
    if !actual.eq_ignore_ascii_case(expected) {
        return Err(format!(
            "LI.FI quote {} does not match the request",
            path.join(".")
        ));
    }
    Ok(())
}

fn exact_string(value: &Value, key: &str, expected: &str) -> Result<(), String> {
    if required_str(value, &[key], key)? != expected {
        return Err(format!("LI.FI quote {key} does not match the request"));
    }
    Ok(())
}

fn integer_string(value: &Value, key: &str) -> Result<String, String> {
    let raw = required_str(value, &[key], key)?;
    parse_uint(raw)?;
    Ok(raw.into())
}

fn parse_uint(value: &str) -> Result<u128, String> {
    value
        .parse::<u128>()
        .map_err(|_| format!("invalid unsigned integer: {value}"))
}

fn decimal_to_hex_word(value: &str) -> Result<String, String> {
    Ok(format!("{:064x}", parse_uint(value)?))
}

fn hex_to_decimal(value: &str) -> Result<String, String> {
    u128::from_str_radix(value, 16)
        .map(|number| number.to_string())
        .map_err(|_| "allowance exceeds supported uint128 range".into())
}

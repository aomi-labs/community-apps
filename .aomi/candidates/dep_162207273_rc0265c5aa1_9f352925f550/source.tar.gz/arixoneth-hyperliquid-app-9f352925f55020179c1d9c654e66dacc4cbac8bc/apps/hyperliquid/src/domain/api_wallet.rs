use alloy::signers::local::PrivateKeySigner;
use aomi_sdk::{DynToolCallCtx, Secret, resolve_user_secret_value};
use serde_json::json;

use crate::{
    client::HyperliquidApp,
    domain::{account, market::Network},
};

pub const MAINNET_KEY: Secret = Secret::new(
    "HYPERLIQUID_API_PRIVATE_KEY",
    "Approved Hyperliquid mainnet API-wallet private key for your connected account; never the master wallet key.",
    false,
).user_owned();
pub const TESTNET_KEY: Secret = Secret::new(
    "HYPERLIQUID_TESTNET_API_PRIVATE_KEY",
    "Approved Hyperliquid testnet API-wallet private key for your connected account; never the master wallet key.",
    false,
).user_owned();

pub fn key_name(network: Network) -> &'static str {
    match network {
        Network::Mainnet => MAINNET_KEY.name,
        Network::Testnet => TESTNET_KEY.name,
    }
}

/// Credentials are resolved afresh from this invocation's user-owned context.
/// There is deliberately no process-wide key, environment or file fallback.
pub(crate) fn signer(
    app: &HyperliquidApp,
    ctx: &DynToolCallCtx,
    action: &str,
) -> Result<Option<PrivateKeySigner>, String> {
    if !matches!(
        action,
        "order"
            | "cancel"
            | "cancelByCloid"
            | "modify"
            | "batchModify"
            | "twapOrder"
            | "twapCancel"
            | "updateLeverage"
            | "updateIsolatedMargin"
    ) {
        return Ok(None);
    }
    let slot = key_name(app.network);
    if !ctx.secrets.contains_key(slot) {
        return Ok(None);
    }
    let raw = resolve_user_secret_value(ctx, slot, "Hyperliquid API-wallet key is empty")?;
    let signer: PrivateKeySigner = raw
        .trim()
        .parse()
        .map_err(|_| "Invalid Hyperliquid API-wallet key")?;
    let owner = account::wallet(ctx)?;
    let address = signer.address().to_string().to_lowercase();
    let role = app.venue.info(json!({"type":"userRole", "user":address}))?;
    if role["role"] != "agent" {
        return Err("Use an approved API-wallet key, not a master-wallet key".into());
    }
    let approved_owner = role
        .pointer("/data/user")
        .and_then(|value| value.as_str())
        .ok_or("Hyperliquid did not identify the API wallet's owner")?;
    if account::address(approved_owner)? != owner {
        return Err("Hyperliquid API wallet is not approved for the connected account".into());
    }
    Ok(Some(signer))
}

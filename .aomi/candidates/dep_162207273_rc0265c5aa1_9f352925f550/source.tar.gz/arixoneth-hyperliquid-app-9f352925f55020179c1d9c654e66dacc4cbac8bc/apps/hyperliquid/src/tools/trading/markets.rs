use crate::{
    client::HyperliquidApp,
    domain::market::{self, MarketType},
};
use aomi_sdk::DynToolCallCtx;
use schemars::JsonSchema;
use serde::Deserialize;
use serde_json::{Value, json};
#[derive(Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct MarketsArgs {
    pub query: Option<String>,
    pub market_type: Option<MarketType>,
    pub dex: Option<String>,
    pub include_context: Option<bool>,
    pub include_inactive: Option<bool>,
    pub limit: Option<u16>,
}
pub fn run(app: &HyperliquidApp, args: MarketsArgs, _ctx: DynToolCallCtx) -> Result<Value, String> {
    let limit = args.limit.unwrap_or(30);
    if !(1..=200).contains(&limit) {
        return Err("limit must be 1–200".into());
    }
    let items = market::discovery_catalog(app, args.dex.as_deref(), args.market_type)?
        .into_iter()
        .filter(|m| {
            (args.include_inactive.unwrap_or(false) || m.active)
                && args.market_type.is_none_or(|t| m.market_type == t)
                && args.query.as_ref().is_none_or(|q| {
                    m.symbol.to_lowercase().contains(&q.to_lowercase())
                        || m.market_ref.to_lowercase().contains(&q.to_lowercase())
                })
        })
        .map(|mut m| {
            if !args.include_context.unwrap_or(true) {
                m.context = Value::Null;
            }
            m
        })
        .collect::<Vec<_>>();
    let total = items.len();
    let mut displayed = items.into_iter().take(limit as usize).collect::<Vec<_>>();
    if args.include_context.unwrap_or(true) {
        market::hydrate_contexts(app, &mut displayed)?;
    }
    Ok(json!({"network":app.network,"total":total,"markets":displayed}))
}
read_tool!(
    Markets,
    MarketsArgs,
    "hl_markets",
    "Discover spot, native perpetual and DEX-qualified HIP-3 markets. Returns canonical market references, collateral, precision and fresh market context. Use exact market_ref for writes.",
    run
);

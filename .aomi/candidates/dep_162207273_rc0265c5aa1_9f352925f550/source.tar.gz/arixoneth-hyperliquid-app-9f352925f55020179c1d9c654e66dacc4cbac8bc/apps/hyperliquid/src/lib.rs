use aomi_sdk::*;
pub mod client;
pub mod domain;
pub mod tools;

dyn_aomi_app!(
    app = client::HyperliquidApp, name = "hyperliquid", version = "0.3.0",
    preamble = include_str!("preamble.md"),
    tools = [tools::continuation::SubmitHyperliquidAction, tools::continuation::CompleteHyperliquidFunding],
    secrets = [domain::api_wallet::MAINNET_KEY, domain::api_wallet::TESTNET_KEY],
    namespaces = ["evm-core"],
    skills = [
        { id: "hyperliquid/portfolio", description: "Inspect and manage accounts, balances, positions, funding and transfers", tags: ["portfolio", "balance", "position", "margin", "deposit", "withdraw", "transfer", "history"], tools: [tools::portfolio::Portfolio, tools::portfolio::AccountActivity, tools::portfolio::PrepareDeposit, tools::portfolio::PrepareWithdraw, tools::portfolio::PrepareTransfer], sections: { instructions: "skills/portfolio/instructions.md", workflows: "skills/portfolio/workflows.md", safety: "skills/portfolio/safety.md" }, },
        { id: "hyperliquid/trading", description: "Research and trade spot, native perpetuals, HIP-3, stock, index and commodity markets; use for orders, strategies and risk controls", tags: ["trade", "buy", "sell", "long", "short", "order", "perp", "spot", "market", "orderbook", "candles", "funding", "twap", "hip3", "hip-3", "dex", "rwa", "stock", "index", "commodity", "spx", "risk", "leverage", "margin", "liquidation", "tp", "sl", "stop", "bracket", "ladder"], tools: [tools::trading::Markets, tools::trading::MarketSnapshot, tools::trading::OrderBook, tools::trading::Candles, tools::trading::Funding, tools::trading::Orders, tools::trading::PrepareOrder, tools::trading::PrepareCancel, tools::trading::PrepareModify, tools::trading::PrepareClose, tools::trading::PrepareTwap, tools::trading::PrepareRisk], sections: { instructions: "skills/trading/instructions.md", execution: "skills/trading/execution.md", hip3: "skills/hip3.md", rwa: "skills/rwa.md", strategies: "skills/order-strategies.md", risk: "skills/risk.md", safety: "skills/trading/safety.md" }, },
    ],
);

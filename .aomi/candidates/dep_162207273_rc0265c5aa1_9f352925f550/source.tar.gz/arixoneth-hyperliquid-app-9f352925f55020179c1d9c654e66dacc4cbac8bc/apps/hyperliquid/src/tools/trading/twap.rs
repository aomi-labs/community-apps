use crate::{
    client::HyperliquidApp,
    domain::{
        account::wallet,
        market::resolve,
        order::{Side, SizeSpec, round_size, wire_decimal},
    },
    tools::trading::prepare_order::{mid_for, mids},
};
use aomi_sdk::{DynAomiTool, DynToolCallCtx, ToolReturn, schemars::JsonSchema};
use serde::Deserialize;
use serde_json::json;
pub struct PrepareTwap;
#[derive(Debug, Deserialize, JsonSchema)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum TwapIntent {
    Place {
        market: String,
        side: Side,
        size: SizeSpec,
        duration_minutes: u32,
        randomize: bool,
        #[serde(default)]
        reduce_only: bool,
    },
    Cancel {
        market: String,
        twap_id: u64,
    },
}
#[derive(Debug, Deserialize, JsonSchema)]
pub struct PrepareTwapArgs {
    pub intent: TwapIntent,
}
impl DynAomiTool for PrepareTwap {
    type App = HyperliquidApp;
    type Args = PrepareTwapArgs;
    const NAME: &'static str = "hl_prepare_twap";
    const DESCRIPTION: &'static str = "Prepare or cancel a native venue-managed Hyperliquid TWAP. With an approved API-wallet key, supported trading actions execute immediately; call only for explicit user intent, never for a dry run.";
    fn run_with_routes(
        app: &Self::App,
        args: Self::Args,
        ctx: DynToolCallCtx,
    ) -> Result<ToolReturn, String> {
        let account = wallet(&ctx)?;
        let (action, preview) = match args.intent {
            TwapIntent::Place {
                market,
                side,
                size,
                duration_minutes,
                randomize,
                reduce_only,
            } => {
                if !(5..=1440).contains(&duration_minutes) {
                    return Err("duration_minutes must be between 5 and 1440".into());
                }
                let m = resolve(app, &market)?;
                let all = mids(
                    app.venue
                        .info(json!({"type":"allMids","dex":m.dex.as_deref().unwrap_or("")}))?,
                )?;
                let reference = mid_for(&all, &m)?;
                let size = round_size(size.base_at(reference)?, &m)?;
                if !reduce_only {
                    let notional = size
                        .checked_mul(reference)
                        .ok_or("TWAP notional overflowed decimal range")?;
                    let duration_minimum = rust_decimal::Decimal::from(duration_minutes)
                        .checked_mul(rust_decimal::Decimal::TEN)
                        .ok_or("TWAP minimum calculation overflowed decimal range")?;
                    let minimum = duration_minimum.max(rust_decimal::Decimal::ONE_HUNDRED);
                    if notional < minimum {
                        return Err(format!(
                            "TWAP notional {} is below the venue minimum of max(100 quote units, 10 quote units per minute): {minimum}",
                            wire_decimal(notional)
                        ));
                    }
                }
                (
                    json!({"type":"twapOrder","twap":{"a":m.asset_id,"b":side.is_buy(),"s":wire_decimal(size),"r":reduce_only,"m":duration_minutes,"t":randomize}}),
                    json!({"kind":"twap_place","account":account,"market_ref":m.market_ref,"side":side,"size":wire_decimal(size),"duration_minutes":duration_minutes,"randomize":randomize,"reduce_only":reduce_only}),
                )
            }
            TwapIntent::Cancel { market, twap_id } => {
                let m = resolve(app, &market)?;
                (
                    json!({"type":"twapCancel","a":m.asset_id,"t":twap_id}),
                    json!({"kind":"twap_cancel","account":account,"market_ref":m.market_ref,"twap_id":twap_id}),
                )
            }
        };
        crate::domain::signing::prepare(app, &ctx, action, preview)
    }
}

use crate::client::HyperliquidApp;
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Hash, Serialize, Deserialize, JsonSchema)]
#[serde(rename_all = "lowercase")]
pub enum Network {
    #[default]
    Mainnet,
    Testnet,
}
impl Network {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Mainnet => "mainnet",
            Self::Testnet => "testnet",
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize, JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum MarketType {
    Perp,
    Spot,
}

#[derive(Clone, Debug, Serialize)]
pub struct Market {
    pub market_ref: String,
    pub symbol: String,
    pub coin: String,
    pub market_type: MarketType,
    pub dex: Option<String>,
    #[serde(skip_serializing)]
    pub asset_id: u32,
    pub sz_decimals: u32,
    pub max_leverage: Option<u32>,
    pub collateral: String,
    pub active: bool,
    pub only_isolated: bool,
    pub context: Value,
}

fn array<'a>(value: &'a Value, field: &str) -> Result<&'a Vec<Value>, String> {
    value
        .get(field)
        .and_then(Value::as_array)
        .ok_or_else(|| format!("Venue metadata missing {field}"))
}

pub fn markets(app: &HyperliquidApp, dex: Option<&str>) -> Result<Vec<Market>, String> {
    markets_of_type(app, dex, None)
}

pub fn markets_of_type(
    app: &HyperliquidApp,
    dex: Option<&str>,
    kind: Option<MarketType>,
) -> Result<Vec<Market>, String> {
    load_markets(app, dex, kind, true)
}

/// Batched metadata for discovery; hydrate only the displayed perpetual DEXs.
pub fn discovery_catalog(
    app: &HyperliquidApp,
    dex: Option<&str>,
    kind: Option<MarketType>,
) -> Result<Vec<Market>, String> {
    load_markets(app, dex, kind, false)
}

fn load_markets(
    app: &HyperliquidApp,
    dex: Option<&str>,
    kind: Option<MarketType>,
    with_context: bool,
) -> Result<Vec<Market>, String> {
    let mut result = Vec::new();
    let spot = app.venue.info(json!({"type":"spotMetaAndAssetCtxs"}))?;
    let spot_meta = spot.get(0).ok_or("Missing spot metadata")?;
    let tokens = array(spot_meta, "tokens")?;
    let token = |index: u64| tokens.iter().find(|t| t["index"].as_u64() == Some(index));
    if kind != Some(MarketType::Perp) && (dex.is_none() || dex == Some("")) {
        for entry in array(spot_meta, "universe")? {
            let index = entry["index"].as_u64().ok_or("Missing spot market index")?;
            let pair = array(entry, "tokens")?;
            let base = pair
                .first()
                .and_then(Value::as_u64)
                .and_then(token)
                .ok_or("Missing base token")?;
            let quote = pair
                .get(1)
                .and_then(Value::as_u64)
                .and_then(token)
                .ok_or("Missing quote token")?;
            let coin = entry["name"]
                .as_str()
                .ok_or("Missing spot coin")?
                .to_string();
            let symbol = format!(
                "{}/{}",
                base["name"].as_str().unwrap_or("?"),
                quote["name"].as_str().unwrap_or("?")
            );
            result.push(Market {
                market_ref: format!("hl:{}:spot:{coin}", app.network.as_str()),
                symbol,
                coin: coin.clone(),
                market_type: MarketType::Spot,
                dex: None,
                asset_id: u32::try_from(index)
                    .ok()
                    .and_then(|i| 10000u32.checked_add(i))
                    .ok_or("Invalid spot index")?,
                sz_decimals: base["szDecimals"]
                    .as_u64()
                    .ok_or("Missing spot precision")? as u32,
                max_leverage: None,
                collateral: quote["name"].as_str().unwrap_or("unknown").to_string(),
                active: true,
                only_isolated: false,
                context: spot
                    .get(1)
                    .and_then(Value::as_array)
                    .and_then(|contexts| {
                        contexts
                            .iter()
                            .find(|context| context["coin"].as_str() == Some(coin.as_str()))
                    })
                    .cloned()
                    .unwrap_or(Value::Null),
            });
        }
    }
    if kind == Some(MarketType::Spot) {
        return Ok(result);
    }
    let dexes = app.venue.info(json!({"type":"perpDexs"}))?;
    let dexes = dexes.as_array().ok_or("Malformed DEX metadata")?;
    let batched = if !with_context && dex.is_none() {
        let metadata = app.venue.info(json!({"type":"allPerpMetas"}))?;
        if metadata
            .as_array()
            .is_none_or(|rows| rows.len() != dexes.len())
        {
            return Err("DEX catalog changed while loading metadata; refresh discovery".into());
        }
        Some(metadata)
    } else {
        None
    };
    for (dex_index, entry) in dexes.iter().enumerate() {
        let name = entry["name"].as_str().unwrap_or("");
        if dex.is_some_and(|filter| filter != name) {
            continue;
        }
        let meta = if let Some(ref batched) = batched {
            json!([batched[dex_index], []])
        } else {
            app.venue
                .info(json!({"type":"metaAndAssetCtxs","dex":name}))?
        };
        let metadata = meta.get(0).ok_or("Missing perpetual metadata")?;
        let collateral_id = metadata["collateralToken"].as_u64().unwrap_or(0);
        let collateral = token(collateral_id)
            .and_then(|v| v["name"].as_str())
            .ok_or("Unknown perpetual collateral token")?;
        for (index, entry) in array(metadata, "universe")?.iter().enumerate() {
            let coin = entry["name"]
                .as_str()
                .ok_or("Missing perpetual coin")?
                .to_string();
            if (!name.is_empty() && !coin.starts_with(&format!("{name}:")))
                || (name.is_empty() && coin.contains(':'))
            {
                return Err("Perpetual metadata does not match its DEX".into());
            }
            let asset_id = if name.is_empty() {
                index as u32
            } else {
                100000u32
                    .checked_add(
                        (dex_index as u32)
                            .checked_mul(10000)
                            .ok_or("Invalid DEX index")?,
                    )
                    .and_then(|v| v.checked_add(index as u32))
                    .ok_or("Invalid asset index")?
            };
            result.push(Market {
                market_ref: format!("hl:{}:perp:{coin}", app.network.as_str()),
                symbol: coin.clone(),
                coin,
                market_type: MarketType::Perp,
                dex: (!name.is_empty()).then(|| name.to_string()),
                asset_id,
                sz_decimals: entry["szDecimals"]
                    .as_u64()
                    .ok_or("Missing perpetual precision")? as u32,
                max_leverage: entry["maxLeverage"].as_u64().map(|v| v as u32),
                collateral: collateral.to_string(),
                active: !entry["isDelisted"].as_bool().unwrap_or(false),
                only_isolated: entry["onlyIsolated"].as_bool().unwrap_or(false),
                context: meta
                    .get(1)
                    .and_then(|v| v.get(index))
                    .cloned()
                    .unwrap_or(Value::Null),
            });
        }
    }
    if dex.is_some_and(|v| !v.is_empty()) && result.is_empty() {
        return Err("Unknown or empty perpetual DEX".into());
    }
    Ok(result)
}

pub fn resolve(app: &HyperliquidApp, selector: &str) -> Result<Market, String> {
    if selector.trim().is_empty() {
        return Err("A market selector is required".into());
    }
    let suffix = if selector.starts_with("hl:") {
        let prefix = format!("hl:{}:", app.network.as_str());
        selector
            .strip_prefix(&prefix)
            .ok_or("Market belongs to a different network")?
            .split_once(':')
            .ok_or("Invalid canonical market reference")?
            .1
    } else {
        selector
    };
    let kind = if selector.starts_with("hl:") {
        match selector.split(':').nth(2) {
            Some("perp") => Some(MarketType::Perp),
            Some("spot") => Some(MarketType::Spot),
            _ => return Err("Unknown market type in canonical reference".into()),
        }
    } else {
        None
    };
    let dex = suffix
        .split_once(':')
        .map(|(name, _)| name)
        .or_else(|| kind.map(|_| ""));
    // A bare symbol searches every DEX so a colliding ticker never silently selects a venue.
    let catalog = if dex.is_none() {
        discovery_catalog(app, dex, kind)?
    } else {
        markets_of_type(app, dex, kind)?
    };
    let candidates = catalog
        .into_iter()
        .filter(|market| {
            market.market_ref == selector
                || market.coin.eq_ignore_ascii_case(selector)
                || market.symbol.eq_ignore_ascii_case(selector)
                || (!selector.contains(':')
                    && market
                        .symbol
                        .rsplit(':')
                        .next()
                        .is_some_and(|s| s.eq_ignore_ascii_case(selector)))
        })
        .collect::<Vec<_>>();
    match candidates.as_slice() {
        [market] if dex.is_none() => resolve(app, &market.market_ref),
        [market] => Ok(market.clone()),
        [] => Err(format!("Market {selector} was not found")),
        _ => Err(format!(
            "Ambiguous market; choose one of {}",
            candidates
                .iter()
                .map(|m| m.market_ref.as_str())
                .collect::<Vec<_>>()
                .join(", ")
        )),
    }
}

/// Context arrays are matched to the fresh response's universe by name.
pub fn hydrate_contexts(app: &HyperliquidApp, markets: &mut [Market]) -> Result<(), String> {
    let mut contexts = std::collections::HashMap::<String, Value>::new();
    for market in markets
        .iter_mut()
        .filter(|m| m.market_type == MarketType::Perp && m.context.is_null())
    {
        let dex = market.dex.as_deref().unwrap_or("");
        if !contexts.contains_key(dex) {
            contexts.insert(
                dex.to_owned(),
                app.venue
                    .info(json!({"type":"metaAndAssetCtxs","dex":dex}))?,
            );
        }
        let response = &contexts[dex];
        market.context = array(&response[0], "universe")?
            .iter()
            .position(|entry| entry["name"].as_str() == Some(&market.coin))
            .and_then(|index| response.get(1).and_then(|rows| rows.get(index)))
            .cloned()
            .unwrap_or(Value::Null);
    }
    Ok(())
}

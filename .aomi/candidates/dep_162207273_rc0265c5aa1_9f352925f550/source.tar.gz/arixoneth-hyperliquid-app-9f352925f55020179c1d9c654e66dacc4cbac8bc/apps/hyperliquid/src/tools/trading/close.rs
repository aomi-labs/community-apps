use crate::{
    client::HyperliquidApp,
    domain::{
        account::wallet,
        market::resolve,
        order::{Side, TimeInForce, decimal, limit_order, market_price, order_action, round_size},
    },
    tools::trading::prepare_order::{mid_for, mids},
};
use aomi_sdk::{DynAomiTool, DynToolCallCtx, ToolReturn, schemars::JsonSchema};
use rust_decimal::Decimal;
use serde::Deserialize;
use serde_json::{Value, json};
use std::str::FromStr;
pub struct PrepareClose;
#[derive(Debug, Deserialize, JsonSchema)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum CloseSize {
    Full,
    Base { quantity: String },
    PositionFractionBps { bps: u16 },
}
#[derive(Debug, Deserialize, JsonSchema)]
pub struct PrepareCloseArgs {
    pub market: String,
    pub size: CloseSize,
    #[serde(default = "default_slippage")]
    pub max_slippage_bps: u16,
}
fn default_slippage() -> u16 {
    50
}
impl DynAomiTool for PrepareClose {
    type App = HyperliquidApp;
    type Args = PrepareCloseArgs;
    const NAME: &'static str = "hl_prepare_close";
    const DESCRIPTION: &'static str = "Prepare a reduce-only IOC close that cannot open an opposite position. With an approved API-wallet key, supported trading actions execute immediately; call only for explicit user intent, never for a dry run.";
    fn run_with_routes(
        app: &Self::App,
        args: Self::Args,
        ctx: DynToolCallCtx,
    ) -> Result<ToolReturn, String> {
        let address = wallet(&ctx)?;
        let m = resolve(app, &args.market)?;
        let state = app
            .venue
            .info(json!({"type":"clearinghouseState","user":address,"dex":m.dex.as_deref().unwrap_or("")}))?;
        let positions = state
            .get("assetPositions")
            .and_then(Value::as_array)
            .ok_or("clearinghouseState omitted assetPositions")?;
        let p = positions
            .iter()
            .find_map(|x| {
                let p = x.get("position").unwrap_or(x);
                (p.get("coin").and_then(Value::as_str) == Some(m.coin.as_str())).then_some(p)
            })
            .ok_or("no open position")?;
        let signed = Decimal::from_str(
            p.get("szi")
                .and_then(Value::as_str)
                .ok_or("position szi missing")?,
        )
        .map_err(|_| "position szi invalid")?;
        if signed == Decimal::ZERO {
            return Err("position is already closed".into());
        }
        let total = signed.abs();
        let qty = match args.size {
            CloseSize::Full => total,
            CloseSize::Base { quantity } => {
                let q = decimal(&quantity, "quantity")?;
                if q > total {
                    return Err("close quantity exceeds position".into());
                }
                q
            }
            CloseSize::PositionFractionBps { bps } => {
                if bps == 0 || bps > 10_000 {
                    return Err("bps must be 1..=10000".into());
                }
                total
                    .checked_mul(Decimal::from(bps))
                    .and_then(|value| value.checked_div(Decimal::from(10_000u32)))
                    .ok_or("close fraction overflowed decimal range")?
            }
        };
        let side = if signed > Decimal::ZERO {
            Side::Sell
        } else {
            Side::Buy
        };
        let all = mids(app.venue.info(json!({"type":"allMids"}))?)?;
        let px = crate::domain::order::ioc_bound_price(
            market_price(mid_for(&all, &m)?, side, args.max_slippage_bps)?,
            &m,
            side,
        )?;
        let order = limit_order(&m, side, round_size(qty, &m)?, px, TimeInForce::Ioc, true)?;
        crate::domain::signing::prepare(
            app,
            &ctx,
            order_action(vec![order.clone()], "na"),
            json!({"kind":"close","account":address,"market_ref":m.market_ref,"reduce_only":true,"order":order}),
        )
    }
}

use std::sync::Arc;

use hyperliquid::{
    client::{HyperliquidApp, HyperliquidVenue},
    domain::market::{Network, markets, resolve},
};
use serde_json::{Value, json};

#[derive(Clone)]
struct FixtureVenue;

impl HyperliquidVenue for FixtureVenue {
    fn info(&self, request: Value) -> Result<Value, String> {
        match request["type"].as_str() {
            Some("spotMetaAndAssetCtxs") => Ok(json!([
                {
                    "tokens":[
                        {"name":"USDC","index":0,"szDecimals":6},
                        {"name":"ABC","index":7,"szDecimals":3}
                    ],
                    "universe":[{"tokens":[7,0],"name":"ABC/USDC","index":42}]
                },
                [{"coin":"@unrelated","midPx":"999"},{"coin":"ABC/USDC","midPx":"2.5"}]
            ])),
            Some("perpDexs") => Ok(json!([null, {"name":"xyz"}])),
            Some("allPerpMetas") => Ok(json!([
                self.info(json!({"type":"metaAndAssetCtxs","dex":""}))?[0],
                self.info(json!({"type":"metaAndAssetCtxs","dex":"xyz"}))?[0]
            ])),
            Some("metaAndAssetCtxs") if request["dex"] == "" => Ok(json!([
                {
                    "collateralToken":0,
                    "universe":[
                        {"name":"BTC","szDecimals":5,"maxLeverage":40},
                        {"name":"ABC","szDecimals":2,"maxLeverage":10}
                    ]
                },
                [{"markPx":"60000"},{"markPx":"2"}]
            ])),
            Some("metaAndAssetCtxs") if request["dex"] == "xyz" => Ok(json!([
                {
                    "collateralToken":0,
                    "universe":[
                        {"name":"xyz:AAPL","szDecimals":3,"maxLeverage":5},
                        {"name":"xyz:ABC","szDecimals":2,"maxLeverage":3}
                    ]
                },
                [{"markPx":"250"},{"markPx":"2.1"}]
            ])),
            other => Err(format!("unexpected fixture request {other:?}: {request}")),
        }
    }

    fn exchange(&self, _request: Value) -> Result<Value, String> {
        panic!("market resolution must never call /exchange")
    }
}

fn app() -> HyperliquidApp {
    HyperliquidApp::new(Network::Mainnet, Arc::new(FixtureVenue))
}

#[test]
fn assigns_protocol_asset_ids_for_native_spot_and_hip3() {
    let app = app();
    let all = markets(&app, None).expect("fixture markets");
    let native = all.iter().find(|market| market.coin == "BTC").unwrap();
    let spot = all.iter().find(|market| market.coin == "ABC/USDC").unwrap();
    let hip3 = all.iter().find(|market| market.coin == "xyz:AAPL").unwrap();

    assert_eq!(native.asset_id, 0);
    assert_eq!(spot.asset_id, 10_042, "spot ID uses the metadata index");
    assert_eq!(
        spot.context["midPx"], "2.5",
        "spot context must match coin, not position"
    );
    assert_eq!(
        hip3.asset_id, 110_000,
        "first HIP-3 DEX has protocol index one"
    );
    assert_eq!(hip3.market_ref, "hl:mainnet:perp:xyz:AAPL");
}

#[test]
fn canonical_hip3_reference_resolves_with_dex_qualification() {
    let market = resolve(&app(), "hl:mainnet:perp:xyz:AAPL").expect("HIP-3 market");
    assert_eq!(market.asset_id, 110_000);
    assert_eq!(market.dex.as_deref(), Some("xyz"));
}

#[test]
fn ambiguous_bare_name_is_rejected() {
    let error = resolve(&app(), "ABC").expect_err("native ABC and xyz:ABC must be ambiguous");
    assert!(error.contains("Ambiguous market"), "{error}");
    assert!(error.contains("hl:mainnet:perp:ABC"), "{error}");
    assert!(error.contains("hl:mainnet:perp:xyz:ABC"), "{error}");
}

#[test]
fn cross_network_canonical_reference_is_rejected() {
    let error = resolve(&app(), "hl:testnet:perp:BTC").expect_err("network mismatch");
    assert!(error.contains("different network"), "{error}");
}

#[test]
fn discovery_batches_catalog_and_fetches_context_only_for_visible_dex() {
    use aomi_sdk::{DynAomiTool, DynToolCallCtx};
    use hyperliquid::tools::trading::Markets;
    use std::sync::Mutex;
    struct Recorded(Mutex<Vec<Value>>);
    impl HyperliquidVenue for Recorded {
        fn info(&self, request: Value) -> Result<Value, String> {
            self.0.lock().unwrap().push(request.clone());
            FixtureVenue.info(request)
        }
        fn exchange(&self, _: Value) -> Result<Value, String> {
            panic!("read-only")
        }
    }
    let venue = Arc::new(Recorded(Mutex::new(vec![])));
    let app = HyperliquidApp::new(Network::Testnet, venue.clone());
    let result = Markets::run(
        &app,
        serde_json::from_value(json!({"query":"ABC","market_type":"perp","limit":1})).unwrap(),
        DynToolCallCtx {
            session_id: "test".into(),
            tool_name: "test".into(),
            call_id: "test".into(),
            state_attributes: Default::default(),
            secrets: Default::default(),
        },
    )
    .unwrap();
    assert_eq!(result["total"], 2);
    assert_eq!(result["markets"][0]["context"]["markPx"], "2");
    let requests = venue.0.lock().unwrap();
    assert_eq!(
        requests
            .iter()
            .filter(|r| r["type"] == "allPerpMetas")
            .count(),
        1
    );
    let context_requests = requests
        .iter()
        .filter(|r| r["type"] == "metaAndAssetCtxs")
        .collect::<Vec<_>>();
    assert_eq!(context_requests.len(), 1);
    assert_eq!(context_requests[0]["dex"], "");
}

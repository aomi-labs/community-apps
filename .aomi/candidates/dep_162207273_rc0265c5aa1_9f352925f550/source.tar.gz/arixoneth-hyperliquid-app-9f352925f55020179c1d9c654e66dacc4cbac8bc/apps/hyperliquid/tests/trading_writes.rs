use std::{
    collections::HashMap,
    sync::{Arc, Mutex},
};

use aomi_sdk::{DynAomiTool, DynToolCallCtx, ToolReturn};
use hyperliquid::{
    client::{HyperliquidApp, HyperliquidVenue},
    domain::{
        market::Network,
        order::{Side, SizeSpec, ladder_prices, market_price},
    },
    tools::trading::{
        PrepareCancel, PrepareClose, PrepareModify, PrepareOrder, PrepareRisk, PrepareTwap,
    },
};
use hypersdk::hypercore::types::Action;
use rust_decimal::Decimal;
use serde_json::{Map, Value, json};

#[derive(Default)]
struct MockVenue {
    requests: Mutex<Vec<Value>>,
    open: Mutex<Value>,
    position: Mutex<Value>,
}
impl MockVenue {
    fn with_state(open: Value, position: Value) -> Self {
        Self {
            requests: Mutex::new(Vec::new()),
            open: Mutex::new(open),
            position: Mutex::new(position),
        }
    }
}
impl HyperliquidVenue for MockVenue {
    fn info(&self, request: Value) -> Result<Value, String> {
        self.requests.lock().unwrap().push(request.clone());
        Ok(match request["type"].as_str().unwrap_or("") {
            "spotMetaAndAssetCtxs" => {
                json!([{"tokens":[{"index":0,"name":"USDC","szDecimals":6}],"universe":[]},[]])
            }
            "perpDexs" => json!([{"name":""}]),
            "allPerpMetas" => {
                json!([{"collateralToken":0,"universe":[{"name":"BTC","szDecimals":3,"maxLeverage":50}]}])
            }
            "metaAndAssetCtxs" => {
                json!([{"collateralToken":0,"universe":[{"name":"BTC","szDecimals":3,"maxLeverage":50}]},[{}]])
            }
            "allMids" => json!({"BTC":"100"}),
            "frontendOpenOrders" => self.open.lock().unwrap().clone(),
            "clearinghouseState" => self.position.lock().unwrap().clone(),
            other => return Err(format!("unexpected info request {other}")),
        })
    }
    fn exchange(&self, _: Value) -> Result<Value, String> {
        Err("exchange must not run during prepare".into())
    }
}

fn app(open: Value, position: Value) -> HyperliquidApp {
    HyperliquidApp::new(
        Network::Mainnet,
        Arc::new(MockVenue::with_state(open, position)),
    )
}
fn ctx() -> DynToolCallCtx {
    let mut state = Map::new();
    state.insert(
        "domain".into(),
        json!({"evm":{"address":"0x1111111111111111111111111111111111111111"}}),
    );
    DynToolCallCtx {
        session_id: "s".into(),
        tool_name: "test".into(),
        call_id: "c".into(),
        state_attributes: state,
        secrets: HashMap::new(),
    }
}
fn value(result: ToolReturn) -> Value {
    serde_json::to_value(result).unwrap()
}
fn action(result: ToolReturn) -> Value {
    let routed = value(result);
    let action = routed["__aomi_tool_routes"][1]["args"]["prepared"]["action"].clone();
    serde_json::from_value::<Action>(action.clone()).expect("pinned hypersdk parses action");
    action
}

#[test]
fn decimal_ladder_and_slippage_are_exact() {
    let prices = ladder_prices("1.1".parse().unwrap(), "1.3".parse().unwrap(), 3).unwrap();
    assert_eq!(
        prices,
        vec![
            "1.1".parse::<Decimal>().unwrap(),
            "1.2".parse().unwrap(),
            "1.3".parse().unwrap()
        ]
    );
    assert_eq!(
        market_price("100".parse().unwrap(), Side::Buy, 25)
            .unwrap()
            .normalize()
            .to_string(),
        "100.25"
    );
}

#[test]
fn market_order_routes_exact_ioc_action() {
    let args: <PrepareOrder as DynAomiTool>::Args=serde_json::from_value(json!({"intent":{"kind":"orders","orders":[{"market":"hl:mainnet:perp:BTC","side":"buy","size":{"base":{"quantity":"1.2349"}},"order_type":{"kind":"market","max_slippage_bps":50},"reduce_only":false}]}})).unwrap();
    let routed = value(
        PrepareOrder::run_with_routes(&app(json!([]), json!({"assetPositions":[]})), args, ctx())
            .unwrap(),
    );
    let prepared = &routed["__aomi_tool_routes"][1]["args"]["prepared"];
    assert_eq!(prepared["action"]["orders"][0]["s"], "1.234");
    assert_eq!(prepared["action"]["orders"][0]["p"], "100.5");
    assert_eq!(prepared["action"]["orders"][0]["t"]["limit"]["tif"], "Ioc");
}

#[test]
fn quote_notional_market_order_derives_base_size_without_floats() {
    let args:<PrepareOrder as DynAomiTool>::Args=serde_json::from_value(json!({"intent":{"kind":"orders","orders":[{"market":"BTC","side":"buy","size":{"quote_notional":{"amount":"200"}},"order_type":{"kind":"market","max_slippage_bps":50},"reduce_only":false}]}})).unwrap();
    let order = action(
        PrepareOrder::run_with_routes(&app(json!([]), json!({"assetPositions":[]})), args, ctx())
            .unwrap(),
    )["orders"][0]
        .clone();
    assert_eq!(order["s"], "2");
    assert_eq!(order["p"], "100.5");
}

#[test]
fn scoped_cancel_freezes_only_matching_side() {
    let open = json!([{"coin":"BTC","oid":7,"side":"A","reduceOnly":false},{"coin":"BTC","oid":8,"side":"B","reduceOnly":false}]);
    let args:<PrepareCancel as DynAomiTool>::Args=serde_json::from_value(json!({"intent":{"kind":"scope","market":"BTC","side":"sell","include_triggers":false,"include_protection":false,"include_twap":false}})).unwrap();
    let routed = value(
        PrepareCancel::run_with_routes(&app(open, json!({"assetPositions":[]})), args, ctx())
            .unwrap(),
    );
    assert_eq!(
        routed["__aomi_tool_routes"][1]["args"]["prepared"]["action"]["cancels"],
        json!([{"a":0,"o":7}])
    );
}

#[test]
fn exact_cancel_action_parses() {
    let args: <PrepareCancel as DynAomiTool>::Args = serde_json::from_value(
        json!({"intent":{"kind":"exact","orders":[{"market":"BTC","order_id":42}]}}),
    )
    .unwrap();
    let action = action(
        PrepareCancel::run_with_routes(&app(json!([]), json!({"assetPositions":[]})), args, ctx())
            .unwrap(),
    );
    assert_eq!(action["cancels"], json!([{"a":0,"o":42}]));
}

#[test]
fn scoped_twap_cancel_requires_and_freezes_exact_ids() {
    let args:<PrepareCancel as DynAomiTool>::Args=serde_json::from_value(json!({"intent":{"kind":"scope","market":null,"side":null,"include_triggers":false,"include_protection":false,"include_twap":true,"twap_ids":[{"market":"BTC","twap_id":70},{"market":"BTC","twap_id":71}]}})).unwrap();
    let first = action(
        PrepareCancel::run_with_routes(&app(json!([]), json!({"assetPositions":[]})), args, ctx())
            .unwrap(),
    );
    assert_eq!(first, json!({"type":"twapCancel","a":0,"t":70}));
}

#[test]
fn modify_fails_when_original_disappeared() {
    let args:<PrepareModify as DynAomiTool>::Args=serde_json::from_value(json!({"modifications":[{"order_ref":{"market":"BTC","order_id":99},"new_price":"101","new_remaining_size":null}]})).unwrap();
    let err =
        PrepareModify::run_with_routes(&app(json!([]), json!({"assetPositions":[]})), args, ctx())
            .unwrap_err();
    assert!(err.contains("disappeared"));
}

#[test]
fn close_is_always_reduce_only() {
    let position = json!({"assetPositions":[{"position":{"coin":"BTC","szi":"2"}}]});
    let args:<PrepareClose as DynAomiTool>::Args=serde_json::from_value(json!({"market":"BTC","size":{"kind":"position_fraction_bps","bps":5000},"max_slippage_bps":100})).unwrap();
    let routed =
        value(PrepareClose::run_with_routes(&app(json!([]), position), args, ctx()).unwrap());
    let order = &routed["__aomi_tool_routes"][1]["args"]["prepared"]["action"]["orders"][0];
    assert_eq!(order["r"], true);
    assert_eq!(order["b"], false);
    assert_eq!(order["s"], "1");
}

#[test]
fn all_close_size_modes_are_reduce_only() {
    for size in [
        json!({"kind":"full"}),
        json!({"kind":"base","quantity":"0.75"}),
        json!({"kind":"position_fraction_bps","bps":2500}),
    ] {
        let position = json!({"assetPositions":[{"position":{"coin":"BTC","szi":"-2"}}]});
        let args: <PrepareClose as DynAomiTool>::Args =
            serde_json::from_value(json!({"market":"BTC","size":size,"max_slippage_bps":100}))
                .unwrap();
        let order =
            action(PrepareClose::run_with_routes(&app(json!([]), position), args, ctx()).unwrap())
                ["orders"][0]
                .clone();
        assert_eq!(order["r"], true);
        assert_eq!(order["b"], true);
    }
}

#[test]
fn all_write_tool_schemas_are_objects_with_properties() {
    let app = app(json!([]), json!({"assetPositions":[]}));
    for schema in [
        PrepareOrder::descriptor(&app),
        PrepareCancel::descriptor(&app),
        PrepareModify::descriptor(&app),
        PrepareClose::descriptor(&app),
        PrepareTwap::descriptor(&app),
        PrepareRisk::descriptor(&app),
    ] {
        assert_eq!(schema.parameters_schema["type"], "object");
        assert!(schema.parameters_schema["properties"].is_object());
    }
}

#[test]
fn bracket_protection_and_ladder_actions_parse() {
    let venue_app = app(
        json!([]),
        json!({"assetPositions":[{"position":{"coin":"BTC","szi":"2"}}]}),
    );
    let bracket:<PrepareOrder as DynAomiTool>::Args=serde_json::from_value(json!({"intent":{"kind":"bracket","entry":{"market":"BTC","side":"buy","size":{"base":{"quantity":"1"}},"order_type":{"kind":"limit","price":"100","time_in_force":"gtc"},"reduce_only":false},"take_profit":{"trigger_price":"120","execution":{"kind":"limit","price":"119"}},"stop_loss":{"trigger_price":"90","execution":{"kind":"market"}}}})).unwrap();
    let bracket = action(PrepareOrder::run_with_routes(&venue_app, bracket, ctx()).unwrap());
    assert_eq!(bracket["grouping"], "normalTpsl");
    assert_eq!(bracket["orders"].as_array().unwrap().len(), 3);
    assert_eq!(bracket["orders"][1]["r"], true);

    let protect:<PrepareOrder as DynAomiTool>::Args=serde_json::from_value(json!({"intent":{"kind":"protect_position","market":"BTC","size":{"kind":"position_fraction_bps","bps":5000},"take_profit":{"trigger_price":"125","execution":{"kind":"market"}},"stop_loss":null,"replace_existing":false}})).unwrap();
    let protect = action(PrepareOrder::run_with_routes(&venue_app, protect, ctx()).unwrap());
    assert_eq!(protect["grouping"], "positionTpsl");
    assert_eq!(protect["orders"][0]["s"], "1");

    for allocation in ["equal_size", "equal_notional"] {
        let ladder:<PrepareOrder as DynAomiTool>::Args=serde_json::from_value(json!({"intent":{"kind":"ladder","market":"BTC","side":"buy","total_size":{"base":{"quantity":"3"}},"start_price":"90","end_price":"100","levels":3,"allocation":allocation,"reduce_only":false}})).unwrap();
        assert_eq!(
            action(PrepareOrder::run_with_routes(&venue_app, ladder, ctx()).unwrap())["orders"]
                .as_array()
                .unwrap()
                .len(),
            3
        );
    }
}

#[test]
fn market_quote_bracket_protection_uses_exact_compiled_entry_size() {
    let venue_app = app(json!([]), json!({"assetPositions":[]}));
    let args: <PrepareOrder as DynAomiTool>::Args = serde_json::from_value(json!({
        "intent":{"kind":"bracket","entry":{"market":"BTC","side":"buy",
            "size":{"quote_notional":{"amount":"100"}},
            "order_type":{"kind":"market","max_slippage_bps":100},"reduce_only":false},
            "take_profit":{"trigger_price":"120","execution":{"kind":"market"}},
            "stop_loss":null}
    }))
    .unwrap();
    let prepared = action(PrepareOrder::run_with_routes(&venue_app, args, ctx()).unwrap());
    assert_eq!(prepared["orders"][0]["s"], prepared["orders"][1]["s"]);
}

#[test]
fn batch_limit_and_trigger_actions_parse() {
    let args:<PrepareOrder as DynAomiTool>::Args=serde_json::from_value(json!({"intent":{"kind":"orders","orders":[
      {"market":"BTC","side":"buy","size":{"base":{"quantity":"0.25"}},"order_type":{"kind":"limit","price":"99.123","time_in_force":"alo"},"reduce_only":false},
      {"market":"BTC","side":"sell","size":{"base":{"quantity":"0.10"}},"order_type":{"kind":"trigger","purpose":"stop_loss","trigger_price":"90","execution":{"kind":"market"}},"reduce_only":true}
    ]}})).unwrap();
    assert_eq!(
        action(
            PrepareOrder::run_with_routes(
                &app(json!([]), json!({"assetPositions":[]})),
                args,
                ctx()
            )
            .unwrap()
        )["orders"]
            .as_array()
            .unwrap()
            .len(),
        2
    );
}

#[test]
fn replacing_protection_first_freezes_exact_cancel() {
    let args:<PrepareOrder as DynAomiTool>::Args=serde_json::from_value(json!({"intent":{"kind":"protect_position","market":"BTC","size":{"kind":"full_position"},"take_profit":{"trigger_price":"120","execution":{"kind":"market"}},"stop_loss":null,"replace_existing":true}})).unwrap();
    let open = json!([{"coin":"BTC","oid":55,"side":"A","isTrigger":true,"isPositionTpsl":true,"reduceOnly":true}]);
    let prepared = action(
        PrepareOrder::run_with_routes(
            &app(
                open,
                json!({"assetPositions":[{"position":{"coin":"BTC","szi":"2"}}]}),
            ),
            args,
            ctx(),
        )
        .unwrap(),
    );
    assert_eq!(prepared["type"], "cancel");
    assert_eq!(prepared["cancels"], json!([{"a":0,"o":55}]));
}

#[test]
fn found_modify_preserves_limit_and_trigger_semantics() {
    let open = json!([{"coin":"BTC","oid":9,"side":"B","limitPx":"100","sz":"0.5","reduceOnly":false,"tif":"Alo","triggerPx":"0.0","isTrigger":false},{"coin":"BTC","oid":10,"side":"A","limitPx":"89","sz":"1","reduceOnly":true,"orderType":"Stop Market","triggerPx":"90"}]);
    let args:<PrepareModify as DynAomiTool>::Args=serde_json::from_value(json!({"modifications":[{"order_ref":{"market":"BTC","order_id":9},"new_price":"101.123","new_remaining_size":"0.4"},{"order_ref":{"market":"BTC","order_id":10},"new_price":null,"new_remaining_size":"0.8"}]})).unwrap();
    let action = action(
        PrepareModify::run_with_routes(&app(open, json!({"assetPositions":[]})), args, ctx())
            .unwrap(),
    );
    assert_eq!(action["type"], "batchModify");
    assert_eq!(action["modifies"][0]["order"]["t"]["limit"]["tif"], "Alo");
    assert_eq!(action["modifies"][1]["order"]["t"]["trigger"]["tpsl"], "sl");
}

#[test]
fn twap_place_and_cancel_actions_parse() {
    let venue_app = app(json!([]), json!({"assetPositions":[]}));
    let place:<PrepareTwap as DynAomiTool>::Args=serde_json::from_value(json!({"intent":{"kind":"place","market":"BTC","side":"buy","size":{"base":{"quantity":"3.3456"}},"duration_minutes":30,"randomize":true,"reduce_only":false}})).unwrap();
    assert_eq!(
        action(PrepareTwap::run_with_routes(&venue_app, place, ctx()).unwrap())["twap"]["s"],
        "3.345"
    );
    let cancel: <PrepareTwap as DynAomiTool>::Args =
        serde_json::from_value(json!({"intent":{"kind":"cancel","market":"BTC","twap_id":77}}))
            .unwrap();
    assert_eq!(
        action(PrepareTwap::run_with_routes(&venue_app, cancel, ctx()).unwrap())["t"],
        77
    );
}

#[test]
fn twap_enforces_duration_derived_notional_but_allows_reduce_only_dust() {
    let venue_app = app(json!([]), json!({"assetPositions":[]}));
    let too_small: <PrepareTwap as DynAomiTool>::Args = serde_json::from_value(json!({
        "intent":{"kind":"place","market":"BTC","side":"buy",
            "size":{"quote_notional":{"amount":"60"}},"duration_minutes":5,
            "randomize":false,"reduce_only":false}
    }))
    .unwrap();
    assert!(
        PrepareTwap::run_with_routes(&venue_app, too_small, ctx())
            .unwrap_err()
            .contains("100 quote units")
    );

    let accepted: <PrepareTwap as DynAomiTool>::Args = serde_json::from_value(json!({
        "intent":{"kind":"place","market":"BTC","side":"buy",
            "size":{"quote_notional":{"amount":"125"}},"duration_minutes":5,
            "randomize":false,"reduce_only":false}
    }))
    .unwrap();
    assert!(PrepareTwap::run_with_routes(&venue_app, accepted, ctx()).is_ok());

    let dust_reduce: <PrepareTwap as DynAomiTool>::Args = serde_json::from_value(json!({
        "intent":{"kind":"place","market":"BTC","side":"sell",
            "size":{"base":{"quantity":"0.001"}},"duration_minutes":5,
            "randomize":false,"reduce_only":true}
    }))
    .unwrap();
    assert!(PrepareTwap::run_with_routes(&venue_app, dust_reduce, ctx()).is_ok());
}

#[test]
fn every_risk_intent_action_parses() {
    let venue_app = app(
        json!([]),
        json!({"assetPositions":[{"position":{"coin":"BTC","szi":"2"}}]}),
    );
    for (input, kind) in [
        (
            json!({"intent":{"kind":"set_leverage","market":"BTC","leverage":10,"margin_mode":"isolated"}}),
            "updateLeverage",
        ),
        (
            json!({"intent":{"kind":"add_isolated_margin","market":"BTC","amount":"1.234567"}}),
            "updateIsolatedMargin",
        ),
        (
            json!({"intent":{"kind":"remove_isolated_margin","market":"BTC","amount":"0.5"}}),
            "updateIsolatedMargin",
        ),
        (
            json!({"intent":{"kind":"set_account_mode","mode":"unified"}}),
            "userSetAbstraction",
        ),
        (
            json!({"intent":{"kind":"set_account_mode","mode":"portfolio_margin"}}),
            "userSetAbstraction",
        ),
        (
            json!({"intent":{"kind":"set_account_mode","mode":"standard"}}),
            "userSetAbstraction",
        ),
    ] {
        let args: <PrepareRisk as DynAomiTool>::Args = serde_json::from_value(input).unwrap();
        let action = action(PrepareRisk::run_with_routes(&venue_app, args, ctx()).unwrap());
        assert_eq!(action["type"], kind);
    }
}

#[test]
fn decimal_extremes_return_errors_instead_of_panicking() {
    assert!(market_price(Decimal::MAX, Side::Buy, 5_000).is_err());
    assert!(ladder_prices(Decimal::MAX, Decimal::MIN, 100).is_err());
    let size = SizeSpec::QuoteNotional {
        amount: Decimal::MAX.to_string(),
    };
    assert!(size.base_at(Decimal::new(1, 28)).is_err());
}

#[test]
fn rejects_post_rounding_minimum_notional_per_order_and_ladder_leg() {
    let venue_app = app(json!([]), json!({"assetPositions":[]}));
    let order: <PrepareOrder as DynAomiTool>::Args = serde_json::from_value(json!({
        "intent":{"kind":"orders","orders":[{
            "market":"BTC","side":"buy","size":{"base":{"quantity":"0.0999"}},
            "order_type":{"kind":"limit","price":"100","time_in_force":"gtc"},
            "reduce_only":false
        }]}
    }))
    .unwrap();
    assert!(
        PrepareOrder::run_with_routes(&venue_app, order, ctx())
            .unwrap_err()
            .contains("minimum of 10")
    );

    let ladder: <PrepareOrder as DynAomiTool>::Args = serde_json::from_value(json!({
        "intent":{"kind":"ladder","market":"BTC","side":"buy",
            "total_size":{"base":{"quantity":"0.2"}},"start_price":"90",
            "end_price":"100","levels":3,"allocation":"equal_size","reduce_only":false}
    }))
    .unwrap();
    assert!(
        PrepareOrder::run_with_routes(&venue_app, ladder, ctx())
            .unwrap_err()
            .contains("minimum of 10")
    );

    let dust_close: <PrepareOrder as DynAomiTool>::Args = serde_json::from_value(json!({
        "intent":{"kind":"orders","orders":[{
            "market":"BTC","side":"sell","size":{"base":{"quantity":"0.001"}},
            "order_type":{"kind":"limit","price":"100","time_in_force":"gtc"},
            "reduce_only":true
        }]}
    }))
    .unwrap();
    assert!(PrepareOrder::run_with_routes(&venue_app, dust_close, ctx()).is_ok());
}

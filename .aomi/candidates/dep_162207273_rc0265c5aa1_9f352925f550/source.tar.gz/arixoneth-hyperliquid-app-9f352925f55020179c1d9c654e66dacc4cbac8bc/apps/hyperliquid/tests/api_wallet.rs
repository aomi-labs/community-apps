use std::sync::{Arc, Mutex};

use alloy::signers::local::PrivateKeySigner;
use aomi_sdk::{DynAomiTool, DynToolCallCtx};
use hyperliquid::{
    client::{HyperliquidApp, HyperliquidVenue},
    domain::{
        api_wallet::{MAINNET_KEY, TESTNET_KEY},
        market::Network,
        signing,
    },
    tools::continuation::{SubmitHyperliquidAction, submit_action::SubmitHyperliquidActionArgs},
};
use serde_json::{Value, json};

const OWNER: &str = "0x1111111111111111111111111111111111111111";
// Public fixture, never funded or used by the live runner.
const KEY: &str = "0000000000000000000000000000000000000000000000000000000000000001";

struct Venue {
    role: Value,
    exchanges: Mutex<Vec<Value>>,
    fail_exchange: bool,
}
impl HyperliquidVenue for Venue {
    fn info(&self, request: Value) -> Result<Value, String> {
        assert_eq!(request["type"], "userRole");
        let signer: PrivateKeySigner = KEY.parse().unwrap();
        assert_eq!(request["user"], signer.address().to_string().to_lowercase());
        Ok(self.role.clone())
    }
    fn exchange(&self, request: Value) -> Result<Value, String> {
        self.exchanges.lock().unwrap().push(request);
        if self.fail_exchange {
            return Err("transport interrupted".into());
        }
        Ok(json!({"status":"ok","response":{"type":"default"}}))
    }
}
fn setup(role: Value, fail_exchange: bool) -> (HyperliquidApp, Arc<Venue>, DynToolCallCtx) {
    let venue = Arc::new(Venue {
        role,
        exchanges: Mutex::new(vec![]),
        fail_exchange,
    });
    let app = HyperliquidApp::new(Network::Testnet, venue.clone());
    let ctx = DynToolCallCtx {
        session_id: "api-wallet-test".into(),
        tool_name: "test".into(),
        call_id: "test".into(),
        state_attributes: serde_json::from_value(json!({"domain":{"evm":{"address":OWNER}}}))
            .unwrap(),
        secrets: [(TESTNET_KEY.name.into(), KEY.into())].into(),
    };
    (app, venue, ctx)
}
fn action() -> Value {
    json!({"type":"updateLeverage","asset":0,"isCross":true,"leverage":2})
}

#[test]
fn signs_as_agent_and_keeps_master_account_identity() {
    let (app, venue, ctx) = setup(json!({"role":"agent","data":{"user":OWNER}}), false);
    let result = signing::prepare(&app, &ctx, action(), json!({})).unwrap();
    let result = serde_json::to_value(result).unwrap();
    assert_eq!(result["status"], "accepted");
    assert!(!result.to_string().contains(KEY));
    assert!(result.get("__aomi_tool_routes").is_none());
    let requests = venue.exchanges.lock().unwrap();
    assert_eq!(requests.len(), 1);
    let request = &requests[0];
    let signature = serde_json::from_value(request["signature"].clone()).unwrap();
    let hash = signing::action_prehash(
        &serde_json::from_value(request["action"].clone()).unwrap(),
        &request["action"],
        request["nonce"].as_u64().unwrap(),
        None,
        request["expiresAfter"].as_u64(),
        Network::Testnet,
    )
    .unwrap();
    let signer: PrivateKeySigner = KEY.parse().unwrap();
    assert_eq!(
        signing::recover_signer(&signature, hash).unwrap(),
        signer.address().to_string().to_lowercase()
    );
}

#[test]
fn rejects_wrong_account_master_keys_revoked_agents_and_malformed_keys() {
    for role in [
        json!({"role":"user"}),
        json!({"role":"missing"}),
        json!({"role":"agent","data":{"user":"0x2222222222222222222222222222222222222222"}}),
        json!({"role":"agent"}),
    ] {
        let (app, venue, ctx) = setup(role, false);
        assert!(signing::prepare(&app, &ctx, action(), json!({})).is_err());
        assert!(venue.exchanges.lock().unwrap().is_empty());
    }
    for key in ["", " ", "invalid-secret-value"] {
        let (app, venue, mut ctx) = setup(json!({}), false);
        ctx.secrets.insert(TESTNET_KEY.name.into(), key.into());
        let error = signing::prepare(&app, &ctx, action(), json!({}))
            .err()
            .unwrap();
        assert!(!error.contains("invalid-secret-value"));
        assert!(venue.exchanges.lock().unwrap().is_empty());
    }
}

#[test]
fn absent_or_other_network_key_preserves_wallet_route_and_deletion_takes_effect() {
    let (app, venue, mut ctx) = setup(json!({"role":"agent","data":{"user":OWNER}}), false);
    signing::prepare(&app, &ctx, action(), json!({})).unwrap();
    ctx.secrets.remove(TESTNET_KEY.name);
    ctx.secrets.insert(MAINNET_KEY.name.into(), KEY.into());
    let result =
        serde_json::to_value(signing::prepare(&app, &ctx, action(), json!({})).unwrap()).unwrap();
    assert!(result.get("__aomi_tool_routes").is_some());
    assert_eq!(venue.exchanges.lock().unwrap().len(), 1);
}

#[test]
fn user_transfers_require_wallet_signature_even_when_api_key_is_present() {
    let (app, venue, ctx) = setup(json!({}), false);
    let result = serde_json::to_value(
        signing::prepare(
            &app,
            &ctx,
            json!({"type":"usdClassTransfer","amount":"1","toPerp":true}),
            json!({}),
        )
        .unwrap(),
    )
    .unwrap();
    assert!(result.get("__aomi_tool_routes").is_some());
    assert!(venue.exchanges.lock().unwrap().is_empty());
}

#[test]
fn ambiguous_submission_is_not_retried() {
    let (app, venue, ctx) = setup(json!({"role":"agent","data":{"user":OWNER}}), true);
    let result =
        serde_json::to_value(signing::prepare(&app, &ctx, action(), json!({})).unwrap()).unwrap();
    assert_eq!(result["status"], "submission_ambiguous");
    assert_eq!(venue.exchanges.lock().unwrap().len(), 1);
}

#[test]
fn public_continuation_cannot_use_api_key_to_sign_model_supplied_actions() {
    let (app, venue, mut ctx) = setup(json!({}), false);
    ctx.secrets.clear();
    let result =
        serde_json::to_value(signing::prepare(&app, &ctx, action(), json!({})).unwrap()).unwrap();
    let args: SubmitHyperliquidActionArgs =
        serde_json::from_value(result["__aomi_tool_routes"][1]["args"].clone()).unwrap();
    ctx.secrets.insert(TESTNET_KEY.name.into(), KEY.into());
    assert!(SubmitHyperliquidAction::run_with_routes(&app, args, ctx).is_err());
    assert!(venue.exchanges.lock().unwrap().is_empty());
}

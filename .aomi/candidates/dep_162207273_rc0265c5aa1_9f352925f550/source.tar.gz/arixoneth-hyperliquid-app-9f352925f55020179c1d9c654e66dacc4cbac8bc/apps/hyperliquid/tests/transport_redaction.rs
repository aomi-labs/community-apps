use hyperliquid::client::{HyperliquidVenue, hypersdk::HyperSdkVenue};
use serde_json::json;

#[test]
fn exchange_transport_errors_do_not_echo_signed_request_material() {
    for (status, body) in [
        (400, "sensitive-signature-echo"),
        (200, "invalid-json-sensitive-echo"),
    ] {
        let server = tiny_http::Server::http("127.0.0.1:0").unwrap();
        let url = format!("http://{}", server.server_addr());
        let worker = std::thread::spawn(move || {
            let request = server.recv().unwrap();
            request
                .respond(tiny_http::Response::from_string(body).with_status_code(status))
                .unwrap();
        });
        let error = HyperSdkVenue::with_base_url(url)
            .exchange(json!({"signature":"fixture"}))
            .unwrap_err();
        worker.join().unwrap();
        assert!(!error.contains(body));
    }
}

//! Explicitly invoked disposable-wallet testing. This binary cannot target mainnet.
use alloy::{
    dyn_abi::TypedData,
    signers::{SignerSync, local::PrivateKeySigner},
};
use aomi_sdk::{DynAomiTool, DynToolCallCtx, ToolReturn};
use hyperliquid::{
    client::{HyperliquidApp, HyperliquidVenue, hypersdk::HyperSdkVenue},
    domain::market::Network,
    tools::{
        continuation::{SubmitHyperliquidAction, submit_action::SubmitHyperliquidActionArgs},
        trading::PrepareCancel,
    },
};
use serde_json::{Value, json};
use std::{collections::HashMap, sync::Arc};

fn submit_signed(
    app: &HyperliquidApp,
    ctx: &DynToolCallCtx,
    prepared: ToolReturn,
    signer: &PrivateKeySigner,
) -> Result<Value, String> {
    let envelope = serde_json::to_value(prepared).map_err(|e| e.to_string())?;
    submit_envelope(app, ctx, envelope, signer)
}

fn submit_envelope(
    app: &HyperliquidApp,
    ctx: &DynToolCallCtx,
    envelope: Value,
    signer: &PrivateKeySigner,
) -> Result<Value, String> {
    if envelope.get("__aomi_tool_routes").is_none() {
        return Ok(envelope);
    }
    let routes = envelope["__aomi_tool_routes"]
        .as_array()
        .ok_or("No wallet routes")?;
    let signing = routes
        .iter()
        .find(|r| r["tool"] == "evm_commit_message" || r["tool_name"] == "evm_commit_message")
        .or_else(|| routes.first())
        .ok_or("No signing route")?;
    let data: TypedData = serde_json::from_value(signing["args"]["typed_data"].clone())
        .map_err(|e| format!("Invalid wallet typed-data route: {e}"))?;
    let signature = signer
        .sign_dynamic_typed_data_sync(&data)
        .map_err(|e| e.to_string())?;
    let continuation = routes
        .iter()
        .find(|r| {
            r["tool"] == "submit_hyperliquid_action"
                || r["tool_name"] == "submit_hyperliquid_action"
        })
        .or_else(|| routes.get(1))
        .ok_or("No continuation")?;
    let mut args: SubmitHyperliquidActionArgs =
        serde_json::from_value(continuation["args"].clone()).map_err(|e| e.to_string())?;
    args.hyperliquid_signature = Some(json!(signature.to_string()));
    let result = SubmitHyperliquidAction::run_with_routes(app, args, ctx.clone())?;
    serde_json::to_value(result).map_err(|e| e.to_string())
}

fn run() -> Result<(), String> {
    let args = std::env::args().skip(1).collect::<Vec<_>>();
    if (args.len() != 2 && !(args.len() == 4 && args[0] == "api-restore-risk"))
        || ![
            "account",
            "signed-probe",
            "roundtrip",
            "strategies",
            "twap",
            "api-all",
            "api-reads",
            "api-roundtrip",
            "api-strategies",
            "api-twap",
            "api-variants",
            "api-markets",
            "api-cleanup",
            "api-restore-risk",
        ]
        .contains(&args[0].as_str())
    {
        return Err(
            "Usage: testnet <mode> <private-key-file>; api-restore-risk also takes <cross|isolated> <leverage>; see README; always testnet"
                .into(),
        );
    }
    let path = std::path::Path::new(&args[1]);
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        if std::fs::metadata(path)
            .map_err(|_| "Cannot inspect key file")?
            .permissions()
            .mode()
            & 0o077
            != 0
        {
            return Err("Key file must not be accessible to group/other (use mode 0600)".into());
        }
    }
    let raw = std::fs::read_to_string(path).map_err(|_| "Cannot read testnet key file")?;
    let signer: PrivateKeySigner = raw.trim().parse().map_err(|_| "Invalid testnet key file")?;
    let signing_address = signer.address().to_string().to_lowercase();
    let venue = Arc::new(HyperSdkVenue::testnet());
    let app = HyperliquidApp::new(Network::Testnet, venue.clone());
    let role = venue.info(json!({"type":"userRole","user":signing_address}))?;
    let address = if role["role"] == "agent" {
        hyperliquid::domain::account::address(
            role["data"]["user"].as_str().ok_or("Agent owner missing")?,
        )?
    } else {
        signing_address.clone()
    };
    let api = args[0].starts_with("api-");
    if api && role["role"] != "agent" {
        return Err("API tests require an approved testnet API-wallet key".into());
    }
    if !api && args[0] != "account" && role["role"] == "agent" {
        return Err("This is an API wallet; use an api-* test mode".into());
    }
    let state = venue.info(json!({"type":"clearinghouseState","user":address}))?;
    println!(
        "{}",
        json!({"network":"testnet","address":address,"signing_address":signing_address,"role":role,"account":state})
    );
    if args[0] == "account" {
        return Ok(());
    }
    let ctx = DynToolCallCtx {
        session_id: "disposable-testnet-probe".into(),
        tool_name: PrepareCancel::NAME.into(),
        call_id: "cancel-probe".into(),
        state_attributes: serde_json::from_value(json!({"domain":{"evm":{"address":address}}}))
            .unwrap(),
        secrets: if api {
            [(
                hyperliquid::domain::api_wallet::TESTNET_KEY.name.into(),
                raw.trim().into(),
            )]
            .into()
        } else {
            HashMap::new()
        },
    };
    if args[0] == "api-restore-risk" {
        execute::<hyperliquid::tools::trading::PrepareRisk>(
            &app,
            &ctx,
            &signer,
            "restore_original_risk",
            json!({"intent":{"kind":"set_leverage","market":"hl:testnet:perp:BTC","margin_mode":args[2],"leverage":args[3].parse::<u32>().map_err(|_| "Invalid leverage")?}}),
        )?;
        return Ok(());
    }
    if api {
        return api_run(&app, &ctx, &signer, &args[0]);
    }
    if args[0] == "roundtrip" {
        return roundtrip(&app, &ctx, &signer);
    }
    if args[0] == "strategies" {
        return strategies(&app, &ctx, &signer);
    }
    if args[0] == "twap" {
        return twap_roundtrip(&app, &ctx, &signer);
    }
    // A nonexistent order ID exercises authorization without risking an execution.
    let prepared=PrepareCancel::run_with_routes(&app,serde_json::from_value(json!({"intent":{"kind":"exact","orders":[{"market":"hl:testnet:perp:BTC","order_id":0}]}})).map_err(|e|e.to_string())?,ctx.clone())?;
    let result = submit_signed(&app, &ctx, prepared, &signer)?;
    println!(
        "{}",
        json!({"probe":"signed_cancel_nonexistent_order","result":result})
    );
    Ok(())
}

fn strategies(
    app: &HyperliquidApp,
    ctx: &DynToolCallCtx,
    signer: &PrivateKeySigner,
) -> Result<(), String> {
    use hyperliquid::tools::trading::{PrepareClose, PrepareOrder};
    use rust_decimal::Decimal;
    use std::str::FromStr;
    let market = "hl:testnet:perp:BTC";
    let metadata = hyperliquid::domain::market::resolve(app, market)?;
    let mid = app.venue.info(json!({"type":"allMids"}))?;
    let mid =
        Decimal::from_str(mid["BTC"].as_str().ok_or("No BTC mid")?).map_err(|e| e.to_string())?;
    let price = |factor: u32| -> Result<String, String> {
        Ok(hyperliquid::domain::order::round_price(
            mid * Decimal::from(factor) / Decimal::from(100),
            &metadata,
        )?
        .normalize()
        .to_string())
    };
    execute::<PrepareOrder>(
        app,
        ctx,
        signer,
        "ladder",
        json!({"intent":{"kind":"ladder","market":market,"side":"buy","total_size":{"quote_notional":{"amount":"40"}},"start_price":price(48)?,"end_price":price(50)?,"levels":2,"allocation":"equal_notional"}}),
    )?;
    execute::<PrepareCancel>(
        app,
        ctx,
        signer,
        "cancel_ladder_scope",
        json!({"intent":{"kind":"scope","market":market,"include_triggers":true,"include_protection":true}}),
    )?;
    execute::<PrepareOrder>(
        app,
        ctx,
        signer,
        "bracket",
        json!({"intent":{"kind":"bracket","entry":{"market":market,"side":"buy","size":{"quote_notional":{"amount":"20"}},"order_type":{"kind":"market","max_slippage_bps":100}},"take_profit":{"trigger_price":price(150)?,"execution":{"kind":"market"}},"stop_loss":{"trigger_price":price(50)?,"execution":{"kind":"market"}}}}),
    )?;
    let args = json!({"intent":{"kind":"protect_position","market":market,"size":{"kind":"full_position"},"take_profit":{"trigger_price":price(140)?,"execution":{"kind":"market"}},"stop_loss":{"trigger_price":price(60)?,"execution":{"kind":"market"}},"replace_existing":true}});
    let prepared = PrepareOrder::run_with_routes(
        app,
        serde_json::from_value(args).map_err(|e| e.to_string())?,
        ctx.clone(),
    )?;
    let replacement = submit_signed(app, ctx, prepared, signer)?;
    let result = submit_envelope(app, ctx, replacement, signer)?;
    println!("{}", json!({"test":"replace_protection","result":result}));
    if result["status"] != "accepted" {
        return Err("Replacement protection was not accepted".into());
    }
    execute::<PrepareCancel>(
        app,
        ctx,
        signer,
        "cancel_protection",
        json!({"intent":{"kind":"scope","market":market,"include_triggers":true,"include_protection":true}}),
    )?;
    execute::<PrepareClose>(
        app,
        ctx,
        signer,
        "close_bracket_position",
        json!({"market":market,"size":{"kind":"full"},"max_slippage_bps":100}),
    )?;
    twap_roundtrip(app, ctx, signer)
}

fn twap_roundtrip(
    app: &HyperliquidApp,
    ctx: &DynToolCallCtx,
    signer: &PrivateKeySigner,
) -> Result<(), String> {
    use hyperliquid::tools::trading::{PrepareClose, PrepareTwap};
    let market = "hl:testnet:perp:BTC";
    let twap = execute::<PrepareTwap>(
        app,
        ctx,
        signer,
        "twap_place",
        json!({"intent":{"kind":"place","market":market,"side":"buy","size":{"quote_notional":{"amount":"120"}},"duration_minutes":5,"randomize":false}}),
    )?;
    let twap_id = twap
        .pointer("/response/response/data/status/running/twapId")
        .and_then(Value::as_u64)
        .ok_or("TWAP id missing")?;
    execute::<PrepareTwap>(
        app,
        ctx,
        signer,
        "twap_cancel",
        json!({"intent":{"kind":"cancel","market":market,"twap_id":twap_id}}),
    )?;
    let state = app.venue.info(
        json!({"type":"clearinghouseState","user":hyperliquid::domain::account::wallet(ctx)?}),
    )?;
    if state["assetPositions"]
        .as_array()
        .is_some_and(|rows| !rows.is_empty())
    {
        execute::<PrepareClose>(
            app,
            ctx,
            signer,
            "close_twap_fill",
            json!({"market":market,"size":{"kind":"full"},"max_slippage_bps":100}),
        )?;
    }
    let state = app.venue.info(
        json!({"type":"clearinghouseState","user":hyperliquid::domain::account::wallet(ctx)?}),
    )?;
    let orders = app.venue.info(
        json!({"type":"frontendOpenOrders","user":hyperliquid::domain::account::wallet(ctx)?}),
    )?;
    println!(
        "{}",
        json!({"final_positions":state["assetPositions"],"final_open_orders":orders})
    );
    if state["assetPositions"]
        .as_array()
        .is_none_or(|rows| !rows.is_empty())
        || orders.as_array().is_none_or(|rows| !rows.is_empty())
    {
        return Err("Strategy test cleanup incomplete".into());
    }
    Ok(())
}
fn main() {
    if let Err(error) = run() {
        eprintln!("{error}");
        std::process::exit(1);
    }
}

fn execute<T: DynAomiTool<App = HyperliquidApp>>(
    app: &HyperliquidApp,
    ctx: &DynToolCallCtx,
    signer: &PrivateKeySigner,
    label: &str,
    args: Value,
) -> Result<Value, String> {
    let prepared = T::run_with_routes(
        app,
        serde_json::from_value(args).map_err(|e| e.to_string())?,
        ctx.clone(),
    )?;
    let result = submit_signed(app, ctx, prepared, signer)?;
    println!("{}", json!({"test":label,"result":result}));
    if result["status"] != "accepted" {
        return Err(format!("{label} did not receive venue acceptance"));
    }
    Ok(result)
}

fn order_id(result: &Value) -> Result<u64, String> {
    result
        .pointer("/response/response/data/statuses/0/resting/oid")
        .and_then(Value::as_u64)
        .ok_or_else(|| "Venue did not return a resting order ID".into())
}

fn roundtrip(
    app: &HyperliquidApp,
    ctx: &DynToolCallCtx,
    signer: &PrivateKeySigner,
) -> Result<(), String> {
    use hyperliquid::tools::{
        portfolio::PrepareTransfer,
        trading::{PrepareClose, PrepareModify, PrepareOrder, PrepareRisk},
    };
    use rust_decimal::Decimal;
    use std::str::FromStr;
    let market = "hl:testnet:perp:BTC";
    let existing = app.venue.info(
        json!({"type":"frontendOpenOrders","user":hyperliquid::domain::account::wallet(ctx)?}),
    )?;
    let orders = existing
        .as_array()
        .ok_or("Invalid open orders")?
        .iter()
        .filter(|order| order["coin"] == "BTC")
        .map(|order| json!({"market":market,"order_id":order["oid"]}))
        .collect::<Vec<_>>();
    if !orders.is_empty() {
        execute::<PrepareCancel>(
            app,
            ctx,
            signer,
            "cleanup_previous_orders",
            json!({"intent":{"kind":"exact","orders":orders}}),
        )?;
    }
    let previous = app.venue.info(
        json!({"type":"clearinghouseState","user":hyperliquid::domain::account::wallet(ctx)?}),
    )?;
    if previous["assetPositions"]
        .as_array()
        .is_some_and(|rows| !rows.is_empty())
    {
        execute::<PrepareClose>(
            app,
            ctx,
            signer,
            "cleanup_previous_position",
            json!({"market":market,"size":{"kind":"full"},"max_slippage_bps":100}),
        )?;
    }
    let metadata = hyperliquid::domain::market::resolve(app, market)?;
    let mid = app.venue.info(json!({"type":"allMids"}))?;
    let mid =
        Decimal::from_str(mid["BTC"].as_str().ok_or("No BTC mid")?).map_err(|e| e.to_string())?;
    let half = hyperliquid::domain::order::round_price(mid / Decimal::from(2), &metadata)?
        .normalize()
        .to_string();
    let balance = app.venue.info(
        json!({"type":"clearinghouseState","user":hyperliquid::domain::account::wallet(ctx)?}),
    )?;
    let mut available = Decimal::from_str(
        balance["withdrawable"]
            .as_str()
            .ok_or("Missing withdrawable balance")?,
    )
    .map_err(|e| e.to_string())?;
    let abstraction = app.venue.info(
        json!({"type":"userAbstraction","user":hyperliquid::domain::account::wallet(ctx)?}),
    )?;
    if matches!(
        abstraction.as_str(),
        Some("unifiedAccount" | "portfolioMargin")
    ) {
        let spot = app.venue.info(json!({"type":"spotClearinghouseState","user":hyperliquid::domain::account::wallet(ctx)?}))?;
        let balance = spot["balances"]
            .as_array()
            .and_then(|rows| rows.iter().find(|row| row["coin"] == "USDC"))
            .ok_or("No unified USDC balance")?;
        available = Decimal::from_str(balance["total"].as_str().ok_or("Missing unified balance")?)
            .map_err(|e| e.to_string())?
            - Decimal::from_str(balance["hold"].as_str().ok_or("Missing unified hold")?)
                .map_err(|e| e.to_string())?;
    }
    if available < Decimal::from(50) {
        if !ctx.secrets.is_empty() {
            return Err(
                "Fund the master testnet perpetual account with at least 50 USDC before API tests"
                    .into(),
            );
        }
        execute::<PrepareTransfer>(
            app,
            ctx,
            signer,
            "fund_perpetual_balance",
            json!({"intent":{"kind":"spot_to_perp","amount":"100"}}),
        )?;
    }
    execute::<PrepareRisk>(
        app,
        ctx,
        signer,
        "set_isolated_leverage",
        json!({"intent":{"kind":"set_leverage","market":market,"leverage":2,"margin_mode":"isolated"}}),
    )?;
    let placed = execute::<PrepareOrder>(
        app,
        ctx,
        signer,
        "resting_limit",
        json!({"intent":{"kind":"orders","orders":[{"market":market,"side":"buy","size":{"quote_notional":{"amount":"20"}},"order_type":{"kind":"limit","price":half,"time_in_force":"alo"}}]}}),
    )?;
    let oid = order_id(&placed)?;
    let changed_price = hyperliquid::domain::order::round_price(
        mid * Decimal::from_str("0.49").unwrap(),
        &metadata,
    )?
    .normalize()
    .to_string();
    execute::<PrepareModify>(
        app,
        ctx,
        signer,
        "modify_remaining",
        json!({"modifications":[{"order_ref":{"market":market,"order_id":oid},"new_price":changed_price}]}),
    )?;
    let open = app.venue.info(
        json!({"type":"frontendOpenOrders","user":hyperliquid::domain::account::wallet(ctx)?}),
    )?;
    let oid = open
        .as_array()
        .and_then(|orders| orders.iter().find(|order| order["coin"] == "BTC"))
        .and_then(|order| order["oid"].as_u64())
        .ok_or("Modified resting order missing")?;
    execute::<PrepareCancel>(
        app,
        ctx,
        signer,
        "cancel_exact",
        json!({"intent":{"kind":"exact","orders":[{"market":market,"order_id":oid}]}}),
    )?;
    if ctx.secrets.is_empty() {
        execute::<PrepareTransfer>(
            app,
            ctx,
            signer,
            "perp_to_spot",
            json!({"intent":{"kind":"perp_to_spot","amount":"1"}}),
        )?;
        execute::<PrepareTransfer>(
            app,
            ctx,
            signer,
            "spot_to_perp",
            json!({"intent":{"kind":"spot_to_perp","amount":"1"}}),
        )?;
    } else {
        println!(
            "{}",
            json!({"test":"transfers", "status":"wallet_required", "reason":"API wallets cannot authorize usdClassTransfer"})
        );
    }
    execute::<PrepareOrder>(
        app,
        ctx,
        signer,
        "market_open",
        json!({"intent":{"kind":"orders","orders":[{"market":market,"side":"buy","size":{"quote_notional":{"amount":"20"}},"order_type":{"kind":"market","max_slippage_bps":100}}]}}),
    )?;
    execute::<PrepareRisk>(
        app,
        ctx,
        signer,
        "add_isolated_margin",
        json!({"intent":{"kind":"add_isolated_margin","market":market,"amount":"1"}}),
    )?;
    execute::<PrepareRisk>(
        app,
        ctx,
        signer,
        "remove_isolated_margin",
        json!({"intent":{"kind":"remove_isolated_margin","market":market,"amount":"0.5"}}),
    )?;
    execute::<PrepareClose>(
        app,
        ctx,
        signer,
        "reduce_only_close",
        json!({"market":market,"size":{"kind":"full"},"max_slippage_bps":100}),
    )?;
    let state = app.venue.info(
        json!({"type":"clearinghouseState","user":hyperliquid::domain::account::wallet(ctx)?}),
    )?;
    let open = app.venue.info(
        json!({"type":"frontendOpenOrders","user":hyperliquid::domain::account::wallet(ctx)?}),
    )?;
    println!(
        "{}",
        json!({"final_positions":state["assetPositions"],"final_open_orders":open})
    );
    if !state["assetPositions"]
        .as_array()
        .is_some_and(Vec::is_empty)
        || !open.as_array().is_some_and(Vec::is_empty)
    {
        return Err("Testnet cleanup must finish: position/order remains".into());
    }
    Ok(())
}

fn read<T: DynAomiTool<App = HyperliquidApp>>(
    app: &HyperliquidApp,
    ctx: &DynToolCallCtx,
    label: &str,
    args: Value,
) -> Result<(), String> {
    let result = T::run(
        app,
        serde_json::from_value(args).map_err(|e| e.to_string())?,
        ctx.clone(),
    )?;
    if !result.is_object() {
        return Err(format!("{label} returned a non-object"));
    }
    println!("{}", json!({"test":label,"status":"passed"}));
    Ok(())
}

fn all_reads(app: &HyperliquidApp, ctx: &DynToolCallCtx) -> Result<(), String> {
    use hyperliquid::tools::{
        portfolio::{AccountActivity, Portfolio},
        trading::{Candles, Funding, MarketSnapshot, Markets, OrderBook, Orders},
    };
    let market = "hl:testnet:perp:BTC";
    read::<Markets>(
        app,
        ctx,
        "markets_all",
        json!({"include_context":true,"limit":10}),
    )?;
    read::<MarketSnapshot>(app, ctx, "market_snapshot", json!({"market":market}))?;
    read::<OrderBook>(app, ctx, "orderbook", json!({"market":market,"depth":5}))?;
    read::<Candles>(
        app,
        ctx,
        "candles",
        json!({"market":market,"interval":"1h","limit":5}),
    )?;
    for view in ["current", "history", "predicted"] {
        read::<Funding>(
            app,
            ctx,
            &format!("funding_{view}"),
            json!({"market":market,"view":view}),
        )?;
    }
    for view in ["open", "history"] {
        read::<Orders>(
            app,
            ctx,
            &format!("orders_{view}"),
            json!({"view":view,"market":market}),
        )?;
    }
    read::<Orders>(
        app,
        ctx,
        "orders_status",
        json!({"view":"status","order_ref":{"market":market,"order_id":0}}),
    )?;
    for section in [
        "overview",
        "balances",
        "positions",
        "margin",
        "open_orders",
        "account_mode",
        "subaccounts",
        "vaults",
        "fees",
        "rate_limits",
    ] {
        read::<Portfolio>(
            app,
            ctx,
            &format!("portfolio_{section}"),
            json!({"sections":[section],"dex":""}),
        )?;
    }
    for kind in [
        "fills",
        "funding_payments",
        "ledger",
        "transfers",
        "twap_history",
    ] {
        read::<AccountActivity>(
            app,
            ctx,
            &format!("activity_{kind}"),
            json!({"kind":kind,"limit":5}),
        )?;
    }
    Ok(())
}

fn api_run(
    app: &HyperliquidApp,
    ctx: &DynToolCallCtx,
    signer: &PrivateKeySigner,
    mode: &str,
) -> Result<(), String> {
    if mode == "api-reads" {
        return all_reads(app, ctx);
    }
    if mode == "api-cleanup" {
        return cleanup_btc(app, ctx, signer);
    }
    if mode == "api-markets" {
        return other_markets(app, ctx, signer);
    }
    let owner = hyperliquid::domain::account::wallet(ctx)?;
    let orders = app
        .venue
        .info(json!({"type":"frontendOpenOrders","user":owner}))?;
    let state = app
        .venue
        .info(json!({"type":"clearinghouseState","user":owner}))?;
    if orders.as_array().is_none_or(|rows| !rows.is_empty())
        || state["assetPositions"]
            .as_array()
            .is_none_or(|rows| !rows.is_empty())
    {
        return Err(
            "Use a dedicated account with no orders or positions for the API write suite".into(),
        );
    }
    let prior_risk = app
        .venue
        .info(json!({"type":"activeAssetData","user":owner,"coin":"BTC"}))?;
    let result = match mode {
        "api-roundtrip" => roundtrip(app, ctx, signer),
        "api-strategies" => strategies(app, ctx, signer),
        "api-twap" => twap_roundtrip(app, ctx, signer),
        "api-variants" => order_variants(app, ctx, signer),
        "api-all" => (|| {
            all_reads(app, ctx)?;
            roundtrip(app, ctx, signer)?;
            order_variants(app, ctx, signer)?;
            strategies(app, ctx, signer)?;
            other_markets(app, ctx, signer)?;
            all_reads(app, ctx)
        })(),
        _ => Err("Unknown API test mode".into()),
    };
    // Inspect before cleanup, including after an interrupted/ambiguous test.
    // The dedicated-account preflight ensures these are the suite's BTC orders.
    let cleanup = cleanup_btc(app, ctx, signer);
    let restore = execute::<hyperliquid::tools::trading::PrepareRisk>(
        app,
        ctx,
        signer,
        "restore_original_leverage",
        json!({"intent":{"kind":"set_leverage","market":"hl:testnet:perp:BTC",
        "leverage":prior_risk["leverage"]["value"],"margin_mode":prior_risk["leverage"]["type"]}}),
    );
    cleanup?;
    restore?;
    result
}

fn cleanup_btc(
    app: &HyperliquidApp,
    ctx: &DynToolCallCtx,
    signer: &PrivateKeySigner,
) -> Result<(), String> {
    let owner = hyperliquid::domain::account::wallet(ctx)?;
    let orders = app
        .venue
        .info(json!({"type":"frontendOpenOrders","user":owner}))?;
    if orders
        .as_array()
        .ok_or("Missing cleanup orders")?
        .iter()
        .any(|row| row["coin"] == "BTC")
    {
        execute::<PrepareCancel>(
            app,
            ctx,
            signer,
            "cleanup_btc_orders",
            json!({"intent":{"kind":"scope","market":"hl:testnet:perp:BTC","include_triggers":true,"include_protection":true}}),
        )?;
    }
    let state = app
        .venue
        .info(json!({"type":"clearinghouseState","user":owner}))?;
    if state["assetPositions"]
        .as_array()
        .ok_or("Missing cleanup positions")?
        .iter()
        .any(|row| row["position"]["coin"] == "BTC")
    {
        execute::<hyperliquid::tools::trading::PrepareClose>(
            app,
            ctx,
            signer,
            "cleanup_btc_position",
            json!({"market":"hl:testnet:perp:BTC","size":{"kind":"full"},"max_slippage_bps":100}),
        )?;
    }
    Ok(())
}

fn order_variants(
    app: &HyperliquidApp,
    ctx: &DynToolCallCtx,
    signer: &PrivateKeySigner,
) -> Result<(), String> {
    use hyperliquid::tools::trading::{PrepareClose, PrepareModify, PrepareOrder};
    use rust_decimal::Decimal;
    use std::str::FromStr;
    let market = "hl:testnet:perp:BTC";
    let metadata = hyperliquid::domain::market::resolve(app, market)?;
    let mids = app.venue.info(json!({"type":"allMids"}))?;
    let mid =
        Decimal::from_str(mids["BTC"].as_str().ok_or("No BTC mid")?).map_err(|e| e.to_string())?;
    let price = |pct: u32| -> Result<String, String> {
        Ok(hyperliquid::domain::order::round_price(
            mid * Decimal::from(pct) / Decimal::from(100),
            &metadata,
        )?
        .normalize()
        .to_string())
    };
    let batch = execute::<PrepareOrder>(
        app,
        ctx,
        signer,
        "batch_gtc_alo",
        json!({"intent":{"kind":"orders","orders":[
            {"market":market,"side":"buy","size":{"quote_notional":{"amount":"20"}},"order_type":{"kind":"limit","price":price(48)?,"time_in_force":"gtc"}},
            {"market":market,"side":"buy","size":{"quote_notional":{"amount":"20"}},"order_type":{"kind":"limit","price":price(49)?,"time_in_force":"alo"}}
        ]}}),
    )?;
    let statuses = batch
        .pointer("/response/response/data/statuses")
        .and_then(Value::as_array)
        .ok_or("Batch statuses missing")?;
    let modifications = statuses.iter().map(|row| Ok(json!({"order_ref":{"market":market,"order_id":row["resting"]["oid"].as_u64().ok_or("Batch order did not rest")?},"new_price":price(47)?}))).collect::<Result<Vec<_>,String>>()?;
    execute::<PrepareModify>(
        app,
        ctx,
        signer,
        "batch_modify",
        json!({"modifications":modifications}),
    )?;
    execute::<PrepareCancel>(
        app,
        ctx,
        signer,
        "batch_cancel",
        json!({"intent":{"kind":"scope","market":market,"include_triggers":true,"include_protection":true}}),
    )?;
    execute::<PrepareOrder>(
        app,
        ctx,
        signer,
        "limit_ioc",
        json!({"intent":{"kind":"orders","orders":[{"market":market,"side":"buy","size":{"quote_notional":{"amount":"60"}},"order_type":{"kind":"limit","price":price(101)?,"time_in_force":"ioc"}}]}}),
    )?;
    for purpose in ["take_profit", "stop_loss"] {
        for execution in [
            json!({"kind":"market"}),
            json!({"kind":"limit","price":price(if purpose=="take_profit" {149} else {49})?}),
        ] {
            let trigger = price(if purpose == "take_profit" { 150 } else { 50 })?;
            let placed = execute::<PrepareOrder>(
                app,
                ctx,
                signer,
                &format!("trigger_{purpose}_{}", execution["kind"].as_str().unwrap()),
                json!({"intent":{"kind":"orders","orders":[{"market":market,"side":"sell","size":{"quote_notional":{"amount":"20"}},"reduce_only":true,"order_type":{"kind":"trigger","purpose":purpose,"trigger_price":trigger,"execution":execution}}]}}),
            )?;
            let oid = order_id(&placed)?;
            execute::<PrepareModify>(
                app,
                ctx,
                signer,
                "modify_trigger",
                json!({"modifications":[{"order_ref":{"market":market,"order_id":oid},"new_price":price(if purpose=="take_profit" {145} else {55})?}]}),
            )?;
            execute::<PrepareCancel>(
                app,
                ctx,
                signer,
                "cancel_trigger",
                json!({"intent":{"kind":"scope","market":market,"include_triggers":true,"include_protection":true}}),
            )?;
        }
    }
    execute::<PrepareClose>(
        app,
        ctx,
        signer,
        "partial_close",
        json!({"market":market,"size":{"kind":"position_fraction_bps","bps":5000},"max_slippage_bps":100}),
    )?;
    execute::<PrepareClose>(
        app,
        ctx,
        signer,
        "remaining_close",
        json!({"market":market,"size":{"kind":"full"},"max_slippage_bps":100}),
    )?;
    execute::<PrepareOrder>(
        app,
        ctx,
        signer,
        "limit_bracket",
        json!({"intent":{"kind":"bracket","entry":{"market":market,"side":"buy","size":{"quote_notional":{"amount":"20"}},"order_type":{"kind":"limit","price":price(50)?,"time_in_force":"gtc"}},"take_profit":{"trigger_price":price(150)?,"execution":{"kind":"limit","price":price(149)?}},"stop_loss":{"trigger_price":price(40)?,"execution":{"kind":"limit","price":price(39)?}}}}),
    )?;
    execute::<PrepareCancel>(
        app,
        ctx,
        signer,
        "cancel_limit_bracket",
        json!({"intent":{"kind":"scope","market":market,"include_triggers":true,"include_protection":true}}),
    )?;
    Ok(())
}

fn other_markets(
    app: &HyperliquidApp,
    ctx: &DynToolCallCtx,
    signer: &PrivateKeySigner,
) -> Result<(), String> {
    use hyperliquid::tools::trading::{Candles, MarketSnapshot, OrderBook, PrepareOrder};
    use rust_decimal::Decimal;
    use std::str::FromStr;
    // Official testnet HYPE/USDC spot ID and an active USDC HIP-3 index.
    // Resolve metadata afresh rather than sending hardcoded venue asset IDs.
    for market in ["hl:testnet:spot:@1035", "hl:testnet:perp:xyz:XYZ100"] {
        let metadata = hyperliquid::domain::market::resolve(app, market)?;
        let orders = app.venue.info(json!({"type":"frontendOpenOrders","user":hyperliquid::domain::account::wallet(ctx)?,"dex":metadata.dex.as_deref().unwrap_or("")}))?;
        if orders
            .as_array()
            .ok_or("Malformed orders")?
            .iter()
            .any(|row| row["coin"] == metadata.coin)
        {
            return Err("Market already has orders; refusing to disturb them".into());
        }
        read::<MarketSnapshot>(
            app,
            ctx,
            &format!("snapshot_{market}"),
            json!({"market":market}),
        )?;
        read::<OrderBook>(
            app,
            ctx,
            &format!("book_{market}"),
            json!({"market":market,"depth":3}),
        )?;
        read::<Candles>(
            app,
            ctx,
            &format!("candles_{market}"),
            json!({"market":market,"interval":"1h","limit":3}),
        )?;
        let mid = Decimal::from_str(
            metadata.context["midPx"]
                .as_str()
                .ok_or("Market has no midpoint")?,
        )
        .map_err(|e| e.to_string())?;
        let price = hyperliquid::domain::order::round_price(mid / Decimal::from(2), &metadata)?
            .normalize()
            .to_string();
        let placed = execute::<PrepareOrder>(
            app,
            ctx,
            signer,
            &format!("limit_{market}"),
            json!({"intent":{"kind":"orders","orders":[{"market":market,"side":"buy","size":{"quote_notional":{"amount":"20"}},"order_type":{"kind":"limit","price":price,"time_in_force":"alo"}}]}}),
        )?;
        execute::<PrepareCancel>(
            app,
            ctx,
            signer,
            &format!("cancel_{market}"),
            json!({"intent":{"kind":"exact","orders":[{"market":market,"order_id":order_id(&placed)?}]}}),
        )?;
    }
    Ok(())
}

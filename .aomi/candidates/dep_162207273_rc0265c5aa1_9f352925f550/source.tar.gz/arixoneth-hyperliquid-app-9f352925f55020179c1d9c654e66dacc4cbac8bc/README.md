# Hyperliquid for Aomi

A standalone Aomi SDK application for Hyperliquid market research, portfolios,
user-authorized trading, and LI.FI funding. This repository is separate from
Hoodit. The GitHub repository is private; the app manifest allows community discovery.

## Structure

- `apps/hyperliquid/src/client`: venue transport adapter; protocol serialization
  uses the locally vendored `hypersdk` source at `b7590599fd0442ae10d9734e1489a19343e32fe9`.
- `domain`: market identity, exact decimal orders, accounts, signing and funding.
- `tools/portfolio`: account aggregation/history, deposit, withdrawal, transfer.
- `tools/trading`: discovery, market data, orders, cancel/modify/close, TWAP, risk.
- `tools/continuation`: signature verification/submission and funding settlement.
- `skills`: two tool-owning core skills and four instruction-only overlays.

Only `submit_hyperliquid_action` and `complete_hyperliquid_funding` are globally
exposed. The portfolio and trading tools appear when their skills activate.
HIP-3, RWA, strategy and risk overlays add instructions without duplicate tools.

## Execution model

Write tools derive the master account from `DynToolCallCtx.domain.evm.address`.
They resolve fresh venue metadata and validate exact decimal amounts. With an
approved API-wallet secret, trading tools sign and submit immediately. Each call
reads the current user's secret, verifies the agent's owner through `userRole`,
and signs only the allowlisted trading action. Keys and signatures never enter
model-visible arguments or results. Without a key, tools retain the typed-data
wallet route. The continuation verifies the action commitment and recovered
signer before posting once to `/exchange`. A rejection, partial rejection, accepted request, pending
settlement and ambiguous submission are different states.

L1 action signatures use the phantom Agent domain. Direct user signatures follow
the official Hyperliquid Python SDK. The vendored SDK corrects signed isolated-margin removal and a 0.2.15
withdrawal type-name discrepancy (`Withdraw`, not `Withdraw3`), with an independent
cross-language signing vector. API-wallet private keys enter only through user-owned invocation secrets:
`HYPERLIQUID_API_PRIVATE_KEY` for mainnet and
`HYPERLIQUID_TESTNET_API_PRIVATE_KEY` for testnet. Both slots are optional so
read-only use and wallet signing remain available. There is no environment or
shared operator-key fallback. Master keys are rejected by the API signing path.
Transfers, withdrawals, funding and account-mode changes retain wallet routes.

Markets use canonical references such as `hl:mainnet:perp:BTC`,
`hl:mainnet:perp:xyz:AAPL` and `hl:mainnet:spot:@107`. Raw venue asset IDs stay
inside the domain layer. An ambiguous bare symbol is rejected.

Deposits resolve source tokens through LI.FI, check exact allowances, simulate
wallet transactions, then require matching bridge status and HyperCore ledger
credit. Withdrawals settle on Arbitrum first. An onward route is quoted only after
matching withdrawal-ledger and Arbitrum token-transfer evidence. Merely accepting
a signature or submitting a transaction is never reported as settled.

## Development and tests

Requires Rust 1.93 or newer. The app pins the published SDK 5.1.1 release that
introduced user-owned application credentials. Deploy only to a host requiring
the same SDK version.
`Cargo.lock` is committed. Local builds use the Aomi workflow's managed cache:

```sh
export AOMI_CARGO_CACHE_ROOT=/path/to/aomi/.worktrees/.state/cache/cargo
./scripts/check test --locked
./scripts/check clippy --locked --package hyperliquid --all-targets --no-deps -- -D warnings
cargo fmt --all -- --check
```

The normal suite uses fixtures and fixed test-only signing keys. Opt-in live
checks call public read-only endpoints, never `/exchange`:

```sh
./scripts/check test --locked --test live_readonly -- --ignored --test-threads=1
```

Use a disposable testnet wallet for signed exchange testing. Store its
key in a local file outside this repository with mode `0600`; never commit it.
The API runner injects it into the same user-secret context used by the app.
It discovers the master account from the agent role and cannot target mainnet.

```sh
./scripts/check run --example testnet -- api-all /path/to/testnet-api-wallet.key
./scripts/check run --example testnet -- api-reads /path/to/testnet-api-wallet.key
# Legacy master-wallet route tests (separate disposable account):
./scripts/check run --example testnet -- roundtrip /path/to/testnet.key
./scripts/check run --example testnet -- strategies /path/to/testnet.key
```

The runner is hard-bound to testnet. API modes exercise the app's actual secret
signing path; legacy modes exercise wallet routes. The write suite requires an
account with no existing orders/positions and checks cleanup. Unified account
collateral is read from spot; a zero per-DEX balance is not an unfunded account. Use only
a dedicated test wallet: the roundtrip clears its existing BTC orders/position.
An interrupted run may need cleanup before rerunning.

## Operational boundaries

- App default is Hyperliquid mainnet; test fixtures and the testnet runner construct
  an explicit testnet adapter. Network references and signatures are bound.
- Nonces are monotonic per signer/network within one process. This is not a
  distributed nonce allocator: concurrent signing for the same wallet across
  app replicas needs shared coordination before unattended production use.
- `/exchange` is never automatically retried after a transport failure. Inspect
  order status/fills/account history before preparing a replacement action.
- Native TWAP runs at the venue. Unattended market making, repricing grids and
  custom trailing stops still need a separately scheduled strategy implementation.
- Scope cancellation requires explicit TWAP IDs when including TWAPs because the
  REST API does not provide a safe active-master enumeration endpoint.
- LI.FI funding is mainnet-only. Route availability and fees are provider-dependent.

## Staging

Project: [1665](https://build-staging.aomi.dev/projects/1665?platform=community),
platform `community`, backend `https://api-staging.aomi.dev`.
The root `.aomi/config.json` is the only platform/composition authority.
Deploy only a pushed, tested immutable commit; preflight, build/release, promote,
and runtime chat verification are separate steps.

See [verification.md](docs/verification.md) for evidence and remaining live tests.

### Focused API test modes

`api-all` runs reads, native BTC order/risk variants, protection and TWAP,
then spot/HIP-3 market probes and post-trade reads. Focused modes are
`api-reads`, `api-roundtrip`, `api-variants`, `api-strategies`, `api-twap`, and
`api-markets`. `api-cleanup` cancels BTC orders and closes its position on the
dedicated test account. `api-restore-risk <key-file> <cross|isolated> <leverage>`
restores a separately recorded baseline after a terminated older run. Normal
API suites restore their captured leverage/margin setting automatically.
These tools use test assets but do place real orders on the testnet venue.

import { NextResponse } from "next/server";
import { CHAIN } from "@/lib/chain";
import { apiBase } from "@/lib/api";
import { requestChain } from "@/lib/envelope";
import type { ChainKey } from "@/lib/chainChoice";
import { CARD_HEADER, mintCard, throwawayKey } from "@/lib/agentcard";
import { TEXT_CAP, matchedFilters, verdictOf, type ScreenVerdict } from "@/lib/screen";
import { SCREEN_THROTTLE, Throttle, callerKey } from "@/lib/throttle";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/* POST /api/screen — send a visitor's text through Google Cloud Model Armor, live.
 *
 * The screen sits on POST /graph/query for CARDED callers and inspects
 * `{operation, variables}` in both directions (armor.py::request_text). So the
 * smallest true demonstration is: a card, the `meta` operation, and the visitor's
 * text in `variables.note`. A 403 back names the filter Google fired and never
 * echoes the text; a 200 with the inspection counter up by one is a pass; a 200
 * with the counter unchanged is what an ANONYMOUS call looks like — never
 * screened, because a browser reader behind a proxy is not agent-to-agent
 * traffic. The `carded` toggle shows both.
 *
 * ONE CARD FOR EVERY VISITOR, minted here and never sent to a browser. A card per
 * visitor would give each of them their own per-key budget at the API, and the
 * key would be free to mint — exactly the hole the human tier exists to close.
 * One key means every visitor shares one budget, which is the honest shape.
 * Re-minted when it nears its 15-minute bound. The text is capped well under the
 * screen's own cap.
 */

const TIMEOUT_MS = 15_000;
const REMINT_MARGIN_S = 60;

interface HeldCard {
  header: string;
  expiresAt: number;
}
let held: HeldCard | null = null;
let heldKey: `0x${string}` | null = null;
const throttle = new Throttle(SCREEN_THROTTLE);

async function card(chain: ChainKey): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  if (held && held.expiresAt - now > REMINT_MARGIN_S) return held.header;
  heldKey ??= await throwawayKey();
  type Challenge = { audience?: string; chain_id?: number };
  const ch: Challenge = await fetch(`${apiBase(chain)}/agent/challenge`, {
    cache: "no-store",
    headers: { accept: "application/json" },
    signal: AbortSignal.timeout(TIMEOUT_MS),
  })
    .then((r) => r.json() as Promise<Challenge>)
    .catch((): Challenge => ({}));
  const minted = await mintCard({
    privateKey: heldKey,
    chainId: Number(ch.chain_id ?? CHAIN.chainId),
    audience: String(ch.audience ?? "acr-index-api"),
    name: "acr-terminal-screen-lab",
    role: "reader",
    ttlSeconds: 900,
  });
  held = { header: minted.header, expiresAt: minted.expiresAt };
  return minted.header;
}

async function armorCounts(chain: ChainKey): Promise<{ screened: number; blocked: number } | null> {
  try {
    const r = await fetch(`${apiBase(chain)}/armor/info`, { cache: "no-store", signal: AbortSignal.timeout(TIMEOUT_MS) });
    const j = (await r.json()) as { screened?: number; blocked?: number };
    return { screened: Number(j.screened ?? 0), blocked: Number(j.blocked ?? 0) };
  } catch {
    return null;
  }
}

export interface ScreenResult {
  status: number | null;
  verdict: ScreenVerdict;
  matched: string[];
  /** The refusal never carries the refused text. Asserted, not assumed. */
  echoed: boolean;
  ms: number;
  carded: boolean;
  screened_delta: number | null;
  blocked_delta: number | null;
  counts: { screened: number; blocked: number } | null;
  note: string | null;
}

export async function POST(request: Request) {
  const chain = requestChain(request);
  let body: { text?: unknown; carded?: unknown } = {};
  try {
    body = (await request.json()) as typeof body;
  } catch {
    /* handled below */
  }
  const text = typeof body.text === "string" ? body.text.slice(0, TEXT_CAP) : "";
  const carded = body.carded !== false;
  if (!text.trim()) {
    return NextResponse.json({ detail: "text is required" }, { status: 400 });
  }
  // One card for everyone means one budget for everyone; this keeps one visitor
  // — or one crawler — from spending it. The API's per-key budget is the backstop.
  const gate = throttle.allow(callerKey(request.headers));
  if (!gate.ok) {
    return NextResponse.json(
      {
        detail:
          gate.reason === "caller"
            ? `easy: ${SCREEN_THROTTLE.perKey} sends a minute per visitor, so the lab's one shared card lasts for everyone. Try again in ${gate.retryInS}s`
            : `the lab is busy: ${SCREEN_THROTTLE.global} sends a minute across all visitors. Try again in ${gate.retryInS}s`,
        retry_in_s: gate.retryInS,
      },
      { status: 429, headers: { "Retry-After": String(gate.retryInS), "Cache-Control": "no-store" } },
    );
  }

  const before = await armorCounts(chain);
  const started = Date.now();
  let status: number | null = null;
  let answer: unknown = null;
  let note: string | null = null;
  try {
    const headers: Record<string, string> = { "content-type": "application/json", accept: "application/json" };
    if (carded) headers[CARD_HEADER] = await card(chain);
    const res = await fetch(`${apiBase(chain)}/graph/query`, {
      method: "POST",
      cache: "no-store",
      headers,
      body: JSON.stringify({ operation: "meta", variables: { note: text } }),
      signal: AbortSignal.timeout(TIMEOUT_MS),
    });
    status = res.status;
    answer = await res.json().catch(() => null);
  } catch (e) {
    const timedOut = e instanceof Error && e.name === "TimeoutError";
    note = timedOut ? "the press did not answer in time. It sleeps between visits, so press again" : "the press is unreachable";
  }
  const ms = Date.now() - started;
  const after = await armorCounts(chain);
  const screenedDelta = before && after ? after.screened - before.screened : null;
  const blockedDelta = before && after ? after.blocked - before.blocked : null;

  const out: ScreenResult = {
    status,
    verdict: verdictOf(status, screenedDelta, carded),
    matched: matchedFilters(answer),
    echoed: answer != null && JSON.stringify(answer).includes(text),
    ms,
    carded,
    screened_delta: screenedDelta,
    blocked_delta: blockedDelta,
    counts: after,
    note,
  };
  return NextResponse.json(out, { headers: { "Cache-Control": "no-store" } });
}

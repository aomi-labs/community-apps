#!/usr/bin/env python3
"""Talk to Hoodit on Aomi chat one turn at a time, like a user.

The guest session is kept in a small state file so follow-ups continue the
same conversation. Prints the answer and a compact line per tool call.

  scripts/hoodit-chat.py --new "what's good rn?"
  scripts/hoodit-chat.py "why that one over the others?"
  scripts/hoodit-chat.py --show-tools "check 0x..."
"""
from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path
import time
import urllib.parse

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("smoke", ROOT / "scripts" / "hoodit-staging-smoke.py")
smoke = importlib.util.module_from_spec(spec)
spec.loader.exec_module(smoke)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("message")
    parser.add_argument("--new", action="store_true", help="start a fresh guest conversation")
    parser.add_argument("--state", default=str(Path.home() / ".cache" / "hoodit-chat.json"))
    parser.add_argument("--base", default="https://chat-staging.aomi.dev")
    parser.add_argument("--application-id", type=int, default=2937810)
    parser.add_argument("--model", default="gpt-6-luna")
    parser.add_argument("--show-tools", action="store_true", help="print each tool result in full")
    parser.add_argument("--timeout", type=int, default=300)
    args = parser.parse_args()
    base = args.base.rstrip("/")
    state_path = Path(args.state)
    state = {} if args.new or not state_path.exists() else json.loads(state_path.read_text())
    if not state.get("token"):
        state = {"token": smoke.request_json(f"{base}/api/auth/widget/guest", origin=base, method="POST", body={})["access_token"], "seen": []}
    payload = {"applicationId": args.application_id, "message": args.message, "model": args.model}
    if state.get("session"):
        payload["sessionId"] = state["session"]
    started = time.monotonic()
    delta = smoke.normalize_delta(smoke.request_json(f"{base}/v1/agent/chat", token=state["token"], origin=base, method="POST", body=payload))
    state["session"] = delta.get("sessionId") or state.get("session")
    deltas = [delta]
    status = delta.get("status")
    while status not in ("complete", "failed", "cancelled", "interrupted") or delta.get("hasMore"):
        if time.monotonic() - started > args.timeout:
            print("(timed out)")
            break
        query = urllib.parse.urlencode({"cursor": delta.get("cursor", ""), "wait": 30000})
        delta = smoke.normalize_delta(smoke.request_json(f"{base}/v1/agent/chat/{urllib.parse.quote(state['session'])}?{query}", token=state["token"], origin=base))
        deltas.append(delta)
        status = delta.get("status") or status
    seen = set(state.get("seen", []))
    answer = ""
    for d in deltas:
        for m in d.get("messages", []):
            key = m.get("id")
            if key in seen or m.get("streaming"):
                continue
            if m.get("toolName") and m.get("toolResult") is not None:
                seen.add(key)
                result = m["toolResult"]
                text = result[1] if isinstance(result, list) and len(result) == 2 and isinstance(result[1], str) else json.dumps(result)
                print(f"· {m['toolName']} {json.dumps(m.get('toolArguments'))[:160]} → {len(text)} chars")
                if args.show_tools:
                    print(text)
            elif m.get("role") == "agent" and str(m.get("content", "")).strip():
                seen.add(key)
                answer = str(m["content"]).strip()
    state["seen"] = sorted(seen)
    state_path.parent.mkdir(parents=True, exist_ok=True)
    state_path.write_text(json.dumps(state))
    print(f"\n[{status} in {time.monotonic() - started:.0f}s]\n")
    print(answer)


if __name__ == "__main__":
    main()

Use hl_portfolio for balances, positions, margin, account mode, open orders, subaccounts, vaults, fees and rate limits. Public read-only inspection may specify an address; all movements derive identity from the connected wallet. HyperCore spot and perpetual balances are distinct. HIP-3 DEX margin accounts and collateral may differ: select the DEX explicitly. Report decimals and units faithfully; missing data is unknown, never zero. Use hl_account_activity for fills, funding payments, transfers and TWAP history. Market funding belongs to trading.

For unified account or portfolio margin, collateral lives in spot balances. A zero per-DEX summary does not mean the account is unfunded. Use the returned account_mode, balances and summary_scope; never treat unknown aggregate equity as zero.
Use `hl_validate_api_wallet` to verify a saved mainnet or testnet API-wallet
credential without placing an order or changing account state. Report only the
validated owner/agent identities returned by the tool; never request or echo a
private key in chat.

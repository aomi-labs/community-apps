use std::sync::Arc;

use alloy::signers::local::PrivateKeySigner;
use aomi_sdk::{DynToolCallCtx, resolve_user_secret_value};
use schemars::JsonSchema;
use serde::Deserialize;
use serde_json::{Value, json};

use crate::{
    client::{HyperliquidApp, hypersdk::HyperSdkVenue},
    domain::{account::wallet, api_wallet, market::Network},
};

#[derive(Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct ValidateApiWalletArgs {
    pub network: Network,
}

pub fn run(
    app: &HyperliquidApp,
    args: ValidateApiWalletArgs,
    ctx: DynToolCallCtx,
) -> Result<Value, String> {
    let selected = match args.network {
        Network::Mainnet => app.clone(),
        Network::Testnet => {
            HyperliquidApp::new(Network::Testnet, Arc::new(HyperSdkVenue::testnet()))
        }
    };
    let slot = api_wallet::key_name(args.network);
    if !ctx.secrets.contains_key(slot) {
        return Err(format!(
            "No user-owned {} API-wallet credential is configured",
            args.network.as_str()
        ));
    }
    let raw = resolve_user_secret_value(&ctx, slot, "Hyperliquid API-wallet credential is empty")?;
    let signer: PrivateKeySigner = raw
        .trim()
        .parse()
        .map_err(|_| "Invalid Hyperliquid API-wallet credential")?;
    let agent = signer.address().to_string().to_lowercase();
    let role = selected
        .venue
        .info(json!({"type": "userRole", "user": agent}))?;
    if role["role"] != "agent" {
        return Err("Use an approved API-wallet key, not a master-wallet key".into());
    }
    let owner = role
        .pointer("/data/user")
        .and_then(Value::as_str)
        .ok_or("Hyperliquid did not identify the API wallet's owner")?
        .to_lowercase();
    let connected_account = wallet(&ctx)?;

    Ok(json!({
        "credential_resolved": true,
        "api_wallet_approved": true,
        "connected_account_match": owner == connected_account,
        "network": args.network,
        "owner": owner,
        "connected_account": connected_account,
        "agent": agent,
        "writes_submitted": false,
    }))
}

read_tool!(
    ValidateApiWallet,
    ValidateApiWalletArgs,
    "hl_validate_api_wallet",
    "Resolve the selected user-owned Hyperliquid API-wallet credential, verify its venue-approved agent role, and report whether its owner matches the connected account. This is read-only and never signs or submits an exchange action.",
    run
);

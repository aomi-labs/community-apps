use aomi_sdk::DynAomiApp;
use hyperliquid::client::HyperliquidApp;
use serde_json::{Map, Value};
use std::collections::HashSet;

#[derive(Clone, Copy)]
enum Children {
    Map,
    Direct,
    List,
    None,
}

fn children(key: &str) -> Children {
    match key {
        "properties" | "$defs" | "definitions" => Children::Map,
        "items" | "additionalProperties" => Children::Direct,
        "anyOf" | "oneOf" | "allOf" => Children::List,
        _ => Children::None,
    }
}

fn normalize(schema: &mut Value, root: bool) {
    let Value::Object(object) = schema else {
        return;
    };
    object.remove("uniqueItems");
    if root {
        object.remove("anyOf");
        object.remove("oneOf");
        object.remove("allOf");
        object
            .entry("type")
            .or_insert_with(|| Value::String("object".into()));
    } else if let Some(one_of) = object.remove("oneOf") {
        object.insert("anyOf".into(), one_of);
    }
    if object.get("type").and_then(Value::as_str) == Some("object") {
        object
            .entry("properties")
            .or_insert_with(|| Value::Object(Map::new()));
        if let Some(properties) = object.get("properties").and_then(Value::as_object) {
            object.insert(
                "required".into(),
                Value::Array(properties.keys().cloned().map(Value::String).collect()),
            );
        }
    }
    for (key, value) in object {
        match children(key) {
            Children::Map => {
                if let Value::Object(map) = value {
                    for child in map.values_mut() {
                        normalize(child, false);
                    }
                }
            }
            Children::Direct => normalize(value, false),
            Children::List => {
                if let Value::Array(items) = value {
                    for child in items {
                        normalize(child, false);
                    }
                }
            }
            Children::None => {}
        }
    }
}

fn validate(schema: &Value, path: &str, root: bool) {
    let object = schema
        .as_object()
        .unwrap_or_else(|| panic!("{path} is a bare or malformed schema: {schema}"));
    let is_object = object.get("type").and_then(Value::as_str) == Some("object");
    if root || is_object {
        let properties = object
            .get("properties")
            .and_then(Value::as_object)
            .unwrap_or_else(|| panic!("{path} is an object schema without properties"));
        let declared = properties
            .keys()
            .map(String::as_str)
            .collect::<HashSet<_>>();
        let required = object
            .get("required")
            .and_then(Value::as_array)
            .unwrap_or_else(|| panic!("{path} is missing required"))
            .iter()
            .filter_map(Value::as_str)
            .collect::<HashSet<_>>();
        assert_eq!(declared, required, "{path} has an invalid required list");
    }
    for (key, value) in object {
        match children(key) {
            Children::Map => {
                let map = value
                    .as_object()
                    .unwrap_or_else(|| panic!("{path}.{key} is not a schema map"));
                for (name, child) in map {
                    validate(child, &format!("{path}.{key}.{name}"), false);
                }
            }
            Children::Direct => {
                if key != "additionalProperties" || !value.is_boolean() {
                    validate(value, &format!("{path}.{key}"), false);
                }
            }
            Children::List => {
                let items = value
                    .as_array()
                    .unwrap_or_else(|| panic!("{path}.{key} is not a schema list"));
                for (index, child) in items.iter().enumerate() {
                    validate(child, &format!("{path}.{key}[{index}]"), false);
                }
            }
            Children::None => {}
        }
    }
}

#[test]
fn all_tools_have_unique_provider_safe_schemas_and_actionable_skills() {
    let manifest = HyperliquidApp::default().manifest();
    assert_eq!(manifest.tools.len(), 20);
    assert_eq!(manifest.skills.len(), 2);
    let names = manifest
        .tools
        .iter()
        .map(|tool| tool.name.as_str())
        .collect::<HashSet<_>>();
    assert_eq!(names.len(), 20);
    for tool in &manifest.tools {
        let mut schema = tool.parameters_schema.clone();
        normalize(&mut schema, true);
        validate(&schema, &tool.name, true);
    }
    let trading = manifest
        .skills
        .iter()
        .find(|skill| skill.id == "hyperliquid/trading")
        .expect("trading skill");
    assert_eq!(trading.injected_tools.len(), 12);
    for required in ["hl_markets", "hl_market_snapshot", "hl_prepare_order"] {
        assert!(
            trading.injected_tools.iter().any(|tool| tool == required),
            "trading skill is missing {required}"
        );
    }
    let portfolio = manifest
        .skills
        .iter()
        .find(|skill| skill.id == "hyperliquid/portfolio")
        .expect("portfolio skill");
    assert!(
        portfolio
            .injected_tools
            .iter()
            .any(|tool| tool == "hl_validate_api_wallet"),
        "portfolio skill is missing the read-only API-wallet validator"
    );
    for guidance in ["hip3", "rwa", "strategies", "risk"] {
        assert!(
            trading
                .sections
                .iter()
                .any(|section| section.name == guidance),
            "trading skill is missing {guidance} guidance"
        );
    }
    assert_eq!(manifest.name, "hyperliquid");
    assert!(manifest.preamble.len() < 1500);
}

#[test]
fn api_wallet_slots_are_optional_user_owned_and_network_specific() {
    let slots = HyperliquidApp::default().manifest().secrets.unwrap();
    assert_eq!(slots.len(), 2);
    assert!(slots.iter().all(|slot| slot.user_own && !slot.required));
    assert_ne!(slots[0].name, slots[1].name);
}

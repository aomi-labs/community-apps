//! One token snapshot, built the same way for every tool: GMGN token info
//! and security first (flow, liquidity, ATH and holder mix are GMGN's; the
//! audit found Codex's wrong or inconsistent there), Codex as fallback,
//! and the Pons launch record from chain for stage, curve and dev.
use super::market::{Pair, Stage, TradeSupport, known_pair, launchpad, pair_of, trade_support};
use super::pons::{self, Curve, Dev};
use crate::providers::chain::Chain;
use crate::providers::codex::{Codex, types as cx};
use crate::providers::gmgn::{Gmgn, types as gm};
use crate::providers::text;
use crate::runtime::{Fail, Runtime, Source, Turn};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Window {
    M5,
    H1,
    H4,
    H6,
    H24,
}

impl Window {
    pub fn label(self) -> &'static str {
        match self {
            Window::M5 => "5m",
            Window::H1 => "1h",
            Window::H4 => "4h",
            Window::H6 => "6h",
            Window::H24 => "24h",
        }
    }
}

/// Buy and sell dollars and trade counts over one window.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Flow {
    pub buy_usd: Option<f64>,
    pub sell_usd: Option<f64>,
    pub buys: Option<f64>,
    pub sells: Option<f64>,
}

/// Share of supply or trading (percent 0–100) held or done by each kind of
/// wallet.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct HolderMix {
    pub dev_pct: Option<f64>,
    pub dev_team_pct: Option<f64>,
    pub snipers_pct: Option<f64>,
    pub bundler_trading_pct: Option<f64>,
    pub rat_trading_pct: Option<f64>,
    pub bot_degen_pct: Option<f64>,
    pub fresh_wallet_pct: Option<f64>,
}

/// How many holders carry each GMGN wallet tag.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct TaggedWallets {
    pub smart: Option<f64>,
    pub kol: Option<f64>,
    pub snipers: Option<f64>,
    pub bundlers: Option<f64>,
    pub whales: Option<f64>,
    pub fresh: Option<f64>,
    pub rats: Option<f64>,
}

/// GMGN's contract screen. `None` fields are unknown.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct Security {
    pub honeypot: Option<bool>,
    pub buy_tax_pct: Option<f64>,
    pub sell_tax_pct: Option<f64>,
    pub renounced: Option<bool>,
    pub open_source: Option<bool>,
    pub blacklist: Option<bool>,
    /// GMGN says the pool's liquidity is locked or burnt.
    pub lp_locked: Option<bool>,
    pub flags: Vec<String>,
}

impl Security {
    /// A red flag that rules out a buy on its own.
    pub fn red_flag(&self) -> bool {
        self.honeypot == Some(true) || self.sell_tax_pct.is_some_and(|t| t > 10.0)
    }
}

#[derive(Clone, Debug, Default, PartialEq)]
pub struct Socials {
    pub twitter: Option<String>,
    pub website: Option<String>,
    pub telegram: Option<String>,
}

#[derive(Clone, Debug, PartialEq)]
pub struct TokenSnapshot {
    pub token: String,
    pub symbol: Option<String>,
    pub name: Option<String>,
    pub launchpad: Option<String>,
    pub stage: Stage,
    pub pair: Option<Pair>,
    pub created_at: Option<i64>,
    pub price_usd: Option<f64>,
    pub fdv_usd: Option<f64>,
    pub liquidity_usd: Option<f64>,
    pub volume_24h_usd: Option<f64>,
    pub change_pct: Vec<(Window, f64)>,
    pub flow: Vec<(Window, Flow)>,
    pub holders: Option<f64>,
    /// Top 10 wallets; pools, curves and lockers excluded.
    pub top10_pct: Option<f64>,
    pub mix: HolderMix,
    pub tagged: TaggedWallets,
    pub ath_usd: Option<f64>,
    /// Launchpad curve progress 0–100 while on a curve (any launchpad).
    pub curve_pct: Option<f64>,
    /// Pons curve read from chain: raised and target.
    pub curve: Option<Curve>,
    pub creator: Option<String>,
    pub dev: Option<Dev>,
    /// The creator has sold out (GMGN).
    pub dev_sold_out: Option<bool>,
    pub creator_tax_pct: Option<f64>,
    pub socials: Socials,
    pub security: Option<Security>,
    pub last_trade_at: Option<i64>,
    pub source: Source,
}

impl TokenSnapshot {
    pub fn trade_support(&self) -> TradeSupport {
        trade_support(
            self.launchpad.as_deref(),
            self.stage,
            self.pair.as_ref().map(|p| p.kind),
        )
    }

    pub fn from_gmgn(info: gm::TokenInfo) -> Self {
        let p = &info.price;
        let now = p.price.get();
        let change = |then: crate::providers::Num| match (now, then.get()) {
            (Some(n), Some(t)) if t > 0.0 => Some((n / t - 1.0) * 100.0),
            _ => None,
        };
        let change_pct = [
            (Window::M5, change(p.price_5m)),
            (Window::H1, change(p.price_1h)),
            (Window::H6, change(p.price_6h)),
            (Window::H24, change(p.price_24h)),
        ]
        .into_iter()
        .filter_map(|(w, v)| v.map(|v| (w, v)))
        .collect();
        let flow = vec![
            (
                Window::M5,
                flow(p.buy_volume_5m, p.sell_volume_5m, p.buys_5m, p.sells_5m),
            ),
            (
                Window::H1,
                flow(p.buy_volume_1h, p.sell_volume_1h, p.buys_1h, p.sells_1h),
            ),
            (
                Window::H6,
                flow(p.buy_volume_6h, p.sell_volume_6h, p.buys_6h, p.sells_6h),
            ),
            (
                Window::H24,
                flow(p.buy_volume_24h, p.sell_volume_24h, p.buys_24h, p.sells_24h),
            ),
        ];
        let launchpad = launchpad(info.launchpad_platform.as_deref());
        let progress = info.launchpad_progress.get();
        let stage = gmgn_stage(launchpad.is_some(), info.launchpad_status.get(), progress);
        let s = &info.stat;
        let t = &info.wallet_tags_stat;
        let supply = info.total_supply.get();
        Self {
            token: info.address.to_ascii_lowercase(),
            symbol: info.symbol.clone(),
            name: info.name.clone(),
            launchpad,
            stage,
            pair: text(&info.pool.quote_address).and_then(known_pair),
            created_at: info.creation_timestamp.ts().or(info.open_timestamp.ts()),
            price_usd: now,
            fdv_usd: now.zip(supply).map(|(p, s)| p * s),
            liquidity_usd: info.liquidity.get(),
            volume_24h_usd: p.volume_24h.get(),
            change_pct,
            flow,
            holders: info.holder_count.get(),
            top10_pct: s.top_10_holder_rate.pct(),
            mix: HolderMix {
                dev_pct: s.creator_hold_rate.pct(),
                dev_team_pct: s.dev_team_hold_rate.pct(),
                snipers_pct: s.top70_sniper_hold_rate.pct(),
                bundler_trading_pct: s.top_bundler_trader_percentage.pct(),
                rat_trading_pct: s.top_rat_trader_percentage.pct(),
                bot_degen_pct: s.bot_degen_rate.pct(),
                fresh_wallet_pct: s.fresh_wallet_rate.pct(),
            },
            tagged: TaggedWallets {
                smart: t.smart_wallets.get(),
                kol: t.renowned_wallets.get(),
                snipers: t.sniper_wallets.get(),
                bundlers: t.bundler_wallets.get(),
                whales: t.whale_wallets.get(),
                fresh: t.fresh_wallets.get(),
                rats: t.rat_trader_wallets.get(),
            },
            ath_usd: info.ath_price.get(),
            curve_pct: (stage == Stage::Curve)
                .then(|| progress.map(|p| p * 100.0))
                .flatten(),
            curve: None,
            creator: text(&info.dev.creator_address).map(str::to_ascii_lowercase),
            dev: None,
            dev_sold_out: text(&info.dev.creator_token_status).map(|s| s == "creator_close"),
            creator_tax_pct: None,
            socials: Socials {
                twitter: text(&info.link.twitter_username).map(str::to_string),
                website: text(&info.link.website).map(str::to_string),
                telegram: text(&info.link.telegram).map(str::to_string),
            },
            security: None,
            last_trade_at: None,
            source: Source::Gmgn,
        }
    }

    /// The fallback card from Codex's deepest-pool view.
    pub fn from_codex(row: cx::Token) -> Self {
        let token = row.token.address.to_ascii_lowercase();
        let pad = row.token.launchpad.as_ref();
        let graduated = pad.is_some_and(|l| l.completed == Some(true) || l.migrated == Some(true));
        let launchpad = launchpad(pad.and_then(|l| l.launchpad_name.as_deref()));
        let stage = match (&launchpad, graduated) {
            (None, _) => Stage::Pool,
            (Some(_), true) => Stage::Graduated,
            (Some(_), false) => Stage::Curve,
        };
        let other_side = match (&row.pair.token0, &row.pair.token1) {
            (Some(a), Some(b)) if a.eq_ignore_ascii_case(&token) => Some(b.as_str()),
            (Some(a), _) => Some(a.as_str()),
            _ => None,
        };
        let change_pct = [
            (Window::H1, row.change1.pct()),
            (Window::H4, row.change4.pct()),
            (Window::H24, row.change24.pct()),
        ]
        .into_iter()
        .filter_map(|(w, v)| v.map(|v| (w, v)))
        .collect();
        Self {
            token,
            symbol: row.token.symbol.clone(),
            name: row.token.name.clone(),
            curve_pct: None,
            launchpad,
            stage,
            pair: other_side.and_then(known_pair),
            created_at: row.token.created_at.ts().or(row.created_at.ts()),
            price_usd: row.price_usd.get(),
            fdv_usd: row.market_cap.get(),
            liquidity_usd: row.liquidity.get(),
            volume_24h_usd: row.volume24.get(),
            change_pct,
            flow: vec![
                (
                    Window::H1,
                    flow(
                        row.buy_volume1,
                        row.sell_volume1,
                        Default::default(),
                        Default::default(),
                    ),
                ),
                (
                    Window::H24,
                    flow(
                        row.buy_volume24,
                        row.sell_volume24,
                        Default::default(),
                        Default::default(),
                    ),
                ),
            ],
            holders: row.holders.get(),
            top10_pct: None,
            mix: HolderMix {
                dev_pct: row.dev_held_percentage.get(),
                snipers_pct: row.sniper_held_percentage.get(),
                ..HolderMix::default()
            },
            tagged: TaggedWallets::default(),
            ath_usd: row.ath_price.get(),
            curve: None,
            creator: text(&row.token.creator_address).map(str::to_ascii_lowercase),
            dev: None,
            dev_sold_out: None,
            creator_tax_pct: None,
            socials: Socials::default(),
            security: None,
            last_trade_at: row.last_transaction.ts(),
            source: Source::Codex,
        }
    }

    pub fn flow(&self, window: Window) -> Option<&Flow> {
        self.flow.iter().find(|(w, _)| *w == window).map(|(_, f)| f)
    }
}

fn flow(
    buy: crate::providers::Num,
    sell: crate::providers::Num,
    buys: crate::providers::Num,
    sells: crate::providers::Num,
) -> Flow {
    Flow {
        buy_usd: buy.get(),
        sell_usd: sell.get(),
        buys: buys.get(),
        sells: sells.get(),
    }
}

/// GMGN's `launchpad_status` is 1 once graduated; progress 0–1 on a curve.
pub fn gmgn_stage(on_launchpad: bool, status: Option<f64>, progress: Option<f64>) -> Stage {
    if !on_launchpad {
        return Stage::Pool;
    }
    if status == Some(1.0) || progress.is_some_and(|p| p >= 1.0) {
        Stage::Graduated
    } else {
        Stage::Curve
    }
}

pub fn security(raw: gm::Security) -> Security {
    Security {
        honeypot: raw.honeypot.get(),
        buy_tax_pct: raw.buy_tax.pct(),
        sell_tax_pct: raw.sell_tax.pct(),
        renounced: raw.renounced.get(),
        open_source: raw.open_source.get(),
        blacklist: raw.blacklist.get(),
        lp_locked: raw.lock_summary.is_locked.get(),
        flags: raw.flags.into_iter().take(6).collect(),
    }
}

/// What a watcher polls: curve progress and whether the coin graduated.
/// Progress reads 100 from the moment the curve is swept, so "ping me at
/// 90%" never misses a graduation between polls; `graduated` turns 1 only
/// once it trades in a pool. A rescued (failed) launch is neither.
pub fn watch_progress(snap: &TokenSnapshot) -> (Option<f64>, Option<bool>) {
    match snap.stage {
        Stage::Curve => (snap.curve_pct, Some(false)),
        Stage::Graduating => (Some(100.0), Some(false)),
        Stage::Graduated => (Some(100.0), Some(true)),
        Stage::Rescued => (None, Some(false)),
        Stage::Pool => (None, None),
    }
}

/// How much of the snapshot to fill in.
#[derive(Clone, Copy, PartialEq, Eq)]
pub enum Depth {
    /// Market numbers and stage (watch polls).
    Basic,
    /// Everything on the card: security, Pons curve, dev, pair.
    Card,
}

/// Reads one token: GMGN info (and security for a card), falling back to
/// Codex when GMGN can't answer; then Pons stage, curve and dev from chain.
pub async fn snapshot(
    rt: &Runtime,
    turn: &Turn,
    token: &str,
    depth: Depth,
) -> Result<TokenSnapshot, Fail> {
    let gmgn = Gmgn::new(rt, turn);
    let chain = Chain::new(rt, turn);
    let card = depth == Depth::Card;
    let (info, security, launch) = tokio::join!(
        gmgn.token_info(token),
        async {
            if card {
                Some(gmgn.security(token).await)
            } else {
                None
            }
        },
        chain.pons(token)
    );
    let mut snap = match info {
        Ok(info) if !info.address.is_empty() => TokenSnapshot::from_gmgn(info),
        Ok(_) | Err(_) => {
            let why = match &info {
                Err(Fail::NotFound(_)) | Ok(_) => "gmgn doesn't list it".to_string(),
                Err(fail) => fail.message(),
            };
            let row = Codex::new(rt, turn).token(token).await?;
            turn.gap(format!(
                "{why}; card from codex's deepest pool (flow, liquidity and ATH may undercount)"
            ));
            TokenSnapshot::from_codex(row)
        }
    };
    match security {
        Some(Ok(s)) => snap.security = Some(self::security(s)),
        Some(Err(_)) => turn.gap("contract security screen unavailable"),
        None => {}
    }
    match launch {
        Ok(Some(launch)) => {
            snap.stage = pons::stage(&launch);
            snap.launchpad = Some("pons".into());
            snap.curve_pct = pons::curve_pct(&chain, &launch).await;
            if card {
                snap.pair = pair_of(&chain, &launch.pair_token).await;
                snap.curve = pons::curve(&chain, &launch).await;
                snap.creator_tax_pct = Some(launch.creator_tax_bps as f64 / 100.0);
                snap.dev = pons::dev(&chain, Some(&launch), snap.creator.as_deref()).await;
            }
        }
        Ok(None) => {
            if card {
                snap.dev = pons::dev(&chain, None, snap.creator.as_deref()).await;
            }
        }
        Err(_) if snap.launchpad.as_deref() == Some("pons") => {
            turn.gap("Pons launch record unreadable; stage and curve are gmgn's");
        }
        Err(_) => {}
    }
    Ok(snap)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn info(name: &str) -> gm::TokenInfo {
        let text = std::fs::read_to_string(format!(
            "{}/src/fixtures/gmgn/{name}.json",
            env!("CARGO_MANIFEST_DIR")
        ))
        .unwrap();
        let body: serde_json::Value = serde_json::from_str(&text).unwrap();
        serde_json::from_value(body["data"].clone()).unwrap()
    }

    #[test]
    fn gmgn_snapshot_reads_flow_mix_and_stage() {
        let snap = TokenSnapshot::from_gmgn(info("info_vrax"));
        assert_eq!(snap.symbol.as_deref(), Some("VRAX"));
        assert_eq!(snap.launchpad.as_deref(), Some("pons"));
        assert_eq!(snap.stage, Stage::Graduated);
        assert_eq!(snap.pair.as_ref().map(|p| p.symbol.as_str()), Some("USDG"));
        assert!((snap.top10_pct.unwrap() - 14.28).abs() < 1e-9);
        assert_eq!(snap.tagged.kol, Some(17.0));
        let h1 = snap.flow(Window::H1).unwrap();
        assert!((h1.buy_usd.unwrap() - 6956.34338423).abs() < 1e-6);
        assert_eq!(snap.dev_sold_out, Some(true));
        assert!((snap.fdv_usd.unwrap() - 981_121.35).abs() < 1.0);
        assert_eq!(snap.trade_support(), TradeSupport::Full);
    }

    #[test]
    fn gmgn_stage_rules() {
        assert_eq!(gmgn_stage(false, None, None), Stage::Pool);
        assert_eq!(gmgn_stage(true, Some(0.0), Some(0.4)), Stage::Curve);
        assert_eq!(gmgn_stage(true, Some(1.0), Some(1.0)), Stage::Graduated);
    }

    #[test]
    fn security_red_flags() {
        let mut s = Security::default();
        assert!(!s.red_flag());
        s.sell_tax_pct = Some(12.0);
        assert!(s.red_flag());
    }
}

//! Admission control, one gate per provider. Every request asks its gate
//! before it goes out; a refusal turns into a stale answer or a gap.
use super::{Fail, Source};
use std::collections::{HashMap, VecDeque};
use std::sync::Mutex;
use std::time::{Duration, Instant};

/// Watch polls run in their own lane so they can never starve a chat.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum Lane {
    #[default]
    Chat,
    Watch,
}

/// GMGN's free plan allows 5 weight a second per IP and counts it per
/// window: a 1-weight call followed 0.3 s later by a 5-weight call is
/// refused, and repeats earn an IP ban that blocks every user on the host.
/// We allow 5 weight per 1.4 s rolling window, about 70% of the plan.
const GMGN_CAPACITY: u32 = 5;
const GMGN_WINDOW: Duration = Duration::from_millis(1400);
/// A chat call waits at most this long in the queue; longer means a gap.
const GMGN_MAX_WAIT: Duration = Duration::from_secs(4);
/// Weight a watch poll must leave free in the window for chats.
const GMGN_WATCH_HEADROOM: u32 = 2;

/// Paid Codex requests one thread may make within [`CODEX_WINDOW`], about
/// one answer's worth. The host passes no turn id, so the thread is the unit.
pub const CODEX_PER_THREAD: usize = 16;
const CODEX_WINDOW: Duration = Duration::from_secs(120);
/// Paid Codex requests per host per UTC day (~$0.001 each), by lane.
const CODEX_DAILY_CHAT: u32 = 5000;
const CODEX_DAILY_WATCH: u32 = 1500;

/// Keyless LI.FI allows ~100 quotes per 2 h per IP; stay well under it.
const LIFI_KEYLESS_PER_HOUR: u32 = 40;

#[derive(Default)]
pub struct Gates {
    gmgn: Mutex<Window>,
    codex: Mutex<Spend>,
    lifi: Mutex<Option<(Instant, u32)>>,
}

/// GMGN requests sent or scheduled, by send time, oldest first.
#[derive(Default)]
struct Window {
    sent: VecDeque<(Instant, u32)>,
    paused_until: Option<Instant>,
}

#[derive(Default)]
struct Spend {
    day: i64,
    chat: u32,
    watch: u32,
    threads: HashMap<String, VecDeque<Instant>>,
}

/// What a request costs at its gate.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Cost {
    /// GMGN rate-limit weight.
    Gmgn(u32),
    /// One paid Codex request.
    Codex,
    /// One LI.FI quote; keyed quotes aren't paced here.
    Lifi {
        keyed: bool,
    },
    Free,
}

impl Gates {
    /// Admits one request, returning how long to wait before sending it.
    pub fn admit(&self, cost: Cost, lane: Lane, thread: &str) -> Result<Duration, Fail> {
        let now = Instant::now();
        match cost {
            Cost::Gmgn(weight) => self.admit_gmgn(weight, lane, now),
            Cost::Codex => self
                .admit_codex(thread, lane, now, crate::view::now() / 86_400)
                .map(|()| Duration::ZERO),
            Cost::Lifi { keyed } => self.admit_lifi(keyed, now).map(|()| Duration::ZERO),
            Cost::Free => Ok(Duration::ZERO),
        }
    }

    /// Whether a request that already waited in the queue may still go.
    pub fn still_open(&self, cost: Cost) -> Result<(), Fail> {
        if !matches!(cost, Cost::Gmgn(_)) {
            return Ok(());
        }
        let window = self
            .gmgn
            .lock()
            .map_err(|_| Fail::Budget("gmgn gate poisoned"))?;
        match window.paused_until {
            Some(until) if Instant::now() < until => Err(Fail::RateLimited {
                source: Source::Gmgn,
                retry_after_s: (until - Instant::now()).as_secs().max(1),
            }),
            _ => Ok(()),
        }
    }

    /// Stops GMGN traffic until `retry_after_s` from now (a 429 or a ban).
    pub fn pause_gmgn(&self, retry_after_s: u64) {
        let Ok(mut window) = self.gmgn.lock() else {
            return;
        };
        let until = Instant::now() + Duration::from_secs(retry_after_s.max(2));
        window.paused_until = Some(window.paused_until.map_or(until, |p| p.max(until)));
    }

    /// Schedules a GMGN request at the earliest time its weight fits in
    /// the rolling window, after every request already scheduled (FIFO).
    fn admit_gmgn(&self, weight: u32, lane: Lane, now: Instant) -> Result<Duration, Fail> {
        let mut window = self
            .gmgn
            .lock()
            .map_err(|_| Fail::Budget("gmgn gate poisoned"))?;
        if let Some(until) = window.paused_until {
            if now < until {
                return Err(Fail::RateLimited {
                    source: Source::Gmgn,
                    retry_after_s: (until - now).as_secs().max(1),
                });
            }
            window.paused_until = None;
        }
        while window
            .sent
            .front()
            .is_some_and(|(at, _)| *at + GMGN_WINDOW <= now)
        {
            window.sent.pop_front();
        }
        let weight = weight.min(GMGN_CAPACITY);
        let mut at = window.sent.back().map_or(now, |(last, _)| (*last).max(now));
        // Move `at` past the oldest requests until the window from `at`
        // back holds room for this one.
        loop {
            let used: u32 = window
                .sent
                .iter()
                .filter(|(t, _)| *t + GMGN_WINDOW > at)
                .map(|(_, w)| w)
                .sum();
            if used + weight <= GMGN_CAPACITY {
                break;
            }
            let Some(next) = window
                .sent
                .iter()
                .map(|(t, _)| *t + GMGN_WINDOW)
                .find(|expires| *expires > at)
            else {
                break;
            };
            at = next;
        }
        let wait = at.saturating_duration_since(now);
        let refused = match lane {
            Lane::Chat => wait > GMGN_MAX_WAIT,
            Lane::Watch => {
                let used: u32 = window.sent.iter().map(|(_, w)| w).sum();
                !wait.is_zero() || used + weight > GMGN_CAPACITY - GMGN_WATCH_HEADROOM
            }
        };
        if refused {
            return Err(Fail::Budget("gmgn request queue is full right now"));
        }
        window.sent.push_back((at, weight));
        Ok(wait)
    }

    fn admit_codex(&self, thread: &str, lane: Lane, now: Instant, today: i64) -> Result<(), Fail> {
        let mut spend = self
            .codex
            .lock()
            .map_err(|_| Fail::Budget("codex gate poisoned"))?;
        if spend.day != today {
            *spend = Spend {
                day: today,
                ..Spend::default()
            };
        }
        spend.threads.retain(|_, calls| {
            while calls
                .front()
                .is_some_and(|t| now.duration_since(*t) > CODEX_WINDOW)
            {
                calls.pop_front();
            }
            !calls.is_empty()
        });
        let (used, cap) = match lane {
            Lane::Chat => (spend.chat, CODEX_DAILY_CHAT),
            Lane::Watch => (spend.watch, CODEX_DAILY_WATCH),
        };
        if used >= cap {
            return Err(Fail::Budget("daily market-data budget used up"));
        }
        let recent = spend.threads.get(thread).map_or(0, VecDeque::len);
        if lane == Lane::Chat && recent >= CODEX_PER_THREAD {
            return Err(Fail::Budget("this answer's market-data budget is used up"));
        }
        match lane {
            Lane::Chat => spend.chat += 1,
            Lane::Watch => spend.watch += 1,
        }
        spend
            .threads
            .entry(thread.to_string())
            .or_default()
            .push_back(now);
        Ok(())
    }

    fn admit_lifi(&self, keyed: bool, now: Instant) -> Result<(), Fail> {
        if keyed {
            return Ok(());
        }
        let mut window = self
            .lifi
            .lock()
            .map_err(|_| Fail::Budget("quote gate poisoned"))?;
        let (start, used) = window.get_or_insert((now, 0));
        if now.duration_since(*start) >= Duration::from_secs(3600) {
            *start = now;
            *used = 0;
        }
        if *used >= LIFI_KEYLESS_PER_HOUR {
            return Err(Fail::RateLimited {
                source: Source::Lifi,
                retry_after_s: 600,
            });
        }
        *used += 1;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn gmgn_never_puts_more_than_5_weight_in_a_window() {
        let gates = Gates::default();
        let t0 = Instant::now();
        // A card (1 + 1) then a holder list (5): the list waits for the
        // window to clear instead of going out 0.3 s later.
        assert_eq!(gates.admit_gmgn(1, Lane::Chat, t0).unwrap(), Duration::ZERO);
        assert_eq!(gates.admit_gmgn(1, Lane::Chat, t0).unwrap(), Duration::ZERO);
        assert_eq!(gates.admit_gmgn(5, Lane::Chat, t0).unwrap(), GMGN_WINDOW);
        // FIFO: a small call queues behind it rather than jumping ahead.
        assert_eq!(
            gates.admit_gmgn(1, Lane::Chat, t0).unwrap(),
            GMGN_WINDOW * 2
        );
        // Past four seconds of queue the call is refused, not queued.
        assert!(gates.admit_gmgn(5, Lane::Chat, t0).is_err());
        // Every 1.4 s window of what was scheduled holds at most 5.
        let sent = gates.gmgn.lock().unwrap().sent.clone();
        for (start, _) in &sent {
            let inside: u32 = sent
                .iter()
                .filter(|(t, _)| *t >= *start && *t < *start + GMGN_WINDOW)
                .map(|(_, w)| w)
                .sum();
            assert!(inside <= GMGN_CAPACITY, "{inside} in one window");
        }
        // Once the window has passed, calls go straight out.
        let later = t0 + Duration::from_secs(10);
        assert_eq!(
            gates.admit_gmgn(5, Lane::Chat, later).unwrap(),
            Duration::ZERO
        );
    }

    #[test]
    fn watch_polls_leave_room_for_chat() {
        let gates = Gates::default();
        let t0 = Instant::now();
        assert!(gates.admit_gmgn(1, Lane::Watch, t0).is_ok());
        assert!(gates.admit_gmgn(2, Lane::Chat, t0).is_ok());
        // 3 of 5 used: a watch poll would leave less than 2 for chat.
        assert!(gates.admit_gmgn(1, Lane::Watch, t0).is_err());
        assert!(gates.admit_gmgn(2, Lane::Chat, t0).is_ok());
    }

    #[test]
    fn a_pause_refuses_until_reset() {
        let gates = Gates::default();
        gates.pause_gmgn(30);
        let err = gates.admit_gmgn(1, Lane::Chat, Instant::now()).unwrap_err();
        assert!(matches!(err, Fail::RateLimited { retry_after_s, .. } if retry_after_s >= 29));
        let later = Instant::now() + Duration::from_secs(31);
        assert!(gates.admit_gmgn(1, Lane::Chat, later).is_ok());
    }

    #[test]
    fn codex_budget_is_per_thread_window_and_refusals_are_free() {
        let gates = Gates::default();
        let t0 = Instant::now();
        for _ in 0..CODEX_PER_THREAD {
            gates.admit_codex("a", Lane::Chat, t0, 1).unwrap();
        }
        assert!(gates.admit_codex("a", Lane::Chat, t0, 1).is_err());
        assert!(gates.admit_codex("a", Lane::Chat, t0, 1).is_err());
        // Refusals didn't count against the day.
        assert_eq!(gates.codex.lock().unwrap().chat, CODEX_PER_THREAD as u32);
        assert!(gates.admit_codex("b", Lane::Chat, t0, 1).is_ok());
        // The thread's window slides.
        let later = t0 + CODEX_WINDOW + Duration::from_secs(1);
        assert!(gates.admit_codex("a", Lane::Chat, later, 1).is_ok());
        // Watch polls have their own daily count and no thread window.
        for _ in 0..30 {
            gates.admit_codex("w", Lane::Watch, later, 1).unwrap();
        }
    }

    #[test]
    fn keyless_quotes_are_paced() {
        let gates = Gates::default();
        let t0 = Instant::now();
        for _ in 0..LIFI_KEYLESS_PER_HOUR {
            gates.admit_lifi(false, t0).unwrap();
        }
        assert!(gates.admit_lifi(false, t0).is_err());
        assert!(gates.admit_lifi(true, t0).is_ok());
    }
}

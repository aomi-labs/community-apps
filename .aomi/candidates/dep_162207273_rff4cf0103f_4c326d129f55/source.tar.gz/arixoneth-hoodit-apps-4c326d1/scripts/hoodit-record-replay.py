#!/usr/bin/env python3
"""Re-record the offline replay fixture for apps/hoodit/tests/replay.rs.

Runs the replay plan live (real keys, about $0.01 of Codex and 25 GMGN
weight), then keeps only the fields Hoodit reads so the fixture stays small:

  set -a; . ~/.config/hoodit/mpp-test-wallet.env; . ~/.config/hoodit/gmgn.env; set +a
  export LIFI_API_KEY=...
  scripts/hoodit-record-replay.py
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "apps" / "hoodit"
PLAN = APP / "tests" / "fixtures" / "replay-plan.json"
OUT = APP / "tests" / "fixtures" / "replay.json"


def gmgn_fields() -> set[str]:
    src = (APP / "src" / "providers" / "gmgn" / "types.rs").read_text()
    fields = set(re.findall(r"pub (\w+):", src)) | set(re.findall(r'alias = "(\w+)"', src))
    # Envelopes and list keys around the typed rows.
    return fields | {"data", "rank", "list", "coins", "activities", "tokens", "code",
                     "new_creation", "near_completion", "completed", "$fail", "message", "source"}


def slim_gmgn(value, fields):
    if isinstance(value, dict):
        return {k: slim_gmgn(v, fields) for k, v in value.items() if k in fields}
    if isinstance(value, list):
        return [slim_gmgn(v, fields) for v in value]
    return value


def slim_lifi(value):
    if "$fail" in value:
        return value
    e = value["estimate"]
    costs = lambda key: [{"amountUSD": c.get("amountUSD")} for c in e.get(key) or []]
    return {
        "estimate": {"toAmount": e["toAmount"], "toAmountMin": e.get("toAmountMin"),
                     "feeCosts": costs("feeCosts"), "gasCosts": costs("gasCosts")},
        "includedSteps": [{"tool": s.get("tool"), "toolDetails": {"name": (s.get("toolDetails") or {}).get("name")}}
                          for s in value.get("includedSteps") or []],
    }


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        recorded = Path(tmp) / "recorded.json"
        subprocess.run(
            ["cargo", "run", "-q", "-p", "hoodit", "--example", "live", "--", str(PLAN)],
            cwd=ROOT, check=True, stdout=subprocess.DEVNULL,
            env={**os.environ, "HOODIT_RECORD": str(recorded)},
        )
        raw = json.loads(recorded.read_text())
    fields = gmgn_fields()
    out = {}
    for key, value in raw.items():
        if key.startswith("gmgn:"):
            value = slim_gmgn(value, fields)
        elif key.startswith("lifi:"):
            value = slim_lifi(value)
        out[key] = value
    OUT.write_text(json.dumps(out, separators=(",", ":"), ensure_ascii=False, sort_keys=True))
    print(f"{len(out)} responses, {OUT.stat().st_size // 1024} KB -> {OUT.relative_to(ROOT)}")


if __name__ == "__main__":
    main()

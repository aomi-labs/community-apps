import type { Event } from "@aomi-labs/client";
import { describe, expect, it } from "vitest";

import { CampaignTrace } from "./campaign-trace.ts";

const message = (sequence: number, sender: string, content: string) =>
  ({ type: "message", sequence, sender, content }) as unknown as Event;
const error = (sequence: number, text: string) => ({ type: "error", sequence, message: text }) as unknown as Event;

describe("CampaignTrace", () => {
  it.each([
    "execution_limit_reached: This agent reached its execution limit. Send another message to continue.",
    "This run reached its active-work time limit. Send another message to continue.",
  ])("flags a resumable runtime limit: %s", (notice) => {
    const trace = new CampaignTrace([message(1, "user", "fuzz it"), message(2, "system", notice)]);
    expect(trace.resumable).toBe(true);
  });

  it("is not resumable once the user has continued, or after other errors", () => {
    expect(
      new CampaignTrace([
        message(1, "system", "execution_limit_reached: …"),
        message(2, "user", CampaignTrace.CONTINUE_PROMPT),
      ]).resumable,
    ).toBe(false);
    const capped = new CampaignTrace([error(3, "guest model input exceeds the runtime cap")]);
    expect(capped.resumable).toBe(false);
    expect(capped.errors).toEqual(["guest model input exceeds the runtime cap"]);
  });

  it("keeps every event in the ledger with a one-line label", () => {
    const trace = new CampaignTrace([
      message(1, "user", "fuzz it"),
      { type: "turn_state_changed", sequence: 2, state: "processing" } as unknown as Event,
      error(3, "boom"),
    ]);
    expect(trace.ledger.map((entry) => [entry.sequence, entry.type, entry.label])).toEqual([
      [1, "message", "user: fuzz it"],
      [2, "turn_state_changed", "processing"],
      [3, "error", "boom"],
    ]);
  });

  it("starts the campaign when a turn stopped before arc_fuzz_start", () => {
    const beforeStart = new CampaignTrace([message(1, "user", "fuzz it")]);
    expect(beforeStart.continuationPrompt).toContain("No fuzz campaign has started yet");
    expect(beforeStart.continuationPrompt).toContain("call arc_fuzz_start");

    const started = new CampaignTrace([
      {
        type: "tool_complete",
        sequence: 2,
        id: "start-1",
        tool_name: "arc-studio-fuzzer::arc_fuzz_start",
        result: JSON.stringify({ campaign_id: "campaign-1" }),
      } as unknown as Event,
    ]);
    expect(started.continuationPrompt).toBe(CampaignTrace.CONTINUE_PROMPT);
  });

  it("reads the campaign report from a round's compact progress", () => {
    const progress = { campaign_id: "0xabc", status: "exploring", round: 2, executions: 9, findings: [] };
    const trace = new CampaignTrace([
      {
        type: "tool_complete",
        sequence: 5,
        id: "c1",
        tool_name: "arc-studio-fuzzer::arc_fuzz_round",
        result: JSON.stringify({ next_batch: null, progress }),
      } as unknown as Event,
    ]);
    expect(trace.report?.round).toBe(2);
  });

  it("keeps the runtime's notice as the reason a turn stopped", () => {
    const reason = "This guest session's conversation is too long for another model call. Sign in to an Aomi account to continue longer runs.";
    const trace = new CampaignTrace([message(1, "user", "fuzz it"), message(2, "notice", reason)]);
    expect(trace.notice).toBe(reason);
    expect(new CampaignTrace([message(2, "notice", reason), message(3, "user", "again")]).notice).toBeUndefined();
  });
});

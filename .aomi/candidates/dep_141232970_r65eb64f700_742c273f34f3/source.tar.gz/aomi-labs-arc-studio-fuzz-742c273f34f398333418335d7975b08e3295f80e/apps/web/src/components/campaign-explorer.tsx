import { useEffect, useMemo, useRef, useState } from "react";
import { ChevronDown, ChevronRight, GitBranch, LocateFixed } from "lucide-react";
import type { CampaignTrace } from "@aomi-labs/arc-studio-fuzz-core";
import { campaignPhase, exploration, nodeState, object, type PathNode } from "@/lib/exploration";

const short = (value: string) => (value.length > 18 ? `${value.slice(0, 8)}…${value.slice(-6)}` : value);
const label = (node: PathNode) =>
  node.call.action?.function ?? `${node.call.label} · ${node.call.data.slice(0, 10) || "call"}`;
function tone(state: string) {
  if (state === "Confirmed finding") return "text-danger border-danger/35 bg-danger/8";
  if (state === "Simulation error" || state === "Replay failed" || state === "Incomplete result")
    return "text-warning border-warning/35 bg-warning/10";
  if (state === "Executing") return "text-accent-strong border-accent/40 bg-accent/10";
  return "text-ink-muted border-border bg-bg";
}

export function CampaignProgress({
  trace,
  busy,
  preparing,
  stopped,
  failure,
  visible = true,
}: {
  trace: CampaignTrace;
  busy: boolean;
  preparing: boolean;
  stopped: boolean;
  failure: string | null;
  visible?: boolean;
}) {
  const { report, rows } = trace;
  const hypothesis =
    report?.hypothesis ?? object(rows.find((row) => row.name === "arc_fuzz_start")?.arguments).hypothesis;
  const [age, setAge] = useState(0);
  const lastEvent = trace.ledger.at(-1)?.key;
  useEffect(() => {
    setAge(0);
    if (!busy || !visible) return;
    const since = Date.now();
    const timer = setInterval(() => setAge(Math.floor((Date.now() - since) / 1000)), 1000);
    return () => clearInterval(timer);
  }, [lastEvent, busy, visible]);
  const phase = failure
    ? "Needs attention"
    : stopped
      ? busy
        ? "Stopping"
        : "Stopped"
      : campaignPhase(report, rows, busy, preparing);
  const active = busy ? rows.findLast((row) => row.state === "calling") : undefined;
  const activities: Record<string, string> = {
    arc_map_attack_surface: "Reading the contract and identifying callable functions",
    arc_source: "Reading contract source",
    arc_fuzz_start: "Building the first execution batch",
    arc_fuzz_round: "Checking replay evidence and choosing the next paths",
    arc_fuzz_report: "Collecting campaign evidence",
    sim_replay_traces: "Running ordered transaction sequences from the baseline",
    sim_open: "Opening an isolated Arc fork",
    sim_set_code: "Installing code in the simulation",
    sim_set_balance: "Funding simulation actors",
    sim_snapshot: "Saving the baseline snapshot",
    sim_call: "Checking contract state",
    sim_close: "Releasing the fork",
  };
  const activity = preparing
    ? "Opening an isolated Arc fork"
    : active
      ? (activities[active.name] ?? "Agent is working on the campaign")
      : busy
        ? "Waiting for the agent’s next step"
        : report?.status === "complete"
          ? "The bounded campaign has finished"
          : "Campaign state is preserved; use Continue to resume";
  return (
    <section aria-label="Campaign progress" className="mb-3 shrink-0 rounded-lg border border-border bg-bg p-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="flex items-center gap-2 text-sm font-semibold">
          <span className={`size-2 rounded-full ${busy ? "animate-pulse bg-accent" : "bg-ink-muted"}`} />
          {phase}
        </h2>
        <span className={`text-[11px] ${busy && age >= 30 ? "text-warning" : "text-ink-muted"}`}>
          {busy
            ? age >= 30
              ? `No new events for ${age}s`
              : `Listening for updates${lastEvent ? ` · #${trace.ledger.at(-1)?.sequence}` : ""}`
            : `${rows.length} tool calls observed`}
        </span>
      </div>
      <p role="status" className="mt-1 text-xs text-ink-muted">
        {activity}
      </p>
      {typeof hypothesis === "string" && (
        <p title={hypothesis} className="mt-1 truncate text-xs text-ink-muted">
          Testing: {hypothesis}
        </p>
      )}
      {phase === "Confirming violation" && (
        <p className="mt-2 text-xs text-ink-muted">
          Minimizing the candidate and replaying from the baseline. Only two clean reproductions confirm a finding.
        </p>
      )}
      {report?.status === "budget_exhausted" && (
        <p className="mt-2 text-xs text-warning">
          Execution budget reached with work remaining. This is an incomplete campaign.
        </p>
      )}
      <dl className="mt-3 grid grid-cols-2 gap-2 text-xs sm:grid-cols-4">
        {[
          ["Executions / budget", report ? `${report.executions} / ${report.max_executions ?? "—"}` : "—"],
          ["Queued frontier", report?.frontier_size ?? "—"],
          ["States expanded", report?.corpus_size ?? "—"],
          ["Confirmed findings", report?.findings.length ?? 0],
        ].map(([name, value]) => (
          <div key={name} className="rounded-sm bg-surface-2 px-2 py-1.5">
            <dt className="text-[10px] text-ink-muted">{name}</dt>
            <dd className="mt-0.5 font-mono">{value}</dd>
          </div>
        ))}
      </dl>
      {report && report.max_executions > 0 && (
        <div className="mt-2">
          <progress
            aria-label="Execution budget used"
            className="campaign-budget h-1.5 w-full"
            max={report.max_executions}
            value={Math.min(report.executions, report.max_executions)}
          />
          <p className="text-[10px] text-ink-muted">
            Budget used · exploration is bounded, not a measure of contract safety
          </p>
        </div>
      )}
    </section>
  );
}

export function CampaignExplorer({
  trace,
  busy,
  targetName,
}: {
  trace: CampaignTrace;
  busy: boolean;
  targetName?: string;
}) {
  const tree = useMemo(() => exploration(trace.rows, trace.report, targetName), [trace.rows, trace.report, targetName]);
  const [selected, setSelected] = useState<string>();
  const [follow, setFollow] = useState(true);
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [attempt, setAttempt] = useState<string>();
  const selectedRef = useRef<HTMLDivElement>(null);
  const newest = [...tree.replays].reverse().find((replay) => replay.state === "Executing") ?? tree.replays.at(-1);
  const liveNode = newest ? [...tree.nodes.values()].find((node) => node.replays.includes(newest)) : undefined;
  const node = tree.nodes.get(follow ? (liveNode?.id ?? "") : (selected ?? "")) ?? liveNode;
  const replay = node?.replays.find((item) => item.id === attempt) ?? node?.replays.at(-1);
  useEffect(() => {
    if (!follow || !liveNode) return;
    setExpanded((previous) => {
      const next = new Set(previous);
      for (const candidate of tree.nodes.values())
        if (liveNode.id.startsWith(candidate.id.slice(0, -1))) next.add(candidate.id);
      return next;
    });
  }, [follow, liveNode?.id]); // Only a newly observed path changes automatic expansion.
  useEffect(() => {
    if (follow)
      selectedRef.current?.scrollIntoView({
        block: "nearest",
        behavior: "smooth",
      });
  }, [follow, node?.id]);
  const choose = (id: string) => {
    setSelected(id);
    setFollow(false);
    setAttempt(undefined);
  };
  const toggle = (id: string) => {
    setFollow(false);
    setExpanded((previous) => {
      const next = new Set(previous);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };
  return (
    <section
      aria-label="Fuzz tree"
      className="@container flex min-h-0 flex-1 flex-col overflow-hidden rounded-lg border border-border bg-bg"
    >
      <div className="flex shrink-0 flex-wrap items-center justify-between gap-2 border-b border-border px-3 py-2">
        <h3 className="flex items-center gap-2 text-xs font-semibold">
          <GitBranch className="size-4 text-accent" />
          Observed execution tree
        </h3>
        <button
          aria-pressed={follow}
          onClick={() => {
            setSelected(node?.id);
            setFollow(!follow);
          }}
          className="flex items-center gap-1 rounded-pill border border-border px-2 py-1 text-[11px] hover:bg-hover"
        >
          <LocateFixed className="size-3" />
          {follow ? "Following latest" : "Follow latest"}
        </button>
      </div>
      <p
        className="shrink-0 px-3 py-1.5 text-[11px] text-ink-muted"
        title="Branches show issued call sequences. Shared prefixes are grouped; retries and confirmations stay in replay history. Unissued frontier and individual pruning decisions are not in this view."
      >
        {tree.replays.length} issued replays · {tree.nodes.size} call nodes · observed paths only
      </p>
      {tree.roots.length === 0 ? (
        <div className="overflow-auto px-4 py-8 text-center text-xs text-ink-muted">
          {trace.report
            ? "Replay details are not present in the available event history. Campaign counters above reflect the latest report."
            : "The agent is reading the contract and planning actions. Paths appear when the first replay batch is issued."}
        </div>
      ) : (
        <div className="grid min-h-0 flex-1 grid-rows-2 @min-[600px]:grid-cols-2 @min-[600px]:grid-rows-1">
          <div className="min-h-0 overflow-auto border-t border-border p-3" aria-label="Observed execution paths">
            <div className="mb-2 text-[11px] text-ink-muted">● Baseline snapshot</div>
            <TreeLevel
              nodes={tree.roots}
              busy={busy}
              selected={node?.id}
              expanded={expanded}
              choose={choose}
              toggle={toggle}
              selectedRef={selectedRef}
            />
          </div>
          <div
            aria-label="Selected path"
            className="min-h-0 min-w-0 overflow-auto border-t border-border bg-surface-2/40 p-3 @min-[600px]:border-l"
          >
            {node && (
              <>
                <h4 className="text-xs font-semibold">
                  Selected path · {node.path.length} call
                  {node.path.length === 1 ? "" : "s"}
                </h4>
                {node.confirmed.map((property) => (
                  <p key={property} className="mt-2 text-xs text-danger">
                    Confirmed finding: {property} · reproduced 2×
                  </p>
                ))}
                <ol className="mt-3 space-y-2">
                  {node.path.map((call, index) => (
                    <li key={index} className="rounded-md border border-border bg-bg p-2 text-[11px]">
                      <div className="flex items-start justify-between gap-2">
                        <span className="break-words font-mono">
                          {index + 1}. {call.action?.actor ?? short(call.from)} →{" "}
                          {call.action?.contract ? `${call.action.contract}.` : ""}
                          {call.action?.function ?? call.label}
                        </span>
                        <span className="shrink-0 text-ink-muted">{replay?.statuses[index] ?? "Unobserved"}</span>
                      </div>
                      {call.action && (
                        <p className="mt-1 break-all text-ink-muted">
                          Arguments: {call.action.arguments?.join(", ") || "none"}
                        </p>
                      )}
                      <details className="mt-1 text-ink-muted">
                        <summary className="cursor-pointer">Call data and addresses</summary>
                        <dl className="mt-1 space-y-1 break-all font-mono">
                          <div>
                            <dt>From</dt>
                            <dd>{call.from}</dd>
                          </div>
                          <div>
                            <dt>To</dt>
                            <dd>{call.to}</dd>
                          </div>
                          <div>
                            <dt>Value (base units)</dt>
                            <dd>{call.value}</dd>
                          </div>
                          <div>
                            <dt>Calldata</dt>
                            <dd>{call.data}</dd>
                          </div>
                        </dl>
                      </details>
                    </li>
                  ))}
                </ol>
                {node.replays.length > 0 ? (
                  <>
                    <label className="mt-3 block text-[11px]">
                      Replay history
                      <select
                        aria-label="Replay history"
                        value={replay?.id}
                        onChange={(event) => setAttempt(event.target.value)}
                        className="mt-1 block w-full rounded-sm border border-border bg-bg p-1.5 font-mono text-[11px]"
                      >
                        {node.replays.map((item) => (
                          <option key={item.id} value={item.id}>
                            {item.id} · {item.state === "Executing" && !busy ? "Awaiting result" : item.state}
                          </option>
                        ))}
                      </select>
                    </label>
                    {replay?.statuses.includes("engine_error") && (
                      <p className="mt-2 text-xs text-warning">
                        The simulation could not execute this path. This is not evidence of a contract violation.
                      </p>
                    )}
                    {replay && (
                      <>
                        <Evidence label="Watched balance changes" rows={replay.balances} />
                        <Evidence label="Probe results" rows={replay.probes} />
                      </>
                    )}
                  </>
                ) : (
                  <p className="mt-3 text-xs text-ink-muted">
                    This shared prefix has no standalone replay. Select a terminal path for execution evidence.
                  </p>
                )}
              </>
            )}
          </div>
        </div>
      )}
      <div className="flex shrink-0 flex-wrap gap-x-3 gap-y-1 border-t border-border px-3 py-2 text-[10px] text-ink-muted">
        <span>○ Queued</span>
        <span className="text-accent-strong">● Executing</span>
        <span>✓ Executed</span>
        <span>↩ Reverted</span>
        <span className="text-warning">! Simulation error</span>
        <span className="text-danger">◆ Confirmed finding</span>
      </div>
    </section>
  );
}

function TreeLevel({
  nodes,
  busy,
  selected,
  expanded,
  choose,
  toggle,
  selectedRef,
}: {
  nodes: PathNode[];
  busy: boolean;
  selected?: string;
  expanded: Set<string>;
  choose: (id: string) => void;
  toggle: (id: string) => void;
  selectedRef: React.RefObject<HTMLDivElement | null>;
}) {
  const [limit, setLimit] = useState(12);
  // Always reveal a followed/selected branch even beyond the collapsed sibling limit.
  const visible = nodes.filter((node, index) => index < limit || node.id === selected || expanded.has(node.id));
  const hidden = nodes.length - visible.length;
  return (
    <ul className="space-y-1 border-l border-border pl-3">
      {visible.map((node) => {
        const state = nodeState(node, busy);
        return (
          <li key={node.id}>
            <div
              ref={selected === node.id ? selectedRef : undefined}
              className={`flex items-center gap-1 rounded-sm border ${selected === node.id ? "ring-1 ring-accent" : ""} ${tone(state)}`}
            >
              {node.children.length ? (
                <button
                  aria-label={`${expanded.has(node.id) ? "Collapse" : "Expand"} ${label(node)}`}
                  aria-expanded={expanded.has(node.id)}
                  onClick={() => toggle(node.id)}
                  className="p-1.5"
                >
                  {expanded.has(node.id) ? <ChevronDown className="size-3" /> : <ChevronRight className="size-3" />}
                </button>
              ) : (
                <span className="w-6 shrink-0 text-center text-[10px]">
                  {state === "Confirmed finding" ? "◆" : state === "Executing" ? "●" : state === "Reverted" ? "↩" : "○"}
                </span>
              )}
              <button
                aria-pressed={selected === node.id}
                onClick={() => choose(node.id)}
                className="min-w-0 flex-1 py-2 pr-2 text-left"
              >
                <span className="block truncate font-mono text-[11px]" title={label(node)}>
                  {label(node)}
                </span>
                <span className="block text-[10px]">
                  {node.call.action?.actor ?? short(node.call.from)} · {state}
                </span>
              </button>
            </div>
            {expanded.has(node.id) && node.children.length > 0 && (
              <div className="mt-1">
                <TreeLevel
                  nodes={node.children}
                  busy={busy}
                  selected={selected}
                  expanded={expanded}
                  choose={choose}
                  toggle={toggle}
                  selectedRef={selectedRef}
                />
              </div>
            )}
          </li>
        );
      })}
      {hidden > 0 && (
        <li>
          <button onClick={() => setLimit((value) => value + 12)} className="px-2 py-1 text-[11px] text-accent-strong">
            Show more branches ({hidden} hidden)
          </button>
        </li>
      )}
    </ul>
  );
}

function Evidence({ label, rows }: { label: string; rows: Record<string, unknown>[] }) {
  return (
    <details className="mt-2 text-[11px]">
      <summary className="cursor-pointer">
        {label} ({rows.length})
      </summary>
      {rows.length ? (
        rows.map((row, index) => (
          <dl key={index} className="mt-1 space-y-1 rounded-sm border border-border bg-bg p-2">
            {Object.entries(row).map(([key, value]) => (
              <div key={key} className="break-all">
                <dt className="text-ink-muted">{key.replaceAll("_", " ")}</dt>
                <dd className="font-mono">{typeof value === "string" ? value : JSON.stringify(value)}</dd>
              </div>
            ))}
          </dl>
        ))
      ) : (
        <p className="mt-1 text-ink-muted">No evidence reported.</p>
      )}
    </details>
  );
}

//! Campaign behaviour against a fake host that executes replay batches
//! with the semantics of the Arc Studio demo's `UnsafeVault`: anyone can
//! withdraw from the pooled deposits.

use std::collections::{BTreeMap, BTreeSet};
use std::str::FromStr;

use alloy_primitives::{Address, U256, keccak256};
use serde_json::{Value, json};

use crate::abi::{Actors, ContractAbi};
use crate::campaign::{FuzzCampaign, FuzzRoundArgs, FuzzStartArgs};
use crate::client::{AttackSurface, CompilerArtifact, MapAttackSurfaceArgs, Sessions, SourceArgs};
use crate::plan::{
    ExpectedStatus, FuzzActor, FuzzCall, FuzzContract, FuzzDeployment, FuzzPlan, FuzzProperty,
    ProtocolContract,
};
use crate::replay::{CompactTrace, ReplayBalance, ReplayBatch, ReplayStatus};

fn test_ctx() -> aomi_sdk::DynToolCallCtx {
    aomi_sdk::DynToolCallCtx {
        session_id: "test".into(),
        tool_name: "test".into(),
        call_id: "test".into(),
        state_attributes: Default::default(),
        secrets: Default::default(),
    }
}

const ARC: u64 = 5042;

fn vault() -> FuzzContract {
    FuzzContract {
        name: "UnsafeVault".into(),
        abi: json!([
            {"type":"function","name":"deposit","stateMutability":"payable","inputs":[],"outputs":[]},
            {"type":"function","name":"withdraw","stateMutability":"nonpayable","inputs":[{"name":"amount","type":"uint256"}],"outputs":[]},
            {"type":"function","name":"balances","stateMutability":"view","inputs":[{"name":"who","type":"address"}],"outputs":[{"type":"uint256"}]}
        ])
        .to_string(),
        deployed_bytecode: "0x6080".into(),
        deployment: None,
        protocol: vec![],
    }
}

fn call(label: &str, actor: &str, function: &str, arguments: &[&str], value: &str) -> FuzzCall {
    FuzzCall {
        label: label.into(),
        actor: actor.into(),
        contract: None,
        function: function.into(),
        arguments: arguments.iter().map(|a| a.to_string()).collect(),
        value: value.into(),
    }
}

fn actor(name: &str) -> FuzzActor {
    FuzzActor {
        name: name.into(),
        balance: "10000000000000000000".into(),
        address: None,
    }
}

fn must_revert(name: &str, actor: &str, function: &str) -> FuzzProperty {
    FuzzProperty {
        name: name.into(),
        actor: actor.into(),
        contract: None,
        function: function.into(),
        expected_status: Some(ExpectedStatus::Reverted),
        max_actor_profit: None,
        probes: vec![],
    }
}

fn vault_plan() -> FuzzPlan {
    FuzzPlan {
        hypothesis: "bob can withdraw alice's deposit".into(),
        actors: vec![actor("alice"), actor("bob")],
        actions: vec![
            call("alice deposits", "alice", "deposit()", &[], "100"),
            call("bob withdraws", "bob", "withdraw(uint256)", &["100"], "0"),
        ],
        invariants: vec![must_revert(
            "unauthorized_withdraw_must_revert",
            "bob",
            "withdraw(uint256)",
        )],
        max_depth: 3,
        max_executions: 32,
    }
}

/// The vault plan listed withdraw-first, so its own order is not the drain
/// and the search has to find it.
fn search_plan() -> FuzzPlan {
    let mut plan = vault_plan();
    plan.actions.reverse();
    plan
}

fn start(plan: FuzzPlan) -> (FuzzCampaign, Value) {
    let mut campaign = FuzzCampaign::new(
        vault(),
        FuzzStartArgs {
            chain_id: ARC,
            plan,
        },
    )
    .unwrap();
    let result = campaign.start();
    (campaign, result)
}

fn batch(value: &Value) -> Option<ReplayBatch> {
    (!value.is_null())
        .then(|| ReplayBatch {
            snapshot: crate::replay::BASELINE.to_owned(),
            chain_id: value["chain_id"].as_u64().unwrap(),
            watch: serde_json::from_value(value["watch"].clone()).unwrap(),
            traces: Vec::new(),
        })
        .map(|_| ReplayBatch {
            traces: serde_json::from_value::<Vec<Value>>(value["traces"].clone())
                .unwrap()
                .into_iter()
                .map(|trace| crate::replay::ReplayTrace {
                    id: trace["id"].as_str().unwrap().into(),
                    calls: serde_json::from_value::<Vec<Value>>(trace["calls"].clone())
                        .unwrap()
                        .iter()
                        .map(replay_call)
                        .collect(),
                    probes: serde_json::from_value::<Vec<Value>>(trace["probes"].clone())
                        .unwrap()
                        .iter()
                        .map(replay_call)
                        .collect(),
                })
                .collect(),
            snapshot: crate::replay::BASELINE.to_owned(),
            chain_id: value["chain_id"].as_u64().unwrap(),
            watch: serde_json::from_value(value["watch"].clone()).unwrap(),
        })
}

fn replay_call(value: &Value) -> crate::replay::ReplayCall {
    crate::replay::ReplayCall {
        label: value["label"].as_str().unwrap().into(),
        from: value["from"].as_str().unwrap().into(),
        to: value["to"].as_str().unwrap().into(),
        data: value["data"].as_str().unwrap().into(),
        value: value["value"].as_str().unwrap().into(),
    }
}

/// Execute a batch the way `sim_replay_traces(compact=true)` would for an
/// `UnsafeVault` whose withdraw only checks the pooled balance.
fn execute(batch: &ReplayBatch, engine_error_on: Option<&str>) -> Vec<CompactTrace> {
    let deposit = &keccak256("deposit()")[..4];
    batch
        .traces
        .iter()
        .map(|trace| {
            let start = |address: &String| {
                if address == &trace.calls[0].to {
                    U256::ZERO
                } else {
                    U256::from(10_000_000_000_000_000_000u128)
                }
            };
            let mut balances: BTreeMap<String, U256> =
                batch.watch.iter().map(|a| (a.clone(), start(a))).collect();
            let before = balances.clone();
            let mut pool = U256::ZERO;
            let mut statuses = Vec::new();
            for call in &trace.calls {
                if engine_error_on == Some(call.label.as_str()) {
                    statuses.push(ReplayStatus::EngineError);
                    break;
                }
                let data = alloy_primitives::hex::decode(&call.data).unwrap();
                let value = U256::from_str(&call.value).unwrap();
                if &data[..4] == deposit {
                    pool += value;
                    *balances.get_mut(&call.from).unwrap() -= value;
                    *balances.get_mut(&call.to).unwrap() += value;
                    statuses.push(ReplayStatus::Succeeded);
                } else {
                    let amount = U256::from_be_slice(&data[4..36]);
                    if pool >= amount {
                        pool -= amount;
                        *balances.get_mut(&call.from).unwrap() += amount;
                        *balances.get_mut(&call.to).unwrap() -= amount;
                        statuses.push(ReplayStatus::Succeeded);
                    } else {
                        statuses.push(ReplayStatus::Reverted);
                    }
                }
            }
            CompactTrace {
                id: trace.id.clone(),
                statuses,
                // Echo every probe, as the host does, with a constant reading.
                probes: trace
                    .probes
                    .iter()
                    .map(|probe| crate::replay::ReplayProbe {
                        label: probe.label.clone(),
                        status: ReplayStatus::Succeeded,
                        return_data: Some("0x00".into()),
                    })
                    .collect(),
                balances: balances
                    .iter()
                    .filter(|(address, after)| before[*address] != **after)
                    .map(|(address, after)| ReplayBalance {
                        address: address.clone(),
                        before: before[address].to_string(),
                        after: after.to_string(),
                    })
                    .collect(),
            }
        })
        .collect()
}

/// Drive the campaign to completion; returns the final report.
fn run_to_completion(campaign: &mut FuzzCampaign, first: &Value) -> Value {
    let mut next = first.clone();
    for _ in 0..64 {
        let Some(batch) = batch(&next) else {
            return campaign.report();
        };
        let result = campaign
            .round(FuzzRoundArgs {
                replay: execute(&batch, None),
                plan: None,
            })
            .unwrap();
        next = result["next_batch"].clone();
    }
    panic!("campaign did not complete");
}

#[test]
fn start_emits_setup_and_a_host_shaped_batch() {
    let (_, result) = start(vault_plan());
    assert_eq!(
        result["setup"]["snapshot"]["label"],
        crate::replay::BASELINE
    );
    assert_eq!(result["setup"]["set_code"]["runtime_bytecode"], "0x6080");
    assert_eq!(result["setup"]["set_balances"].as_array().unwrap().len(), 2);
    let next = &result["next_batch"];
    assert_eq!(
        next["watch"].as_array().unwrap().len(),
        3,
        "actors + contract"
    );
    assert_eq!(
        next["traces"].as_array().unwrap().len(),
        3,
        "the plan-order scenario, then one per action"
    );
    assert_eq!(next["traces"][0]["calls"].as_array().unwrap().len(), 2);
    let call = &next["traces"][0]["calls"][0];
    let keys: Vec<_> = call.as_object().unwrap().keys().cloned().collect();
    assert_eq!(
        keys,
        ["data", "from", "label", "to", "value"],
        "no gas, no extras"
    );
    assert!(next.get("watch_addresses").is_none());
    assert_eq!(result["progress"]["status"], "exploring");
}

#[test]
fn breadth_first_search_minimizes_and_reproduces_the_vault_drain() {
    let (mut campaign, result) = start(vault_plan());
    let report = run_to_completion(&mut campaign, &result["next_batch"]);

    assert_eq!(report["status"], "complete");
    let findings = report["findings"].as_array().unwrap();
    assert_eq!(findings.len(), 1, "{report:#}");
    let finding = &findings[0];
    assert_eq!(finding["property"], "unauthorized_withdraw_must_revert");
    assert_eq!(finding["reproductions"], 2);
    let labels: Vec<_> = finding["minimized_trace"]
        .as_array()
        .unwrap()
        .iter()
        .map(|call| call["label"].as_str().unwrap())
        .collect();
    assert_eq!(
        labels,
        ["alice deposits", "bob withdraws"],
        "minimal ordered reproduction"
    );
    assert_eq!(
        finding["steps"][1]["status"], "succeeded",
        "the unauthorized withdraw succeeded"
    );
    assert!(report["unconfirmed"].as_array().unwrap().is_empty());
    assert_eq!(
        report["uncovered_writes"].as_array().unwrap().len(),
        0,
        "every writable entrypoint was exercised"
    );
}

#[test]
fn an_engine_error_is_inconclusive_not_a_revert() {
    let (mut campaign, result) = start(vault_plan());
    let batch = batch(&result["next_batch"]).unwrap();
    let out = campaign
        .round(FuzzRoundArgs {
            replay: execute(&batch, Some("a1")), // a1 = "bob withdraws"
            plan: None,
        })
        .unwrap();
    // The scenario [a0, a1] and [a1] alone both hit the engine error.
    assert_eq!(out["progress"]["inconclusive_traces"], 2);
    assert!(
        !campaign.report()["behavior_coverage"]
            .as_array()
            .unwrap()
            .iter()
            .any(|b| b == "bob:withdraw(uint256):reverted"),
        "an engine error must not count as the expected revert"
    );
    assert!(
        campaign.report()["behavior_coverage"]
            .as_array()
            .unwrap()
            .iter()
            .any(|b| b == "bob:withdraw(uint256):engine_error")
    );
}

#[test]
fn storage_only_states_are_not_pruned_together() {
    // Two actions that both succeed without moving value. A fingerprint of
    // statuses + balances alone would expand only the first.
    let contract = FuzzContract {
        name: "Config".into(),
        abi: json!([
            {"type":"function","name":"setOwner","stateMutability":"nonpayable","inputs":[{"type":"address"}],"outputs":[]},
            {"type":"function","name":"pause","stateMutability":"nonpayable","inputs":[],"outputs":[]}
        ])
        .to_string(),
        deployed_bytecode: "0x00".into(),
        deployment: None,
        protocol: vec![],
    };
    let plan = FuzzPlan {
        hypothesis: "config takeover".into(),
        actors: vec![actor("attacker")],
        actions: vec![
            call(
                "take ownership",
                "attacker",
                "setOwner(address)",
                &["$attacker"],
                "0",
            ),
            call("pause", "attacker", "pause()", &[], "0"),
        ],
        invariants: vec![FuzzProperty {
            max_actor_profit: Some("0".into()),
            expected_status: None,
            ..must_revert("no profit", "attacker", "pause()")
        }],
        max_depth: 2,
        max_executions: 32,
    };
    let mut campaign = FuzzCampaign::new(
        contract,
        FuzzStartArgs {
            chain_id: ARC,
            plan,
        },
    )
    .unwrap();
    let result = campaign.start();
    let batch = batch(&result["next_batch"]).unwrap();
    let replay = batch
        .traces
        .iter()
        .map(|trace| CompactTrace {
            id: trace.id.clone(),
            statuses: vec![ReplayStatus::Succeeded],
            probes: vec![],
            balances: vec![],
        })
        .collect();
    let out = campaign
        .round(FuzzRoundArgs { replay, plan: None })
        .unwrap();
    assert_eq!(out["progress"]["corpus_size"], 2);
    assert_eq!(
        out["next_batch"]["traces"].as_array().unwrap().len(),
        3,
        "both depth-1 states are extended; [a0, a1] already ran as the scenario"
    );
}

#[test]
fn every_violation_in_a_batch_is_kept() {
    let mut plan = vault_plan();
    plan.actions.push(call(
        "alice withdraws",
        "alice",
        "withdraw(uint256)",
        &["0"],
        "0",
    ));
    plan.invariants.push(must_revert(
        "alice_withdraw_must_revert",
        "alice",
        "withdraw(uint256)",
    ));
    let (mut campaign, result) = start(plan);
    let report = run_to_completion(&mut campaign, &result["next_batch"]);
    let properties: Vec<_> = report["findings"]
        .as_array()
        .unwrap()
        .iter()
        .map(|f| f["property"].as_str().unwrap().to_string())
        .collect();
    assert!(
        properties.contains(&"alice_withdraw_must_revert".to_string()),
        "{report:#}"
    );
    assert!(properties.contains(&"unauthorized_withdraw_must_revert".to_string()));
}

#[test]
fn a_flaky_violation_is_reported_as_unconfirmed() {
    let (mut campaign, result) = start(vault_plan());
    let mut next = result["next_batch"].clone();
    // Run honestly until the campaign asks for reproductions, then fail them.
    loop {
        let batch = batch(&next).expect("campaign reaches reproduction");
        let reproducing = campaign.report()["status"] == "confirming"
            && batch.traces.len() == 2
            && batch.traces[0].calls == batch.traces[1].calls;
        let mut replay = execute(&batch, None);
        if reproducing {
            for trace in &mut replay {
                trace.statuses = vec![ReplayStatus::Succeeded, ReplayStatus::Reverted];
                trace.balances.clear();
            }
        }
        let out = campaign
            .round(FuzzRoundArgs { replay, plan: None })
            .unwrap();
        if reproducing {
            assert!(out["progress"]["findings"].as_array().unwrap().is_empty());
            let unconfirmed = &out["progress"]["unconfirmed"][0];
            assert_eq!(unconfirmed["property"], "unauthorized_withdraw_must_revert");
            assert_eq!(
                unconfirmed["reason"],
                "violation did not reproduce from the baseline"
            );
            return;
        }
        next = out["next_batch"].clone();
    }
}

#[test]
fn round_rejects_mismatched_replays_without_losing_the_batch() {
    let (mut campaign, result) = start(vault_plan());
    let batch = batch(&result["next_batch"]).unwrap();
    let mut replay = execute(&batch, None);

    let err = campaign
        .round(FuzzRoundArgs {
            replay: replay[..1].to_vec(),
            plan: None,
        })
        .unwrap_err();
    assert!(err.contains("expected 3 replayed traces"), "{err}");
    replay[1].id = replay[0].id.clone();
    let err = campaign
        .round(FuzzRoundArgs {
            replay: replay.clone(),
            plan: None,
        })
        .unwrap_err();
    assert!(err.contains("repeats a trace id"), "{err}");

    let replay = execute(&batch, None);
    campaign
        .round(FuzzRoundArgs { replay, plan: None })
        .expect("the pending batch survived the rejected attempts");
}

#[test]
fn a_revision_is_deferred_while_confirming_and_cannot_change_actors() {
    let (mut campaign, result) = start(search_plan());
    let mut next = result["next_batch"].clone();
    loop {
        let batch = batch(&next).unwrap();
        let out = campaign
            .round(FuzzRoundArgs {
                replay: execute(&batch, None),
                plan: Some(search_plan()),
            })
            .unwrap();
        if out["progress"]["status"] == "confirming" {
            assert!(out["revision"].as_str().unwrap().starts_with("deferred"));
            break;
        }
        assert_eq!(out["revision"], "applied");
        next = out["next_batch"].clone();
    }

    // A rejected revision is reported, and the round still yields its batch.
    let (mut campaign, result) = start(search_plan());
    let batch = batch(&result["next_batch"]).unwrap();
    let mut changed = search_plan();
    changed.actors[0].balance = "1".into();
    let out = campaign
        .round(FuzzRoundArgs {
            replay: execute(&batch, None),
            plan: Some(changed),
        })
        .unwrap();
    let revision = out["revision"].as_str().unwrap();
    assert!(revision.starts_with("rejected"), "{revision}");
    assert!(revision.contains("cannot change actors"), "{revision}");
    assert!(
        !out["next_batch"].is_null(),
        "the search continues on the old plan"
    );
}

#[test]
fn a_revision_may_drop_entrypoints_that_already_ran() {
    let (mut campaign, result) = start(search_plan());
    let batch = batch(&result["next_batch"]).unwrap();
    // Only the deposit: withdraw ran in the first batch, so it stays covered.
    let mut focused = search_plan();
    focused
        .actions
        .retain(|action| action.label == "alice deposits");
    focused.invariants.clear();
    focused
        .invariants
        .push(must_revert("deposit_never_reverts", "alice", "deposit()"));
    let out = campaign
        .round(FuzzRoundArgs {
            replay: execute(&batch, None),
            plan: Some(focused.clone()),
        })
        .unwrap();
    assert_eq!(out["revision"], "applied");

    // At the start nothing ran yet, so every writable entrypoint is required.
    let err = FuzzCampaign::new(
        vault(),
        FuzzStartArgs {
            chain_id: ARC,
            plan: focused,
        },
    )
    .err()
    .unwrap();
    assert!(err.contains("missing: withdraw(uint256)"), "{err}");
}

#[test]
fn a_revision_keeps_the_frontier_and_seeds_only_new_actions() {
    let (mut campaign, result) = start(search_plan());
    let batch = batch(&result["next_batch"]).unwrap();
    let mut revised = search_plan();
    revised
        .actions
        .push(call("bob deposits", "bob", "deposit()", &[], "1"));
    let out = campaign
        .round(FuzzRoundArgs {
            replay: execute(&batch, None),
            plan: Some(revised),
        })
        .unwrap();
    assert_eq!(out["revision"], "applied");
    let labels: Vec<Vec<String>> = out["next_batch"]["traces"]
        .as_array()
        .unwrap()
        .iter()
        .map(|trace| {
            trace["calls"]
                .as_array()
                .unwrap()
                .iter()
                .map(|c| c["label"].as_str().unwrap().to_string())
                .collect()
        })
        .collect();
    assert!(
        labels.iter().any(|trace| trace.len() == 2),
        "depth-2 extensions queued before the revision survive: {labels:?}"
    );
    assert!(
        // Replay labels are action ids; the added "bob deposits" is a2.
        labels.iter().any(|trace| trace == &["a2"]),
        "the new action starts at depth one: {labels:?}"
    );
}

#[test]
fn plans_are_validated_against_the_contract() {
    let reject = |plan: FuzzPlan, needle: &str| {
        let err = FuzzCampaign::new(
            vault(),
            FuzzStartArgs {
                chain_id: ARC,
                plan,
            },
        )
        .err()
        .expect("plan is rejected");
        assert!(err.contains(needle), "{err}");
    };
    let mut plan = vault_plan();
    plan.actions.pop();
    plan.invariants.clear();
    plan.invariants.push(must_revert("p", "alice", "deposit()"));
    reject(plan, "missing: withdraw(uint256)");

    let mut plan = vault_plan();
    plan.invariants[0].probes = vec![call("read", "alice", "withdraw(uint256)", &["1"], "0")];
    reject(plan, "must be a view or pure function");

    let mut plan = vault_plan();
    plan.invariants[0].probes = (0..=ReplayBatch::MAX_PROBES)
        .map(|i| {
            call(
                "read",
                "alice",
                "balances(address)",
                &[&format!("0x{i:040x}")],
                "0",
            )
        })
        .collect();
    reject(plan, "distinct probes");

    let mut plan = vault_plan();
    plan.actors.push(actor("Bad Name"));
    reject(plan, "lowercase");

    let err = FuzzCampaign::new(
        vault(),
        FuzzStartArgs {
            chain_id: 1,
            plan: vault_plan(),
        },
    )
    .err()
    .unwrap();
    assert!(err.contains("Arc fuzzing supports chain"), "{err}");
}

#[test]
fn plans_report_all_validation_errors_at_once() {
    let mut plan = vault_plan();
    plan.actions.pop();
    plan.invariants[0] = FuzzProperty {
        expected_status: None,
        ..must_revert("deposit safety", "alice", "deposit()")
    };

    let err = FuzzCampaign::new(
        vault(),
        FuzzStartArgs {
            chain_id: ARC,
            plan,
        },
    )
    .err()
    .expect("plan is rejected");

    assert!(err.contains("missing: withdraw(uint256)"), "{err}");
    assert!(
        err.contains("property `deposit safety` needs expected_status or max_actor_profit"),
        "{err}"
    );
}

#[test]
fn arguments_encode_actor_references_tuples_and_arrays() {
    let abi = ContractAbi::parse(
        &json!([{"type":"function","name":"f","stateMutability":"nonpayable","inputs":[
            {"type":"address"},
            {"type":"uint256[]"},
            {"type":"tuple","components":[{"type":"bool"},{"type":"bytes2"}]}
        ],"outputs":[]}])
        .to_string(),
    )
    .unwrap();
    let actors = Actors::derive(Default::default(), &[actor("alice")]).unwrap();
    let alice = actors.get("alice").unwrap().address;
    let data = abi
        .encode(
            &actors,
            "f(address,uint256[],(bool,bytes2))",
            &[
                "$alice".into(),
                "[\"1\",\"2\"]".into(),
                "[true,\"0xabcd\"]".into(),
            ],
        )
        .unwrap();
    assert_eq!(Address::from_slice(&data[16..36]), alice);
    assert!(
        abi.encode(&actors, "f(address,uint256[],(bool,bytes2))", &[])
            .is_err()
    );
    assert!(
        abi.encode(
            &actors,
            "f(address,uint256[],(bool,bytes2))",
            &["$mallory".into(), "[]".into(), "[true,\"0xabcd\"]".into()]
        )
        .unwrap_err()
        .contains("unknown actor")
    );
}

#[test]
fn attack_surface_maps_signatures_observers_and_seeds() {
    let surface = AttackSurface::map(&CompilerArtifact {
        source_code: "contract UnsafeVault { function withdraw(uint256 a) external { payable(msg.sender).call{value: a}(\"\"); } }".into(),
        contract: vault(),
        downloaded: false,
        snapshot_path: None,
    })
    .unwrap();
    let surface = serde_json::to_value(surface).unwrap();
    let entry = |signature: &str| {
        surface["entry_points"]
            .as_array()
            .unwrap()
            .iter()
            .find(|entry| entry["signature"] == signature)
            .cloned()
            .unwrap_or_else(|| panic!("no entry point {signature}"))
    };
    assert_eq!(entry("deposit()")["mutability"], "payable");
    assert_eq!(entry("withdraw(uint256)")["mutability"], "nonpayable");
    assert_eq!(surface["state_observers"], json!(["balances(address)"]));
    let seeds = surface["attack_hypothesis_seeds"].as_array().unwrap();
    for needle in ["reentrancy", "Native-USDC", "value extraction"] {
        assert!(
            seeds.iter().any(|s| s.as_str().unwrap().contains(needle)),
            "missing {needle} seed: {seeds:?}"
        );
    }
}

#[test]
fn artifact_urls_are_limited_to_the_fuzz_site() {
    let args = |url: &str| MapAttackSurfaceArgs {
        artifact_url: Some(url.into()),
        source_code: None,
        contract: None,
    };
    for url in [
        "http://arc-studio-fuzz.vercel.app/api/artifacts/x",
        "https://evil.example/api/artifacts/x",
        "https://arc-studio-fuzz.vercel.app.evil.example/x",
        // A squatted Vercel project name that a preview pattern would have admitted.
        "https://arc-studio-fuzz-x-aomi-labs.vercel.app/api/artifacts/x",
        "https://user:pass@arc-studio-fuzz.vercel.app/api/artifacts/x",
        "https://evil.example@arc-studio-fuzz.vercel.app/api/artifacts/x",
        "https://arc-studio-fuzz.vercel.app:8443/api/artifacts/x",
        "https://169.254.169.254/latest/meta-data",
        "not a url",
    ] {
        let error = args(url).artifact(&test_ctx()).err().unwrap_or_default();
        assert!(
            error.contains("must be https://arc-studio-fuzz.vercel.app")
                || error.contains("not a valid URL"),
            "{url} was not refused: {error}"
        );
    }
    let inline = MapAttackSurfaceArgs {
        artifact_url: None,
        source_code: Some("contract V {}".into()),
        contract: Some(vault()),
    }
    .artifact(&test_ctx())
    .unwrap();
    assert!(!inline.downloaded);
    assert!(
        MapAttackSurfaceArgs {
            artifact_url: None,
            source_code: None,
            contract: None
        }
        .artifact(&test_ctx())
        .is_err()
    );
}

#[test]
fn sessions_are_bounded_and_evict_the_least_recent() {
    let mut sessions = Sessions::default();
    for i in 0..=64 {
        sessions.open(
            format!("s{i}"),
            CompilerArtifact {
                source_code: "contract V {}".into(),
                contract: vault(),
                downloaded: false,
                snapshot_path: None,
            },
        );
    }
    assert!(
        sessions.get_mut("s0").is_err(),
        "the oldest session was evicted"
    );
    assert!(sessions.get_mut("s64").is_ok());
    assert!(sessions.close("s64"));
    assert!(!sessions.close("s64"));
}

#[test]
fn preamble_assigns_attack_selection_to_the_agent_and_matches_the_host_contract() {
    let preamble = super::PREAMBLE;
    for needle in [
        "You choose the actors",
        "A revert is evidence about a precondition",
        "Do not say a contract is safe",
        "copy `snapshot`, `chain_id`, `watch`, and `traces` verbatim",
        "engine_error",
    ] {
        assert!(preamble.contains(needle), "preamble lacks `{needle}`");
    }
    assert!(!preamble.contains("watch_addresses"));
}

#[test]
fn start_and_round_args_deserialize_from_model_json() {
    let start: FuzzStartArgs = serde_json::from_value(json!({
        "chain_id": 5042,
        "hypothesis": "h",
        "actors": [{"name": "alice"}],
        "actions": [{"label": "d", "actor": "alice", "function": "deposit()", "value": "1"}],
        "invariants": [{"name": "p", "actor": "alice", "function": "deposit()", "expected_status": "reverted"}]
    }))
    .expect("flat start args parse");
    assert_eq!(start.plan.max_depth, 4, "defaults apply");
    assert!(
        serde_json::from_value::<FuzzStartArgs>(json!({"chain_id": 5042, "plan": {}})).is_err(),
        "a nested plan is rejected"
    );
    let round: FuzzRoundArgs = serde_json::from_value(json!({
        "replay": [{
            "id": "1-1",
            "statuses": ["succeeded", "engine_error"],
            "probes": [{"label": "read", "status": "succeeded", "return_data": "0x01"}],
            "balances": [{"address": "0x01", "before": "1", "after": "2"}]
        }]
    }))
    .expect("compact host output parses");
    assert_eq!(round.replay[0].statuses[1], ReplayStatus::EngineError);
}

/// Provider strict mode rejects the whole tool list if any object schema
/// node lacks `properties`, so every tool is checked, used or not.
fn assert_strict_object_nodes(path: &str, schema: &Value) {
    if schema.get("type") == Some(&Value::String("object".into())) {
        assert!(
            schema.get("properties").is_some_and(Value::is_object),
            "{path} has type=object without properties: {schema:#}"
        );
    }
    match schema {
        Value::Object(fields) => {
            for (name, child) in fields {
                assert_strict_object_nodes(&format!("{path}.{name}"), child);
            }
        }
        Value::Array(items) => {
            for (index, child) in items.iter().enumerate() {
                assert_strict_object_nodes(&format!("{path}[{index}]"), child);
            }
        }
        _ => {}
    }
}

#[test]
fn manifest_tool_schemas_are_provider_strict() {
    use aomi_sdk::DynAomiApp;
    let manifest = crate::client::ArcStudioFuzzerApp::default().manifest();
    assert_eq!(manifest.namespaces, Some(vec!["evm-sim".to_string()]));
    let names: Vec<_> = manifest
        .tools
        .iter()
        .map(|tool| tool.name.as_str())
        .collect();
    assert_eq!(
        names,
        [
            "arc_map_attack_surface",
            "arc_source",
            "arc_fuzz_start",
            "arc_fuzz_round",
            "arc_fuzz_report",
            "arc_fuzz_close"
        ]
    );
    for tool in &manifest.tools {
        assert!(
            tool.description.len() >= 80,
            "{} is underspecified",
            tool.name
        );
        assert_strict_object_nodes(&tool.name, &tool.parameters_schema);
    }
}

const DEPLOYED: &str = "0x00000000000000000000000000000000000000de";
const OWNER: &str = "0x0000000000000000000000000000000000000abc";

fn deployed_vault(chain_id: u64) -> FuzzContract {
    FuzzContract {
        deployment: Some(FuzzDeployment {
            address: DEPLOYED.into(),
            chain_id,
            installed: false,
        }),
        ..vault()
    }
}

#[test]
fn a_deployed_contract_is_fuzzed_in_place_on_its_chain() {
    let testnet = 5_042_002;
    let mut campaign = FuzzCampaign::new(
        deployed_vault(testnet),
        FuzzStartArgs {
            chain_id: testnet,
            plan: vault_plan(),
        },
    )
    .unwrap();
    let result = campaign.start();
    assert!(
        result["setup"]["set_code"].is_null(),
        "a live deployment already has its code and constructor state"
    );
    assert_eq!(result["progress"]["deployed"], true);
    assert_eq!(result["progress"]["target"], DEPLOYED);
    let batch = batch(&result["next_batch"]).unwrap();
    assert_eq!(batch.chain_id, testnet);
    assert!(batch.watch.iter().any(|a| a == DEPLOYED));
    assert!(
        batch
            .traces
            .iter()
            .flat_map(|t| &t.calls)
            .all(|c| c.to == DEPLOYED)
    );
    let limitations = campaign.report()["limitations"].to_string();
    assert!(limitations.contains("live deployment"), "{limitations}");
    assert!(!limitations.contains("runs no constructor"));

    let wrong_chain = FuzzCampaign::new(
        deployed_vault(testnet),
        FuzzStartArgs {
            chain_id: ARC,
            plan: vault_plan(),
        },
    );
    assert!(
        wrong_chain
            .err()
            .unwrap()
            .contains("deployed on chain 5042002"),
        "the campaign must run on the deployment's chain"
    );
}

#[test]
fn a_fixed_address_actor_sends_as_that_account() {
    let mut plan = vault_plan();
    plan.actors[1].address = Some(OWNER.into());
    let mut campaign = FuzzCampaign::new(
        deployed_vault(ARC),
        FuzzStartArgs {
            chain_id: ARC,
            plan: plan.clone(),
        },
    )
    .unwrap();
    let batch = batch(&campaign.start()["next_batch"]).unwrap();
    assert!(
        batch
            .traces
            .iter()
            .flat_map(|t| &t.calls)
            .any(|c| c.from == OWNER),
        "bob's calls come from the fixed address"
    );
    assert!(batch.watch.iter().any(|a| a == OWNER));

    let mut twice = plan.clone();
    twice.actors[0].address = Some(OWNER.into());
    let error = FuzzCampaign::new(
        deployed_vault(ARC),
        FuzzStartArgs {
            chain_id: ARC,
            plan: twice,
        },
    )
    .err()
    .unwrap();
    assert!(error.contains("reuses another actor's address"), "{error}");

    let mut invalid = plan;
    invalid.actors[1].address = Some("owner".into());
    let error = FuzzCampaign::new(
        deployed_vault(ARC),
        FuzzStartArgs {
            chain_id: ARC,
            plan: invalid,
        },
    )
    .err()
    .unwrap();
    assert!(error.contains("invalid address"), "{error}");
}

#[test]
fn rounds_carry_compact_progress_and_short_replay_labels() {
    let mut plan = vault_plan();
    plan.invariants[0].probes = vec![call(
        "bob's recorded deposit",
        "bob",
        "balances(address)",
        &["$bob"],
        "0",
    )];
    let (mut campaign, result) = start(plan);

    // Replay calls and probes carry short ids, not the plan's prose.
    let first = batch(&result["next_batch"]).unwrap();
    let labels: BTreeSet<_> = first
        .traces
        .iter()
        .flat_map(|t| t.calls.iter().chain(&t.probes))
        .map(|c| c.label.clone())
        .collect();
    assert_eq!(
        labels,
        BTreeSet::from(["a0".to_string(), "a1".into(), "p0".into()])
    );

    // A round result omits the growing and static report fields.
    let out = campaign
        .round(FuzzRoundArgs {
            replay: execute(&first, None),
            plan: None,
        })
        .unwrap();
    for heavy in [
        "behavior_coverage",
        "covered_writes",
        "limitations",
        "hypothesis",
    ] {
        assert!(
            out["progress"].get(heavy).is_none(),
            "progress carries {heavy}"
        );
        assert!(
            campaign.report().get(heavy).is_some(),
            "the full report keeps {heavy}"
        );
    }
    assert!(out.get("report").is_none());

    // Findings translate replay ids back to the plan's prose.
    let report = run_to_completion(&mut campaign, &out["next_batch"]);
    let probe = &report["findings"][0]["probes"][0];
    assert_eq!(probe["label"], "bob's recorded deposit", "{report:#}");
}

#[test]
fn harness_installed_code_is_targeted_without_set_code_but_keeps_the_constructor_caveat() {
    let testnet = 5_042_002;
    let mut contract = deployed_vault(testnet);
    contract.deployment.as_mut().unwrap().installed = true;
    let mut campaign = FuzzCampaign::new(
        contract,
        FuzzStartArgs {
            chain_id: testnet,
            plan: vault_plan(),
        },
    )
    .unwrap();
    let result = campaign.start();
    assert!(
        result["setup"]["set_code"].is_null(),
        "the harness already installed the code"
    );
    assert!(
        !result["setup"]["set_balances"]
            .as_array()
            .unwrap()
            .is_empty(),
        "the agent still funds its actors"
    );
    assert_eq!(result["progress"]["target"], DEPLOYED);
    assert_eq!(result["progress"]["deployed"], false);
    let limitations = campaign.report()["limitations"].to_string();
    assert!(limitations.contains("runs no constructor"), "{limitations}");
}

#[test]
fn long_source_is_served_in_numbered_slices() {
    let source = (1..=450)
        .map(|line| format!("// line {line}"))
        .collect::<Vec<_>>()
        .join("\n");
    let artifact = CompilerArtifact {
        source_code: format!("{source}\ncontract UnsafeVault {{}}"),
        contract: vault(),
        downloaded: true,
        snapshot_path: None,
    };
    let surface = serde_json::to_value(AttackSurface::map(&artifact).unwrap()).unwrap();
    assert!(
        surface.get("source_code").is_none(),
        "long source is not inlined"
    );
    assert_eq!(surface["source_lines"], 451);

    let mut sessions = Sessions::default();
    sessions.open("s".into(), artifact);
    let session = sessions.get_mut("s").unwrap();
    let slice = session
        .source(SourceArgs {
            from_line: 2,
            to_line: 1_000,
        })
        .unwrap();
    assert_eq!(slice["from_line"], 2);
    assert_eq!(slice["to_line"], 201, "at most 200 lines per call");
    assert_eq!(slice["total_lines"], 451);
    let text = slice["source"].as_str().unwrap();
    assert!(text.starts_with("    2  // line 2"), "{text}");
    assert_eq!(text.lines().count(), 200);
    assert!(
        session
            .source(SourceArgs {
                from_line: 0,
                to_line: 3,
            })
            .is_err()
    );

    let short = CompilerArtifact {
        source_code: "contract UnsafeVault {}".into(),
        contract: vault(),
        downloaded: true,
        snapshot_path: None,
    };
    let surface = serde_json::to_value(AttackSurface::map(&short).unwrap()).unwrap();
    assert_eq!(surface["source_code"], "contract UnsafeVault {}");
}

const POOL: &str = "0x0000000000000000000000000000000000000001";
const TOKEN: &str = "0x0000000000000000000000000000000000000002";

#[test]
fn a_seeded_protocol_is_fuzzed_across_its_contracts() {
    let testnet = 5_042_002;
    let pool = FuzzContract {
        name: "Pool".into(),
        abi: json!([
            {"type":"function","name":"deposit","stateMutability":"nonpayable","inputs":[{"type":"uint256"}],"outputs":[]}
        ])
        .to_string(),
        deployed_bytecode: "0x00".into(),
        deployment: Some(FuzzDeployment {
            address: POOL.into(),
            chain_id: testnet,
            installed: true,
        }),
        protocol: vec![ProtocolContract {
            name: "Token".into(),
            address: TOKEN.into(),
            abi: json!([
                {"type":"function","name":"approve","stateMutability":"nonpayable","inputs":[{"type":"address"},{"type":"uint256"}],"outputs":[{"type":"bool"}]},
                {"type":"function","name":"transfer","stateMutability":"nonpayable","inputs":[{"type":"address"},{"type":"uint256"}],"outputs":[{"type":"bool"}]},
                {"type":"function","name":"balanceOf","stateMutability":"view","inputs":[{"type":"address"}],"outputs":[{"type":"uint256"}]}
            ])
            .to_string(),
        }],
    };
    let token_call = |label: &str, function: &str, arguments: &[&str]| FuzzCall {
        contract: Some("Token".into()),
        ..call(label, "alice", function, arguments, "0")
    };
    let plan = FuzzPlan {
        hypothesis: "deposits pull approved tokens".into(),
        actors: vec![actor("alice")],
        actions: vec![
            token_call("approve pool", "approve(address,uint256)", &["@Pool", "5"]),
            call("deposit", "alice", "deposit(uint256)", &["5"], "0"),
        ],
        invariants: vec![FuzzProperty {
            probes: vec![token_call(
                "token balance",
                "balanceOf(address)",
                &["$alice"],
            )],
            ..must_revert("no free deposit", "alice", "deposit(uint256)")
        }],
        max_depth: 2,
        max_executions: 8,
    };
    let mut campaign = FuzzCampaign::new(
        pool.clone(),
        FuzzStartArgs {
            chain_id: testnet,
            plan: plan.clone(),
        },
    )
    .expect("Token.transfer is not required: coverage is the contract under test's");
    let result = campaign.start();
    let batch = batch(&result["next_batch"]).unwrap();
    let approve = batch
        .traces
        .iter()
        .flat_map(|t| &t.calls)
        .find(|c| c.to == TOKEN)
        .expect("the token call goes to the token");
    assert_eq!(
        approve.data,
        format!("0x095ea7b3{:0>64}{:0>64}", &POOL[2..], "5"),
        "`@Pool` resolves to the pool's address"
    );
    assert!(
        batch
            .traces
            .iter()
            .flat_map(|t| &t.calls)
            .any(|c| c.to == POOL)
    );
    assert!(
        batch.traces[0].probes.iter().all(|p| p.to == TOKEN),
        "probes can read other protocol contracts"
    );

    let mut unknown = plan.clone();
    unknown.actions[0].contract = Some("Oracle".into());
    unknown.actions[1].arguments = vec!["@Missing".into()];
    let error = FuzzCampaign::new(
        pool,
        FuzzStartArgs {
            chain_id: testnet,
            plan: unknown,
        },
    )
    .err()
    .unwrap();
    assert!(error.contains("unknown contract `Oracle`"), "{error}");
}

#[test]
fn rounds_name_actions_that_never_succeed() {
    let (mut campaign, first) = start(vault_plan());
    let batch = batch(&first["next_batch"]).unwrap();
    // Every call reverts: nothing has met its preconditions yet.
    let replay = batch
        .traces
        .iter()
        .map(|trace| CompactTrace {
            id: trace.id.clone(),
            statuses: vec![ReplayStatus::Reverted; trace.calls.len()],
            probes: vec![],
            balances: vec![],
        })
        .collect();
    let round = campaign
        .round(FuzzRoundArgs { replay, plan: None })
        .unwrap();
    let stuck = round["progress"]["never_succeeded"].as_array().unwrap();
    assert!(!stuck.is_empty(), "{round}");
    assert!(stuck.iter().all(|label| label.as_str().is_some()));
    assert!(
        round["progress"]["advice"]
            .as_str()
            .unwrap()
            .contains("revised plan")
    );
}

#[test]
fn the_plan_order_scenario_runs_first_and_a_resent_plan_does_not_repeat_it() {
    let mut plan = search_plan();
    plan.actions
        .push(call("bob deposits", "bob", "deposit()", &[], "1"));
    let (mut campaign, result) = start(plan.clone());
    let traces = |next: &Value| -> Vec<Vec<String>> {
        next["traces"]
            .as_array()
            .unwrap()
            .iter()
            .map(|trace| {
                trace["calls"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .map(|c| c["label"].as_str().unwrap().to_string())
                    .collect()
            })
            .collect()
    };
    let first = traces(&result["next_batch"]);
    // Depth 3 over three actions: the prefixes [a0, a1] and [a0, a1, a2]
    // run before the breadth-first singletons.
    assert_eq!(first[0], ["a0", "a1"]);
    assert_eq!(first[1], ["a0", "a1", "a2"]);
    assert_eq!(first[2], ["a0"]);

    // a0 errors, so nothing extends it and only a requeue could bring the
    // scenario back.
    let replay = execute(&batch(&result["next_batch"]).unwrap(), Some("a0"));
    let (mut plain, _) = start(plan.clone());
    let unrevised = plain
        .round(FuzzRoundArgs {
            replay: replay.clone(),
            plan: None,
        })
        .unwrap();
    let out = campaign
        .round(FuzzRoundArgs {
            replay,
            plan: Some(plan),
        })
        .unwrap();
    assert_eq!(out["revision"], "applied");
    assert_eq!(
        traces(&out["next_batch"]),
        traces(&unrevised["next_batch"]),
        "an unchanged plan does not requeue its scenario"
    );
    assert_eq!(
        out["progress"]["frontier_size"],
        unrevised["progress"]["frontier_size"]
    );
}

#[test]
fn a_lost_round_response_can_be_retried_and_the_recipe_is_reported() {
    let (mut campaign, initial) = start(vault_plan());
    let replay = execute(&batch(&initial["next_batch"]).unwrap(), None);
    let args = FuzzRoundArgs { replay, plan: None };
    let first = campaign.round(args.clone()).unwrap();
    let retried = campaign.round(args).unwrap();
    assert_eq!(first, retried);
    assert_eq!(campaign.report()["next_batch"], first["next_batch"]);
    assert_eq!(campaign.report()["round"], 1);
}

#[test]
fn duplicate_invariant_names_are_rejected() {
    let mut plan = vault_plan();
    plan.invariants.push(must_revert(
        "unauthorized_withdraw_must_revert",
        "alice",
        "deposit()",
    ));
    let error = FuzzCampaign::new(
        vault(),
        FuzzStartArgs {
            chain_id: ARC,
            plan,
        },
    )
    .err()
    .unwrap();
    assert!(error.contains("nonempty and unique"), "{error}");
}

#[test]
fn a_fresh_worker_recovers_the_same_campaign_and_pending_batch() {
    use crate::client::ArcStudioFuzzerApp;
    use crate::tool::{EmptyArgs, FuzzReport, FuzzRound, FuzzStart, MapAttackSurface};
    use aomi_sdk::{DynAomiTool, DynToolCallCtx};
    let mut ctx = DynToolCallCtx {
        session_id: "durable".into(),
        tool_name: "test".into(),
        call_id: "1".into(),
        state_attributes: Default::default(),
        secrets: Default::default(),
    };
    let mapped = MapAttackSurface::run(
        &ArcStudioFuzzerApp::default(),
        MapAttackSurfaceArgs {
            artifact_url: None,
            source_code: Some("contract UnsafeVault {}".into()),
            contract: Some(vault()),
        },
        ctx.clone(),
    )
    .unwrap();
    ctx.state_attributes
        .insert("app_state".into(), mapped["__aomi_app_state"].clone());
    let initial = FuzzStart::run(
        &ArcStudioFuzzerApp::default(),
        FuzzStartArgs {
            chain_id: ARC,
            plan: vault_plan(),
        },
        ctx.clone(),
    )
    .unwrap();
    assert!(initial["__aomi_app_state"]["start"].is_null());
    assert_eq!(initial["__aomi_app_state"]["chain_id"], ARC);
    ctx.state_attributes
        .insert("app_state".into(), initial["__aomi_app_state"].clone());
    let args = FuzzRoundArgs {
        replay: execute(&batch(&initial["next_batch"]).unwrap(), None),
        plan: None,
    };
    let result = FuzzRound::run(&ArcStudioFuzzerApp::default(), args.clone(), ctx.clone()).unwrap();
    ctx.state_attributes
        .insert("app_state".into(), result["__aomi_app_state"].clone());
    let restored =
        FuzzReport::run(&ArcStudioFuzzerApp::default(), EmptyArgs {}, ctx.clone()).unwrap();
    assert_eq!(restored["next_batch"], result["next_batch"]);
    assert_eq!(restored["round"], result["progress"]["round"]);
    assert_eq!(
        FuzzRound::run(&ArcStudioFuzzerApp::default(), args, ctx).unwrap(),
        result
    );
}

#[test]
fn a_legacy_round_journal_migrates_to_the_versioned_checkpoint() {
    use crate::client::ArcStudioFuzzerApp;
    use crate::tool::{EmptyArgs, FuzzReport};
    use aomi_sdk::{DynAomiTool, DynToolCallCtx};

    let mut campaign = FuzzCampaign::new(
        vault(),
        FuzzStartArgs {
            chain_id: ARC,
            plan: vault_plan(),
        },
    )
    .unwrap();
    campaign.start();
    let first = campaign.report();
    let round = FuzzRoundArgs {
        replay: execute(&batch(&first["next_batch"]).unwrap(), None),
        plan: None,
    };
    let expected = campaign.round(round.clone()).unwrap();
    let mut ctx = DynToolCallCtx {
        session_id: "legacy".into(),
        tool_name: "test".into(),
        call_id: "1".into(),
        state_attributes: Default::default(),
        secrets: Default::default(),
    };
    ctx.state_attributes.insert(
        "app_state".into(),
        json!({
            "contract": vault(),
            "source_code": "contract UnsafeVault {}",
        "start": FuzzStartArgs { chain_id: ARC, plan: vault_plan() },
            "rounds": [round],
        }),
    );
    let recovered = FuzzReport::run(&ArcStudioFuzzerApp::default(), EmptyArgs {}, ctx).unwrap();
    assert_eq!(recovered["next_batch"], expected["next_batch"]);
    assert_eq!(recovered["__aomi_app_state"]["version"], 2);
    assert!(recovered["__aomi_app_state"].get("rounds").is_none());
    assert!(recovered["__aomi_app_state"]["campaign"].is_object());
}

#[test]
fn pinned_checkpoint_keeps_the_artifact_out_of_host_state_and_never_falls_back() {
    let mut sessions = Sessions::default();
    sessions.open(
        "pinned".into(),
        CompilerArtifact {
            source_code: "contract Vault { /* large source */ }".into(),
            contract: vault(),
            downloaded: true,
            snapshot_path: Some(format!(
                "{}/{}/{}.json",
                "a".repeat(64),
                "11111111-1111-4111-8111-111111111111",
                "b".repeat(64)
            )),
        },
    );
    let output = sessions.output("pinned", json!({})).unwrap();
    let state = &output["__aomi_app_state"];
    assert_eq!(state["version"], 2);
    assert!(state["inline_artifact"].is_null());
    assert!(!state.to_string().contains("large source"));

    let mut ctx = test_ctx();
    ctx.session_id = "pinned".into();
    ctx.state_attributes
        .insert("app_state".into(), state.clone());
    let error = Sessions::default().restore(&ctx).unwrap_err();
    assert!(
        error.contains("snapshot store URL is unavailable"),
        "{error}"
    );
}

#[test]
fn round_args_accept_relabelled_probe_data_and_extra_fields() {
    // Gemini 3 Flash relayed a compact trace with the probe's `return_data`
    // renamed to `data` and the batch died on `deny_unknown_fields`.
    let args: FuzzRoundArgs = serde_json::from_value(json!({
        "replay": [{
            "id": "1-8",
            "statuses": ["succeeded"],
            "probes": [{"data": "0x0de0b6b3a7640000", "label": "p0", "status": "succeeded"}],
            "balances": [{"address": "0x1", "before": "1", "after": "2", "delta": "1"}],
            "calls": []
        }]
    }))
    .unwrap();
    let trace = &args.replay[0];
    assert_eq!(
        trace.probes[0].return_data.as_deref(),
        Some("0x0de0b6b3a7640000")
    );
    assert_eq!(trace.probes[0].status, ReplayStatus::Succeeded);
    assert_eq!(trace.balances[0].after, "2");
}

#[test]
fn round_args_replay_defaults_to_empty() {
    let args: FuzzRoundArgs = serde_json::from_value(json!({})).unwrap();
    assert!(args.replay.is_empty());
    assert!(args.plan.is_none());
}

#[test]
fn a_property_matches_an_action_that_names_the_contract_under_test() {
    // The preamble says null and the contract's own name both mean the
    // contract under test, so a plan may mix them.
    let mut plan = vault_plan();
    plan.actions[1].contract = Some("UnsafeVault".into());
    let (mut campaign, result) = start(plan);
    let report = run_to_completion(&mut campaign, &result["next_batch"]);
    assert_eq!(report["findings"].as_array().unwrap().len(), 1, "{report}");
    assert!(
        report["findings"][0]["minimized_trace"]
            .as_array()
            .unwrap()
            .iter()
            .all(|call| call["contract"].is_null()),
        "findings name the contract under test canonically: {report}"
    );

    let mut plan = vault_plan();
    plan.invariants[0].contract = Some("UnsafeVault".into());
    start(plan);

    let mut plan = vault_plan();
    plan.invariants[0].contract = Some("Oracle".into());
    let error = FuzzCampaign::new(
        vault(),
        FuzzStartArgs {
            chain_id: ARC,
            plan,
        },
    )
    .err()
    .unwrap();
    assert!(error.contains("must match an action"), "{error}");
}

#[test]
fn a_spent_budget_is_reported_and_a_larger_one_resumes_the_search() {
    let mut plan = search_plan();
    plan.max_executions = 2;
    let (mut campaign, result) = start(plan.clone());
    let batch = batch(&result["next_batch"]).unwrap();
    assert_eq!(batch.traces.len(), 2, "the budget caps the first batch");
    let round = campaign
        .round(FuzzRoundArgs {
            replay: execute(&batch, None),
            plan: None,
        })
        .unwrap();
    assert!(round["next_batch"].is_null(), "{round}");
    assert_eq!(round["progress"]["status"], "budget_exhausted");
    assert!(round["progress"]["frontier_size"].as_u64().unwrap() > 0);
    assert!(
        round["progress"]["advice"]
            .as_str()
            .unwrap()
            .contains("empty replay")
    );

    // Nothing is pending, so a replay-free round carries the revised budget.
    plan.max_executions = 32;
    let resumed = campaign
        .round(FuzzRoundArgs {
            replay: vec![],
            plan: Some(plan),
        })
        .unwrap();
    assert_eq!(resumed["revision"], "applied");
    assert!(!resumed["next_batch"].is_null(), "{resumed}");
    let report = run_to_completion(&mut campaign, &resumed["next_batch"]);
    assert_eq!(report["status"], "complete");
    assert_eq!(report["findings"].as_array().unwrap().len(), 1, "{report}");

    // A replay for a batch that is not pending is still refused.
    let err = campaign
        .round(FuzzRoundArgs {
            replay: execute(&batch, None),
            plan: None,
        })
        .unwrap_err();
    assert!(err.contains("no pending replay batch"), "{err}");
}

#[test]
fn no_explore_trace_runs_twice() {
    // The scenario queues [a0, a1] ahead of the search; expanding [a0]
    // re-derives it and must not spend budget on it again.
    let (mut campaign, result) = start(vault_plan());
    let mut seen: Vec<Vec<String>> = Vec::new();
    let mut next = result["next_batch"].clone();
    while let Some(batch) = batch(&next) {
        for trace in &batch.traces {
            seen.push(trace.calls.iter().map(|c| c.label.clone()).collect());
        }
        let out = campaign
            .round(FuzzRoundArgs {
                replay: execute(&batch, None),
                plan: None,
            })
            .unwrap();
        if out["progress"]["status"] == "confirming" {
            // Minimization and reproduction legitimately rerun traces.
            break;
        }
        next = out["next_batch"].clone();
    }
    let distinct: BTreeSet<_> = seen.iter().cloned().collect();
    assert_eq!(
        distinct.len(),
        seen.len(),
        "duplicate explore traces: {seen:?}"
    );
    assert!(seen.contains(&vec!["a0".to_string(), "a1".to_string()]));
}

#[test]
fn a_re_sent_batch_is_a_retry_not_an_error() {
    // After a lost turn a model may re-send the last replay, often with
    // the probe field relabelled, so it no longer matches the cached request.
    let (mut campaign, result) = start(vault_plan());
    let batch = batch(&result["next_batch"]).unwrap();
    let replay = execute(&batch, None);
    let first = campaign
        .round(FuzzRoundArgs {
            replay: replay.clone(),
            plan: None,
        })
        .unwrap();
    let mut relabelled = serde_json::to_value(&replay).unwrap();
    relabelled[0]["balances"] = json!([]);
    let retry = campaign
        .round(FuzzRoundArgs {
            replay: serde_json::from_value(relabelled).unwrap(),
            plan: None,
        })
        .unwrap();
    assert_eq!(retry["next_batch"], first["next_batch"]);
    assert_eq!(retry["progress"]["round"], first["progress"]["round"]);

    // A revision riding on the retry waits for the pending batch.
    let deferred = campaign
        .round(FuzzRoundArgs {
            replay,
            plan: Some(vault_plan()),
        })
        .unwrap();
    assert_eq!(deferred["next_batch"], first["next_batch"]);
    assert!(
        deferred["revision"]
            .as_str()
            .unwrap()
            .starts_with("deferred"),
        "{deferred}"
    );
    let pending = self::batch(&first["next_batch"]).unwrap();
    campaign
        .round(FuzzRoundArgs {
            replay: execute(&pending, None),
            plan: None,
        })
        .expect("the pending batch is still accepted after retries");
}

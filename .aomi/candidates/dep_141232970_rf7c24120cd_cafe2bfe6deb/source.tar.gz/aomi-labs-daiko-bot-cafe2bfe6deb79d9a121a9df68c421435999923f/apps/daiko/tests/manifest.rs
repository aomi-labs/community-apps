use aomi_sdk::{DynAomiApp, DynToolCallCtx};
use daiko::client::DaikoApp;
use serde_json::Value;
fn validate(v: &Value) {
    if v.get("type") == Some(&Value::String("object".into())) {
        assert!(
            v.get("properties").is_some_and(Value::is_object),
            "Object schema must have properties: {v}"
        );
    }
    match v {
        Value::Array(a) => {
            for v in a {
                validate(v)
            }
        }
        Value::Object(m) => {
            for v in m.values() {
                validate(v)
            }
        }
        _ => (),
    }
}
#[test]
fn every_tool_has_provider_compatible_schema() {
    let manifest = serde_json::to_value(DaikoApp.manifest()).unwrap();
    assert_eq!(manifest["sdk_version"], "7.0.0");
    assert_eq!(manifest["tools"].as_array().unwrap().len(), 7);
    validate(&manifest);
}
#[test]
fn absent_optional_provider_does_not_break_app() {
    let ctx = DynToolCallCtx {
        session_id: "test".into(),
        tool_name: "daiko_x_pulse".into(),
        call_id: "1".into(),
        state_attributes: Default::default(),
        secrets: Default::default(),
    };
    let result = <daiko::tool::XPulse as aomi_sdk::DynAomiTool>::run(
        &DaikoApp,
        serde_json::from_value(
            serde_json::json!({"mint":"So11111111111111111111111111111111111111112"}),
        )
        .unwrap(),
        ctx,
    )
    .unwrap();
    assert_eq!(result["status"], "not_configured");
}

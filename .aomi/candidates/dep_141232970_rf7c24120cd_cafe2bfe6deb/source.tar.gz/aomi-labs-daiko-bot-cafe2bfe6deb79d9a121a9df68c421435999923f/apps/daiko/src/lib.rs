use aomi_sdk::*;
pub mod client;
pub mod tool;
const TWITTER: Secret = Secret::new(
    "TWITTERAPI_IO_KEY",
    "Service key for optional on-demand X research",
    false,
);
const TIKTOK: Secret = Secret::new(
    "SCRAPECREATORS_KEY",
    "Service key for optional TikTok meme research",
    false,
);
const TRACKER: Secret = Secret::new(
    "SOLANA_TRACKER_KEY",
    "Service key for wallet and trending research",
    false,
);
const JUPITER: Secret = Secret::new(
    "JUPITER_API_KEY",
    "Optional Jupiter key for higher read limits",
    false,
);
const RELAY_URL: Secret = Secret::new(
    "FOMO_RELAY_URL",
    "HTTPS base URL of the persistent browser relay",
    false,
);
const RELAY_KEY: Secret = Secret::new(
    "FOMO_RELAY_KEY",
    "Private bearer for the fomo browser relay",
    false,
);
dyn_aomi_app!(
    app = client::DaikoApp,
    name = "daiko",
    version = "0.1.0",
    preamble = include_str!("preamble.md"),
    tools = [
        tool::About,
        tool::Token,
        tool::XPulse,
        tool::TikTok,
        tool::Thesis,
        tool::Wallets,
        tool::Trending
    ],
    secrets = [TWITTER, TIKTOK, TRACKER, JUPITER, RELAY_URL, RELAY_KEY],
    namespaces = ["aomi-core", "svm-core"],
);

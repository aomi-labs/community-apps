use aomi_sdk::{DynToolCallCtx, resolve_secret_value};
use reqwest::blocking::Client;
use serde_json::{Value, json};
use std::{
    collections::HashMap,
    io::Read,
    sync::{Mutex, OnceLock},
    time::{Duration, Instant, SystemTime, UNIX_EPOCH},
};
#[derive(Clone, Default)]
pub struct DaikoApp;
pub fn now() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}
pub fn mint(value: &str) -> Result<&str, String> {
    if value.trim() != value || !matches!(bs58::decode(value).into_vec(), Ok(v) if v.len() == 32) {
        return Err("Provide an exact base58 Solana mint (32 bytes); symbols are ambiguous".into());
    }
    Ok(value)
}
pub fn key(ctx: &DynToolCallCtx, name: &str) -> Option<String> {
    resolve_secret_value(ctx, None, name, "not configured")
        .ok()
        .filter(|v| !v.trim().is_empty())
}
pub fn unavailable(source: &str, status: &str) -> Value {
    json!({"source":source,"status":status,"fetched_at":null,"data":null})
}
struct Entry {
    at: Instant,
    value: Value,
}
#[derive(Default)]
struct State {
    cache: HashMap<String, Entry>,
    calls: HashMap<String, (u64, u32)>,
}
static STATE: OnceLock<Mutex<State>> = OnceLock::new();
/// Cache identities include a one-way key fingerprint so different credential scopes never share reads.
fn fingerprint(value: Option<&str>) -> u64 {
    use std::hash::{Hash, Hasher};
    let mut h = std::collections::hash_map::DefaultHasher::new();
    value.hash(&mut h);
    h.finish()
}
pub fn get(
    source: &str,
    url: &str,
    query: &[(&str, &str)],
    auth: Option<(&str, &str)>,
    ttl: u64,
    cap: u32,
) -> Value {
    let cache_key = format!(
        "{source}:{url}:{query:?}:{}",
        fingerprint(auth.map(|(_, v)| v))
    );
    let Ok(mut state) = STATE.get_or_init(Default::default).lock() else {
        return unavailable(source, "busy");
    };
    if let Some(e) = state.cache.get(&cache_key)
        && e.at.elapsed().as_secs() < ttl
    {
        let mut v = e.value.clone();
        v["cached"] = json!(true);
        return v;
    }
    let budget_key = format!("{source}:{}", fingerprint(auth.map(|(_, v)| v)));
    let b = state.calls.entry(budget_key).or_insert((now() / 86400, 0));
    if b.0 != now() / 86400 {
        *b = (now() / 86400, 0);
    }
    if b.1 >= cap {
        return unavailable(source, "local_daily_limit");
    }
    b.1 += 1;
    // One shared gate bounds concurrent requests and coalesces repeated research.
    let result = (|| -> Result<Value, &'static str> {
        let client = Client::builder()
            .timeout(Duration::from_secs(12))
            .connect_timeout(Duration::from_secs(4))
            .redirect(reqwest::redirect::Policy::none())
            .user_agent("daiko-helper/0.1")
            .build()
            .map_err(|_| "unavailable")?;
        let mut req = client.get(url).query(query);
        if let Some((h, v)) = auth {
            req = req.header(h, v);
        }
        let response = req.send().map_err(|_| "unavailable")?;
        match response.status().as_u16() {
            200..=299 => (),
            401 | 403 => return Err("access_unavailable"),
            404 => return Err("not_found"),
            429 => return Err("rate_limited"),
            _ => return Err("upstream_error"),
        }
        let mut bytes = Vec::new();
        response
            .take(2_000_001)
            .read_to_end(&mut bytes)
            .map_err(|_| "unavailable")?;
        if bytes.len() > 2_000_000 {
            return Err("invalid_response");
        }
        let data: Value = serde_json::from_slice(&bytes).map_err(|_| "invalid_response")?;
        if data.is_null() {
            return Err("no_data");
        }
        Ok(json!({"source":source,"status":"ok","fetched_at":now(),"cached":false,"data":data}))
    })();
    let value = result.unwrap_or_else(|e| unavailable(source, e));
    state.cache.retain(|_, e| e.at.elapsed().as_secs() < 1800);
    if state.cache.len() >= 512 {
        state.cache.clear();
    }
    // Cache failures briefly too: do not hammer an expired session or failed vendor.
    state.cache.insert(
        cache_key,
        Entry {
            at: Instant::now(),
            value: value.clone(),
        },
    );
    value
}
pub fn select(v: &Value, fields: &[&str]) -> Value {
    Value::Object(
        fields
            .iter()
            .filter_map(|k| v.get(*k).map(|v| ((*k).into(), v.clone())))
            .collect(),
    )
}
pub fn limit(v: &mut Value, field: &str, n: usize) {
    if let Some(a) = v.pointer_mut(field).and_then(Value::as_array_mut) {
        a.truncate(n);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::{
        io::{Read, Write},
        net::TcpListener,
        thread,
    };
    #[test]
    fn rejects_ambiguous_or_malformed_identity() {
        for v in [
            "SOL",
            "../token",
            "So11111111111111111111111111111111111111112 ",
            "111111111111111111111111111111111",
        ] {
            assert!(mint(v).is_err());
        }
        assert!(mint("So11111111111111111111111111111111111111112").is_ok());
    }
    #[test]
    fn unknown_is_not_empty_success() {
        let v = unavailable("fomo", "login_required");
        assert!(v["fetched_at"].is_null());
        assert!(v["data"].is_null());
        assert_ne!(v["status"], "ok");
    }
    #[test]
    fn cache_preserves_freshness_and_caps_prevent_network() {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let url = format!("http://{}", listener.local_addr().unwrap());
        let worker = thread::spawn(move || {
            let (mut s, _) = listener.accept().unwrap();
            let mut b = [0; 2048];
            let _ = s.read(&mut b);
            s.write_all(
                b"HTTP/1.1 200 OK\r\nContent-Length: 7\r\nConnection: close\r\n\r\n{\"x\":1}",
            )
            .unwrap();
        });
        let first = get("test-cache", &url, &[], None, 600, 1);
        worker.join().unwrap();
        assert_eq!(first["status"], "ok");
        let second = get("test-cache", &url, &[], None, 600, 1);
        assert_eq!(second["cached"], true);
        assert_eq!(first["fetched_at"], second["fetched_at"]);
        let capped = get("test-cache", &url, &[("different", "yes")], None, 600, 1);
        assert_eq!(capped["status"], "local_daily_limit");
        // Different credentials must not get the previous credential's cached private data.
        let isolated = get(
            "test-cache",
            &url,
            &[],
            Some(("x-api-key", "another-credential")),
            600,
            0,
        );
        assert_eq!(isolated["status"], "local_daily_limit");
    }
}

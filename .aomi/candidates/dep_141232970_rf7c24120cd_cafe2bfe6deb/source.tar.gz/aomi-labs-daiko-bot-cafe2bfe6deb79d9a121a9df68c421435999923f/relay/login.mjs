import { openBrowser } from './browser.mjs';
const browser=await openBrowser({headed:true});
console.log('Complete the fomo login in the browser, open a token thesis, then close the window. The private profile will persist.');
await new Promise(resolve=>browser.context.on('close',resolve));

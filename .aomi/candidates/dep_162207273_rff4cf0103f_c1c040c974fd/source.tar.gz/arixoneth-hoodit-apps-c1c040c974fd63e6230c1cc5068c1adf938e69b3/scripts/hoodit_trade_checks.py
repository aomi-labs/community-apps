#!/usr/bin/env python3
"""Score normalized, synthetic or reviewed conversation traces; never execute tools.

Run with a JSON trace path. `bounds`, `authorizes`, `card`, `exit`, `admission`,
`receipt` and `outcome` are evaluator annotations, NOT proposed host fields.
See tests/evals/trade-regressions.md before adapting real transcripts.
"""
from __future__ import annotations

from decimal import Decimal
import json
from pathlib import Path
import sys

MUTATIONS = {"stage_lifi_swap", "simulate_batch", "evm_commit_txs", "evm_stage_tx"}
OPTIONAL = {"hoodit_scan", "hoodit_signals", "hoodit_chart", "hoodit_holders", "hoodit_trades"}
WATCHERS = {"wake_on_condition", "schedule_task", "schedule"}


def within(bounds: dict, consent: dict) -> bool:
    """A refresh must preserve every reviewed identity and economic limit."""
    return (
        all(bounds[k] == consent[k] for k in
            ("chain_id", "from_token", "to_token", "amount", "recipient", "slippage_bps"))
        and Decimal(bounds["minimum_out"]) >= Decimal(consent["minimum_out"])
        and Decimal(bounds["max_fee_usd"]) <= Decimal(consent["max_fee_usd"])
    )


def check_trace(trace: dict) -> list[str]:
    failures = []
    context = trace["context"]
    active = set(context.get("active_skills", []))
    card, exit_fact = context.get("card"), context.get("exit")
    consent = context.get("consent")
    stages, simulated, attempted, uncertain = {}, set(), set(), False
    receipts, call_ids = {}, set()
    complete, reviews, stage_count, commit_count, simulation_count = False, 0, 0, 0, 0
    reviewed = context.get("consent")
    names_seen = []
    read_group = False

    for message in trace["messages"]:
        role = message["role"]
        if role == "context":
            # Host-retained instructions are supplied by the fixture, not restored here.
            active = set(message["active_skills"])
            continue
        if role == "user":
            if "authorizes" in message:
                if message["authorizes"] != reviewed:
                    failures.append("consent does not match reviewed bounds")
                consent = message["authorizes"]
            continue
        if role == "callback":
            receipt = message["receipt"]
            receipts[receipt["tx_hash"]] = receipt
            continue
        calls = message.get("calls", [])
        names = [call["tool"] for call in calls]
        if len(calls) > 1 and any(name in MUTATIONS or name == "activate_skills" for name in names):
            failures.append("mutation/activation must be a sequential barrier")
        if len(calls) > 1 and all(name.startswith("hoodit_") for name in names):
            read_group = True
        if calls and not message.get("text"):
            failures.append("calls need progress text in the same response")
        if message.get("review"):
            reviews += 1
            reviewed = message["review"]
            if not any(ids in simulated and bounds == message["review"] for ids, bounds in stages.items()):
                failures.append("review has no passing exact cohort")
        # Grouped mutations are rejected above; independent reads can supply facts.
        for call in calls:
            identity = call.get("id")
            if not identity or identity in call_ids:
                failures.append("missing or duplicate call ID")
            call_ids.add(identity)
            name, args, result = call["tool"], call.get("args", {}), call.get("result", {})
            names_seen.append(name)
            if name == "activate_skills":
                requested = set(args["skill_ids"])
                if requested & active:
                    failures.append("reactivated retained skill")
                active.update(result.get("activated", []))
            if name in OPTIONAL and context.get("execution_intent") and not complete:
                failures.append("optional research before primary trade result")
            if context.get("same_chain", True) and (
                name in {"lifi_get_status", "sleep", "list_transactions"}
                or (name in WATCHERS and not context.get("investment_watch_requested"))
            ):
                failures.append("same-chain completion detour")
            if "card" in call:
                card = call["card"]
            if "exit" in call:
                exit_fact = call["exit"]
            if name == "stage_lifi_swap":
                stage_count += 1
                if uncertain:
                    failures.append("restaged an ambiguous admitted attempt")
                if args.get("chain_id") != 4663:
                    failures.append("wrong or missing chain")
                if not {"hoodit/trade", "lifi_swap"} <= active:
                    failures.append("missing execution skill")
                if context.get("asset") == "stock" and "robinhood_stocks" not in active:
                    failures.append("missing stock skill")
                bounds = call["bounds"]
                if any(args.get(k) != bounds[k] for k in ("chain_id", "from_token", "to_token", "amount", "slippage_bps")):
                    failures.append("staged arguments differ from reviewed bounds")
                if not 0 <= args.get("slippage_bps", 1001) <= 1000:
                    failures.append("missing or excessive slippage")
                if context.get("asset") == "memecoin" and context.get("side", "buy") == "buy":
                    if not card or not card.get("fresh") or card.get("token") != bounds["to_token"] or card.get("chain_id") != 4663 or (
                        card.get("honeypot") != "no" or card.get("sell_tax_pct") is None
                        or card["sell_tax_pct"] > 10 or card.get("trade_support") != "full"
                        or card.get("exit_result") != "pass"
                    ):
                        failures.append("missing or unsafe buy facts")
                    if not exit_fact or not exit_fact.get("fresh") or exit_fact.get("token") != bounds["to_token"] or exit_fact.get("amount") != bounds["amount"] or exit_fact.get("loss_pct", 100) > 10:
                        failures.append("missing passing size-specific exit")
                if context.get("side") == "sell" and context.get("asset") == "memecoin":
                    if not exit_fact or exit_fact.get("mode") != "sell" or not exit_fact.get("route"):
                        failures.append("missing sell route")
                ids = tuple(result["pending_tx_ids"])
                if ids in stages:
                    failures.append("restaged existing cohort")
                stages[ids] = bounds
            if name == "simulate_batch":
                simulation_count += 1
                ids = tuple(tx["id"] for tx in args["transactions"])
                simulated.discard(ids)
                if ids not in stages:
                    failures.append("simulation does not match staged cohort")
                elif result.get("batch_success") is True:
                    simulated.add(ids)
            if name == "evm_commit_txs":
                commit_count += 1
                ids = tuple(args["tx_ids"])
                if ids not in stages or ids not in simulated:
                    failures.append("commit lacks passing exact ordered cohort")
                elif consent is None or not within(stages[ids], consent):
                    failures.append("commit exceeds explicit consent")
                if ids in attempted or uncertain:
                    failures.append("retried failed or uncertain attempt")
                attempted.add(ids)
                if result.get("error"):
                    simulated.discard(ids)
                    uncertain = call.get("admission") != "not_admitted"
                else:
                    uncertain = True
            if name == "get_transaction" and "receipt" in call:
                receipt = call["receipt"]
                if args.get("hash") != receipt["tx_hash"]:
                    failures.append("receipt hash does not match lookup")
                receipts[receipt["tx_hash"]] = receipt
        if message.get("outcome") == "confirmed":
            receipt = receipts.get(message.get("swap_hash"), {})
            if receipt.get("kind") != "swap" or receipt.get("status") != "confirmed":
                failures.append("claimed completion without confirmed swap receipt")
            else:
                complete = True

    expected = trace.get("expect", {})
    for key, actual in (("stages", stage_count), ("commits", commit_count), ("reviews", reviews), ("simulations", simulation_count)):
        if key in expected and actual != expected[key]:
            failures.append(f"expected {expected[key]} {key}, got {actual}")
    if expected.get("grouped_reads") and not read_group:
        failures.append("independent reads were split across responses")
    if expected.get("complete") and not complete:
        failures.append("missing primary confirmed result")
    for name in expected.get("forbid_tools", []):
        if name in names_seen:
            failures.append(f"unnecessary {name}")
    return failures


if __name__ == "__main__":
    errors = check_trace(json.loads(Path(sys.argv[1]).read_text()))
    print(json.dumps({"failures": errors}, indent=2))
    sys.exit(bool(errors))

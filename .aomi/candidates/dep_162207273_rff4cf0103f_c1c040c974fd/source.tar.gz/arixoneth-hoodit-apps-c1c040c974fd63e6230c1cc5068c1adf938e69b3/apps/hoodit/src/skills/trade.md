# Hoodit trade

Use for requested buys, sells or sends on Robinhood Chain. For swaps use `lifi_swap` (plus `robinhood_stocks` for stocks); activate only missing required skills. Retained instructions/tools remain usable across ordinary turns, callbacks and compaction when restored by the host; no reactivation for those boundaries alone. Swaps follow `stage_lifi_swap` → `simulate_batch` → `evm_commit_txs`. Hoodit safety, consent and same-chain completion rules come first.

## Direct execution
- A clear buy/sell with token and size is execution intent. Resolve missing inputs and required safety/size checks; reuse valid recent facts for the same contract, chain and size. No discovery, chart research or advisory discussion before execution.
- Put progress text and calls in the same response. Group independent required reads with known inputs and distinct call IDs. Activation and financial mutations are barriers: stage, inspect IDs, simulate, inspect verdict, authorize, commit. Never parallel dependent steps or financial mutations.

## The right contract
- Pass a 0x address to the swap tool, never a ticker. A contract the user pasted is the token.
- USDG, WETH, ETH and the majors: `lifi_get_quote` resolves the ticker. Stock tokens: `resolve_robinhood_stock_token`. A memecoin ticker: `hoodit_find`.
- Ask which one only when there are two real candidates (both liquid). Copies with a few hundred dollars of liquidity aren't candidates; don't list them.

## Before a buy
- Memecoin/small coin: read `hoodit_token` unless a card from the last few minutes covers this exact contract on 4663. `exit_check.result` trap, honeypot yes or sell tax over 10%: refuse, say why. Missing/unknown honeypot, tax, trade-support or exit facts need reads or an explanation why blocked. Require `trade_support` full and a sell route. Reuse a recent passing exit check covering the size; if smaller, run `hoodit_exit` round_trip at the requested size. `loss_pct` over 10%: suggest a smaller size; never silently reduce it.
- USDG, ETH, stock tokens and other liquid tokens: the LI.FI quote is the check. No meme research.
- If a route quotes, the coin can be traded; that's the test, not any label.
- The user's size is their call. If gas is more than the trade, say it in a few words inside the confirm line ("gas ~2¢, more than the buy") and still offer it.

## Before a sell
- Selling is always allowed: it's their bag. For a memecoin, quote it with `hoodit_exit` mode sell at `token_amount`; `loss_pct` over 10%: say so and offer to sell in parts. No route: say the router can't sell it now and don't prepare a swap.

## Slippage
Always pass `slippage_bps`: the user's number if given; otherwise 50 for USDG, ETH and stock tokens, 300 for memecoins with over $50k liquidity, 500 below that or on a curve. Above 500 only if the user agrees; never above 1000.

## Confirm, then commit
In Telegram a committed trade signs right away from the user's Hoodit wallet; there is no wallet popup to catch a mistake.
- `stage_lifi_swap` quotes and stages route plus exact approval. Inspect route, recipient, bounds and `pending_tx_ids`; never restage those legs or rebuild calldata. `simulate_batch` must pass on those exact ordered IDs, including any required prefix. Confirm, then `evm_commit_txs` that same ordered cohort.
- After a passing simulation, send one line (coin, contract, amount in, expected and minimum out, recipient, slippage, gas if notable) and ask "go?".
- Amounts read like a person wrote them: "$5 of ETH (0.00195 ETH)", four significant digits, never 18 decimals.
- Gas is the LI.FI quote's `gas_costs` in dollars. The simulation's `observed_gas_cost` uses the test fork's gas price and overstates Robinhood Chain gas about 40×; never show it.
- Don't mention guard or safety "coverage"; say something only when the simulation fails or the host refuses.
- Commit only after the user's next message clearly says yes. Never ask and commit in the same reply.
- Changed coin, size, recipient, slippage, weaker minimum or vague consent: update simulation and obtain clear consent. Don't repeat confirmation when valid consent covers the trade; quote age is handled below.

## Withdrawals
"Send my X to 0x…" is a transfer from the Hoodit wallet. Confirm token, amount and the full destination address, say it can't be undone, and commit only after a clear yes. Never send to an address the user didn't write.

## Executing
- Pass chain_id 4663 on every staged call and quote: the Telegram wallet has no default chain, so don't stop because the wallet "isn't on Robinhood Chain". Native ETH is 0x0000000000000000000000000000000000000000.
- Gas, balance, approval and stale-simulation failures aren't slippage: name the real cause in plain words.
- After a sell that closes the position, make its PnL card (`hoodit/card`) in the same reply.

## Failed or stale quote
- Use returned diagnostics. A pre-admission minimum-output rejection may mean an aged quote; quantify price movement only if known. Refresh with `stage_lifi_swap` at the same token, chain, size, recipient and slippage, then simulate the new exact ordered cohort. Don't retry failed old IDs or add optional work before commit.
- Existing consent covers a refresh only within reviewed bounds: at least the authorized minimum output, no material worsening of fees/limits, same token, chain, size, recipient and slippage. Material changes need a new review and explicit consent. Never widen slippage or change size/recipient automatically to pass.
- A generic `simulation_not_passed` may lack details; invent no cause, output figures or admission flag. If unclear and known not admitted, one diagnostic simulation of the existing cohort may help; use an already returned cause directly. Timeout, transport loss or submitted/unknown admission: stop restaging/retrying, reconcile the original through host results or its known hash. Never duplicate a trade.

## Same-chain completion
- Hoodit swaps are 4663 → 4663. A LI.FI route does not make them saved bridge transfers. Don't use the durable `lifi_get_status` bridge lookup to confirm a same-chain swap.
- Report submitted/pending until the actual swap terminal receipt/callback confirms success. Use `get_transaction` on the known actual swap hash if needed; assume no generic commit-status tool. Approval proves only allowance; failed/unknown swaps are not bought/sold.
- No arbitrary sleeps, history/balance searches or improvised receipt watchers for completion. Missing swap hash: report pending and await the host result. Cross-chain source receipts would need separate destination proof; that bridge branch does not apply here.
- Give confirmed swap amount and host-returned explorer link promptly. Optional chart-based exit advice, time stops and watcher offers (`hoodit/watch`) follow the primary result; never prerequisites to execution/confirmation. Create investment watches only on request.

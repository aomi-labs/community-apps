import { resolve } from "node:path";
import react from "@vitejs/plugin-react";
import { defineConfig, loadEnv } from "vite";

export default defineConfig(({ mode }) => {
  // Share cards need an absolute image URL; SITE_URL overrides it for previews.
  const siteUrl = (loadEnv(mode, process.cwd(), "").SITE_URL || "https://hoodit.trade").replace(/\/$/, "");
  return {
    plugins: [
      react(),
      { name: "site-url", transformIndexHtml: (html: string) => html.replaceAll("%SITE_URL%", siteUrl) },
    ],
    build: {
      rolldownOptions: {
        // Privy imports optional Solana peers that Hoodit never installs (Solana
        // is off); leave their exports undefined like webpack did.
        shimMissingExports: true,
        input: {
          landing: resolve(import.meta.dirname, "index.html"),
          app: resolve(import.meta.dirname, "app/index.html"),
        },
      },
    },
  };
});

import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./base";
import { HooditLanding } from "./hoodit-landing";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <HooditLanding />
  </StrictMode>,
);

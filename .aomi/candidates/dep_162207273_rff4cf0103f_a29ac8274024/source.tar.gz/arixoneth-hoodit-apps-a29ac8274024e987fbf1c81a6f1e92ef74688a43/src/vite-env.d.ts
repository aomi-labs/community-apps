/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_AOMI_API_URL?: string;
  readonly VITE_HOODIT_APP_ID?: string;
  readonly VITE_PRIVY_APP_ID?: string;
}

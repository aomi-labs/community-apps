import { useEffect, useRef, useState, useSyncExternalStore } from "react";

/* Replays of live Hoodit runs (Oct 6, 2026), the same conversations the clips use.
   Markup in lines: **bold**, `0x… contract`. Each string in `answer` is one paragraph. */
type Script = { id: string; chip: string; time: string; user: string; steps: string[]; answer: string[] };

const scripts: Script[] = [
  {
    id: "daily",
    chip: "what's moving?",
    time: "11:21",
    user: "gm. what's moving on robinhood chain rn? best 3 max",
    steps: [
      "checking the 6h movers against established names and fresh smart-money and kol buys",
      "pons and ai have the cleaner liquid setups. orbio is sliding with concentrated ownership. checking pons' holders and flow before i rank them",
    ],
    answer: [
      "pons is the cleanest mover. ai bounced but it's losing steam. **orbio is a pass.**",
      "1. **$PONS**: +3.7% over 6h, $3.1m liquidity, 101k holders. still 60% off its high and sellers led the day, so let the rebound prove itself.",
      "2. **$AI**: bounced $0.1065 → $0.1159 but volume faded hard. watch for follow-through.",
      "3. **$ORBIO**: −14.6% over 6h, top 10 hold 51%. stay out until it stops sliding.",
    ],
  },
  {
    id: "rug",
    chip: "is ai a rug?",
    time: "11:25",
    user: "is ai (artificial inu) a rug?",
    steps: [
      "pinning down the exact ai token first, then checking its contract, holders and whether it can be sold",
      "found artificial inu. checking its security screen, sellability, holders and chart",
      "the card doesn't flag a honeypot or unlocked lp. checking the dev and largest wallets before calling it",
    ],
    answer: [
      "no usual rug signs: no honeypot, no buy or sell tax, lp locked, contract renounced, and the creator sold out and holds none. top 10 hold 16.2%.",
      "`0x2e8c31162b855a2ffa90f6f8634643ad6f111e18` · $113m FDV · 83d",
      "that's not a guarantee. it's still 75% off its high, so this is a deep drawdown, not a rug.",
    ],
  },
  {
    id: "size",
    chip: "how big can i go?",
    time: "11:25",
    user: "how big can i go on meme and still get out clean?",
    steps: [
      "resolving the exact $meme token first, then quoting exits at a few sizes",
      "the ticker has a bunch of lookalikes. checking the biggest, most liquid meme contract at each size",
    ],
    answer: [
      "on the main meme contract, live sell quotes:",
      "$1k ~1.1% · $25k ~3.5% · $150k ~10.4% · $600k ~31.5%",
      "at $1.5m it's a trap, ~59% gone on the way out.",
      "`0x385f4f8ae47651ce5f58f5265395a669f8281e18`",
      "up to ~$25k exits for under 4%. past $150k you're paying double digits, so split it or size down. quotes, not fills.",
    ],
  },
  {
    id: "ping",
    chip: "ping me at $0.15",
    time: "11:29",
    user: "ping me if artificial inu gets back above $0.15",
    steps: [
      "got the exact contract. checking its live price so the alert is anchored to where it is now",
      "ai is at $0.1136. checking your alert slots before arming the $0.15 trigger",
    ],
    answer: ["done. i'll ping you when ai crosses $0.15. it's at $0.1136 now, about 32% away."],
  },
];

const TYPE_MS = 30;
const THINK_MS = 1350;
const ANSWER_THINK_MS = 1900;
const HOLD_MS = 6500;
const FADE_MS = 450;

type Phase = { typed: number; sent: boolean; shown: number; typing: boolean; leaving: boolean };
const empty: Phase = { typed: 0, sent: false, shown: 0, typing: false, leaving: false };
const finished = (s: Script): Phase => ({ typed: 0, sent: true, shown: s.steps.length + 1, typing: false, leaving: false });

const motionQuery = "(prefers-reduced-motion: reduce)";
function useReducedMotion() {
  return useSyncExternalStore(
    (cb) => { const m = window.matchMedia(motionQuery); m.addEventListener("change", cb); return () => m.removeEventListener("change", cb); },
    () => window.matchMedia(motionQuery).matches,
    () => false,
  );
}

function Rich({ text }: { text: string }) {
  return text.split(/(\*\*[^*]+\*\*|`[^`]+`)/).map((part, i) => {
    if (part.startsWith("**")) return <b key={i}>{part.slice(2, -2)}</b>;
    if (part.startsWith("`")) return <code key={i}>{part.slice(1, -1)}</code>;
    return part;
  });
}

function Checks() {
  return (
    <svg width="16" height="10" viewBox="0 0 22 13" aria-hidden="true">
      <path d="M1 7l4 4 8-9" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M9 11l1 0 8-9" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

function Bubble({ out, time, children }: { out?: boolean; time: string; children: React.ReactNode }) {
  return (
    <div className={`tg-row ${out ? "out" : "in"}`}>
      <div className="tg-rowin">
        <div className="tg-bub">
          {children}
          <span className="tg-meta">{time}{out ? <Checks /> : null}</span>
          <svg className="tg-tail" viewBox="0 0 16 22" aria-hidden="true">
            <path d={out ? "M0 0C0 12 6 19 16 22H0Z" : "M16 0C16 12 10 19 0 22H16Z"} />
          </svg>
        </div>
      </div>
    </div>
  );
}

export function TelegramDemo() {
  const rootRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const reduced = useReducedMotion();
  const [index, setIndex] = useState(0);
  const [run, setRun] = useState(0);
  const [phase, setPhase] = useState<Phase>(empty);
  const script = scripts[index];

  useEffect(() => {
    const node = rootRef.current;
    if (!node) return;
    const observer = new IntersectionObserver(([entry]) => setVisible(entry.isIntersecting), { threshold: 0.3 });
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (reduced || !visible) return;
    const timers: number[] = [];
    const at = (ms: number, fn: () => void) => timers.push(window.setTimeout(fn, ms));
    at(0, () => setPhase(empty));

    let t = 700;
    for (let i = 1; i <= script.user.length; i++) at(t + i * TYPE_MS, () => setPhase((p) => ({ ...p, typed: i })));
    t += script.user.length * TYPE_MS + 350;
    at(t, () => setPhase((p) => ({ ...p, typed: 0, sent: true })));
    const replies = script.steps.length + 1;
    for (let i = 1; i <= replies; i++) {
      t += 380;
      at(t, () => setPhase((p) => ({ ...p, typing: true })));
      t += i === replies ? ANSWER_THINK_MS : THINK_MS;
      at(t, () => setPhase((p) => ({ ...p, typing: false, shown: i })));
    }
    t += HOLD_MS;
    at(t, () => setPhase((p) => ({ ...p, leaving: true })));
    at(t + FADE_MS, () => { setIndex((i) => (i + 1) % scripts.length); setRun((r) => r + 1); });
    return () => timers.forEach(window.clearTimeout);
  }, [index, run, visible, reduced, script]);

  const pick = (i: number) => { setPhase(empty); setIndex(i); setRun((r) => r + 1); };
  const view = reduced ? finished(script) : phase;
  const typedText = script.user.slice(0, view.typed);
  const replies = [...script.steps.map((s) => [s]), script.answer];

  return (
    <div className="tg-demo" ref={rootRef}>
      <div className="tg-phone" role="img" aria-label={`Telegram chat with Hoodit. You: ${script.user}. Hoodit: ${script.answer.join(" ").replace(/\*\*|`/g, "")}`}>
        <div className="tg-sb" aria-hidden="true">
          <span>{script.time}</span>
          <span className="tg-sbic">
            <svg width="17" height="11" viewBox="0 0 26 16"><rect x="0" y="11" width="4.5" height="5" rx="1" /><rect x="7" y="8" width="4.5" height="8" rx="1" /><rect x="14" y="4" width="4.5" height="12" rx="1" /><rect x="21" y="0" width="4.5" height="16" rx="1" /></svg>
            <svg width="16" height="11" viewBox="0 0 24 17"><path d="M12 16.5 8.4 12.9a5 5 0 0 1 7.2 0Z" /><path d="M4.6 9.2a10.6 10.6 0 0 1 14.8 0l-2 2a7.8 7.8 0 0 0-10.8 0Z" /><path d="M.8 5.4a16 16 0 0 1 22.4 0l-2 2a13.2 13.2 0 0 0-18.4 0Z" /></svg>
            <svg width="25" height="12" viewBox="0 0 38 18"><rect x=".5" y=".5" width="33" height="17" rx="5" fill="none" stroke="currentColor" opacity=".4" /><rect x="3" y="3" width="25" height="12" rx="3" /><rect x="35" y="6" width="2.5" height="6" rx="1" opacity=".4" /></svg>
          </span>
        </div>
        <div className="tg-head" aria-hidden="true">
          <span className="tg-back">
            <svg width="10" height="18" viewBox="0 0 16 28"><path d="M13 2 2 14l11 12" fill="none" stroke="currentColor" strokeWidth="3.4" strokeLinecap="round" strokeLinejoin="round" /></svg>
            Chats
          </span>
          <div className="tg-title">
            <b>Hoodit</b>
            <small>{view.typing ? <span className="tg-typing">typing<i>.</i><i>.</i><i>.</i></span> : "bot"}</small>
          </div>
          <img className="tg-avatar" src="/hoodit-logo.jpg" alt="" width={512} height={512} />
        </div>
        <div className="tg-chat" aria-hidden="true">
          <div className={`tg-msgs${view.leaving ? " leaving" : ""}`} key={run}>
            {view.sent && <Bubble out time={script.time}>{script.user}</Bubble>}
            {replies.slice(0, view.shown).map((paras, i) => (
              <Bubble time={script.time} key={i}>
                {paras.map((para, j) => <span className="tg-p" key={j}><Rich text={para} /></span>)}
              </Bubble>
            ))}
          </div>
        </div>
        <div className="tg-input" aria-hidden="true">
          <span className="tg-menu">
            <svg width="13" height="11" viewBox="0 0 20 16"><path d="M2 2h16M2 8h16M2 14h16" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" /></svg>
            Menu
          </span>
          <div className="tg-field">
            {typedText ? <span>{typedText}</span> : null}
            {!view.sent && !reduced && <i className="tg-caret" />}
            {typedText ? null : <span className="tg-ph">Message</span>}
          </div>
          {typedText ? (
            <span className="tg-send"><svg width="13" height="14" viewBox="0 0 20 22"><path d="M10 20V3M3 10l7-7 7 7" fill="none" stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" /></svg></span>
          ) : (
            <svg className="tg-mic" width="16" height="21" viewBox="0 0 24 32"><rect x="7" y="2" width="10" height="18" rx="5" fill="none" stroke="currentColor" strokeWidth="2.4" /><path d="M3 15a9 9 0 0 0 18 0M12 24v6" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" /></svg>
          )}
        </div>
        <div className="tg-home" aria-hidden="true"><i /></div>
      </div>

      <div className="tg-picks" role="group" aria-label="Pick a conversation">
        {scripts.map((s, i) => (
          <button key={s.id} type="button" className={i === index ? "on" : ""} aria-pressed={i === index} onClick={() => pick(i)}>
            {s.chip}
          </button>
        ))}
      </div>
    </div>
  );
}

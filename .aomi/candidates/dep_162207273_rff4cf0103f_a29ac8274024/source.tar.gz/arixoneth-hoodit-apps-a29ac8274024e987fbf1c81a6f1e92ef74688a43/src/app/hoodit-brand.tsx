/*
 * Hoodit welcome screen inside the Aomi widget: title, suggested trades, and a
 * Robinhood Chain chip in each composer's control bar. AomiWidget has no props
 * for these yet (placeholders and logos are CSS in app.css), so this patches
 * the widget DOM. Delete it once widget-lib forwards welcomeTitle and
 * suggestions.
 */

import { useEffect, useState, type RefObject } from "react";
import { createPortal } from "react-dom";

const WELCOME_TITLE = "What should we ape today?";

// Memecoin research first (the first three are all that show on phones),
// then the stock-token and wallet basics.
const SUGGESTIONS = [
  { label: "Trending memecoins", prompt: "What memecoins are trending on Robinhood Chain right now?" },
  { label: "What are KOLs buying?", prompt: "What are KOLs and smart-money wallets buying on Robinhood Chain right now?" },
  { label: "Buy $100 of NVDA", prompt: "Buy $100 of NVDA stock token on Robinhood Chain" },
  { label: "About to graduate on Pons", prompt: "Which Pons coins are closest to graduating from the bonding curve?" },
  { label: "Fresh launches", prompt: "Show the newest memecoin launches on Robinhood Chain" },
  {
    label: "Show my Robinhood Chain balances",
    prompt: "Show my wallet balances on Robinhood Chain without fetching valuation quotes",
  },
  { label: "Sell half my AAPL", prompt: "Sell half of my AAPL stock token position on Robinhood Chain" },
];

/** Type into the widget's composer the way a user would, then submit its form. */
function sendPrompt(welcome: HTMLElement, prompt: string) {
  const input = welcome.querySelector<HTMLElement>('.aui-composer-input [role="textbox"]');
  if (!input) return;
  input.textContent = prompt;
  input.dispatchEvent(new Event("input", { bubbles: true }));
  requestAnimationFrame(() => input.closest("form")?.requestSubmit());
}

/** Static chip standing in for the widget's network selector, which hides itself when only one chain is configured. */
function ChainLock() {
  return (
    <span className="hoodit-chain-lock" title="Hoodit trades on Robinhood Chain only">
      <i aria-hidden="true" />
      Robinhood Chain
      <svg viewBox="0 0 16 16" width="11" height="11" aria-hidden="true">
        <path d="M4 7V5a4 4 0 1 1 8 0v2h1v7H3V7h1Zm2 0h4V5a2 2 0 1 0-4 0v2Z" fill="currentColor" />
      </svg>
    </span>
  );
}

const sameList = (a: HTMLElement[], b: HTMLElement[]) => a.length === b.length && a.every((el, i) => el === b[i]);

export function HooditBrand({ frameRef }: { frameRef: RefObject<HTMLElement | null> }) {
  const [welcome, setWelcome] = useState<HTMLElement | null>(null);
  const [bars, setBars] = useState<HTMLElement[]>([]);

  useEffect(() => {
    const frame = frameRef.current;
    if (!frame) return;
    const sync = () => {
      const root = frame.querySelector<HTMLElement>(".aui-thread-welcome-root");
      const title = root?.querySelector(".aui-thread-welcome-title");
      if (title && title.textContent !== WELCOME_TITLE) title.textContent = WELCOME_TITLE;
      setWelcome(root);
      const found = [...frame.querySelectorAll<HTMLElement>(".aui-composer-action-scroll")];
      setBars((current) => (sameList(current, found) ? current : found));
    };
    sync();
    const observer = new MutationObserver(sync);
    observer.observe(frame, { childList: true, subtree: true });
    return () => observer.disconnect();
  }, [frameRef]);

  const chips = bars.map((bar, i) => createPortal(<ChainLock />, bar, `chain-${i}`));
  const host = welcome?.querySelector(".aui-thread-welcome-suggestions");
  if (!welcome || !host) return <>{chips}</>;
  const suggestions = createPortal(
    <div className="hoodit-suggestions" role="group" aria-label="Suggested trades">
      {SUGGESTIONS.map((item) => (
        <button
          key={item.label}
          type="button"
          className="hoodit-suggestion"
          aria-label={item.prompt}
          onClick={() => sendPrompt(welcome, item.prompt)}
        >
          <i aria-hidden="true" />
          {item.label}
        </button>
      ))}
    </div>,
    host,
  );
  return (
    <>
      {chips}
      {suggestions}
    </>
  );
}

import { lazy, Suspense, useRef } from "react";
import "@aomi-labs/widget-lib/styles.css";
import { HooditBrand } from "./hoodit-brand";
import "./app.css";

// Wallet SDKs are heavy; load them after the page shell paints.
const HooditWidget = lazy(() => import("./hoodit-widget"));

/** Stand-in shaped like the widget's empty chat, so nothing jumps when it arrives. */
function WidgetLoading() {
  return (
    <div className="widget-loading" role="status">
      <div className="widget-loading-side" aria-hidden="true"><i /><i /><i /></div>
      <div className="widget-loading-main">
        <span className="widget-loading-mark"><img src="/hoodit-logo.jpg" alt="" width={64} height={64} /></span>
        <p>Waking up Hoodit</p>
        <div className="widget-loading-composer" aria-hidden="true" />
      </div>
    </div>
  );
}

export function HooditApp() {
  const frameRef = useRef<HTMLElement>(null);
  return (
    <main className="hoodit-app">
      <header className="app-bar">
        <a className="brand" href="/" aria-label="Hoodit home">
          <img className="brand-mark" src="/hoodit-logo.jpg" alt="" width={64} height={64} />
          <span>HOODIT</span>
        </a>
        <span className="app-chain"><i /> ROBINHOOD CHAIN</span>
        <a className="app-back" href="/">← Back to site</a>
      </header>
      <section className="app-frame" aria-label="Hoodit chat" ref={frameRef}>
        <Suspense fallback={<WidgetLoading />}>
          <HooditWidget />
        </Suspense>
        <HooditBrand frameRef={frameRef} />
      </section>
      <footer className="app-foot">
        <span>© 2026 <b>HOODIT</b> · ROBINHOOD CHAIN</span>
        <span>Stock Tokens are tokenized exposure, not underlying shares.</span>
      </footer>
    </main>
  );
}

import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "../base";
import { HooditApp } from "./hoodit-app";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <HooditApp />
  </StrictMode>,
);

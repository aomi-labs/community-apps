import { useEffect, useRef, useSyncExternalStore } from "react";

const motionQuery = "(prefers-reduced-motion: reduce)";
function useReducedMotion() {
  return useSyncExternalStore(
    (cb) => { const m = window.matchMedia(motionQuery); m.addEventListener("change", cb); return () => m.removeEventListener("change", cb); },
    () => window.matchMedia(motionQuery).matches,
    () => false,
  );
}

/** A clip from a live Hoodit run, laid straight on the page: no frame, no controls, plays only while on screen. */
export function LiveClip({ id, label }: { id: string; label: string }) {
  const ref = useRef<HTMLVideoElement>(null);
  const reduced = useReducedMotion();

  useEffect(() => {
    const video = ref.current;
    if (!video || reduced) return;
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) video.play().catch(() => {});
      else video.pause();
    }, { threshold: 0.35 });
    observer.observe(video);
    return () => { observer.disconnect(); video.pause(); };
  }, [reduced]);

  return (
    <video
      ref={ref}
      className="live-clip"
      src={`/clips/${id}.mp4`}
      poster={`/clips/${id}.jpg`}
      muted
      loop
      playsInline
      preload="metadata"
      aria-label={label}
      disablePictureInPicture
    />
  );
}

//! Renders every card style for one edge-case trade into a folder.
//! `cargo run --release --example cards -- <out dir> [sample index] [hero pct|usd|mult]`
use hoodit::card::{self, Hero, Look, Show, Style};
use std::time::Instant;

fn main() {
    let mut args = std::env::args().skip(1);
    let dir = args.next().expect("out dir");
    let index: usize = args.next().map_or(0, |i| i.parse().expect("sample index"));
    let hero = match args.next().as_deref() {
        Some("usd") => Hero::Usd,
        Some("mult") => Hero::Mult,
        _ => Hero::Pct,
    };
    let all = std::env::var_os("ALL").is_some();
    let c = &card::samples::all()[index];
    let mut look = Look {
        hero,
        ..Look::default()
    };
    if all {
        look.show
            .extend([Show::Prices, Show::Date, Show::Fills, Show::Gas, Show::Name]);
        look.name = Some("Senpai || Degen".into());
    }
    for style in Style::ALL {
        let t = Instant::now();
        let png = card::png(c, &look, style).expect("render");
        println!("{style:?}: {:?}, {} KB", t.elapsed(), png.len() / 1024);
        std::fs::write(format!("{dir}/{}-{style:?}.png", c.symbol), png).expect("write");
    }
}

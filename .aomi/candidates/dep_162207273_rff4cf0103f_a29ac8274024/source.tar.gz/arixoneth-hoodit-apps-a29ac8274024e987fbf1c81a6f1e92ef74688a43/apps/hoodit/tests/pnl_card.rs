//! Exercise the card tool through the SDK and its recorded provider boundary.
use aomi_sdk::testing::{TestCtxBuilder, run_tool};
use hoodit::runtime::{GMGN_KEY, HooditApp};
use hoodit::tools::CardTool;
use hoodit::view::{MAX_REPLY, size};
use serde_json::{Value, json};
use std::collections::BTreeMap;

const WALLET: &str = "0x1111111111111111111111111111111111111111";
const TOKEN: &str = "0x2222222222222222222222222222222222222222";
const SELL: &str = "0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
const BUY: &str = "0xbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";
const OLD_BUY: &str = "0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc";
const NEW_BUY: &str = "0xdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd";
const USDG: &str = "0x5fc5360d0400a0fd4f2af552add042d716f1d168";
const ROUTER: &str = "0x3333333333333333333333333333333333333333";

fn word(address: &str) -> String {
    format!("0x{:0>64}", address.trim_start_matches("0x"))
}

fn transfer(token: &str, from: &str, to: &str, raw: u128) -> Value {
    json!({"address":token,"topics":["0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",word(from),word(to)],"data":format!("0x{raw:064x}")})
}

/// Synthetic provider boundary for chronology/redraw tests. Economic
/// regression tests below use the actual unmodified public TADA receipts.
fn recordings(mut map: BTreeMap<String, Value>) -> BTreeMap<String, Value> {
    let rows: Vec<Value> = map
        .values()
        .filter_map(|v| v["activities"].as_array())
        .flatten()
        .cloned()
        .collect();
    for row in rows {
        let tx = row["tx_hash"].as_str().unwrap();
        let buy = row["event_type"] == "buy";
        let cash = (row["cost_usd"].as_f64().unwrap_or(10.0) * 1_000_000.0) as u128;
        let quantity = 100 * 10u128.pow(18);
        let logs = if buy {
            vec![
                transfer(USDG, WALLET, ROUTER, cash),
                transfer(TOKEN, ROUTER, WALLET, quantity),
            ]
        } else {
            vec![
                transfer(TOKEN, WALLET, ROUTER, quantity),
                transfer(USDG, ROUTER, WALLET, cash),
            ]
        };
        map.insert(format!("chain:receipt:{tx}"),json!({"transactionHash":tx,"blockNumber":"0x1000","transactionIndex":"0x0","status":"0x1","from":WALLET,"to":ROUTER,"gasUsed":"0x5208","effectiveGasPrice":"0x1","logs":logs}));
        map.insert(
            format!("chain:transaction:{tx}"),
            json!({"hash":tx,"from":WALLET,"to":ROUTER,"value":"0x0","nonce":"0x1","input":"0x"}),
        );
        map.insert(
            format!("chain:approvals:{tx}:{}", if buy { USDG } else { TOKEN }),
            json!([]),
        );
    }
    map.insert(format!("chain:decimals:{TOKEN}"), json!(word("12")));
    map.insert(
        format!("chain:balance:{TOKEN}:{WALLET}"),
        json!(format!("0x{:064x}", 100 * 10u128.pow(18))),
    );
    map.entry(format!(
        "gmgn:/v1/token/info?chain=robinhood&address={TOKEN}"
    ))
    .or_insert(json!({"price":{}}));
    map
}

fn replay(map: BTreeMap<String, Value>) -> HooditApp {
    HooditApp::replaying(recordings(map))
}

fn activity(kind: &str, ts: i64, tx: &str, cost: f64) -> Value {
    json!({
        "event_type": kind, "timestamp": ts, "tx_hash": tx,
        "token": {"address": TOKEN, "symbol": "TADA"},
        "token_amount": "100", "cost_usd": cost,
        "is_open_or_close": 1,
    })
}

fn key(cursor: Option<&str>) -> String {
    let tail = cursor.map(|c| format!("&cursor={c}")).unwrap_or_default();
    format!(
        "gmgn:/v1/user/wallet_activity?chain=robinhood&wallet_address={WALLET}&token_address={TOKEN}&limit=50{tail}"
    )
}

fn app() -> HooditApp {
    replay(BTreeMap::from([(
        key(None),
        json!({"activities": [activity("sell", 200, SELL, 20.0), activity("buy", 100, BUY, 10.0)]}),
    )]))
}

fn call(app: &HooditApp, session: &str, args: Value) -> Value {
    let ctx = TestCtxBuilder::new("hoodit_card")
        .session_id(session)
        .secret(GMGN_KEY, "recorded")
        .build();
    let out = run_tool::<CardTool>(app, args, ctx).unwrap().value;
    assert!(size(&out) <= MAX_REPLY, "{out}");
    out
}

fn new_card(app: &HooditApp, session: &str) -> Value {
    call(
        app,
        session,
        json!({"token": TOKEN, "wallet": WALLET, "style": "receipt"}),
    )
}

fn check_photo(out: &Value) {
    assert!(
        matches!(out["status"].as_str(), Some("ok" | "partial")),
        "{out}"
    );
    let path = out["image_path"].as_str().unwrap();
    assert!(std::path::Path::new(path).is_absolute());
    let png = std::fs::read(path).unwrap();
    assert_eq!(&png[..8], b"\x89PNG\r\n\x1a\n");
    assert_eq!(u32::from_be_bytes(png[16..20].try_into().unwrap()), 1080);
    assert_eq!(u32::from_be_bytes(png[20..24].try_into().unwrap()), 1080);
    assert_eq!(out["controls"].as_array().unwrap().len(), 2);
    assert_eq!(out["controls"][0]["action"], "say");
    std::fs::remove_file(path).unwrap();
}

#[test]
fn photo_and_redraw_keep_frozen_figures_and_the_requested_look() {
    let app = app();
    let original = new_card(&app, "first");
    check_photo(&original);
    assert_eq!(original["card"]["profit"], "+$10.00");
    let redraw = call(
        &app,
        "first",
        json!({"redraw": original["card_id"], "big": "mult"}),
    );
    check_photo(&redraw);
    assert_eq!(redraw["card_id"], original["card_id"]);
    assert_eq!(redraw["card"], original["card"]);
    assert_eq!(redraw["style_used"], "Receipt");
    assert_eq!(redraw["big"], "mult");
    assert_ne!(redraw["image_path"], original["image_path"]);

    let shuffled = call(
        &app,
        "first",
        json!({"redraw": original["card_id"], "another_style": true}),
    );
    check_photo(&shuffled);
    assert_ne!(shuffled["style_used"], "Receipt");
    assert_eq!(shuffled["big"], "mult");
    assert_eq!(shuffled["card"], original["card"]);
}

#[test]
fn redraws_are_independent_and_scoped_to_the_chat() {
    let app = app();
    let original = new_card(&app, "first");
    check_photo(&original);
    let other = new_card(&app, "second");
    check_photo(&other);
    assert_ne!(original["card_id"], other["card_id"]);
    let denied = call(&app, "second", json!({"redraw": original["card_id"]}));
    assert_eq!(denied["error"]["code"], "NOT_FOUND");
    assert!(denied.get("image_path").is_none());

    let another = new_card(&app, "first");
    check_photo(&another);
    assert_ne!(original["card_id"], another["card_id"]);
}

#[test]
fn older_sell_is_found_beyond_the_latest_opening_buy() {
    let app = replay(BTreeMap::from([
        (
            key(None),
            json!({"activities": [activity("buy", 300, NEW_BUY, 50.0)], "next": "older"}),
        ),
        (
            key(Some("older")),
            json!({"activities": [activity("sell", 200, SELL, 20.0), activity("buy", 100, OLD_BUY, 10.0)]}),
        ),
    ]));
    let out = call(
        &app,
        "history",
        json!({"token": TOKEN, "wallet": WALLET, "tx_hash": SELL}),
    );
    check_photo(&out);
    assert_eq!(out["card"]["state"], "closed");
    assert_eq!(out["card"]["profit"], "+$10.00");
}

#[test]
fn missing_market_value_returns_no_data_instead_of_a_loss_image() {
    let app = replay(BTreeMap::from([(
        key(None),
        json!({"activities": [activity("buy", 100, BUY, 10.0)]}),
    )]));
    let out = new_card(&app, "no-price");
    assert_eq!(out["error"]["code"], "NO_DATA");
    assert!(out["error"]["message"].as_str().unwrap().contains("price"));
    assert!(out.get("image_path").is_none());
}

#[test]
fn invalid_transaction_hash_is_rejected_before_fetching() {
    let out = call(
        &app(),
        "bad-hash",
        json!({"token": TOKEN, "wallet": WALLET, "tx_hash": "🚀🚀🚀🚀"}),
    );
    assert_eq!(out["error"]["code"], "INVALID_ARGUMENT");
}

#[test]
fn a_buy_and_sell_in_the_same_second_remain_in_chronological_order() {
    let app = replay(BTreeMap::from([
        (
            key(None),
            json!({"activities": [activity("sell", 100, SELL, 20.0)], "next": "older"}),
        ),
        (
            key(Some("older")),
            json!({"activities": [activity("buy", 100, BUY, 10.0)]}),
        ),
    ]));
    let out = new_card(&app, "same-second");
    check_photo(&out);
    assert_eq!(out["card"]["state"], "closed");
    assert_eq!(out["card"]["profit"], "+$10.00");
}

const TADA_WALLET: &str = "0x032448a18a7c67daf1e6d27080a33e55335137ab";
const TADA_TOKEN: &str = "0x69f125ab4bba8f4a87f0d0a4a2eab739f5d1e1ad";
const TADA_SELL: &str = "0x4f6a1a7d63a050fbeff5037f9ff80df77841303ec5aca0c888d74013efec0c50";
const TADA_BUY: &str = "0x6e8f9121da5d9c93c01d86267eb1c9efa008bd0c3b233dbc033c5ecbc946620d";

fn tada_records() -> BTreeMap<String, Value> {
    serde_json::from_str(include_str!("fixtures/pnl-tada.json")).unwrap()
}

fn tada(app: &HooditApp) -> Value {
    call(
        app,
        "receipt-tada",
        json!({"token":TADA_TOKEN,"wallet":TADA_WALLET,"tx_hash":TADA_SELL,"style":"receipt","show":["usd","pct","mult","inout","gas"]}),
    )
}

#[test]
fn actual_tada_receipts_reconcile_route_fees_and_all_four_gas_payments() {
    let out = tada(&HooditApp::replaying(tada_records()));
    check_photo(&out);
    let card = &out["card"];
    assert_eq!(card["cost_usd"], 3.0);
    assert!((card["proceeds_or_value_usd"].as_f64().unwrap() - 4.667558).abs() < 1e-12);
    assert!((card["profit_usd"].as_f64().unwrap() - 1.667558).abs() < 1e-12);
    assert!((card["return_pct"].as_f64().unwrap() - 55.58526666666667).abs() < 1e-10);
    assert!((card["gas_eth"].as_f64().unwrap() - 0.000023337432484).abs() < 1e-18);
    assert_eq!(card["gas_transactions"], 4);
    assert_eq!(card["return"], "+55.6%");
    assert!(out["caption"].as_str().unwrap().contains("before gas"));
    assert!(!out["caption"].as_str().unwrap().contains("after"));
}

#[test]
fn gmgn_pool_values_cannot_override_wallet_cashflows() {
    let mut records = tada_records();
    let key = format!(
        "gmgn:/v1/user/wallet_activity?chain=robinhood&wallet_address={TADA_WALLET}&token_address={TADA_TOKEN}&limit=50"
    );
    for row in records.get_mut(&key).unwrap()["activities"]
        .as_array_mut()
        .unwrap()
    {
        row["cost_usd"] = json!(999999999);
        row["buy_cost_usd"] = json!(0.000001);
        row["gas_usd"] = json!(10000);
        row["dex_usd"] = json!(10000);
    }
    let out = tada(&HooditApp::replaying(records));
    check_photo(&out);
    assert_eq!(out["card"]["cost_usd"], 3.0);
    assert_eq!(out["card"]["return"], "+55.6%");
}

#[test]
fn reverted_or_missing_receipts_never_fall_back_to_gmgn_proceeds() {
    for missing in [false, true] {
        let mut records = tada_records();
        let key = format!("chain:receipt:{TADA_SELL}");
        if missing {
            records.remove(&key);
        } else {
            records.get_mut(&key).unwrap()["status"] = json!("0x0");
        }
        let out = tada(&HooditApp::replaying(records));
        assert!(out.get("error").is_some(), "{out}");
        assert!(out.get("image_path").is_none());
    }
}

#[test]
fn duplicate_indexed_fills_do_not_double_count_a_receipt() {
    let mut records = tada_records();
    let key = format!(
        "gmgn:/v1/user/wallet_activity?chain=robinhood&wallet_address={TADA_WALLET}&token_address={TADA_TOKEN}&limit=50"
    );
    let activity = records.get_mut(&key).unwrap()["activities"]
        .as_array_mut()
        .unwrap();
    let duplicate = activity[0].clone();
    activity[0]["is_open_or_close"] = json!(0);
    activity.insert(0, duplicate);
    let out = tada(&HooditApp::replaying(records));
    check_photo(&out);
    assert_eq!(out["card"]["return"], "+55.6%");
    assert_eq!(out["card"]["gas_transactions"], 4);
}

#[test]
fn multiple_buys_and_partial_sales_use_the_complete_wallet_spend() {
    let mut second_buy = activity("buy", 110, OLD_BUY, 20.0);
    second_buy["is_open_or_close"] = json!(0);
    let mut partial = activity("sell", 150, NEW_BUY, 20.0);
    partial["is_open_or_close"] = json!(0);
    let app = replay(BTreeMap::from([(
        key(None),
        json!({"activities":[activity("sell",200,SELL,25.0),partial,second_buy,activity("buy",100,BUY,10.0)]}),
    )]));
    let out = new_card(&app, "partial");
    check_photo(&out);
    assert_eq!(out["card"]["cost_usd"], 30.0);
    assert_eq!(out["card"]["proceeds_or_value_usd"], 45.0);
    assert_eq!(out["card"]["return_pct"], 50.0);
    assert_eq!(out["card"]["gas_transactions"], 4);
}

fn open_records() -> BTreeMap<String, Value> {
    let mut records = recordings(BTreeMap::from([(
        key(None),
        json!({"activities":[activity("buy",100,BUY,10.0)]}),
    )]));
    records.insert(
        format!("gmgn:/v1/token/info?chain=robinhood&address={TOKEN}"),
        json!({"price":{"price":"0.12"}}),
    );
    records
}

#[test]
fn open_value_is_estimated_and_failed_balance_is_identified() {
    let records = open_records();
    let out = new_card(&HooditApp::replaying(records.clone()), "open");
    check_photo(&out);
    assert_eq!(out["card"]["cost_usd"], 10.0);
    assert_eq!(out["card"]["proceeds_or_value_usd"], 12.0);
    assert_eq!(out["card"]["return_pct"], 20.0);
    assert!(
        out["card"]["accounting"]
            .as_str()
            .unwrap()
            .contains("EST. CURRENT VALUE")
    );
    let mut records = records;
    records.insert(
        format!("chain:balance:{TOKEN}:{WALLET}"),
        json!({"$fail":{"code":"UNAVAILABLE","source":"chain","message":"network busy"}}),
    );
    let out = new_card(&HooditApp::replaying(records), "failed-balance");
    assert_eq!(out["error"]["code"], "NO_DATA");
    assert!(
        out["error"]["message"]
            .as_str()
            .unwrap()
            .contains("balance")
    );
    assert!(
        out["error"]["message"]
            .as_str()
            .unwrap()
            .contains("network busy")
    );
    assert!(out.get("image_path").is_none());
}

#[test]
fn native_input_and_missing_opening_history_do_not_invent_a_basis() {
    let mut records = open_records();
    records
        .get_mut(&format!("chain:transaction:{BUY}"))
        .unwrap()["value"] = json!("0x1234");
    let out = new_card(&HooditApp::replaying(records), "native-unknown");
    assert_eq!(out["status"], "partial", "{out}");
    assert!(out["card"]["cost_usd"].is_null());
    assert!(out["card"]["return_pct"].is_null());
    assert_eq!(out["card"]["proceeds_or_value_usd"], 12.0);
    std::fs::remove_file(out["image_path"].as_str().unwrap()).unwrap();

    let mut records = tada_records();
    let key = format!(
        "gmgn:/v1/user/wallet_activity?chain=robinhood&wallet_address={TADA_WALLET}&token_address={TADA_TOKEN}&limit=50"
    );
    records.get_mut(&key).unwrap()["activities"]
        .as_array_mut()
        .unwrap()
        .retain(|r| r["tx_hash"] != TADA_BUY);
    let out = tada(&HooditApp::replaying(records));
    assert_eq!(out["status"], "ok", "{out}");
    assert!(out["card"]["cost_usd"].is_null());
    assert!(out["card"]["return_pct"].is_null());
    assert_eq!(out["card"]["proceeds_or_value_usd"], 4.667558);
    std::fs::remove_file(out["image_path"].as_str().unwrap()).unwrap();
}

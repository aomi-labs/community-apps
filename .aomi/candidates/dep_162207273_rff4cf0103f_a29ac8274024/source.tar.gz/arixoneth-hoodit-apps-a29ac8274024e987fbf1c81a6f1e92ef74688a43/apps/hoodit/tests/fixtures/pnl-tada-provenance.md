# TADA wallet settlement fixture

Public Robinhood Chain receipts, transactions and approval events were read
on 21 October 2026. The GMGN activity response was captured the same day.
The replay keys match Hoodit's provider boundary. No credentials are stored.

- Wallet: `0x032448a18a7c67daf1e6d27080a33e55335137ab`
- Token: `0x69f125ab4bba8f4a87f0d0a4a2eab739f5d1e1ad`
- [Buy](https://robin.etherscan.io/tx/0x6e8f9121da5d9c93c01d86267eb1c9efa008bd0c3b233dbc033c5ecbc946620d): 3 USDG out, 24,413.514952094774368542 TADA in.
- [Sale](https://robin.etherscan.io/tx/0x4f6a1a7d63a050fbeff5037f9ff80df77841303ec5aca0c888d74013efec0c50): full wallet holding out, 4.667558 USDG in.
- [Buy approval](https://robin.etherscan.io/tx/0xd96953d60cb4a424c3855ce61fcfe58dcec6ce61d49034e15dee752bc5e6fc24)
- [Sale approval](https://robin.etherscan.io/tx/0x89c940d137631d624b7f3a64bf12249a87ce01cdf7bf99d6839cf7cdd78ba1ff)

Expected difference: 1.667558 USDG, +55.5852667%, before ETH gas. The four
receipts charge 0.000023337432484 ETH. Dollar displays value USDG at $1 and
say so; no historical dollar conversion of gas is implied. Internal pool
and router deductions already occur before the final wallet receipt.

The intentionally conflicting GMGN pool values remain in the fixture:
sale `cost_usd=5.421617556705827`, prorated `buy_cost_usd=3.0079683380172484`.
They must never override the wallet settlement.

Related: [Hoodit #15](https://github.com/arixoneth/hoodit-apps/issues/15).

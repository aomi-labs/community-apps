use super::{address, run};
use crate::domain::find::{exact, is_dust, search};
use crate::domain::market::{known_symbol, lookalike, same_ends};
use crate::runtime::{Fail, HooditApp, Lane};
use aomi_sdk::schemars::JsonSchema;
use aomi_sdk::{DynAomiTool, DynToolCallCtx};
use serde::Deserialize;
use serde_json::{Value, json};

#[derive(Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct FindArgs {
    /// Ticker ("PRIORS", "$PRIORS"), name, or an exact 0x contract.
    pub query: String,
}

pub struct Find;

impl DynAomiTool for Find {
    type App = HooditApp;
    type Args = FindArgs;
    const NAME: &'static str = "hoodit_find";
    const DESCRIPTION: &'static str = "Resolve a memecoin or small coin's ticker, name or exact 0x contract on Robinhood Chain. A 0x address returns exactly that token or NOT_FOUND, never a substitute. A ticker returns candidate contracts, exact symbol matches first, then by liquidity, with KOL holder counts and honeypot flags; copies spoofing another candidate's address are hidden. USDG, WETH and stock tickers return the official contract first. Majors and listed tokens also resolve through the host's LI.FI tools.";

    fn run(app: &HooditApp, args: FindArgs, ctx: DynToolCallCtx) -> Result<Value, String> {
        run(app, &ctx, Lane::Chat, async |rt, turn| {
            let q = args.query.trim().trim_start_matches('$');
            if q.is_empty() || q.len() > 64 {
                return Err(Fail::Invalid("query must be 1–64 characters".into()));
            }
            if q.starts_with("0x") {
                let token = address(q)?;
                let exact = exact(rt, turn, &token).await?;
                return Ok(
                    json!({ "match": "exact_address", "token": crate::view::token::candidate(&exact) }),
                );
            }
            let official = known_symbol(q);
            let found = match search(rt, turn, q).await {
                Ok(found) => found,
                Err(_) if official.is_some() => vec![],
                Err(fail) => return Err(fail),
            };
            // Candidates come deepest liquidity first, so a spoof sits below
            // the contract it copies.
            let mut kept: Vec<crate::domain::find::Candidate> = vec![];
            let mut spoofs = 0;
            for c in found {
                let copies = lookalike(&c.token).is_some()
                    || kept.iter().any(|k| same_ends(&k.token, &c.token));
                if copies {
                    spoofs += 1;
                } else if Some(c.token.as_str()) != official.map(|o| o.0) {
                    kept.push(c);
                }
            }
            let found = kept;
            if let Some((token, symbol)) = official {
                let copies: Vec<Value> = found
                    .iter()
                    .filter(|c| !is_dust(c))
                    .take(2)
                    .map(crate::view::token::candidate)
                    .collect();
                return Ok(json!({
                    "query": q,
                    "official": { "symbol": symbol, "token": token },
                    "note": "the chain's own asset; other contracts with this ticker are unrelated copies",
                    "copies": copies,
                    "spoofed_addresses_hidden": spoofs,
                }));
            }
            if found.is_empty() {
                return Err(Fail::NotFound(
                    "no Robinhood Chain token matches that name".into(),
                ));
            }
            let same = found.iter().filter(|c| c.exact_symbol).count();
            let dust = found.iter().filter(|c| is_dust(c)).count();
            let shown: Vec<Value> = found
                .iter()
                .filter(|c| !is_dust(c))
                .take(5)
                .map(crate::view::token::candidate)
                .collect();
            Ok(json!({
                "query": q,
                "same_symbol_contracts": same,
                "dead_copies_hidden": dust,
                "spoofed_addresses_hidden": spoofs,
                "ranked_by": "exact symbol, then liquidity (not proof of the official contract)",
                "candidates": shown,
            }))
        })
    }
}

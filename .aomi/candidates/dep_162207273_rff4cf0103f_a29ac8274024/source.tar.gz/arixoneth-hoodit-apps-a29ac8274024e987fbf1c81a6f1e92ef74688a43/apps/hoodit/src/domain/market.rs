//! Robinhood Chain market vocabulary: pair tokens, launchpad names, a
//! coin's stage.
use crate::providers::chain::Chain;
use crate::providers::{NATIVE, WETH};
use serde::Serialize;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum PairKind {
    Eth,
    Usd,
    Stock,
    Other,
}

/// The token a coin trades against.
#[derive(Clone, Debug, PartialEq)]
pub struct Pair {
    pub symbol: String,
    pub kind: PairKind,
    pub decimals: u8,
}

/// Pair tokens Pons and other launchpads use. These are base assets, not
/// coins, and never belong on a board.
const PAIRS: &[(&str, &str, PairKind, u8)] = &[
    (NATIVE, "ETH", PairKind::Eth, 18),
    (WETH, "WETH", PairKind::Eth, 18),
    (
        "0x5fc5360d0400a0fd4f2af552add042d716f1d168",
        "USDG",
        PairKind::Usd,
        6,
    ),
    (
        "0xd0601ce157db5bdc3162bbac2a2c8af5320d9eec",
        "NVDA",
        PairKind::Stock,
        18,
    ),
    (
        "0x4a0e65a3eccec6dbe60ae065f2e7bb85fae35eea",
        "SPCX",
        PairKind::Stock,
        18,
    ),
    (
        "0xc9a981fee1f9dec688bb123ccdecc63d0debfc4e",
        "GLD",
        PairKind::Stock,
        18,
    ),
    (
        "0x1d11f0496982706c5e14a514d4e79f2e6bde4516",
        "DJT",
        PairKind::Stock,
        18,
    ),
    (
        "0x117cc2133c37b721f49de2a7a74833232b3b4c0c",
        "SPY",
        PairKind::Stock,
        18,
    ),
    (
        "0x322f0929c4625ed5bad873c95208d54e1c003b2d",
        "TSLA",
        PairKind::Stock,
        18,
    ),
    (
        "0x1b0e319c6a659f002271b69db8a7df2f911c153e",
        "GME",
        PairKind::Stock,
        18,
    ),
    (
        "0x2e0847e8910a9732eb3fb1bb4b70a580adad4fe3",
        "GOOGL",
        PairKind::Stock,
        18,
    ),
    (
        "0xd5f3879160bc7c32ebb4dc785f8a4f505888de68",
        "QQQ",
        PairKind::Stock,
        18,
    ),
    (
        "0xaf3d76f1834a1d425780943c99ea8a608f8a93f9",
        "AAPL",
        PairKind::Stock,
        18,
    ),
    (
        "0xe93237c50d904957cf27e7b1133b510c669c2e74",
        "MSFT",
        PairKind::Stock,
        18,
    ),
    (
        "0xc0d6457c16cc70d6790dd43521c899c87ce02f35",
        "META",
        PairKind::Stock,
        18,
    ),
    (
        "0x12f190a9f9d7d37a250758b26824b97ce941bf54",
        "AMZN",
        PairKind::Stock,
        18,
    ),
    (
        "0x86923f96303d656e4aa86d9d42d1e57ad2023fdc",
        "AMD",
        PairKind::Stock,
        18,
    ),
    (
        "0xff080c8ce2e5feadaca0da81314ae59d232d4afd",
        "MU",
        PairKind::Stock,
        18,
    ),
    (
        "0x894e1ec2d74ffe5aef8dc8a9e84686accb964f2a",
        "PLTR",
        PairKind::Stock,
        18,
    ),
];

pub fn known_pair(address: &str) -> Option<Pair> {
    let address = address.to_ascii_lowercase();
    PAIRS
        .iter()
        .find(|(a, ..)| *a == address)
        .map(|(_, symbol, kind, decimals)| Pair {
            symbol: symbol.to_string(),
            kind: *kind,
            decimals: *decimals,
        })
}

/// The base asset with this ticker (`USDG`, `WETH`, `NVDA`…), if any.
pub fn known_symbol(symbol: &str) -> Option<(&'static str, &'static str)> {
    PAIRS
        .iter()
        .find(|(a, s, ..)| s.eq_ignore_ascii_case(symbol) && *a != NATIVE)
        .map(|(a, s, ..)| (*a, *s))
}

/// Two different contracts with the same first and last four hex digits:
/// the newer one is almost always address poisoning.
pub fn same_ends(a: &str, b: &str) -> bool {
    let ends = |x: &str| {
        let x = x.to_ascii_lowercase();
        (
            x.get(2..6).map(str::to_string),
            x.get(x.len().saturating_sub(4)..).map(str::to_string),
        )
    };
    !a.eq_ignore_ascii_case(b) && ends(a) == ends(b)
}

/// The base asset this address imitates, if any.
pub fn lookalike(address: &str) -> Option<&'static str> {
    PAIRS
        .iter()
        .find(|(known, ..)| *known != NATIVE && same_ends(known, address))
        .map(|(_, s, ..)| *s)
}

/// Deployers of Robinhood's stock tokens (AAPL, MSFT, AMD; GME, AVGO).
const STOCK_DEPLOYERS: &[&str] = &[
    "0x5516b3451d4d6c9f63353fe7bc9537477ecce000",
    "0x2b94105fff37630f98e1f24811dad588fc5c3a87",
];

/// WETH, USDG and stock tokens: listed everywhere, never a pick.
pub fn is_base_asset(address: &str, creator: Option<&str>) -> bool {
    known_pair(address).is_some()
        || creator.is_some_and(|c| STOCK_DEPLOYERS.iter().any(|d| d.eq_ignore_ascii_case(c)))
}

/// Any pair token; unknown ones are read from chain and count as `other`.
pub async fn pair_of(chain: &Chain<'_>, address: &str) -> Option<Pair> {
    if let Some(pair) = known_pair(address) {
        return Some(pair);
    }
    let (decimals, symbol) = tokio::join!(chain.decimals(address), chain.symbol(address));
    Some(Pair {
        symbol: symbol.unwrap_or_else(|_| "?".into()),
        kind: PairKind::Other,
        decimals: decimals.ok()?,
    })
}

/// One spelling per launchpad, whichever source named it: GMGN's
/// `pons_v2`, `longxyz`, `o1_rwa` and Codex's `Clanker V4`, `bow.fun`.
/// Plain DEX pools (`pool_uniswap_v4`, `pools_trade_cca`) aren't launchpads.
pub fn launchpad(raw: Option<&str>) -> Option<String> {
    let raw = raw?.trim().to_ascii_lowercase();
    if raw.is_empty() || raw.starts_with("pool") {
        return None;
    }
    let flat: String = raw.chars().filter(|c| c.is_ascii_alphanumeric()).collect();
    let name = match flat.as_str() {
        "ponsv2" | "pons" => "pons",
        "longxyz" | "long" => "long",
        "o1rwa" | "o1exchange" | "o1" => "o1",
        "noxafi" | "noxafun" | "noxa" => "noxa",
        "flappve" | "flap" => "flap",
        "clankerv4" | "clanker" => "clanker",
        "bowfun" | "bow" => "bow.fun",
        "hoodfun" => "hood.fun",
        "feelcash" => "feel.cash",
        "sushilaunch" | "sushi" => "sushi",
        "uniswapcca" => "uniswap_cca",
        other => return Some(other.to_string()),
    };
    Some(name.to_string())
}

/// Where a coin is in its life.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum Stage {
    /// On a launchpad bonding curve.
    Curve,
    /// The curve is being swept into a pool; not tradeable for a moment.
    Graduating,
    /// Graduated from a curve to a pool.
    Graduated,
    /// The launch failed and its funds were rescued.
    Rescued,
    /// Launched straight into a pool, no launchpad.
    Pool,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn spoofed_base_assets_are_caught() {
        assert_eq!(
            known_symbol("usdg").map(|k| k.0),
            Some("0x5fc5360d0400a0fd4f2af552add042d716f1d168")
        );
        assert_eq!(
            lookalike("0x5fc591225f1f20c08c3c59fe25826f6a36e1d168"),
            Some("USDG")
        );
        assert_eq!(
            lookalike("0x5fc5360d0400a0fd4f2af552add042d716f1d168"),
            None
        );
        assert_eq!(
            lookalike("0x44318785554bf11ffd164a6f98d9a453e2fa74af"),
            None
        );
    }

    #[test]
    fn launchpads_have_one_spelling() {
        assert_eq!(launchpad(Some("pons_v2")).as_deref(), Some("pons"));
        assert_eq!(launchpad(Some("pons")).as_deref(), Some("pons"));
        assert_eq!(launchpad(Some("Clanker V4")).as_deref(), Some("clanker"));
        assert_eq!(launchpad(Some("bow.fun")).as_deref(), Some("bow.fun"));
        assert_eq!(launchpad(Some("pool_uniswap_v4")), None);
        assert_eq!(launchpad(Some("pools_trade_cca")), None);
        assert_eq!(launchpad(Some("")), None);
    }

    #[test]
    fn base_assets_are_known() {
        let usdg = known_pair("0x5FC5360D0400A0FD4F2AF552ADD042D716F1D168").unwrap();
        assert_eq!((usdg.kind, usdg.decimals), (PairKind::Usd, 6));
        assert!(is_base_asset(WETH, None));
        assert!(is_base_asset(
            "0xaf3d76f1834a1d425780943c99ea8a608f8a93f9",
            Some(STOCK_DEPLOYERS[0])
        ));
        assert!(!is_base_asset(
            "0x1111111111111111111111111111111111111111",
            None
        ));
    }
}

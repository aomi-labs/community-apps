# Daiko pilot acceptance

## Verified 2026-11-06

- Community Project 1675 belongs to aomi-labs/daiko-bot under Cecilia's builder account.
- App 2937821 activated, artifact-ready and runtime-loaded on staging.
- SDK 7.0.0 and exact Dottie managed Solana wallet manifest accepted by manager preflight.
- Hosted no-tool chat completed with a nonempty assistant response.
- Hosted exact-mint token check returned DEX Screener, Jupiter and RugCheck results and source timestamps.
- Hosted unconfigured-X query honestly reported unavailable, without invented posts or sentiment.
- Twitter key and provider account id saved in 1Password; app-vault presence verified; a fresh hosted X call returned attributed post links.
- ScrapeCreators key saved in 1Password and app-vault presence verified.
- Real TikTok API request succeeded. Compact local tool output: 10 unique videos with links, about 7 KB versus about 2 MB raw vendor data. Hosted verification follows the compacting release.
- Relay launched persistent Chromium and returned authenticated health with login_required; anonymous thesis requests returned no invented data.
- Seven Rust tests and three relay tests pass, including strict manifest schemas, exact mint validation, cache freshness, request guards, credential-scope isolation, TikTok output bounds/deduplication and unavailable-session semantics.

## Still required before group launch

- Dedicated fomo profile signed in, authenticated thesis read, persistent hosted relay URL and restart/re-auth verification. Existing personal-browser fomo access alone does not establish relay availability.
- Solana Tracker key and one token-specific KOL read; trending must distinguish its official ranking from the paid-boost fallback.
- Telegram bot registration through the shared Aomi host, exact application binding, /start wallet provisioning matching Dottie, and a real group mention/reply test. App deployment alone is not proof of a working Telegram front door.
- Pilot group verifies reply length, Japanese/English handling, exact-address identity, source links and no unsolicited trading.

No trade, signature, broadcast or funding was performed during research acceptance. Optional credentials are not a reason to fabricate unavailable evidence. Trial quotas and prepaid vendor balances remain the account-level spend bound; per-process guards are not a fleetwide dollar cap.
